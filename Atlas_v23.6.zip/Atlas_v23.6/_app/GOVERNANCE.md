# Governança do projeto

O Atlas — Suporte Avançado é administrado conjuntamente por:

- João Cerqueira — **@joaocerq-me**;
- Alexandre Linhares — **@alemagnobr**.

## Responsabilidades

Os mantenedores podem organizar issues, revisar Pull Requests, preparar versões e aprovar alterações. Mudanças em autenticação, scripts PowerShell, Active Directory, impressão ou comandos administrativos devem receber revisão de outro mantenedor.

## Fluxo de decisão

1. alterações comuns são propostas por issue ou Pull Request;
2. o autor descreve o objetivo e a validação realizada;
3. outro mantenedor revisa código, impacto e segurança;
4. depois da aprovação, a alteração é integrada à branch `main`;
5. mudanças de comportamento são registradas no `CHANGELOG.md`.

Em caso de dúvida operacional ou de segurança, prevalece a alternativa de menor risco até validação conjunta.
