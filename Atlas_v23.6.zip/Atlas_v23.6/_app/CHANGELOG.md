# v23.6 — Cadeado Admin local visível

- O cadeado do cartão Admin local não usa mais um efeito gráfico aninhado que o ocultava no Windows. Seu glifo e indicador apresentam pulso suave verde ou vermelho, como no painel de impressoras.
- Revisados os fluxos de cancelamento, sincronização somente da estação, ping sem resposta e os botões remotos adicionados na v23.5.
- Corrigido o glifo Abrir chamado, que recorria ao ícone genérico de informação por falta do desenho correspondente.

# v23.5 — Controles da estação e cancelamento

- Consulta da estação pode ser cancelada pelo X; ao cancelar, o painel anterior é restaurado. Nome lógico não encontrado encerra a consulta antes das rotinas WMI.
- Atualização do cabeçalho recarrega apenas Estação conectada; copiar micro aparece junto ao nome; ping permanece disponível sem resposta ICMP.
- Cards Windows e Dados (D:) ganham atalhos existentes de logoff, reinício e limpeza TEMP, com confirmação. Discos e Perfis e o cadeado Admin exibem animação de atividade.

# v23.4 — Favoritos e monitorados nos chamados recentes do usuário

- A janela dos até 25 chamados do usuário permite marcar e desmarcar favoritos e monitorados diretamente nos cartões.
- Apenas o chamado escolhido é preservado nas listas pessoais; o restante da consulta continua temporário.
- A conferência pontual no Capri atualiza também os estados dos chamados salvos fora do catálogo mapeado.

# v23.3 — Histórico de templates mais legível

- Cada atendimento apresenta data e hora no histórico e na prévia.
- A prévia mostra o texto em seções legíveis, sem tentar carregar as imagens externas; “Copiar HTML” mantém o código original completo.
- Botões de copiar e fechar têm tamanho equilibrado, e a confirmação para limpar o histórico é compacta e em português.

# v23.2 — Relógio proporcional no cabeçalho dos templates

- O botão de histórico recebeu os mesmos limites de altura e largura do X (30 × 30 px) e o desenho do relógio foi reduzido para 18 × 18 px.

# v23.1 — Histórico de templates e ajustes visuais

## Histórico diário de templates e grupo do AD

- O grupo de AD `WEB_Libera_Chat` exibe “Acesso ao WhatsApp Web” em Membro de.
- O relógio ao lado do fechamento de Meus templates abre os HTMLs copiados no dia atual, inclusive de templates salvos. Cada item pode ser consultado e copiado novamente.
- “Limpar atendimentos de hoje” remove o arquivo do histórico local após confirmação, sem excluir os modelos salvos.

## Ajuste visual

- Atalhos de favoritos e monitorados ao lado de Chamados e FAQs mais compactos.
- Situação de cada chamado salva no catálogo local destacada nas listas de favoritos e monitorados, com atualização visual após a conferência no Capri.
- Botões de favoritar, monitorar, copiar e abrir chamados com tamanho e espaçamento uniformes.

# v23 — Favoritos, monitoramento e licenças do AD

- Listas locais de chamados favoritos e monitorados, com busca e conferência pontual da situação no Capri.
- Cards de licenças do AD reorganizados, incluindo Lic-ADP1 e a política de uso informada.
- Base funcional v22.4 preservada.

# v22.4 — Busca de favoritos e período local dos chamados

- O painel de FAQs favoritas ganhou uma busca por número e título, sem exigir acentos.
- A estrela de acesso aos favoritos foi reduzida e recebeu contorno mais discreto; as estrelas dos cards e do popup também foram ajustadas.
- Na Central de chamados, o botão com ícone de período ao lado de Filtrar abre datas de início e fim para consultar somente o cache local. A ação Mostrar todos limpa esse período sem consultar o Capri. O botão com calendário continua reservado ao mapeamento.

# v22.3 — Edição dos modelos e ações rápidas nas FAQs favoritas

- Templates salvos têm botão de edição ao lado de excluir. A atualização mantém o mesmo registro e nome, sem criar cópia; modelos antigos de fechamento recuperam os campos do HTML, e modelos sem campos salvos permitem editar o código existente.
- Textos colados nos campos dos templates perdem formatação rica, mantendo somente caracteres e quebras de linha.
- A lista de FAQs favoritas oferece copiar o número e gerenciar/criar orientações pelo mesmo fluxo dos cards do catálogo.

# v22.2 — Busca de templates e FAQs favoritas

- Templates salvos ganham busca por nome, inclusive sem acentos.
- A estrela ao lado de FAQs abre a lista pessoal; cada FAQ pode ser favoritada ou removida. Favoritos ficam separados do catálogo do Capri.
- O ícone de avaliação foi trocado por um balão de feedback com marca de confirmação.
- Finalizar um template copia diretamente o HTML, sem abrir uma revisão externa.

# v22.1 — Cartões lado a lado na tela ampla

- A estação conectada aparece à esquerda, e as informações do usuário à direita.
- Os cartões usam a altura do próprio conteúdo, sem o espaço vertical vazio da estação.
- O modo lateral preserva as abas e o comportamento anterior.

# v22.0 — Exibição persistente e templates reutilizáveis

- O modo amplo fica salvo entre reinícios e troca de sessão; o modo lateral retorna apenas pela seta.
- Em tela ampla, os cartões da estação e do usuário aparecem juntos.
- Seleções dos templates exibem opções com check, e Tab avança entre campos de texto.
- Templates salvos são agrupados em Fechamento e Escalonamento. Os modelos de escalonamento reabrem com o conteúdo salvo e localização pendente para cada chamado.

# v21.2 — Reconferência de estados no Capri

- O botão Atualizar continua mapeando apenas ontem e hoje, mas confere diretamente pelo número todos os chamados abertos e pendentes já salvos.
- Se a página do chamado não expuser o estado, tenta o CSV e a grade HTML da pesquisa pontual. A leitura de linhas do CSV foi corrigida.
- O log identifica os números cujo estado não foi confirmado; nesses casos, o cache preserva o valor anterior.

# v21.1 — Atualização de estados e template de rede

- A janela de apoio técnico mostra "Micro" para a estação solicitante.
- Atualizar reconfere pelo número os chamados locais ainda marcados como abertos ou pendentes; corrige somente estados confirmados no Capri.
- Meus Templates inclui "Estação sem Rede/Internet" com checklist, localização, assinatura do AD, cópia HTML e salvamento pessoal.

# v21.0 — Escolha excepcional de escalonamento

- A escala regular permanece como na v20.20.
- Um link abre a escolha manual entre liderança e as duas supervisões quando os horários tiverem mudado, com confirmação antes do envio.
- A mensagem remota identifica a estação solicitante como "PA"; mantém a duração da v20.20.

# v21.0 — Micro de origem no apoio técnico

- A mensagem de escalonamento exibe o nome do micro que está executando o ATLAS, junto ao nome do analista.

# v21.0 — Escalonamento imediato pela escala

- O painel habilita os destinos pelos horários de Brasília, sem consulta prévia ao usuário logado.
- A ordem líder e supervisão continua vigente; supervisão durante o turno do líder exige contato prévio e motivo.
- No envio, uma sessão ativa ainda é necessária para entregar a janela remota, sem comparar o usuário logado com uma identidade pré-consultada.

# v21.0 — Janela de escalonamento persistente

- A janela permanece aberta durante a verificação de disponibilidade e ao alternar o foco.
- Corrigida a animação de abertura para evitar falhas de pintura.

# v21.0 — Escalonamento de apoio técnico

- Ícone de alerta ao lado da sessão INS abre o painel de escalonamento com transição suave.
- Ao abrir ou atualizar, a consulta remota verifica usuário logado e confirma seu nome no AD antes de liberar o destino; o horário é avaliado em Brasília, incluindo os intervalos de almoço informados.
- O líder tem prioridade. A supervisão é liberada se ele não estiver disponível ou após confirmação de contato e registro do motivo específico.
- A mensagem vermelha utiliza a mesma tarefa interativa das orientações, confere o login de novo no momento do envio e informa apenas o despacho, sem afirmar que a mensagem foi lida.

# v20.16 — Altura do botão Salvar template

- A altura específica do botão Salvar template foi alinhada à do botão de copiar nos temas claro e escuro, sem alterar o comportamento do formulário.

# v20.15 — Botão de salvar com rótulo responsivo

- O botão de salvar no editor de templates mostra ícone e texto legíveis, com área de clique maior.
- Em painéis estreitos, os rótulos de salvar e copiar encurtam para manter as duas ações totalmente visíveis.

# v20.14 — Painel de templates flutuante

- Menu mais compacto com cartões hierarquizados, contorno suave e sombra nos modos claro e escuro.
- Editor mostra uma barra de rolagem evidente, aviso de mais campos e rodapé fixo; o foco leva o campo selecionado para a área visível.
- A janela permanece aberta ao perder o foco. Fechar ou pressionar Esc apenas oculta o painel; ao reabrir, o modelo e os dados digitados continuam disponíveis.

# v20.13 — Templates salvos e novos checklists

- O painel Meus templates abre à direita da lateral e usa a altura disponível da tela, com rolagem nos formulários longos.
- Verificação Wi-Fi e Instalação padrão seguem os blocos HTML enviados, com campos editáveis e opções marcadas como `(X)`.
- O ícone de salvar guarda o HTML preenchido com um nome no perfil do operador; Templates salvos copia o HTML com um clique e permite excluir entradas.

# v20.12 — Meus templates e revisão de integridade

- A lateral ganhou um painel flutuante de templates com formulários de Fechamento e Escalonamento; a conclusão copia o código-fonte HTML para colar no Capri.
- A assinatura usa o nome completo e o cargo do operador consultados no AD. Texto digitado é escapado antes de gerar HTML, preservando parágrafos e as imagens indicadas nos modelos.
- Localização de escalonamento aceita os cinco campos e escolhas exclusivas de situação do setor e local, marcadas como `(X)` no resultado.
- A verificação do pacote confirmou ausência de arquivos de execução duplicados; caches Python gerados foram removidos da distribuição e os contratos de versão foram alinhados.

# v20.11 — Processos por memória e permissão em uma linha

- Os grupos de processos do usuário são exibidos pelo total de memória decrescente, e as instâncias de cada software também seguem a memória decrescente.
- A indicação de impressão colorida permanece em uma linha, seguida imediatamente pelo ícone da FAQ.

# v20.10 — Permissão para impressão colorida

- O card de impressoras da estação mostra a permissão de impressão colorida do usuário conectado após a consulta do AD: departamento GABSEN ou grupo ImpressaoColorida.
- Um ícone de informação no card abre a FAQ 1007 sobre as impressoras com contrato no Capri.
- Durante a leitura do AD e quando não há usuário conectado, o card não presume autorização.

# v20.9 — Login em tela cheia e Links úteis

- Em janelas largas, a apresentação e o formulário de login ocupam colunas lado a lado, e o formulário tem largura controlada.
- Na lateral, Links úteis abre um painel flutuante rolável sem deslocar a logo, a navegação ou os controles inferiores.

# v20.8 — Links úteis na lateral

- O painel aberto usa apenas o espaço disponível após reservar a marca, navegação e controles inferiores.
- A lista mantém rolagem para muitos links e já não comprime a logo e a palavra ATLAS ao expandir.

# v20.7 — Espaçamento da marca ATLAS

- A letra S e suas descargas foram aproximadas discretamente do A nos títulos da entrada e da lateral, sem alterar a animação.

# v20.6 — Refinamento da letra elétrica

- O S usa traços tipográficos mais finos e um brilho de contorno menos espesso.
- Descargas assimétricas e curtas acompanham a letra, alternando seus clarões sem ultrapassar o espaço da marca.
- A animação contínua e a ausência da bolinha móvel foram preservadas.

# v20.5 — Ajuste do S e dos raios

- A letra S da marca foi discretamente reduzida sem alterar o encaixe da palavra.
- Seis ramificações elétricas passam atrás da letra com brilho contínuo mais visível nos dois cabeçalhos.
- O ponto luminoso que se deslocava pelo contorno foi removido.

# v20.4 — S elétrico redesenhado

- A letra S da marca passa a usar uma forma serifada consistente com a referência enviada, preenchida e legível durante toda a execução.
- Luz percorre continuamente o contorno com pequenas ramificações alternadas; a animação pausa quando a marca está oculta.
- ATLA usa a mesma família tipográfica do S para unir visualmente a palavra nos cabeçalhos.

# v20.3 — Marca ATLAS com S elétrico

- A lateral exibe a logo maior, centralizada acima de ATLAS; o S da palavra substitui o raio solitário, permanece legível e recebe o clarão nos intervalos já usados.
- O título grande da entrada também integra o S elétrico à palavra, mantendo os textos e fluxos de autenticação.
- O ícone Windows aproveita mais da área de cada resolução, com a figura do Atlas e o símbolo do Senado mais evidentes.

# v20.2 — Proporção e cores da marca

- Logo ampliada na entrada compacta e na apresentação lateral da tela de login, preservando a proporção e os monitores menores.
- Marca compacta ampliada no menu logado com ajuste de espaçamento para caber ao lado de ATLAS e do raio.
- Fundos e detalhes de navegação receberam tons de azul e ciano da nova arte nos modos claro e escuro; o verde permanece nas ações e nos estados funcionais.

# v20.1 — Logo do usuário nos dois temas

- Nova arte baseada na imagem fornecida: Atlas em azul sustentando o símbolo do Senado e arco com os ícones de usuário, suporte e confirmação mais espaçados.
- Versões transparentes com contraste específico para os temas claro e escuro; a marca da tela inicial também acompanha a troca de tema.
- Ícone compacto e os recursos do lançador portátil atualizados a partir da mesma identidade. As demais funções da v20.0 permanecem intactas.

# v20.0 — Nova identidade visual do ATLAS

- Logo em relevo azul com Atlas sustentando o símbolo do Senado e a conexão com o suporte ao usuário; contornos com reflexos discretos, preservando a leitura em fundo claro e escuro.
- Marca em destaque na tela de login e versão compacta ao lado do nome ATLAS e do raio animado na barra lateral.
- Ícone portátil e do instalador atualizado em múltiplas resoluções. A captura, as mensagens e as demais funções da v19.2 permanecem intactas.

# v19.2 — Preview e editor da captura

- Após a seleção validada de tela, o QImage abre no preview com proporção preservada. A seleção de monitores, DPI e ESC permanece na implementação recebida.
- Ferramentas: seleção, caneta, seta, retângulo, elipse, texto, destaque, cor, espessura, tamanho e negrito. A edição mostra a marcação durante o arraste e mantém histórico de desfazer e refazer.
- O caminho inicial respeita a pasta configurada; Alterar permite escolher nome, pasta e PNG/JPG/BMP. Salvar incorpora as marcações em uma imagem normal e só fecha após gravação confirmada. Cancelar descarta com confirmação quando há edições.

# v18.4 — Processos agrupados e cards legíveis

- No suporte remoto, os cards habilitados mostram títulos brancos e descrições claras no tema escuro; os desabilitados permanecem cinza.
- A lista de processos agrupa por software e permite selecionar um PID ou encerrar somente os PIDs exibidos naquele grupo, após confirmação e revalidação na estação.
- As listas de processos e programas possuem colunas, agrupamento e botão de nova consulta; programas são separados por perfil e arquitetura da estação.
- O módulo remoto é lido em UTF-8 no PowerShell 5.1, preservando acentos como “Estação”.

# v18.3 — Cargo do AD e refinamento da lateral

- A avaliação usa rótulos curtos para abrir Outlook Web e Desktop e assina com o cargo do operador obtido do atributo title do AD, omitindo “Terceirizado”.
- Os atalhos laterais de acesso remoto e perfil no AD recebem destaque sutil quando habilitados; continuam cinza sem estação ou usuário.
- A seta do modo lateral acompanha a velocidade da tela de login, sem ponta duplicada, enquanto a caixa flutua com uma transparência suave.

# v18.2 — Avaliação remota pela rota interativa da v17

- A mensagem volta a ser enviada diretamente à sessão pela tarefa interativa validada na v17, sem o lançador WSH que falhava com código 1.
- O próprio processo oculta seu console e exibe somente a janela visual; avaliação permanece por três minutos e as orientações por dez minutos.
- A avaliação usa o nome do usuário da consulta do AD e a assinatura com o nome completo do operador do AD e cargo, com o novo texto solicitado.
- O resultado confirma apenas o despacho da tarefa; a abertura e a leitura pelo usuário não podem ser verificadas remotamente nesta rota.

# v18.1 — Mensagem remota e acesso a Discos e perfis

- A janela de avaliação e orientação confirma sua renderização na sessão remota; a leitura pelo usuário continua fora do alcance da confirmação técnica.
- Erros do PowerShell preservam sua causa no resultado mostrado ao operador, sem o ruído do `Write-Error` do lançador.
- O card Espaço Dados (D:) abre Discos e perfis pelo próprio ícone e acompanha o estado da conexão.
- O fluxo remove uma espera fixa e simplifica a verificação remota, sem alterar os tempos de leitura das mensagens.

# v18 — Diagnóstico remoto e orientação persistente

- A mensagem visual de orientação fica na tarefa interativa enquanto a janela estiver aberta; o envio só é aceito quando o processo ainda está ativo após a abertura. Erros imediatos são reportados ao operador.
- A lateral recupera acesso SCCM, informações do usuário no AD e o cadeado de Admin local com estado colorido. Atalhos dependentes da estação ou do usuário ficam desabilitados até a conexão necessária.
- Processos da sessão do usuário podem ser consultados e encerrados individualmente após confirmação; programas registrados no perfil e na estação são listados sem cache.
- Excluir impressora volta aos cards de Impressoras, com seleção, confirmação, progresso e atualização dos dois resumos.

# v17.2 — Orientação permanece visível na estação

- A janela gráfica passa a ser executada diretamente pela tarefa interativa, que continua ativa enquanto o usuário lê a mensagem.
- O preparo da janela é confirmado antes da abertura; o Atlas também verifica se o processo gráfico continua em execução.
- O botão Fechar e os limites de dez minutos para orientações e três minutos para avaliação continuam controlando o encerramento.
- O lançador gráfico preserva a ausência de um prompt permanente atrás da mensagem.

# v17.1 — Mensagens remotas em uma janela visual

- A avaliação, as orientações de FAQ e a mensagem livre usam a mesma janela escura na sessão remota.
- O iniciador gráfico encerra o processo de console curto após abrir a janela, evitando o prompt permanente atrás da mensagem.
- A avaliação permanece por três minutos; as orientações preservam dez minutos e seus campos de orientação, caminho e contato.
- O usuário conectado é conferido novamente na estação antes do envio para evitar destinatário incorreto.

# v17 — Chamados em segundo plano e avaliação do atendimento

- Os chamados recentes do Capri atualizam seu próprio card sem prolongar o progresso do AD ou da estação.
- A aba Membro de explica as licenças Lic- cadastradas, preservando o código exato do grupo.
- O cartão da estação oferece uma solicitação de avaliação ao usuário remoto por três minutos, com botões para Outlook Web e Desktop e assinatura do operador.
- Instalação, definição de padrão e página de teste usam somente o popup para o progresso e sincronizam nele os resumos das impressoras.
- O pacote portátil e os metadados de instalação usam a versão 17.

# v16 — Cópia seletiva e progresso remoto confiável

- Os cards Nome completo e Empresa copiam título e valor ao clique, preservando os botões de ação e a cópia isolada do login.
- As ações de suporte remoto mostram progresso no próprio card; 100% exige confirmação do processo, e tarefas apenas enviadas permanecem parciais.
- As consultas da estação e do usuário reservam 100% para dados carregados e confirmados; falhas permanecem parciais e a conclusão fica visível por um instante.
- A abertura evita uma checagem duplicada do Python, reduz a espera visual de impressoras e responde mais rápido ao liberar as consultas em fila.
- Esta versão retoma a base v15.21; as alterações de marca da v15.22 foram descartadas.

# v15.21 — Consultas e cópia seletiva

- Os cards escolhidos no Controle de usuários copiam título e descrição; os demais não copiam ao clicar.
- Progresso de usuário e estação só alcança 100% após confirmação do AD e dos chamados do Capri; falhas mantêm percentual parcial.
- Resultados estruturados do Capri deixam de ser renderizados no console visual; os dados seguem completos para a consulta.
- Documentação descreve assinatura necessária para identificar o editor no SmartScreen.

# v15.20 — Lançador com a logo realmente incorporada

- Substitui o atalho externo por `Atlas.exe`, evitando o ícone branco genérico do Windows.
- Incorpora diretamente no executável as imagens de 16, 32 e 48 pixels da logo do Atlas.
- Mantém somente `Atlas.exe` e a pasta `_app` na entrada do pacote.
- O lançador localiza `_app\run.bat` relativamente, preservando a portabilidade.

# v15.19 — Atalho do Atlas com ícone institucional

- Substitui o lançador externo em lote por `Atlas.lnk`, exibido com o escudo do aplicativo.
- O atalho aponta de forma relativa para `_app\run.bat`, preservando a portabilidade da pasta.
- O arquivo de ícone permanece protegido dentro de `_app\assets`.
- A ferramenta de geração do atalho fica registrada no projeto para futuras versões.

# v15.18 — Pacote externo limpo e estrutura interna organizada

- Mantém somente `Executar Atlas.bat` como lançador na entrada do pacote.
- Agrupa código, recursos, testes e documentação dentro da pasta `_app`.
- O lançador usa caminho relativo e continua funcionando após mover ou renomear a pasta principal.
- Cache, sessões, preferências e chamados continuam preservados em `%LOCALAPPDATA%`.

# v15.17 — Refinamento do status e da empresa

- O status ativo da conta passa a ser destacado em verde nos temas claro e escuro.
- Nomes de empresa integralmente em caixa alta recebem capitalização visual mais elegante.
- O valor original recebido do Active Directory permanece intacto; a mudança é somente de apresentação.

# v15.16 — Navegador escolhido aplicado a todos os links

- Chrome, Edge ou o padrão do Windows passam a ser respeitados em todos os links do Atlas.
- O PWM usa a mesma preferência nos links comuns, na captura de sessão e no perfil exclusivo.
- A preferência é transportada e sincronizada entre a conta padrão e a sessão INS.
- Chrome e Edge também são localizados pelo PATH e pelo registro App Paths do Windows.
- O Atlas deixa de trocar silenciosamente para o Edge quando o navegador escolhido não é encontrado.

# v15.15 — Atualização direta das informações do usuário

- Inclui um botão de atualização ao lado do título “Informações do usuário”.
- O botão repete a consulta do usuário exibido, ignorando o cache temporário do AD.
- A atualização renova também a prévia dos chamados recentes do usuário.
- Durante a consulta, o ícone gira e fica bloqueado para evitar execuções duplicadas.

# v15.14 — Informações copiáveis no painel de usuário

- Todos os cartões informativos do painel de usuário passam a copiar seu valor ao clique.
- Nome completo e login de rede também podem ser copiados clicando no próprio cartão.
- A confirmação discreta “Informação copiada” aparece junto ao cartão acionado.
- Os controles de AD, PWM, recuperação por e-mail e chamados preservam suas ações originais.

# v15.13 — Refinamento visual do painel de usuário

- Aumenta contraste, respiro e hierarquia dos cards de informações.
- Suaviza a borda verde externa e equilibra o fundo do painel no tema escuro.
- Amplia os controles de identidade, senha e chamados sem alterar suas ações.
- Renomeia o resumo final para “Chamados recentes de [nome]”.

# v15.12 — Perfil operacional reorganizado

- Exibe o Script de logon do Active Directory ao lado do e-mail institucional.
- Coloca o estado de senha expirada ao lado do vencimento da senha.
- Mantém a recuperação de senha e o acesso ao PWM no card de estado.

# v15.11 — Progresso contínuo sobre a base v15.8

- Reconstruída diretamente a partir do pacote v15.8 fornecido.
- Mantém uma única barra durante micro, detalhes remotos, Active Directory e chamados.
- Atualiza a porcentagem somente conforme cada etapa é confirmada.
- Conclui em 100% também em resultados parciais, informando a indisponibilidade.
- Não inclui a janela nem o redirecionamento para instalação ou atualização do Python.

# v15.8 — Links úteis em altura total e impulso lateral

- Faz o painel Links úteis ocupar dinamicamente todo o vão até os controles inferiores da lateral.
- Remove o antigo limite de altura da lista e mantém rolagem interna somente quando os atalhos excederem o espaço disponível.
- Substitui a seta que desaparecia por uma seta dupla com impulso suave, rastro discreto e borda pulsante.

# v15.7 — Rodapé das páginas e lateral ampliada

- Move os créditos de desenvolvimento da lateral para o rodapé final da área de conteúdo, mantendo os perfis clicáveis.
- Remove o atalho da ferramenta legada e posiciona o modo lateral em seu lugar, com acabamento quadrado e animação reforçada.
- Amplia dinamicamente o painel de Links úteis até o espaço disponível, preservando os controles inferiores.

# v15.6 — Membros do grupo RDP e espaço da unidade D:

- O card Usuários da área de trabalho remota apresenta as contas realmente cadastradas no grupo local da estação, independentemente do usuário conectado.
- O card Espaço Dados (D:) apresenta espaço livre e tamanho total obtidos pelo Win32_LogicalDisk.
- A unidade ausente ou inacessível é indicada sem apresentar um valor incorreto.

# v15.5 — Grupo RDP e posição do TTL

- O card consulta a associação do usuário conectado ao grupo local Usuários da área de trabalho remota, considerando domínio e login.
- O TTL fica abaixo dos botões de ping e acesso remoto no card Micro.

# v15.4 — Links úteis na lateral

- Mantém a lixeira visível para cada atalho, inclusive quando o nome é longo.
- Limita a altura da lista e ativa rolagem quando os links excedem o espaço.
- Permite que a lista ceda espaço à seta do modo lateral e ao rodapé.

# v15.3 — Indicador de ping no card Micro

- Resultado TTL ou tempo limite em cor fixa, sem animação.
- Indicador posicionado imediatamente ao lado do nome lógico da estação.

# v15.2 — TTL real no card Micro

- Extrai o TTL exibido pelo ping.exe do Windows, com segunda leitura se a resposta não trouxer TTL.
- Exibe TTL=valor ou Tempo de limite perdido com desvanecimento lento nas cores solicitadas; elimina Ping OK.
- Atualiza o versionamento para 15.2.

# v15.1 — Ping no card Micro e ajustes visuais

- Exibe TTL do ping inicial diretamente no card Micro, animado em verde para 123/126, amarelo para 250/253 e vermelho quando não há resposta.
- Adapta o conteúdo rolável de Links úteis à lateral escura e alinha os três atalhos às margens dos botões Capri e INS.
- Atualiza o versionamento para 15.1.

# v15.0 — Links úteis editáveis

- Permite adicionar atalhos com nome e endereço, excluir entradas com confirmação e manter as mudanças entre sessões.
- Preserva os cinco links padrão na primeira execução e limita a altura da lista para proteger o rodapé.
- Atualiza o versionamento para 15.0.

# v14.60 — Ícones da lateral

- Centraliza os três botões do rodapé em espaços independentes de 44 × 34 px.
- Corrige a altura imposta pelo estilo global para evitar cortes e redesenha o ícone Windows + L.
- Atualiza o versionamento para 14.60.

# v14.59 — Atalhos e links na lateral

- Move o atalho AD para Nome completo; acesso remoto permanece no card Micro; Windows + L passa ao rodapé junto de Legada e Configurações.
- Reorganiza os seis atalhos restantes e inclui Links úteis com abertura animada.
- Atualiza o versionamento para 14.59.

# v14.58 — Atalhos no card Micro

- Adiciona ping contínuo e acesso remoto SCCM ao card Micro da estação conectada.
- Remove ping contínuo da lista de Suporte remoto e mantém a ação de acesso remoto já existente.
- Atualiza o versionamento para 14.58.

# v14.57 — Acrônimo abaixo das boas-vindas

- Exibe “Assistência Técnica e Lógica de Apoio ao Senado” imediatamente abaixo de “Bem-vindo ao Atlas” na tela de login.
- Atualiza o versionamento para 14.57.

# v14.56 — Identidade do login e fechamento confirmado do Outlook

- Atualiza o título superior da tela de acesso para “ATLAS — Assistência Técnica e Lógica de Apoio ao Senado”.
- Altera a frase de apresentação e reduz a assinatura inferior a “Atlas” com a versão.
- Consulta os processos do Outlook na estação, tenta encerrar os executáveis encontrados e confirma pela consulta remota antes de informar sucesso; a ausência de `olk.exe` não gera falha quando o Outlook já fechou.
- Atualiza versão, caminhos e metadados do instalador para 14.56.

# v14.52 — Ordem cronológica dos chamados do usuário

- A prévia dos chamados do usuário é ordenada explicitamente do mais recente para o mais antigo e limitada aos 25 primeiros.
- Usa a data de criação retornada pelo Capri e, quando a grade não fornece essa coluna, a data codificada no número do chamado como critério de ordenação.
- Atualiza metadados e caminhos de instalação para a versão 14.52.

# v14.51 — Leitura mais robusta das linhas do Capri

- Localiza o link do chamado entre todos os links da linha da tabela, sem presumir que o primeiro já seja o link de detalhes.
- Reforça a correspondência pelo nome completo usando também o texto integral retornado na linha, cobrindo casos de truncamento/índice de coluna da grade.
- Mantém a busca pelo nome completo no Capri, o limite de 25 chamados mais recentes, a deduplicação e a prévia sem cache persistente.
- Atualiza metadados e caminhos de instalação para a versão 14.51.

# v14.50 — Correspondência pelo usuário cliente e título no Capri

- A prévia usa o nome completo do Active Directory e mantém somente chamados em que “Nome do usuário cliente” corresponde exatamente ao usuário ou o título contém o nome completo.
- Quando disponível, usa o título integral do link do Capri para evitar falsos negativos causados por título truncado na tabela.
- Remove duplicados e preserva o limite de até 25 chamados recentes correspondentes; os resultados continuam temporários e não entram no cache da Central de Chamados.
- Atualiza metadados e caminhos de instalação para a versão 14.50.

# v14.49 — Nome completo no Capri e botão compacto

- A prévia de chamados do usuário passa a pesquisar no Capri usando o nome completo recebido do Active Directory.
- O filtro por login continua disponível para o catálogo regular da Central de Chamados.
- A atualização da prévia mantém o indicador de carregamento e usa um botão menor, alinhado aos controles Pesquisar e Filtrar.
- Atualiza metadados e caminhos de instalação para a versão 14.49.

# v14.48 — Ajustes no popup e atualização dos chamados do usuário

- Corrige fundos claros restantes no popup de chamados no modo escuro, incluindo lista, cartões e seletor de situação.
- Remove a barra de 100% permanente após a consulta; progresso e porcentagem aparecem somente durante a busca.
- Adiciona atualização manual no card e no popup, com ícone girando e progresso durante a consulta temporária ao Capri.
- O botão de copiar login de rede copia somente o login, sem o prefixo `SENADO\\`.
- Atualiza metadados e caminhos de instalação para a versão 14.48.

# v14.47 — Chamados recentes do usuário

- Inclui no painel do usuário um card com os chamados recentes no Capri, limitado a 25 resultados e com pesquisa e filtros locais no popup.
- A consulta usa o usuário confirmado no AD, inicia automaticamente após a consulta manual ou pela estação e mantém os resultados apenas em memória.
- A consulta temporária espera a Central de Chamados liberar a sessão do Capri e não lê nem altera o catálogo persistente.
- A barra de progresso da estação acompanha a etapa de usuário e chamados, chegando a 100% apenas quando o fluxo termina; falhas ficam marcadas como parciais.
- Atualiza metadados e caminhos de instalação para a versão 14.47.
