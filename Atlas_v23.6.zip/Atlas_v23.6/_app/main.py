from __future__ import annotations

import ctypes
import base64
import difflib
import getpass
import html
import http.server
import json
import math
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import unicodedata
import urllib.request
import urllib.parse
import weakref
import ctypes.wintypes
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QAbstractAnimation, QByteArray, QBuffer, QDate, QEasingCurve, QEvent, QObject, QParallelAnimationGroup, QPoint, Property, QProcess, QProcessEnvironment, QPropertyAnimation, QSize, QStringListModel, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFont, QIcon, QImage, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap, QRegion, QTextCursor
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import (
    QApplication, QButtonGroup, QCalendarWidget, QCheckBox, QComboBox, QCompleter, QDialog, QFileDialog, QFrame, QGraphicsDropShadowEffect, QGraphicsOpacityEffect, QGridLayout, QHBoxLayout, QHeaderView, QLabel,
    QDateEdit, QInputDialog, QLayout, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu, QMessageBox, QProgressBar, QPushButton, QScrollArea,
    QSizePolicy, QStackedWidget, QStyle, QStyledItemDelegate, QTabBar, QTabWidget, QTextBrowser, QTextEdit, QToolTip, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget, QWidgetAction,
)

from commands.actions import TICKET_CATALOG
from core.bridge_log import filter_bridge_log_chunk
from services.capri import build_ticket_payload, build_user_ticket_preview_payload
from services.printer_access import color_printing_allowed
from services.process_inventory import group_processes_by_memory
from services.escalation import may_escalate
from services.faq_favorites import load_favorites, toggle_favorite
from services.ticket_bookmarks import load_bookmarks, mapped_bookmarks, save_bookmarks, toggle_bookmark, ticket_number
from services.ticket_status_refresh import apply_state_updates, open_ticket_numbers
from services.structural_validation import (
    VALIDATION_INTERVALS, cleanup_regenerable_files, default_validation_settings, validate_installation,
    validation_is_due,
)
from storage.json_store import load_json, save_json
from ui.transitions import fade_theme_change
from ui.widgets import NoWheelComboBox, section_separator
from ui.screen_capture import (
    ScreenCaptureSession, default_capture_filename, default_capture_folder,
)
from ui.capture_editor import CaptureEditorDialog
from ui.ticket_templates import TicketTemplatesPopup
from ui.escalation import EscalationPopup


APP_NAME = "Atlas — Suporte Avançado"
LOGIN_WINDOW_TITLE = "ATLAS — Assistência Técnica e Lógica de Apoio ao Senado"
VERSION = "23.6"
COLOR_PRINTER_FAQ_URL = "https://capri.senado.leg.br/otrs/index.pl?Action=AgentFAQZoom;ItemID=1007;Nav="
AD_LICENSE_DESCRIPTIONS = {
    "lic-o365-e1": "Office no navegador\n• Word, Excel, PowerPoint, Outlook e OneNote na Web\n• Teams no Desktop e na Web\n• SharePoint Online e OneDrive for Business (1 TB por usuário)\n• Stream integrado ao SharePoint; Forms, Planner e Lists\n• Power Automate com recursos limitados",
    "lic-o365-e1-adp1": "Office no navegador\n• Word, Excel, PowerPoint, Outlook e OneNote na Web\n• Teams no Desktop e na Web\n• SharePoint Online e OneDrive for Business (1 TB por usuário)\n• Stream integrado ao SharePoint; Forms, Planner e Lists\n• Power Automate com recursos limitados",
    "lic-m365-apps-contrato-ct12-2025": "Office instalado no computador\n• Word, Excel, PowerPoint, Outlook e OneNote\n• Publisher e Access somente no Windows",
    "lic-m365-f1": "Acesso básico ao Microsoft 365\n• Teams no Desktop e na Web; SharePoint\n• Microsoft 365 Web e Mobile somente para leitura",
    "lic-exchk": "Correio eletrônico\n• Exchange Online pelo Outlook Web",
    "lic-m365-f1-exchk": "Teams e correio eletrônico\n• Teams no Desktop e na Web\n• Outlook Web",
    "lic-ems-e3-contrato-ct12-2025": "Mobilidade e segurança empresarial (EMS E3)\n• Acesso remoto via VPN; Azure Active Directory Premium P1\n• Microsoft Intune; Azure Information Protection P1\n• Microsoft Advanced Threat Analytics; Azure Rights Management\n• Direitos de CAL do Windows Server",
    "lic-visio-plan2-contrato-ct12-2025": "Visio 365\n• Versões Web e Desktop",
    "lic-project-plan3-contrato-ct12-2025": "Project 365\n• Versões Web e Desktop",
    "lic-visualstudio-contrato-ct12-2025": "Desenvolvimento\n• Acesso ao Visual Studio",
    "lic-copilot-contrato-ct12-2025": "Microsoft 365 Copilot\n• Licença para uso do Copilot",
    "lic-m365-lic-e5-security-e1": "Segurança\n• Licença destinada aos analistas da COINTI",
    "lic-o365-e3-adp1": "Office completo\n• Inclui as versões Desktop dos aplicativos",
    "lic-defender-office-plan1-contrato-ct12-2025": "Proteção do Office\n• Anti-phishing avançado; relatórios em tempo real\n• Anexos e links seguros; proteção do Exchange Online\n• Atribuição prevista com Exchange Online Kiosk, Office 365 E1 ou Office 365 E3",
    "lic-fabric-free": "Power BI\n• Versão gratuita",
    "lic-adp1": "Grupo para concessão de licença MFA\n• Microsoft Azure Multi-Factor Authentication\n• Microsoft Defender for Cloud Apps Discovery\n• Microsoft Entra ID P1",
    "web_libera_chat": "Acesso ao WhatsApp Web",
}

AD_LICENSE_POLICY = (
    ("Efetivos, comissionados, estagiários e terceirizados administrativos",
     "Office Web completo; o uso do pacote Desktop depende de avaliação da necessidade."),
    ("Aposentados e comissionados de escritórios de apoio",
     "Licenciamento restrito ao e-mail (Lic-ExchK) na última contratação."),
    ("Terceirizados de áreas não administrativas",
     "Outlook Web e Teams mediante solicitação formal do chefe do setor."),
    ("Usuários externos", "Sem autorização para licenças Microsoft corporativas."),
)


def ad_license_description(group: str) -> str:
    key = str(group).strip().casefold()
    if key in AD_LICENSE_DESCRIPTIONS:
        return AD_LICENSE_DESCRIPTIONS[key]
    if not key.startswith("lic-"):
        return ""
    return "Licença sem descrição cadastrada no ATLAS."
APP_STORAGE = "AtlasSuporteAvancado"
# Base institucional do Senado com variações digitais de alto contraste.
BLUE = "#00305C"
BLUE_2 = "#0A426F"
NAVY = "#061F36"
GREEN = "#00824A"
GREEN_2 = "#00A567"
YELLOW = "#FAE042"
GOLD = "#D9B534"
BG = "#EEF3F7"
SURFACE = "#FFFFFF"
TEXT = "#102638"
MUTED = "#637789"
RED = "#C73D4D"
LATERAL_WIDTH = 740
BROWSER_OPTIONS = (
    ("system", "Padrão do Windows"),
    ("chrome", "Google Chrome"),
    ("edge", "Microsoft Edge"),
)
PWM_URL = "https://gestorsenhas.senado.leg.br/private/login"
PWM_RELAY_PORT = 47831
_OPERATOR_NAME_CACHE = ""
_OPERATOR_FULL_NAME_CACHE = ""
_OPERATOR_JOB_TITLE_CACHE: str | None = None
_OPERATOR_AD_NAME_FOUND = False
_FAQ_PROCEDURE_TEXT_CACHE: dict[str, str] | None = None
_NATIVE_ICON_HANDLES = []
_ICON_CACHE: dict[tuple[str, str, int], QIcon] = {}
ICON_CACHE_LIMIT = 768
_THEMED_BUTTONS: weakref.WeakSet = weakref.WeakSet()
_BROWSER_PREFERENCE_OVERRIDE = ""


def ordered_lateral_slots():
    """Retorna cada monitor duas vezes: primeiro a borda esquerda, depois a direita."""
    screens = sorted(QApplication.screens(), key=lambda item: (item.geometry().x(), item.geometry().y()))
    return [(screen, side) for screen in screens for side in ("left", "right")]


def next_lateral_slot(window):
    """Localiza a borda atual e avança circularmente por todas as bordas disponíveis."""
    slots = ordered_lateral_slots()
    if not slots:
        primary = QApplication.primaryScreen()
        return (primary, "right") if primary else (None, "right")
    current_screen = QApplication.screenAt(window.frameGeometry().center()) or window.screen() or QApplication.primaryScreen()
    candidates = [(index, side) for index, (screen, side) in enumerate(slots) if screen == current_screen]
    if not candidates:
        return slots[0]
    available = current_screen.availableGeometry()
    frame = window.frameGeometry()
    current_side = "left" if abs(frame.left() - available.left()) < abs(frame.right() - available.right()) else "right"
    current_index = next((index for index, side in candidates if side == current_side), candidates[0][0])
    return slots[(current_index + 1) % len(slots)]


def lateral_slot_direction(window, screen, side: str) -> int:
    """Direção visual da seta até o centro da próxima posição lateral."""
    if not screen:
        return 1
    available = screen.availableGeometry()
    width = min(LATERAL_WIDTH, available.width())
    target_center_x = available.left() + width // 2 if side == "left" else available.right() - width // 2
    return 1 if target_center_x > window.frameGeometry().center().x() else -1


def apply_lateral_slot(window, screen, side: str):
    """Encaixa a janela na borda solicitada, respeitando a moldura nativa."""
    if not screen:
        return
    available = screen.availableGeometry()
    width = min(LATERAL_WIDTH, available.width())
    frame = window.frameGeometry()
    client = window.geometry()
    top_frame = max(0, client.top() - frame.top())
    left_frame = max(0, client.left() - frame.left())
    right_frame = max(0, frame.right() - client.right())
    bottom_frame = max(0, frame.bottom() - client.bottom())
    client_height = max(window.minimumHeight(), available.height() - top_frame - bottom_frame)
    client_x = available.left() + left_frame if side == "left" else available.right() - width - right_frame + 1
    window.setGeometry(client_x, available.top() + top_frame, width, client_height)


def operator_friendly_name() -> str:
    """Obtém primeiro e último nome do operador no AD sem impedir a abertura da interface."""
    global _OPERATOR_NAME_CACHE
    if _OPERATOR_NAME_CACHE:
        return _OPERATOR_NAME_CACHE
    account = getpass.getuser().strip()
    base_account = account[:-4] if account.lower().endswith("_ins") else account
    fallback = base_account or account or "Operador"
    if os.name != "nt":
        _OPERATOR_NAME_CACHE = fallback
        return fallback
    script = r"""
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
$accounts = @($env:GSS_OPERATOR_ACCOUNTS -split ';' | Where-Object { $_ })
foreach ($account in $accounts) {
    try {
        $searcher = New-Object DirectoryServices.DirectorySearcher
        $searcher.Filter = "(&(objectCategory=person)(objectClass=user)(sAMAccountName=$account))"
        [void]$searcher.PropertiesToLoad.Add('givenName')
        [void]$searcher.PropertiesToLoad.Add('sn')
        [void]$searcher.PropertiesToLoad.Add('displayName')
        $result = $searcher.FindOne()
        if ($result) {
            [pscustomobject]@{
                given = [string]$result.Properties['givenname'][0]
                surname = [string]$result.Properties['sn'][0]
                display = [string]$result.Properties['displayname'][0]
            } | ConvertTo-Json -Compress
            break
        }
    } catch {}
}
"""
    environment = os.environ.copy()
    environment["GSS_OPERATOR_ACCOUNTS"] = ";".join(dict.fromkeys((account, base_account)))
    try:
        completed = subprocess.run(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=4, check=False, env=environment,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        data = json.loads(completed.stdout.strip()) if completed.stdout.strip() else {}
        given = str(data.get("given", "")).strip()
        surname = str(data.get("surname", "")).strip()
        display = str(data.get("display", "")).strip()
        if given and surname:
            friendly = f"{given.split()[0]} {surname.split()[-1]}"
        elif display:
            friendly = display
        else:
            friendly = fallback
    except (OSError, subprocess.SubprocessError, ValueError, json.JSONDecodeError):
        friendly = fallback
    # Repara defensivamente textos UTF-8 interpretados como ANSI e remove
    # somente o sufixo visual da conta INS; a autenticação não é alterada.
    if any(marker in friendly for marker in ("Ã", "Â", "�")):
        try:
            repaired = friendly.encode("latin-1").decode("utf-8")
            if repaired.count("�") <= friendly.count("�"):
                friendly = repaired
        except (UnicodeEncodeError, UnicodeDecodeError):
            pass
    friendly = re.sub(r"(?i)(?:[._-]?_?ins)$", "", friendly.strip()).strip(" ._-")
    parts = friendly.split()
    friendly = f"{parts[0]} {parts[-1]}" if len(parts) > 1 else (parts[0] if parts else fallback)
    _OPERATOR_NAME_CACHE = friendly
    return friendly


def operator_full_name() -> str:
    """Obtém o nome completo publicado no AD para assinatura e filtro do Capri."""
    global _OPERATOR_FULL_NAME_CACHE, _OPERATOR_JOB_TITLE_CACHE, _OPERATOR_AD_NAME_FOUND
    if _OPERATOR_FULL_NAME_CACHE:
        return _OPERATOR_FULL_NAME_CACHE
    account = getpass.getuser().strip()
    base_account = re.sub(r"(?i)_ins$", "", account)
    fallback = operator_friendly_name()
    if os.name == "nt":
        script = r"""
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$s = New-Object DirectoryServices.DirectorySearcher
$s.Filter = "(&(objectCategory=person)(objectClass=user)(sAMAccountName=$env:ATLAS_OPERATOR_ACCOUNT))"
[void]$s.PropertiesToLoad.Add('displayName')
[void]$s.PropertiesToLoad.Add('title')
$r = $s.FindOne()
if ($r) {
    [pscustomobject]@{
        display = [string]$r.Properties['displayname'][0]
        title = [string]$r.Properties['title'][0]
    } | ConvertTo-Json -Compress
}
"""
        environment = os.environ.copy()
        environment["ATLAS_OPERATOR_ACCOUNT"] = base_account
        try:
            completed = subprocess.run(
                ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", script],
                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=4,
                check=False, env=environment, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            data = json.loads(completed.stdout.strip()) if completed.stdout.strip() else {}
            ad_display = str(data.get("display") or "").strip()
            if ad_display:
                fallback = ad_display
                _OPERATOR_AD_NAME_FOUND = True
            _OPERATOR_JOB_TITLE_CACHE = str(data.get("title") or "").strip()
        except (OSError, subprocess.SubprocessError, ValueError):
            pass
    _OPERATOR_FULL_NAME_CACHE = fallback
    return fallback


def operator_job_title() -> str:
    """Cargo do AD sem o marcador de vínculo Terceirizado."""
    global _OPERATOR_JOB_TITLE_CACHE
    if _OPERATOR_JOB_TITLE_CACHE is None:
        operator_full_name()
    title = re.sub(r"(?i)\bterceirizad[oa]\b", "", _OPERATOR_JOB_TITLE_CACHE or "")
    return re.sub(r"\s+", " ", title).strip(" \t-–—:/|")


def operator_template_signature() -> tuple[str, str]:
    """Não trata o login de fallback como se fosse o nome completo do AD."""
    full_name = operator_full_name()
    return (full_name if _OPERATOR_AD_NAME_FOUND else "", operator_job_title())


def resource_path(relative: str) -> Path:
    root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return root / relative


def faq_cache_path() -> Path:
    """Catálogo persistente do Capri, exclusivo do perfil Windows atual."""
    local_root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    return local_root / APP_STORAGE / "cache" / "faq_catalog.json"


def orientation_cache_path() -> Path:
    return faq_cache_path().with_name("orientation_catalog.json")


def ticket_cache_path() -> Path:
    return faq_cache_path().with_name("ticket_catalog.json")


def capri_session_path() -> Path:
    return faq_cache_path().with_name("capri_session.protected")


def password_manager_session_path() -> Path:
    """Cookie protegido e independente da sessão do Capri."""
    return faq_cache_path().with_name("password_manager_session.protected")


def password_manager_browser_profile_path() -> Path:
    """Perfil Chromium exclusivo e persistente do PWM no usuário padrão."""
    local_root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    return local_root / APP_STORAGE / "browser_profiles" / "pwm"


class PwmChromeRelay(QObject):
    """Ponte local entre o ATLAS e a sessão já autenticada do Chrome.

    A extensão instalada no Chrome consulta esta ponte somente enquanto uma
    página do PWM estiver aberta. O ATLAS nunca recebe dados de outros
    domínios e não abre um perfil de navegador próprio.
    """

    cookies_received = Signal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.port = PWM_RELAY_PORT
        self.token = secrets.token_urlsafe(32)
        self._lock = threading.Lock()
        self._job = None
        self._server = None
        self._thread = None

    def start(self):
        if self._server is not None:
            return
        relay = self

        class Handler(http.server.BaseHTTPRequestHandler):
            server_version = "AtlasPwmRelay/1.0"

            def _headers(self, status=200, content_type="application/json"):
                self.send_response(status)
                self.send_header("Content-Type", f"{content_type}; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Headers", "content-type,x-atlas-pwm-token")
                self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
                self.end_headers()

            def _authorized(self):
                parsed = urllib.parse.urlsplit(self.path)
                query_token = urllib.parse.parse_qs(parsed.query).get("token", [""])[0]
                header_token = self.headers.get("X-Atlas-Pwm-Token", "")
                return secrets.compare_digest(query_token or header_token, relay.token)

            def _write(self, payload, status=200):
                body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                self._headers(status)
                self.wfile.write(body)

            def do_OPTIONS(self):
                self._headers(204)

            def do_GET(self):
                parsed = urllib.parse.urlsplit(self.path)
                # A primeira consulta é o handshake que entrega o token
                # temporário à extensão; os resultados seguintes exigem o
                # token para impedir que outra aplicação publique cookies.
                if parsed.path != "/atlas-pwm/job":
                    self._write({"ok": False, "error": "unauthorized"}, 403)
                    return
                supplied = urllib.parse.parse_qs(parsed.query).get("token", [""])[0]
                supplied = supplied or self.headers.get("X-Atlas-Pwm-Token", "")
                if supplied and not secrets.compare_digest(supplied, relay.token):
                    self._write({"ok": False, "error": "unauthorized"}, 403)
                    return
                with relay._lock:
                    job = dict(relay._job) if relay._job else None
                self._write(job or {"ok": True, "action": "idle"})

            def do_POST(self):
                parsed = urllib.parse.urlsplit(self.path)
                if parsed.path != "/atlas-pwm/result" or not self._authorized():
                    self._write({"ok": False, "error": "unauthorized"}, 403)
                    return
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    payload = json.loads(self.rfile.read(min(length, 2_000_000)).decode("utf-8"))
                except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
                    self._write({"ok": False, "error": "invalid_payload"}, 400)
                    return
                with relay._lock:
                    current = relay._job
                    matching = bool(current and payload.get("job_id") == current.get("job_id"))
                    if matching:
                        relay._job = None
                if matching:
                    relay.cookies_received.emit(payload)
                self._write({"ok": matching})

            def log_message(self, *_args):
                return

        try:
            self._server = http.server.ThreadingHTTPServer(("127.0.0.1", self.port), Handler)
        except OSError:
            self._server = None
            return
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            name="atlas-pwm-chrome-relay",
            daemon=True,
        )
        self._thread.start()

    def request_cookie_sync(self, login: str):
        self.start()
        job = {
            "ok": True,
            "action": "sync_cookies",
            "job_id": secrets.token_hex(16),
            "domain": "gestorsenhas.senado.leg.br",
            "login": login,
            "token": self.token,
        }
        with self._lock:
            self._job = job
        return self._server is not None

    def cancel(self):
        with self._lock:
            self._job = None
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server = None


def classify_ticket_state(state: object, fallback: object = "other") -> str:
    """Normaliza estados novos também nos caches criados por versões anteriores."""
    value = unicodedata.normalize("NFKD", str(state or "")).encode("ascii", "ignore").decode().casefold()
    if "rejeitad" in value or "reject" in value:
        return "rejected"
    if ("cancelad" in value and "cliente" in value) or ("customer" in value and "cancel" in value):
        return "customer_cancelled"
    if "sem exito" in value or "unsuccessful" in value:
        return "closed_unsuccessful"
    if "com exito" in value or "successful" in value or "sucesso" in value:
        return "closed_success"
    if "pendente" in value or "pending" in value:
        return "pending"
    if re.search(r"\b(?:open|new|aberto|novo)\b", value):
        return "open"
    if "fechado" in value or "closed" in value:
        return "closed_other"
    return str(fallback or "other")


def ticket_created_date(value: object):
    """Converte as datas usadas pelo Capri para permitir reconciliação segura do cache."""
    text = str(value or "").strip()
    for pattern in ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%d/%m/%Y",
                    "%d.%m.%Y %H:%M:%S", "%d.%m.%Y %H:%M", "%d.%m.%Y",
                    "%d-%m-%Y %H:%M:%S", "%d-%m-%Y %H:%M", "%d-%m-%Y",
                    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, pattern).date()
        except ValueError:
            continue
    return None


def station_ping_display(data: dict) -> tuple[str, str]:
    result = str(data.get("ping_result") or "").strip()
    if result == "Testando":
        return "pending", "Testando…"
    if result in {"Tempo de limite perdido", "Tempo limite esgotado", "Sem resposta ao ping"}:
        return "timeout", "Tempo de limite perdido"
    try:
        ttl = int(data.get("ping_ttl"))
    except (TypeError, ValueError):
        return ("neutral", "TTL indisponível") if result in {"Resposta recebida", "TTL indisponível"} else ("unknown", "")
    if ttl < 1 or ttl > 255:
        return "unknown", ""
    state = "green" if ttl in {123, 126} else "yellow" if ttl in {250, 253} else "neutral"
    return state, f"TTL={ttl}"


def theme_settings_path() -> Path:
    return faq_cache_path().with_name("appearance.json")


def window_mode_settings_path() -> Path:
    return faq_cache_path().with_name("window_mode.json")


def interactive_user_profile() -> Path:
    """Localiza o perfil padrão com os arquivos reais, mesmo no login _INS."""
    current = Path(os.environ.get("USERPROFILE", "") or Path.home()).expanduser()
    parent = current.parent if current.parent.is_dir() else Path("C:/Users")
    names = []
    for raw in (os.environ.get("USERNAME", ""), getpass.getuser(), current.name):
        clean = str(raw or "").strip()
        for value in (clean, re.sub(r"(?i)_INS$", "", clean)):
            if value and value.casefold() not in {item.casefold() for item in names}:
                names.append(value)
    candidates = [parent / name for name in names]
    if current not in candidates:
        candidates.append(current)
    def score(profile: Path) -> int:
        if not profile.is_dir():
            return -1
        points = 20 if not profile.name.upper().endswith("_INS") else 0
        for relative in (
            "Desktop", "Downloads", "Documents", "Pictures", "Imagens",
            "Music", "Músicas", "Videos", "Vídeos", "OneDrive",
        ):
            folder = profile / relative
            if folder.is_dir():
                points += 3
                try:
                    points += min(8, sum(1 for _ in folder.iterdir()))
                except OSError:
                    pass
        return points
    valid = [candidate for candidate in candidates if candidate.is_dir()]
    return max(valid, key=score) if valid else current


def standard_user_folders(profile: Path) -> list[tuple[str, Path]]:
    """Retorna as pastas conhecidas do perfil Windows real, sem depender do login INS."""
    definitions = (
        ("Área de Trabalho", "Desktop"),
        ("Downloads", "Downloads"),
        ("Documentos", "Documents"),
        ("Imagens", "Pictures"),
        ("Músicas", "Music"),
        ("Vídeos", "Videos"),
    )
    result: list[tuple[str, Path]] = []
    seen: set[str] = set()
    for label, relative in definitions:
        candidates = [profile / relative]
        if relative == "Documents":
            candidates.append(profile / "Documentos")
        elif relative == "Pictures":
            candidates.append(profile / "Imagens")
        elif relative == "Music":
            candidates.append(profile / "Músicas")
        elif relative == "Videos":
            candidates.append(profile / "Vídeos")
        candidates.extend((profile / "OneDrive" / relative, profile / "OneDrive" / label))
        for folder in candidates:
            try:
                key = str(folder.resolve()).casefold()
            except OSError:
                key = str(folder).casefold()
            if key in seen or not folder.is_dir():
                continue
            seen.add(key)
            result.append((label, folder))
            break
    return result


def style_attachment_dialog(dialog: QFileDialog, dark: bool) -> None:
    """Mantém o seletor Qt legível e alinhado ao tema atual do ATLAS."""
    if dark:
        dialog.setStyleSheet("""
            QFileDialog { background: #071522; color: #E7F1F7; }
            QFileDialog QWidget { color: #E7F1F7; }
            QFileDialog QLineEdit, QFileDialog QComboBox, QFileDialog QAbstractItemView,
            QFileDialog QListView, QFileDialog QTreeView { background: #0C2030; color: #E7F1F7;
                border: 1px solid #24455A; border-radius: 7px; selection-background-color: #14506C; }
            QFileDialog QPushButton, QFileDialog QToolButton { background: #0C2638; color: #DCEBF4;
                border: 1px solid #2C6079; border-radius: 7px; padding: 6px 12px; }
            QFileDialog QPushButton:hover, QFileDialog QToolButton:hover { background: #124A61; }
            QFileDialog QHeaderView::section { background: #102B3E; color: #B9D2E0; border: 0; padding: 5px; }
        """)
    else:
        dialog.setStyleSheet("""
            QFileDialog { background: #F3F7FA; color: #183247; }
            QFileDialog QWidget { color: #183247; }
            QFileDialog QLineEdit, QFileDialog QComboBox, QFileDialog QAbstractItemView,
            QFileDialog QListView, QFileDialog QTreeView { background: #FFFFFF; color: #183247;
                border: 1px solid #B9CAD6; border-radius: 7px; selection-background-color: #D6EAF4; }
            QFileDialog QPushButton, QFileDialog QToolButton { background: #FFFFFF; color: #183247;
                border: 1px solid #9DB5C5; border-radius: 7px; padding: 6px 12px; }
            QFileDialog QPushButton:hover, QFileDialog QToolButton:hover { background: #E2F1F7; }
            QFileDialog QHeaderView::section { background: #E5EEF3; color: #28485D; border: 0; padding: 5px; }
        """)
    dialog.resize(820, 560)
    dialog.setMinimumSize(700, 460)


def browser_settings_path() -> Path:
    return faq_cache_path().with_name("browser_preferences.json")


DEFAULT_USEFUL_LINKS = (
    ("Capri", "https://capri.senado.leg.br/"),
    ("Intranet", "https://intranet.senado.leg.br/"),
    ("PWM", "https://gestorsenhas.senado.leg.br/private/login"),
    ("Outlook web", "https://outlook.office.com/mail/"),
    ("Central de Serviços Administrativos", "https://centralservicos.senado.leg.br/"),
)


def useful_links_path() -> Path:
    return faq_cache_path().with_name("useful_links.json")


def saved_templates_path() -> Path:
    """Templates do operador persistem entre versões e fora do cache do Capri."""
    return faq_cache_path().parent.parent / "templates" / "saved_templates.json"


def valid_useful_link(name: str, url: str) -> bool:
    name, url = name.strip(), url.strip()
    if not name or len(name) > 80 or not url or len(url) > 2048 or any(char.isspace() for char in url):
        return False
    try:
        parsed = urllib.parse.urlsplit(url)
        return parsed.scheme.lower() in {"http", "https"} and bool(parsed.hostname) and not (parsed.username or parsed.password)
    except ValueError:
        return False


def load_useful_links() -> list[dict[str, str]]:
    data = load_json_cache(useful_links_path())
    source = data.get("links", DEFAULT_USEFUL_LINKS)
    if not isinstance(source, (list, tuple)):
        return []
    links = []
    for entry in source:
        if isinstance(entry, dict):
            name, url = str(entry.get("name") or "").strip(), str(entry.get("url") or "").strip()
        elif isinstance(entry, (tuple, list)) and len(entry) == 2:
            name, url = str(entry[0]).strip(), str(entry[1]).strip()
        else:
            continue
        if valid_useful_link(name, url):
            links.append({"name": name, "url": url})
    return links


def structural_validation_settings_path() -> Path:
    return faq_cache_path().with_name("structural_validation.json")


def faq_content_overrides_path() -> Path:
    return faq_cache_path().with_name("faq_content_overrides.json")


def faq_orientation_preferences_path() -> Path:
    """Edições e exclusões decididas pelo operador, separadas do catálogo-base."""
    return faq_cache_path().with_name("faq_orientation_preferences.json")


def faq_favorites_path() -> Path:
    return faq_cache_path().with_name("faq_favorites.json")


def ticket_bookmarks_path() -> Path:
    return ticket_cache_path().with_name("ticket_bookmarks.json")


def load_json_cache(path: Path) -> dict:
    return load_json(path)


def load_ticket_cache() -> dict:
    """Aceita somente o catálogo integral, deduplicado e vinculado ao operador atual."""
    data = load_json_cache(ticket_cache_path())
    if int(data.get("schema_version", 0) or 0) < 4 or not data.get("complete"):
        return {}
    if data.get("scope") == "operator" and str(data.get("subject", "")).casefold() != operator_full_name().casefold():
        return {}
    unique: dict[str, dict] = {}
    for raw in data.get("items") or []:
        if not isinstance(raw, dict):
            continue
        item = dict(raw)
        number = re.sub(r"\D", "", str(item.get("number") or item.get("id") or ""))
        if not number:
            continue
        item["number"] = number
        if re.sub(r"\D", "", str(item.get("category") or "")) == number:
            item["category"] = ""
        item["state_kind"] = classify_ticket_state(item.get("state"), item.get("state_kind"))
        unique[number] = item
    data["items"] = list(unique.values())
    data["count"] = len(unique)
    return data


def save_json_cache(path: Path, data: dict) -> bool:
    return save_json(path, data)


def structural_validation_settings() -> dict:
    settings = default_validation_settings()
    settings.update(load_json_cache(structural_validation_settings_path()))
    valid_intervals = {key for key, _label, _days in VALIDATION_INTERVALS}
    if settings.get("interval") not in valid_intervals:
        settings["interval"] = "weekly"
    return settings


def human_file_size(value: int) -> str:
    size = max(0.0, float(value or 0))
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024.0 or unit == "GB":
            return f"{int(size)} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024.0
    return "0 B"


def run_structural_validation(safe_cleanup: bool | None = None) -> dict:
    settings = structural_validation_settings()
    if safe_cleanup is not None:
        settings["safe_cleanup"] = bool(safe_cleanup)
    result = validate_installation(resource_path(""), VERSION)
    cleanup = {
        "cleanup_files": 0, "cleanup_bytes": 0,
        "cleanup_skipped": 0, "cleanup_issues": [],
    }
    if bool(settings.get("safe_cleanup", True)):
        cleanup = cleanup_regenerable_files(faq_cache_path().parent)
        result["last_cleanup_files"] = cleanup["cleanup_files"]
        result["last_cleanup_bytes"] = cleanup["cleanup_bytes"]
        freed = human_file_size(cleanup["cleanup_bytes"])
        result["last_summary"] += (
            f" Manutenção segura: {cleanup['cleanup_files']} resíduo(s) removido(s), {freed} liberados."
        )
    result["maintenance_enabled"] = bool(settings.get("safe_cleanup", True))
    result["cleanup_issues"] = cleanup["cleanup_issues"]
    settings.update(result)
    save_json_cache(structural_validation_settings_path(), settings)
    return settings


def preferred_browser() -> str:
    runtime = str(_BROWSER_PREFERENCE_OVERRIDE or command_argument("--preferred-browser=")).lower()
    preference = runtime or str(load_json_cache(browser_settings_path()).get("browser", "system")).lower()
    return preference if preference in {key for key, _label in BROWSER_OPTIONS} else "system"


def browser_executable(preference: str) -> Path | None:
    if os.name != "nt" or preference not in {"chrome", "edge"}:
        return None
    local_app_data = os.environ.get("LOCALAPPDATA", "")
    program_files = os.environ.get("PROGRAMFILES", "")
    program_files_x86 = os.environ.get("PROGRAMFILES(X86)", "")
    relative_paths = {
        "chrome": (
            (local_app_data, "Google/Chrome/Application/chrome.exe"),
            (program_files, "Google/Chrome/Application/chrome.exe"),
            (program_files_x86, "Google/Chrome/Application/chrome.exe"),
        ),
        "edge": (
            (program_files_x86, "Microsoft/Edge/Application/msedge.exe"),
            (program_files, "Microsoft/Edge/Application/msedge.exe"),
            (local_app_data, "Microsoft/Edge/Application/msedge.exe"),
        ),
    }
    for root, relative in relative_paths[preference]:
        candidate = Path(root) / relative if root else None
        if candidate and candidate.is_file():
            return candidate
    executable_name = "chrome.exe" if preference == "chrome" else "msedge.exe"
    discovered = shutil.which(executable_name)
    if discovered and Path(discovered).is_file():
        return Path(discovered)
    try:
        import winreg
        registry_path = rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{executable_name}"
        for root in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
            for view in (0, winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
                try:
                    with winreg.OpenKey(root, registry_path, 0, winreg.KEY_READ | view) as key:
                        registered = str(winreg.QueryValueEx(key, "")[0] or "").strip().strip('"')
                    if registered and Path(registered).is_file():
                        return Path(registered)
                except OSError:
                    continue
    except (ImportError, OSError):
        pass
    return None


def default_windows_browser_preference() -> str:
    """Identifica Chrome ou Edge quando o operador escolhe o padrão do Windows."""
    if os.name != "nt":
        return ""
    try:
        import winreg
        registry_path = r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, registry_path) as key:
            program_id = str(winreg.QueryValueEx(key, "ProgId")[0] or "").casefold()
        if "chrome" in program_id:
            return "chrome"
        if "edge" in program_id:
            return "edge"
    except (ImportError, OSError):
        pass
    return ""


def command_argument(prefix: str) -> str:
    return next((argument.split("=", 1)[1] for argument in sys.argv if argument.startswith(prefix)), "")


def launch_url_for_current_windows_user(url: str, preference: str) -> tuple[bool, str, bool]:
    """Executa no usuário dono do processo atual, preservando seu perfil de navegador."""
    if preference in {"chrome", "edge"}:
        executable = browser_executable(preference)
        if executable is None:
            return False, preference, False
        try:
            subprocess.Popen(
                [str(executable), url],
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            return True, preference, False
        except OSError:
            return False, preference, False
    if os.name == "nt":
        try:
            os.startfile(url)
            return True, "system", False
        except OSError:
            return False, "system", False
    return bool(QDesktopServices.openUrl(QUrl(url))), "system", False


def available_loopback_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("127.0.0.1", 0))
        return int(probe.getsockname()[1])


def launch_password_manager_browser(
    interactive: bool, preference: str = "system",
) -> tuple[subprocess.Popen | None, int, str]:
    """Abre o PWM num perfil isolado; CDP é usado apenas para ler seus cookies locais."""
    browser_choice = preference if preference in {"chrome", "edge"} else default_windows_browser_preference()
    executable = browser_executable(browser_choice) if browser_choice else None
    if not executable:
        label = dict(BROWSER_OPTIONS).get(preference, "navegador padrão do Windows")
        return None, 0, f"{label} não foi localizado ou não é compatível com a sessão exclusiva do PWM."
    profile = password_manager_browser_profile_path()
    try:
        profile.mkdir(parents=True, exist_ok=True)
    except OSError as error:
        return None, 0, f"Não foi possível preparar o perfil persistente do PWM: {error}"
    port = available_loopback_port()
    command = [
        str(executable),
        f"--user-data-dir={profile}",
        f"--remote-debugging-port={port}",
        "--remote-debugging-address=127.0.0.1",
        "--remote-allow-origins=*",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-sync",
    ]
    if interactive:
        command.append("--app=https://gestorsenhas.senado.leg.br/private/login")
    else:
        command.extend(("--headless=new", "--disable-gpu", "https://gestorsenhas.senado.leg.br/private/login"))
    try:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if not interactive else 0,
        )
    except OSError as error:
        return None, 0, f"Não foi possível abrir o navegador exclusivo do PWM: {error}"
    deadline = time.monotonic() + 12
    version_url = f"http://127.0.0.1:{port}/json/version"
    while time.monotonic() < deadline:
        if process.poll() is not None:
            return None, 0, "O navegador exclusivo do PWM foi encerrado antes de iniciar."
        try:
            with urllib.request.urlopen(version_url, timeout=0.7) as response:
                if response.status == 200:
                    return process, port, executable.stem.lower()
        except (OSError, ValueError):
            time.sleep(0.15)
    try:
        process.terminate()
    except OSError:
        pass
    return None, 0, "O navegador exclusivo do PWM não respondeu no prazo esperado."


def run_browser_session_helper() -> int:
    """Atende links locais dentro da sessão padrão que iniciou o perfil INS."""
    try:
        port = int(command_argument("--browser-bridge-port="))
    except ValueError:
        return 2
    token = command_argument("--browser-bridge-token=")
    if os.name != "nt" or not (1024 <= port <= 65535) or len(token) < 32:
        return 2
    deadline = time.monotonic() + 12 * 60 * 60
    pwm_process: subprocess.Popen | None = None
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            server.bind(("127.0.0.1", port))
            server.listen(4)
            server.settimeout(20)
        except OSError:
            return 3
        while time.monotonic() < deadline:
            try:
                connection, _address = server.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            with connection:
                connection.settimeout(3)
                payload = b""
                try:
                    while len(payload) <= 16384 and not payload.endswith(b"\n"):
                        chunk = connection.recv(4096)
                        if not chunk:
                            break
                        payload += chunk
                    request = json.loads(payload.decode("utf-8"))
                    supplied_token = str(request.get("token", ""))
                    operation = str(request.get("operation", "open_url"))
                    if not secrets.compare_digest(supplied_token, token):
                        response = {"ok": False, "browser": "system", "fallback": False}
                    elif operation == "pwm_browser":
                        if pwm_process is not None and pwm_process.poll() is None:
                            try:
                                pwm_process.terminate()
                                pwm_process.wait(timeout=3)
                            except (OSError, subprocess.SubprocessError):
                                pass
                        interactive = bool(request.get("interactive"))
                        preference = str(request.get("browser", "system")).lower()
                        pwm_process, debug_port, detail = launch_password_manager_browser(interactive, preference)
                        response = {
                            "ok": pwm_process is not None,
                            "debug_port": debug_port,
                            "browser": detail,
                            "interactive": interactive,
                            "message": "" if pwm_process is not None else detail,
                        }
                    elif operation == "pwm_reset":
                        if pwm_process is not None and pwm_process.poll() is None:
                            try:
                                pwm_process.terminate()
                                pwm_process.wait(timeout=3)
                            except (OSError, subprocess.SubprocessError):
                                pass
                        profile = password_manager_browser_profile_path()
                        try:
                            if profile.exists():
                                shutil.rmtree(profile)
                            response = {"ok": True, "message": "Perfil persistente do PWM removido."}
                        except OSError as error:
                            response = {"ok": False, "message": str(error)}
                    elif operation == "save_browser_preference":
                        preference = str(request.get("browser", "system")).lower()
                        valid_browser = preference in {key for key, _label in BROWSER_OPTIONS}
                        saved = valid_browser and save_json_cache(browser_settings_path(), {"browser": preference})
                        response = {"ok": bool(saved), "browser": preference if valid_browser else "system"}
                    else:
                        url = str(request.get("url", "")).strip()
                        preference = str(request.get("browser", "system")).lower()
                        valid_browser = preference in {key for key, _label in BROWSER_OPTIONS}
                        valid_url = url.lower().startswith(("http://", "https://"))
                        if not valid_browser or not valid_url:
                            response = {"ok": False, "browser": "system", "fallback": False}
                        else:
                            opened, used_browser, used_fallback = launch_url_for_current_windows_user(url, preference)
                            response = {"ok": opened, "browser": used_browser, "fallback": used_fallback}
                except (OSError, ValueError, json.JSONDecodeError):
                    response = {"ok": False, "browser": "system", "fallback": False}
                try:
                    connection.sendall((json.dumps(response) + "\n").encode("utf-8"))
                except OSError:
                    pass
    return 0


def start_browser_session_helper() -> tuple[subprocess.Popen | None, int, str]:
    """Inicia a ponte ainda no perfil padrão antes de abrir a sessão INS."""
    if os.name != "nt":
        return None, 0, ""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("127.0.0.1", 0))
        port = int(probe.getsockname()[1])
    token = secrets.token_hex(32)
    if getattr(sys, "frozen", False):
        command = [sys.executable, "--browser-session-helper"]
        working_directory = str(Path(sys.executable).resolve().parent)
    else:
        command = [sys.executable, str(Path(__file__).resolve()), "--browser-session-helper"]
        working_directory = str(Path(__file__).resolve().parent)
    command.extend((f"--browser-bridge-port={port}", f"--browser-bridge-token={token}"))
    try:
        process = subprocess.Popen(
            command,
            cwd=working_directory,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=(
                getattr(subprocess, "CREATE_NO_WINDOW", 0)
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            ),
        )
    except OSError:
        return None, 0, ""
    return process, port, token


def request_browser_bridge(payload: dict, timeout: float = 15) -> dict | None:
    try:
        port = int(command_argument("--browser-bridge-port="))
    except ValueError:
        return None
    token = command_argument("--browser-bridge-token=")
    if not (1024 <= port <= 65535) or len(token) < 32:
        return None
    request_payload = dict(payload)
    request_payload["token"] = token
    request = json.dumps(request_payload) + "\n"
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=timeout) as connection:
            connection.settimeout(timeout)
            connection.sendall(request.encode("utf-8"))
            connection.shutdown(socket.SHUT_WR)
            response_bytes = b""
            while len(response_bytes) <= 4096 and not response_bytes.endswith(b"\n"):
                chunk = connection.recv(2048)
                if not chunk:
                    break
                response_bytes += chunk
        response = json.loads(response_bytes.decode("utf-8"))
        return response if isinstance(response, dict) else None
    except (OSError, ValueError, json.JSONDecodeError):
        return None


def request_browser_session(url: str, preference: str) -> tuple[bool, str, bool] | None:
    response = request_browser_bridge({
        "operation": "open_url", "url": url, "browser": preference,
    }, timeout=4)
    if response is None:
        return None
    return bool(response.get("ok")), str(response.get("browser", "system")), bool(response.get("fallback"))


def request_password_manager_browser(interactive: bool) -> tuple[bool, int, str]:
    """Solicita o perfil PWM ao helper do usuário padrão, inclusive sob a conta INS."""
    preference = preferred_browser()
    response = request_browser_bridge({
        "operation": "pwm_browser", "interactive": interactive, "browser": preference,
    })
    if response is None:
        process, port, detail = launch_password_manager_browser(interactive, preference)
        return process is not None, port, detail
    return bool(response.get("ok")), int(response.get("debug_port") or 0), str(
        response.get("message") or response.get("browser") or ""
    )


def reset_password_manager_browser_profile() -> tuple[bool, str]:
    response = request_browser_bridge({"operation": "pwm_reset"})
    if response is not None:
        return bool(response.get("ok")), str(response.get("message") or "")
    profile = password_manager_browser_profile_path()
    try:
        if profile.exists():
            shutil.rmtree(profile)
        return True, "Perfil persistente do PWM removido."
    except OSError as error:
        return False, str(error)


def sync_browser_preference_with_standard_session(preference: str) -> bool:
    """Replica no helper padrão uma preferência alterada durante a sessão INS."""
    response = request_browser_bridge({
        "operation": "save_browser_preference", "browser": preference,
    }, timeout=4)
    return bool(response and response.get("ok"))


def launch_external_url(url: str) -> tuple[bool, str, bool]:
    """Respeita sempre Chrome, Edge ou o padrão escolhidos nas configurações."""
    preference = preferred_browser()
    if getpass.getuser().lower().endswith("_ins"):
        bridged = request_browser_session(url, preference)
        if bridged is not None:
            return bridged
    return launch_url_for_current_windows_user(url, preference)


def open_password_manager_in_selected_browser() -> tuple[bool, str, bool]:
    """Abre o PWM no navegador escolhido, sem trocar silenciosamente para outro."""
    preference = preferred_browser()
    if getpass.getuser().lower().endswith("_ins"):
        bridged = request_browser_session(PWM_URL, preference)
        if bridged is not None:
            return bridged
    return launch_url_for_current_windows_user(PWM_URL, preference)


def load_faq_cache() -> dict:
    path = faq_cache_path()
    legacy_path = path.parent.parent / "v5.0" / "cache" / path.name
    try:
        if not path.exists() and legacy_path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(legacy_path.read_bytes())
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) and data.get("items") else {}
    except (OSError, ValueError, json.JSONDecodeError):
        return {}


def save_faq_cache(data: dict) -> bool:
    path = faq_cache_path()
    temporary = path.with_suffix(".tmp")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temporary, path)
        return True
    except OSError:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        return False


def normalize_faq_number(value: object) -> str:
    """Preserva o número publicado pelo Capri sem inventar prefixos."""
    return re.sub(r"\D", "", str(value or ""))


def load_orientation_catalog() -> dict:
    """Usa somente o catálogo persistido após o mapeamento solicitado pelo operador."""
    data = load_json_cache(orientation_cache_path())
    return data if isinstance(data.get("items"), list) else {}


def bundled_orientation_catalog() -> dict:
    try:
        data = json.loads(resource_path("data/orientations_catalog.json").read_text(encoding="utf-8"))
        return data if isinstance(data, dict) and isinstance(data.get("items"), list) else {}
    except (OSError, ValueError, json.JSONDecodeError):
        return {}


def load_bundled_faq_search_texts() -> dict[str, str]:
    """Indexa uma vez o conteúdo integral das 697 FAQs distribuídas com o Atlas."""
    global _FAQ_PROCEDURE_TEXT_CACHE
    if _FAQ_PROCEDURE_TEXT_CACHE is not None:
        return _FAQ_PROCEDURE_TEXT_CACHE
    result: dict[str, str] = {}
    try:
        source = resource_path("data/faqs.txt").read_text(encoding="utf-8-sig")
        headers = list(re.finditer(
            r"^#\d+\s+-\s+FAQ#:\s*(?P<id>\d+)\s+[—–-]\s+.*$", source, re.MULTILINE,
        ))
        for index, match in enumerate(headers):
            end = headers[index + 1].start() if index + 1 < len(headers) else len(source)
            block = source[match.start():end]
            raw_id = match.group("id")
            faq_id = normalize_faq_number(raw_id)
            procedure = re.search(r"\nPROCEDIMENTO:\s*(.*?)(?=\nOBSERVAÇÕES:|\Z)", block, re.DOTALL | re.I)
            text = procedure.group(1) if procedure else block
            result[faq_id] = re.sub(r"\s+", " ", text).strip()
    except OSError:
        result = {}
    for faq_id, record in load_json_cache(faq_content_overrides_path()).items():
        content = str(record.get("content") if isinstance(record, dict) else record or "").strip()
        if content:
            result[normalize_faq_number(faq_id)] = re.sub(r"\s+", " ", content)
    _FAQ_PROCEDURE_TEXT_CACHE = result
    return result


def extract_safe_user_guidance(procedure: str) -> str:
    """Seleciona somente instruções de ação destinadas ao usuário final."""
    accepted, seen = [], set()
    technical = re.compile(r"\b(?:powershell|cmd\.exe|regedit|registro do windows|gpupdate|script|executável|\.exe|driver|dll|servidor|fila|supervisão|nível [123]|\bN[123]\b|equipe técnica|atendimento interno)\b", re.I)
    cue = re.compile(r"\b(?:solicite|solicitar|acesse|acessar|clique|entre em contato|contatar|ligar|comparecer|abrir (?:um )?chamado|procure|informe|deverá|deve)\b", re.I)
    for raw in re.split(r"\n+|(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ])", procedure):
        value = re.sub(r"[*_`#]", "", raw)
        value = re.sub(r"^\s*(?:\d+[.)]|[-•])\s*", "", value)
        value = re.sub(r"\s+", " ", value).strip()
        key = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().casefold()
        if 25 <= len(value) <= 360 and cue.search(value) and not technical.search(value) and key not in seen:
            seen.add(key)
            accepted.append(value.rstrip(" ,;:") + ("." if value[-1:] not in ".!?" else ""))
        if len(accepted) == 2:
            break
    return " ".join(accepted)


def map_specific_faq_orientation(faq_number: str, procedure_override: str = "") -> dict | None:
    """Extrai sob demanda somente caminho e contato de uma FAQ do pacote local."""
    wanted = normalize_faq_number(faq_number)
    if not wanted:
        return None
    try:
        source = resource_path("data/faqs.txt").read_text(encoding="utf-8-sig")
    except OSError:
        return None
    headers = list(re.finditer(
        r"^#\d+\s+-\s+FAQ#:\s*(?P<id>\d+)\s+[—–-]\s+(?P<title>.+?)\s*$",
        source, re.MULTILINE,
    ))
    for index, header in enumerate(headers):
        end = headers[index + 1].start() if index + 1 < len(headers) else len(source)
        block = source[header.start():end]
        raw_id = header.group("id")
        official_id = normalize_faq_number(raw_id)
        if official_id != wanted:
            continue
        procedure_match = re.search(r"\nPROCEDIMENTO:\s*(.*?)(?=\nOBSERVAÇÕES:|\Z)", block, re.DOTALL | re.I)
        procedure = procedure_override.strip() or (procedure_match.group(1) if procedure_match else block)

        def clean(value: str) -> str:
            value = re.sub(r"\[\*\*(.*?)\*\*\]\([^)]*\)", r"\1", value)
            value = re.sub(r"[*_`#]", "", value)
            return re.sub(r"\s+", " ", value).strip(" \t\r\n-•")

        paths = []
        for match in re.finditer(
            r"Intranet\s*>\s*Central\s+de\s+Serviços(?:\s*>\s*[^\r\n]+)?",
            procedure, re.I,
        ):
            path = clean(match.group(0))
            path = re.split(r"\s+(?:Link|Observa(?:ção|cao)|Atenção|Importante)\s*:", path, 1, flags=re.I)[0]
            path = re.sub(r"\s*>\s*", " > ", path).rstrip(" .;,:)")
            if path.count(">") >= 2 and path not in paths:
                paths.append(path)

        contacts = []
        for raw in re.split(r"\n+|(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ])", procedure):
            value = clean(re.sub(r"^\d+[.)]\s*|^-\s*", "", raw.strip()))
            has_cue = re.search(r"\b(?:ramal(?:es)?|telefone|tel\.?|0800|entre\s+em\s+contato|ligar|contatar)\b", value, re.I)
            has_number = re.search(r"(?<!\d)(?:0800[\s.-]*\d{4,7}|(?:\(?\d{2}\)?[\s.-]*)?\d{4,5}[\s.-]?\d{0,4})(?!\d)", value)
            if has_cue and has_number and 12 <= len(value) <= 900 and value not in contacts:
                contacts.append(value[:420].rstrip(" ,;:") + ("." if value[-1:] not in ".!?" else ""))
                if len(contacts) == 3:
                    break
        category_match = re.search(r"^Categoria:\s*(.+)$", block, re.MULTILINE | re.I)
        source_category = clean(category_match.group(1)) if category_match else "FAQ específica"
        path = paths[0] if paths else ""
        contact = " ".join(contacts)
        guidance = extract_safe_user_guidance(procedure)
        if not path and not contact and not guidance:
            return {"faq_number": wanted, "title": clean(header.group("title")), "unmappable": True}
        return {
            "id": f"{wanted}:specific", "faq_number": wanted,
            "title": clean(header.group("title")), "category": "FAQ específica",
            "topic": source_category, "source_category": source_category,
            "summary": "", "guidance": guidance, "path": path, "contact": contact,
            "orientation_type": "specific",
            "search_text": clean(" ".join((wanted, header.group("title"), source_category, procedure))),
        }
    return None


def svg_icon(path: Path, size: int = 72) -> QPixmap:
    renderer = QSvgRenderer(str(path))
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    renderer.render(painter)
    painter.end()
    return pixmap


def atlas_brand_pixmap(name: str, size: int) -> QPixmap:
    """Usa o PNG da identidade aprovada com suavização nas escalas da interface."""
    return QPixmap(str(resource_path(f"assets/{name}"))).scaled(
        size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation,
    )


ICON_PATHS = {
    "home": '<path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10M9 20v-6h6v6"/>',
    "remote": '<path d="M5 5h14v10H5zM9 19h6M12 15v4"/><path d="m9 10 2 2 4-4"/>',
    "terminal": '<path d="m6 8 4 4-4 4M12 16h6"/>',
    "user": '<circle cx="12" cy="8" r="3"/><path d="M5 20c.7-4 3-6 7-6s6.3 2 7 6"/>',
    "internet": '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.3 3 14.7 0 18M12 3c-3 3.3-3 14.7 0 18"/>',
    "disk": '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
    "users": '<circle cx="9" cy="8" r="3"/><circle cx="17" cy="10" r="2.5"/><path d="M3 20c.5-4 2.5-6 6-6s5.5 2 6 6M15 15c3.2-.4 5.2 1.3 6 4"/>',
    "refresh": '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M18.8 10a7 7 0 0 0-12-3L4 9m2 5a7 7 0 0 0 12 3l2-2"/>',
    "copy": '<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    "lock": '<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
    "unlock": '<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 7-2M12 14v3"/>',
    "printer": '<path d="M7 9V4h10v5M7 17H5a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"/><path d="M7 14h10v7H7z"/>',
    "ping": '<circle cx="12" cy="12" r="2"/><circle cx="12" cy="12" r="6"/><path d="M5 5a10 10 0 0 0 0 14M19 5a10 10 0 0 1 0 14"/>',
    "download": '<path d="M12 3v12m0 0 5-5m-5 5-5-5"/><path d="M5 19h14"/>',
    "shield": '<path d="M12 3 20 6v6c0 5-3.4 8-8 10-4.6-2-8-5-8-10V6z"/><path d="m8 12 2.5 2.5L16 9"/>',
    "alert": '<path d="M12 3 22 21H2z"/><path d="M12 9v5M12 18h.01"/>',
    "external": '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6"/>',
    "open": '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6"/>',
    "mail": '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/>',
    "dns": '<path d="M4 7h16M4 12h16M4 17h16"/><circle cx="7" cy="7" r="1"/><circle cx="7" cy="12" r="1"/><circle cx="7" cy="17" r="1"/>',
    "logout": '<path d="M10 5H5v14h5M14 8l4 4-4 4M8 12h10"/>',
    "power": '<path d="M12 3v9M7 5.5a8 8 0 1 0 10 0"/>',
    "trash": '<path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 11v5M14 11v5"/>',
    "settings": '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
    "gear": '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06a1.7 1.7 0 0 0-1.88-.34 1.7 1.7 0 0 0-1.03 1.56V21h-4v-.09A1.7 1.7 0 0 0 9 19.36a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.63 15a1.7 1.7 0 0 0-1.55-1H3v-4h.09A1.7 1.7 0 0 0 4.64 9a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 9 4.63h.01A1.7 1.7 0 0 0 10 3.09V3h4v.09A1.7 1.7 0 0 0 15 4.64a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.37 9v.01A1.7 1.7 0 0 0 20.111 10H21v4h-.09A1.7 1.7 0 0 0 19.4 15z"/>',
    "plus": '<path d="M12 5v14M5 12h14"/>',
    "minus": '<path d="M5 12h14"/>',
    "check": '<path d="m5 12 4 4L19 6"/>',
    "back": '<path d="m10 6-6 6 6 6M4 12h16"/>',
    "close": '<path d="M6 6l12 12M18 6 6 18"/>',
    "legacy": '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="m7 9 3 3-3 3M12 15h5"/>',
    "software": '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 9h18M8 4v5M7 14h4M7 17h7"/>',
    "search": '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.6 15.6 5 5"/>',
    "filter": '<path d="M4 5h16l-6 7v6l-4 2v-8z"/>',
    "chevron_right": '<path d="m9 5 7 7-7 7"/>',
    "chevron_down": '<path d="m5 9 7 7 7-7"/>',
    "info": '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
    "orientation": '<path d="M4 5h11v12H8l-4 4z"/><path d="M8 9h7M8 13h5M18 7l3 3-5 5-3 1 1-3z"/>',
    "star": '<path d="m12 2 3.1 6.3 7 .9-5 4.9 1.2 7-6.3-3.3-6.3 3.3 1.2-7-5-4.9 7-.9z"/>',
    "eye": '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/>',
    "feedback": '<path d="M4 4h16v13H9l-5 4z"/><path d="m8 11 2.5 2.5L16 8"/>',
    "directory": '<circle cx="8" cy="7" r="3"/><path d="M2 18c.5-4 2.5-6 6-6 2 0 3.5.6 4.5 1.8M16 5h6M19 2v6M15 12h7M15 16h7M15 20h7"/>',
    "management": '<rect x="3" y="4" width="18" height="15" rx="2"/><path d="M3 9h18M8 19v3M16 19v3M6 22h12M8 13h3M14 13h2"/>',
    "folder": '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    "camera": '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
    "windows_lock": '<rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 21h8M12 18v3"/><rect x="9" y="10" width="6" height="5" rx="1"/><path d="M10.5 10V8.5a1.5 1.5 0 0 1 3 0V10"/>',
    "ticket": '<path d="M4 5h16v5a2 2 0 0 0 0 4v5H4v-5a2 2 0 0 0 0-4z"/><path d="M9 8v8M13 9h4M13 13h4"/>',
    "calendar": '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4M16 3v4M3 10h18"/>',
    "time_filter": '<circle cx="10" cy="10" r="7"/><path d="M10 6v4l3 2M16 16l2 2 4-4"/>',
    "moon": '<path d="M20 15.6A8.8 8.8 0 0 1 8.8 4 8.8 8.8 0 1 0 20 15.6z"/>',
    "sun": '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.66 6.34l1.41-1.41"/>',
}


def modern_icon(name: str, color: str = BLUE, size: int = 22) -> QIcon:
    app = QApplication.instance()
    if app and bool(app.property("darkMode")):
        color = {
            BLUE.casefold(): "#73CFF3",
            BLUE_2.casefold(): "#73CFF3",
            "#258dc2": "#70D0F5",
            GREEN.casefold(): "#62DFAD",
            GREEN_2.casefold(): "#62DFAD",
            RED.casefold(): "#FF7F90",
            "#778b99": "#9BB4C4",
        }.get(str(color).casefold(), color)
    cache_key = (str(name), str(color).casefold(), int(size))
    cached = _ICON_CACHE.get(cache_key)
    if cached is not None:
        # Preserva os ícones recentes e evita invalidar o cache inteiro durante
        # a troca de tema, eliminando um pico de reconstrução visual.
        _ICON_CACHE.pop(cache_key, None)
        _ICON_CACHE[cache_key] = cached
        return cached
    paths = ICON_PATHS.get(name, ICON_PATHS["info"])
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" '
           f'fill="none" stroke="{color}" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">{paths}</svg>')
    renderer = QSvgRenderer(QByteArray(svg.encode("utf-8")))
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    renderer.render(painter)
    painter.end()
    icon = QIcon(pixmap)
    while len(_ICON_CACHE) >= ICON_CACHE_LIMIT:
        _ICON_CACHE.pop(next(iter(_ICON_CACHE)))
    _ICON_CACHE[cache_key] = icon
    return icon


def set_button_icon(button: QPushButton, name: str, color: str = BLUE, size: int = 19):
    # Atributos Python não disparam DynamicPropertyChange nem repolimento QSS.
    # Isso é relevante ao montar centenas de cartões de chamados de uma vez.
    button._atlas_icon_name = name
    button._atlas_icon_color = color
    button._atlas_icon_size = size
    _THEMED_BUTTONS.add(button)
    button.setIcon(modern_icon(name, color, size))
    button.setIconSize(QSize(size, size))


def refresh_themed_button_icons():
    """Recolore apenas botões registrados, sem varrer toda a árvore do Qt."""
    for button in tuple(_THEMED_BUTTONS):
        name = getattr(button, "_atlas_icon_name", None)
        color = getattr(button, "_atlas_icon_color", None)
        size = getattr(button, "_atlas_icon_size", None)
        if name and color and size:
            button.setIcon(modern_icon(str(name), str(color), int(size)))
            button.setIconSize(QSize(int(size), int(size)))


def refresh_themed_button_icons_chunked(owner: QObject, batch_size: int = 36):
    """Revalida ícones em lotes curtos para não interromper o crossfade do painel logado."""
    token = object()
    owner._theme_icon_refresh_token = token
    buttons = tuple(_THEMED_BUTTONS)
    position = 0

    def refresh_batch():
        nonlocal position
        if getattr(owner, "_theme_icon_refresh_token", None) is not token:
            return
        end = min(len(buttons), position + max(1, batch_size))
        for button in buttons[position:end]:
            try:
                name = getattr(button, "_atlas_icon_name", None)
                color = getattr(button, "_atlas_icon_color", None)
                size = getattr(button, "_atlas_icon_size", None)
                if name and color and size and not getattr(button, "_atlas_refresh_rotating", False):
                    button.setIcon(modern_icon(str(name), str(color), int(size)))
                    button.setIconSize(QSize(int(size), int(size)))
            except RuntimeError:
                pass
        position = end
        if position < len(buttons):
            QTimer.singleShot(0, refresh_batch)
        elif getattr(owner, "_theme_icon_refresh_token", None) is token:
            owner._theme_icon_refresh_token = None

    QTimer.singleShot(0, refresh_batch)


def _advance_refresh_icon(button_ref):
    button = button_ref()
    if button is None or not getattr(button, "_atlas_refresh_rotating", False):
        return
    size = int(getattr(button, "_atlas_icon_size", 15) or 15)
    color = str(getattr(button, "_atlas_icon_color", GREEN) or GREEN)
    source = modern_icon("refresh", color, size).pixmap(size, size)
    frame = QPixmap(size, size)
    frame.fill(Qt.transparent)
    painter = QPainter(frame)
    painter.setRenderHint(QPainter.Antialiasing, True)
    painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
    painter.translate(size / 2, size / 2)
    painter.rotate(float(getattr(button, "_atlas_refresh_angle", 0.0)))
    painter.drawPixmap(-size // 2, -size // 2, source)
    painter.end()
    button.setIcon(QIcon(frame))
    button.setIconSize(QSize(size, size))
    button._atlas_refresh_angle = (float(getattr(button, "_atlas_refresh_angle", 0.0)) + 18.0) % 360.0


def set_refresh_icon_busy(button: QPushButton, active: bool):
    """Gira o próprio glifo de atualização, preservando texto, tema e dimensões do botão."""
    active = bool(active)
    timer = getattr(button, "_atlas_refresh_timer", None)
    if not active and timer is None:
        button._atlas_refresh_rotating = False
        return
    button._atlas_refresh_rotating = active
    if timer is None:
        timer = QTimer(button)
        timer.setInterval(34)
        button_ref = weakref.ref(button)
        timer.timeout.connect(lambda: _advance_refresh_icon(button_ref))
        button._atlas_refresh_timer = timer
    if active:
        button._atlas_refresh_angle = 0.0
        _advance_refresh_icon(weakref.ref(button))
        if not timer.isActive():
            timer.start()
    else:
        timer.stop()
        button._atlas_refresh_angle = 0.0
        name = str(getattr(button, "_atlas_icon_name", "refresh") or "refresh")
        color = str(getattr(button, "_atlas_icon_color", GREEN) or GREEN)
        size = int(getattr(button, "_atlas_icon_size", 15) or 15)
        set_button_icon(button, name, color, size)


def fit_dialog_to_content(
    dialog: QDialog,
    contents: list[str],
    min_width: int = 420,
    min_height: int = 270,
    chrome_height: int = 182,
):
    """Dimensiona o popup pelo conteúdo sem ultrapassar a área útil da tela."""
    screen = dialog.screen() or QApplication.primaryScreen()
    available = screen.availableGeometry()
    lines = []
    for content in contents:
        current = str(content or "").splitlines() or [""]
        lines.append(sum(max(1, (len(line) + 78) // 79) for line in current))
    visible_lines = max(lines or [1])
    longest = max((len(line) for content in contents for line in str(content or "").splitlines()), default=40)
    desired_width = min_width + max(0, min(longest, 105) - 58) * 3
    desired_height = chrome_height + min(visible_lines, 24) * 16
    width = min(max(min_width, desired_width), max(360, available.width() - 100))
    height = min(max(min_height, desired_height), max(280, available.height() - 90))
    dialog.resize(width, height)


def windows_identity() -> str:
    domain = os.environ.get("USERDOMAIN", "SENADO")
    return f"{domain}\\{getpass.getuser()}"


def configure_windows_app_identity():
    """Impede que o Windows agrupe o Atlas sob o ícone genérico do Python."""
    if os.name != "nt":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "SenadoFederal.AtlasSuporteAvancado"
        )
    except (AttributeError, OSError):
        pass


def apply_native_window_icon(window):
    """Reforça o ícone no HWND, inclusive na instância aberta pelo perfil INS."""
    icon_path = resource_path("assets/app_icon.ico")
    if os.name != "nt" or not icon_path.exists():
        return
    try:
        configure_windows_app_identity()
        window.setWindowIcon(QIcon(str(icon_path)))
        QApplication.setWindowIcon(QIcon(str(icon_path)))
        hwnd = int(window.winId())
        user32 = ctypes.windll.user32
        handle = user32.LoadImageW(None, str(icon_path), 1, 0, 0, 0x10 | 0x40)
        if handle:
            user32.SendMessageW(hwnd, 0x0080, 1, handle)
            user32.SendMessageW(hwnd, 0x0080, 0, handle)
            _NATIVE_ICON_HANDLES.append(handle)
    except (AttributeError, OSError, TypeError, ValueError):
        pass


def apply_native_titlebar_theme(window: QWidget, dark: bool):
    """Mantém a barra de título dos popups coerente com o tema no Windows."""
    if os.name != "nt" or not window.isWindow():
        return
    try:
        value = ctypes.c_int(1 if dark else 0)
        hwnd = int(window.winId())
        for attribute in (20, 19):
            result = ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, attribute, ctypes.byref(value), ctypes.sizeof(value)
            )
            if result == 0:
                break
    except (AttributeError, OSError, TypeError, ValueError):
        pass


class ThemeWindowFilter(QObject):
    """Alcança inclusive QInputDialog e QMessageBox criados pelo próprio Qt."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.dark_mode = False

    def set_dark_mode(self, enabled: bool):
        self.dark_mode = bool(enabled)
        app = QApplication.instance()
        if app:
            for window in app.topLevelWidgets():
                apply_native_titlebar_theme(window, self.dark_mode)

    def eventFilter(self, watched, event):
        if (
            isinstance(watched, QWidget)
            and watched.isWindow()
            and event.type() in (QEvent.Type.Show, QEvent.Type.WinIdChange)
        ):
            apply_native_titlebar_theme(watched, self.dark_mode)
        return super().eventFilter(watched, event)


def apply_application_theme(dark: bool, refresh_icons: bool = True):
    """Atualiza cores e ícones sem substituir o estilo-base nem recalcular a grade."""
    app = QApplication.instance()
    if not app:
        return
    dark = bool(dark)
    already_applied = app.property("atlasThemeApplied")
    app.setProperty("darkMode", dark)
    if already_applied is None or bool(already_applied) != dark:
        app.setStyleSheet(STYLE + (DARK_STYLE if dark else ""))
        app.setProperty("atlasThemeApplied", dark)
    if refresh_icons:
        refresh_themed_button_icons()
    theme_filter = getattr(app, "theme_window_filter", None)
    if theme_filter:
        theme_filter.set_dark_mode(dark)


def is_admin() -> bool:
    if os.name != "nt":
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


class CREDENTIALW(ctypes.Structure):
    _fields_ = [
        ("Flags", ctypes.wintypes.DWORD),
        ("Type", ctypes.wintypes.DWORD),
        ("TargetName", ctypes.wintypes.LPWSTR),
        ("Comment", ctypes.wintypes.LPWSTR),
        ("LastWritten", ctypes.wintypes.FILETIME),
        ("CredentialBlobSize", ctypes.wintypes.DWORD),
        ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)),
        ("Persist", ctypes.wintypes.DWORD),
        ("AttributeCount", ctypes.wintypes.DWORD),
        ("Attributes", ctypes.c_void_p),
        ("TargetAlias", ctypes.wintypes.LPWSTR),
        ("UserName", ctypes.wintypes.LPWSTR),
    ]


def credential_target(username: str, scope: str = "windows") -> str:
    base = f"GerenciadorSuporteSenado|{username.lower()}"
    return base if scope == "windows" else f"{base}|{scope.lower()}"


def normalize_capri_login(username: str) -> str:
    """Aceita domínio/login e conta INS sem alterar o login real do Capri."""
    value = str(username or "").strip()
    if "\\" in value:
        value = value.rsplit("\\", 1)[-1]
    return re.sub(r"(?i)_ins$", "", value).strip()


def capri_environment(username: str, password: str) -> dict[str, str]:
    """Transporta credenciais sem interpretação de caracteres pelo shell."""
    encode = lambda value: base64.b64encode(str(value).encode("utf-8")).decode("ascii")
    return {
        "GERENCIADOR_CAPRI_USER_B64": encode(normalize_capri_login(username)),
        "GERENCIADOR_CAPRI_PASSWORD_B64": encode(password),
    }


def password_manager_environment(username: str, password: str) -> dict[str, str]:
    """Transporta a credencial do Gestor sem expô-la na linha de comando."""
    encode = lambda value: base64.b64encode(str(value).encode("utf-8")).decode("ascii")
    return {
        "ATLAS_PASSWORD_MANAGER_USER_B64": encode(normalize_capri_login(username)),
        "ATLAS_PASSWORD_MANAGER_PASSWORD_B64": encode(password),
    }


def validate_capri_session(username: str, password: str) -> tuple[bool, str]:
    """Valida uma única sessão do Capri antes de abrir o painel principal."""
    if os.name != "nt":
        return True, "Sessão do Capri ignorada fora do Windows."
    launcher = str(resource_path("scripts/bridge_launcher.ps1"))
    bridge = str(resource_path("scripts/bridge.ps1"))
    environment = os.environ.copy()
    environment.update(capri_environment(username, password))
    try:
        completed = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", launcher,
             "-Script", bridge, "-Action", "capri_login", "-Computer", "", "-Value", ""],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=50, check=False, env=environment,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        output = (completed.stdout + "\n" + completed.stderr).strip()
        return completed.returncode == 0 and "@@CAPRI_SESSION@@" in output, output
    except (OSError, subprocess.SubprocessError) as error:
        return False, str(error)


def terminate_capri_session() -> tuple[bool, str]:
    """Encerra no servidor a sessão persistente do Capri antes de sair do Atlas."""
    session_file = capri_session_path()
    if not session_file.exists():
        return True, "Nenhuma sessão persistente do Capri estava ativa."
    if os.name != "nt":
        try:
            session_file.unlink(missing_ok=True)
            return True, "Sessão local do Capri removida."
        except OSError as error:
            return False, str(error)
    launcher = str(resource_path("scripts/bridge_launcher.ps1"))
    bridge = str(resource_path("scripts/bridge.ps1"))
    try:
        completed = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", launcher,
             "-Script", bridge, "-Action", "capri_logout", "-Computer", "", "-Value", ""],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=35, check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        output = (completed.stdout + "\n" + completed.stderr).strip()
        return completed.returncode == 0 and "@@CAPRI_LOGOUT@@" in output, output
    except (OSError, subprocess.SubprocessError) as error:
        return False, str(error)


def terminate_password_manager_session() -> tuple[bool, str]:
    """Encerra apenas o Gestor de Senhas, sem afetar Capri ou perfil INS."""
    session_file = password_manager_session_path()
    if not session_file.exists():
        return True, "Nenhuma sessão persistente do Gestor de Senhas estava ativa."
    if os.name != "nt":
        try:
            session_file.unlink(missing_ok=True)
            return True, "Sessão local do Gestor de Senhas removida."
        except OSError as error:
            return False, str(error)
    launcher = str(resource_path("scripts/bridge_launcher.ps1"))
    bridge = str(resource_path("scripts/bridge.ps1"))
    try:
        completed = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", launcher,
             "-Script", bridge, "-Action", "password_manager_logout", "-Computer", "", "-Value", ""],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=35, check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        output = (completed.stdout + "\n" + completed.stderr).strip()
        return completed.returncode == 0 and "@@PASSWORD_MANAGER_LOGOUT@@" in output, output
    except (OSError, subprocess.SubprocessError) as error:
        return False, str(error)


def credential_read(username: str, scope: str = "windows") -> str | None:
    """Lê a credencial do cofre do usuário Windows atual."""
    if os.name != "nt":
        return None
    advapi = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
    advapi.CredReadW.argtypes = [ctypes.wintypes.LPCWSTR, ctypes.wintypes.DWORD,
                                 ctypes.wintypes.DWORD, ctypes.POINTER(ctypes.POINTER(CREDENTIALW))]
    advapi.CredReadW.restype = ctypes.wintypes.BOOL
    advapi.CredFree.argtypes = [ctypes.c_void_p]
    pointer = ctypes.POINTER(CREDENTIALW)()
    if not advapi.CredReadW(credential_target(username, scope), 1, 0, ctypes.byref(pointer)):
        return None
    try:
        size = pointer.contents.CredentialBlobSize
        if not size:
            return None
        raw = ctypes.string_at(pointer.contents.CredentialBlob, size)
        try:
            return raw.decode("utf-16-le")
        except UnicodeDecodeError:
            return None
    finally:
        advapi.CredFree(pointer)


def credential_write(username: str, password: str, scope: str = "windows") -> bool:
    """Salva no Credential Manager; nunca grava a senha nos arquivos do app."""
    if os.name != "nt" or not password:
        return False
    advapi = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
    advapi.CredWriteW.argtypes = [ctypes.POINTER(CREDENTIALW), ctypes.wintypes.DWORD]
    advapi.CredWriteW.restype = ctypes.wintypes.BOOL
    raw = password.encode("utf-16-le")
    blob = (ctypes.c_ubyte * len(raw)).from_buffer_copy(raw)
    credential = CREDENTIALW()
    credential.Type = 1  # CRED_TYPE_GENERIC
    credential.TargetName = credential_target(username, scope)
    credential.CredentialBlobSize = len(raw)
    credential.CredentialBlob = ctypes.cast(blob, ctypes.POINTER(ctypes.c_ubyte))
    credential.Persist = 2  # CRED_PERSIST_LOCAL_MACHINE, somente para o usuário atual
    credential.UserName = username
    return bool(advapi.CredWriteW(ctypes.byref(credential), 0))


def credential_delete(username: str, scope: str = "windows") -> bool:
    if os.name != "nt":
        return False
    advapi = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
    advapi.CredDeleteW.argtypes = [ctypes.wintypes.LPCWSTR, ctypes.wintypes.DWORD,
                                   ctypes.wintypes.DWORD]
    advapi.CredDeleteW.restype = ctypes.wintypes.BOOL
    return bool(advapi.CredDeleteW(credential_target(username, scope), 1, 0))


def profile_usernames() -> tuple[str, str]:
    domain = os.environ.get("USERDOMAIN", "SENADO")
    base_user = getpass.getuser().removesuffix("_ins")
    return f"{domain}\\{base_user}", f"{domain}\\{base_user}_ins"


def start_with_credentials(
    username: str,
    password: str,
    profile: str,
    monitor_center: tuple[int, int] | None = None,
    dark_mode: bool = False,
    window_mode: str = "lateral",
) -> tuple[bool, str]:
    """Inicia outra instância com credenciais Windows sem persistir a senha."""
    if os.name != "nt":
        return False, "Autenticação disponível somente no Windows."
    username = username.strip()
    if not username or not password:
        return False, "Informe o usuário e a senha."
    if "\\" in username:
        domain, user = username.split("\\", 1)
    else:
        domain, user = os.environ.get("USERDOMAIN", "SENADO"), username
    monitor_args = ""
    if monitor_center:
        monitor_args = f" --monitor-x={int(monitor_center[0])} --monitor-y={int(monitor_center[1])}"
    theme_arg = " --theme-dark" if dark_mode else " --theme-light"
    browser_arg = f" --preferred-browser={preferred_browser()}"
    mode_arg = " --window-mode-full" if window_mode == "full" else " --window-mode-lateral"
    if getattr(sys, "frozen", False):
        application = sys.executable
        command = f'"{application}" --{profile}{monitor_args}{theme_arg}{browser_arg}{mode_arg}'
        workdir = str(Path(application).resolve().parent)
    else:
        application = sys.executable
        command = f'"{application}" "{Path(__file__).resolve()}" --{profile}{monitor_args}{theme_arg}{browser_arg}{mode_arg}'
        workdir = str(Path(__file__).resolve().parent)
    token = ctypes.wintypes.HANDLE()
    LOGON32_LOGON_INTERACTIVE = 2
    LOGON32_PROVIDER_DEFAULT = 0
    advapi = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
    ok = advapi.LogonUserW(user, domain, password, LOGON32_LOGON_INTERACTIVE,
                           LOGON32_PROVIDER_DEFAULT, ctypes.byref(token))
    if not ok:
        return False, f"Credenciais recusadas pelo Windows (erro {ctypes.get_last_error()})."
    browser_helper_process = None
    if profile == "ins":
        browser_helper_process, bridge_port, bridge_token = start_browser_session_helper()
        if browser_helper_process:
            command += (
                f" --browser-bridge-port={bridge_port}"
                f" --browser-bridge-token={bridge_token}"
            )
    kernel32 = ctypes.WinDLL("Kernel32.dll", use_last_error=True)
    kernel32.CloseHandle(token)
    # CreateProcessWithLogonW mantém a senha somente na memória durante a chamada.
    class STARTUPINFO(ctypes.Structure):
        _fields_ = [("cb", ctypes.wintypes.DWORD), ("lpReserved", ctypes.wintypes.LPWSTR),
                    ("lpDesktop", ctypes.wintypes.LPWSTR), ("lpTitle", ctypes.wintypes.LPWSTR),
                    ("dwX", ctypes.wintypes.DWORD), ("dwY", ctypes.wintypes.DWORD),
                    ("dwXSize", ctypes.wintypes.DWORD), ("dwYSize", ctypes.wintypes.DWORD),
                    ("dwXCountChars", ctypes.wintypes.DWORD), ("dwYCountChars", ctypes.wintypes.DWORD),
                    ("dwFillAttribute", ctypes.wintypes.DWORD), ("dwFlags", ctypes.wintypes.DWORD),
                    ("wShowWindow", ctypes.wintypes.WORD), ("cbReserved2", ctypes.wintypes.WORD),
                    ("lpReserved2", ctypes.POINTER(ctypes.c_byte)),
                    ("hStdInput", ctypes.wintypes.HANDLE), ("hStdOutput", ctypes.wintypes.HANDLE),
                    ("hStdError", ctypes.wintypes.HANDLE)]
    class PROCESS_INFORMATION(ctypes.Structure):
        _fields_ = [("hProcess", ctypes.wintypes.HANDLE), ("hThread", ctypes.wintypes.HANDLE),
                    ("dwProcessId", ctypes.wintypes.DWORD), ("dwThreadId", ctypes.wintypes.DWORD)]
    si, pi = STARTUPINFO(), PROCESS_INFORMATION()
    si.cb = ctypes.sizeof(si)
    mutable_command = ctypes.create_unicode_buffer(command)
    CREATE_NO_WINDOW = 0x08000000
    ok = advapi.CreateProcessWithLogonW(user, domain, password, 1, application,
                                        mutable_command, CREATE_NO_WINDOW, None, workdir,
                                        ctypes.byref(si), ctypes.byref(pi))
    if not ok:
        if browser_helper_process:
            browser_helper_process.terminate()
        return False, f"Não foi possível iniciar a sessão (erro {ctypes.get_last_error()})."
    kernel32.CloseHandle(pi.hThread)
    kernel32.CloseHandle(pi.hProcess)
    return True, "Sessão iniciada."


@dataclass(frozen=True)
class Action:
    title: str
    subtitle: str
    command: str
    category: str
    needs_target: bool = True
    destructive: bool = False
    admin_only: bool = True


ACTIONS = [
    Action("02  Controle remoto SCCM", "Abrir o CmRcViewer para a estação", "cmrc", "Menu principal"),
    Action("03  Ping contínuo", "Monitorar conectividade em tempo real", "ping", "Menu principal", admin_only=False),
    Action("05  Administrador local", "Adicionar ou remover o usuário remoto", "admin", "Menu principal"),
    Action("06  Usuários e grupos locais", "Abrir o gerenciamento da estação", "local_users", "Menu principal"),
    Action("07  Active Directory", "Abrir Usuários e Computadores do AD", "ad", "Menu principal", needs_target=False),
    Action("08  Grupos do usuário no AD", "Consultar os grupos da conta conectada", "ad_groups", "Menu principal"),
    Action("09  Disco e perfis", "Analisar unidades e perfis de usuário", "disk_profiles", "Menu principal"),
    Action("10  Internet e certificados", "Abrir na sessão do usuário remoto", "inetcpl", "Menu principal", admin_only=False),
    Action("12  Voltar ao perfil padrão", "Encerrar a interface INS com segurança", "return_standard", "Menu principal", needs_target=False, admin_only=False),
    Action("00  Fechar o gerenciador", "Encerrar a ferramenta", "close_app", "Menu principal", needs_target=False, admin_only=False),
    Action("01  Fechar Outlook", "Finalizar o Outlook do usuário remoto", "outlook", "Suporte remoto", destructive=True),
    Action("02  Limpar cache DNS", "Executar ipconfig /flushdns remotamente", "dns", "Suporte remoto"),
    Action("03  Atualizar políticas", "Executar GPUpdate /force remotamente", "gpupdate", "Suporte remoto"),
    Action("04  Logoff remoto", "Encerrar a sessão do usuário conectado", "logoff", "Menu principal", destructive=True),
    Action("05  Reiniciar computador", "Reiniciar a estação em 15 segundos", "restart", "Menu principal", destructive=True),
    Action("06  Limpar pasta TEMP", "Remover temporários sem depender do WinRM", "temp", "Suporte remoto", destructive=True),
    Action("07  Configuração Trellix", "Atualizar políticas, propriedades e eventos do agente", "trellix_config", "Suporte remoto"),
    Action("08  Atlas Repair", "Limpar TEMP e DNS, atualizar políticas e configurar o Trellix", "atlas_repair", "Suporte remoto", destructive=True),
    Action("01  Abrir limpeza do Chrome", "Abrir a tela de limpeza diretamente no Chrome remoto", "browser_open_chrome_cleanup", "Suporte remoto"),
    Action("02  Abrir limpeza do Edge", "Abrir a tela de limpeza diretamente no Edge remoto", "browser_open_edge_cleanup", "Suporte remoto"),
    Action("03  Fechar Google Chrome", "Encerrar completamente todas as instâncias do Chrome remoto", "browser_close_chrome", "Suporte remoto", destructive=True),
    Action("04  Fechar Microsoft Edge", "Encerrar completamente todas as instâncias do Edge remoto", "browser_close_edge", "Suporte remoto", destructive=True),
    Action("05  Certificados digitais", "Listar e excluir certificados pessoais da estação remota", "cert_list", "Suporte remoto"),
    Action("06  Processos do usuário", "Ver processos ativos e encerrar um processo selecionado", "remote_process_list", "Suporte remoto"),
    Action("07  Programas do usuário", "Consultar programas registrados no perfil e na estação", "user_software_list", "Suporte remoto"),
    Action("08  Instalar impressora", "Instalar da lista autorizada no AD", "install_printer", "Suporte remoto"),
    Action("08  Excluir impressora", "Remover uma impressora instalada na estação", "remove_printer", "Suporte remoto", destructive=True),
    Action("08  Remover driver HP", "Executar o assistente Prodasen remotamente", "remove_hp_driver", "Suporte remoto"),
    Action("09  Instalar driver HP", "Executar o assistente Prodasen remotamente", "install_hp_driver", "Suporte remoto"),
    Action("10  Imprimir página de teste", "Selecionar uma impressora instalada", "test_print", "Suporte remoto"),
    Action("11  Definir impressora padrão", "Selecionar uma impressora instalada", "set_default_printer", "Suporte remoto"),
    Action("12  Limpar fila de impressão", "Reiniciar spooler e remover itens presos", "spooler", "Suporte remoto", destructive=True),
    Action("00  Voltar ao menu principal", "Retornar às opções principais", "open_main", "Suporte remoto", needs_target=False, admin_only=False),
]

LOADING_ACTIONS = {
    "dns", "gpupdate", "install_printer", "remove_printer", "remove_hp_driver", "install_hp_driver",
    "test_print", "set_default_printer", "spooler", "trellix_config", "atlas_repair", "cert_list",
    "browser_open_chrome_cleanup", "browser_open_edge_cleanup", "browser_close_chrome", "browser_close_edge",
}


class PowerShellRunner(QProcess):
    output = Signal(str)
    completed = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setProcessChannelMode(QProcess.MergedChannels)
        self.readyReadStandardOutput.connect(self._read)
        self._active = False
        self._timed_out = False
        self.deadline = QTimer(self)
        self.deadline.setSingleShot(True)
        self.deadline.timeout.connect(self._timeout)
        self.finished.connect(self._finished)
        self.errorOccurred.connect(self._process_error)

    def _finished(self, code, _status):
        self._read()
        self.deadline.stop()
        if self._active:
            self._active = False
            self.completed.emit(code == 0 and not self._timed_out)

    def _process_error(self, error):
        if error == QProcess.FailedToStart:
            self.output.emit("Não foi possível iniciar o PowerShell.\n")
            self._finished(-1, None)

    def _timeout(self):
        self._timed_out = True
        self.output.emit("\nTempo limite excedido. O resultado remoto não foi confirmado; verifique a estação antes de repetir.\n")
        self.kill()

    def cancel(self):
        """Interrompe uma consulta sem publicar conclusão ou resultado parcial."""
        self._active = False
        self.deadline.stop()
        if self.state() != QProcess.NotRunning:
            self.kill()

    def _read(self):
        text = bytes(self.readAllStandardOutput()).decode("utf-8", errors="replace")
        if text:
            self.output.emit(text)

    def run_script(self, script: str, args: list[str], environment: dict[str, str] | None = None, timeout_ms: int = 0):
        if self.state() != QProcess.NotRunning:
            return False
        process_environment = QProcessEnvironment.systemEnvironment()
        for name, value in (environment or {}).items():
            process_environment.insert(name, value)
        self.setProcessEnvironment(process_environment)
        command = ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script, *args]
        self._active = True
        self._timed_out = False
        if timeout_ms:
            self.deadline.start(timeout_ms)
        self.start("powershell.exe", command)
        return True


class AnimatedSideModeButton(QWidget):
    """Seta vetorial que pode assumir o acabamento dos atalhos do rodapé."""
    clicked = Signal()

    def __init__(
        self, parent=None, core_color="#38D7FF", hover_color="#B9F3FF",
        glow_color="#00AEEF", framed: bool = False,
    ):
        super().__init__(parent)
        self.direction = -1
        self.progress = 0.0
        self.hovered = False
        self.framed = bool(framed)
        self.core_color = core_color
        self.hover_color = hover_color
        self.glow_color = glow_color
        self.setFixedSize(44 if self.framed else 52, 34 if self.framed else 32)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Mover para o lado direito do próximo monitor")
        self.setAccessibleName("Mover Atlas para o próximo monitor")
        self.timer = QTimer(self)
        self.timer.setInterval(34)
        self.timer.timeout.connect(self.advance)
        self.timer.start()

    def set_direction(self, direction: int):
        self.direction = -1 if direction < 0 else 1
        self.progress = 0.0
        self.update()

    def advance(self):
        self.progress = (self.progress + 0.032) % 1.0
        self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(event)

    def enterEvent(self, event):
        self.hovered = True
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hovered = False
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        if self.framed:
            pulse = 1.0 - abs((self.progress * 2.0) - 1.0)
            background = QColor(27, 101, 139, 50 if self.hovered else 16 + int(25 * pulse))
            border = QColor(self.glow_color)
            border.setAlpha(150 if self.hovered else 60 + int(55 * pulse))
            painter.setPen(QPen(border, 1.1))
            painter.setBrush(background)
            painter.drawRoundedRect(self.rect().adjusted(1, 1, -1, -1), 9, 9)
            # Uma seta acompanha a caixa translúcida, no ritmo da tela de login.
            center_y = self.height() / 2
            shift = self.direction * pulse * 2.0
            head_x = self.width() / 2 + self.direction * 5 + shift
            painter.setBrush(Qt.NoBrush)
            color = QColor(self.hover_color if self.hovered else self.core_color)
            color.setAlpha(245 if self.hovered else 180 + int(55 * pulse))
            painter.setPen(QPen(color, 2.6, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
            painter.drawLine(int(head_x - self.direction * 11), int(center_y), int(head_x), int(center_y))
            painter.drawLine(int(head_x), int(center_y), int(head_x - self.direction * 6), int(center_y - 6))
            painter.drawLine(int(head_x), int(center_y), int(head_x - self.direction * 6), int(center_y + 6))
            return
        # Apenas a seta permanece visível. Ela corre no sentido do próximo
        # monitor e desaparece ao tocar a extremidade antes de reaparecer.
        alpha = max(18, int(255 * (1.0 - self.progress)))
        color = QColor(self.hover_color if self.hovered else self.core_color)
        color.setAlpha(alpha)
        center_y = self.height() / 2
        origin = self.width() * (0.68 if self.direction < 0 else 0.32)
        x = origin + self.direction * self.progress * self.width() * 0.40
        tail = x - self.direction * 12

        # Halo suave para manter a seta legível nos fundos claro e azul sem
        # transformá-la em um botão ou aumentar demais seu tamanho.
        glow = QColor(self.glow_color)
        glow.setAlpha(max(10, alpha // 5))
        painter.setPen(QPen(glow, 4.8, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        painter.drawLine(int(tail), int(center_y), int(x), int(center_y))
        painter.drawLine(int(x), int(center_y), int(x - self.direction * 6), int(center_y - 6))
        painter.drawLine(int(x), int(center_y), int(x - self.direction * 6), int(center_y + 6))

        # Núcleo ligeiramente mais firme e halo contido: a forma permanece
        # moderna, mas ganha definição tanto no fundo claro quanto no escuro.
        painter.setPen(QPen(color, 3.2, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        painter.drawLine(int(tail), int(center_y), int(x), int(center_y))
        painter.drawLine(int(x), int(center_y), int(x - self.direction * 6), int(center_y - 6))
        painter.drawLine(int(x), int(center_y), int(x - self.direction * 6), int(center_y + 6))


class ThemeSwitch(QWidget):
    """Interruptor contínuo: posição, cores e símbolos mudam no mesmo movimento."""

    toggled = Signal(bool)

    def __init__(self, checked: bool = False, parent=None):
        super().__init__(parent)
        self._checked = bool(checked)
        self._knob_position = 0.0 if self._checked else 1.0
        self.setFixedSize(62, 32)
        self.setCursor(Qt.PointingHandCursor)
        self._refresh_accessibility()
        self._animation = QPropertyAnimation(self, b"knobPosition", self)
        self._animation.setDuration(420)
        self._animation.setEasingCurve(QEasingCurve.InOutCubic)
        self._loading = False

    def get_knob_position(self):
        return self._knob_position

    def set_knob_position(self, value):
        self._knob_position = float(value)
        self.update()

    knobPosition = Property(float, get_knob_position, set_knob_position)

    def isChecked(self):
        return self._checked

    def setChecked(self, checked: bool, animate: bool = False):
        checked = bool(checked)
        if checked == self._checked and not animate:
            self._knob_position = 0.0 if checked else 1.0
            self.update()
            return
        self._checked = checked
        self._refresh_accessibility()
        target = 0.0 if checked else 1.0
        if animate:
            self._animation.stop()
            self._animation.setStartValue(self._knob_position)
            self._animation.setEndValue(target)
            self._animation.start()
        else:
            self._knob_position = target
            self.update()

    def _refresh_accessibility(self):
        action = "Mudar para o modo claro" if self._checked else "Mudar para o modo escuro"
        self.setToolTip(action)
        self.setAccessibleName(action)

    def set_loading(self, loading: bool):
        self._loading = bool(loading)
        if self._loading:
            self.setCursor(Qt.ArrowCursor)
        else:
            self.setCursor(Qt.PointingHandCursor)
            self._refresh_accessibility()
        self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and not self._loading:
            self.setChecked(not self._checked, True)
            self.toggled.emit(self._checked)
        super().mouseReleaseEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        dark_progress = max(0.0, min(1.0, 1.0 - self._knob_position))

        def mix(light: str, dark: str, progress: float = dark_progress) -> QColor:
            a, b = QColor(light), QColor(dark)
            return QColor(
                round(a.red() + (b.red() - a.red()) * progress),
                round(a.green() + (b.green() - a.green()) * progress),
                round(a.blue() + (b.blue() - a.blue()) * progress),
            )

        track = self.rect().adjusted(1, 1, -1, -1)
        gradient = QLinearGradient(0, 0, self.width(), 0)
        gradient.setColorAt(0.0, mix("#EEF2F2", "#172631"))
        gradient.setColorAt(1.0, mix("#FFFFFF", "#29404F"))
        border = mix("#C3CFD2", "#4A697B")
        painter.setPen(QPen(border, 1.0))
        painter.setBrush(gradient)
        painter.drawRoundedRect(track, 16, 16)
        sun = QColor("#F6BE42"); sun.setAlpha(round(70 + 185 * (1.0 - dark_progress)))
        painter.setPen(QPen(sun, 1.25, Qt.SolidLine, Qt.RoundCap)); painter.setBrush(sun)
        painter.drawEllipse(10, 12, 7, 7)
        for dx, dy in ((0, -6), (0, 6), (-6, 0), (6, 0), (-4, -4), (4, 4), (-4, 4), (4, -4)):
            painter.drawLine(13 + dx, 15 + dy, 13 + int(dx * .72), 15 + int(dy * .72))
        moon = QColor("#F4CE6A"); moon.setAlpha(round(75 + 180 * dark_progress))
        painter.setPen(Qt.NoPen); painter.setBrush(moon); painter.drawEllipse(44, 10, 11, 12)
        painter.setBrush(mix("#FFFFFF", "#29404F")); painter.drawEllipse(41, 8, 10, 10)
        travel = self.width() - 30
        x = 3 + travel * self._knob_position
        painter.setPen(Qt.NoPen)
        shadow = QColor("#000000")
        shadow.setAlpha(45)
        painter.setBrush(shadow)
        painter.drawEllipse(int(x + 1), 5, 24, 24)
        painter.setBrush(mix("#FFFFFF", "#E7EEF2")); painter.setPen(QPen(mix("#B3C0C4", "#77909E"), 0.9))
        painter.drawEllipse(int(x), 3, 26, 26)


class LightningAccent(QWidget):
    """Raio vetorial leve que desce, ganha brilho e desaparece em pausas irregulares."""

    PAUSE_SEQUENCE = (2000, 5000, 3000, 2000, 4000, 5000)

    def __init__(self, dark_mode: bool, parent=None):
        super().__init__(parent)
        self._phase = 0.0
        self.dark_mode = bool(dark_mode)
        self._pause_index = 0
        self.setObjectName("brandLightning")
        self.setFixedSize(22, 52)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAccessibleName("Raio decorativo do Atlas")

        self._flash_animation = QPropertyAnimation(self, b"phase", self)
        self._flash_animation.setDuration(1050)
        self._flash_animation.setStartValue(0.0)
        self._flash_animation.setEndValue(1.0)
        self._flash_animation.setEasingCurve(QEasingCurve.Linear)
        self._flash_animation.finished.connect(self._finish_flash)

        self._pause_timer = QTimer(self)
        self._pause_timer.setSingleShot(True)
        self._pause_timer.timeout.connect(self._start_flash)
        self._schedule_next_flash()

    def get_phase(self) -> float:
        return self._phase

    def set_phase(self, value: float):
        self._phase = max(0.0, min(1.0, float(value)))
        self.update()

    phase = Property(float, get_phase, set_phase)

    def set_dark_mode(self, enabled: bool):
        self.dark_mode = bool(enabled)
        self.update()

    def _schedule_next_flash(self):
        delay = self.PAUSE_SEQUENCE[self._pause_index]
        self._pause_index = (self._pause_index + 1) % len(self.PAUSE_SEQUENCE)
        self._pause_timer.start(delay)

    def _start_flash(self):
        if not self.isVisible() or not self.window().isVisible():
            self._schedule_next_flash()
            return
        self._flash_animation.stop()
        self._flash_animation.start()

    def _finish_flash(self):
        self.set_phase(0.0)
        self._schedule_next_flash()

    @staticmethod
    def _bolt_path(points: tuple[tuple[float, float], ...]) -> QPainterPath:
        path = QPainterPath()
        path.moveTo(*points[0])
        for point in points[1:]:
            path.lineTo(*point)
        return path

    @staticmethod
    def _draw_glowing_path(painter: QPainter, path: QPainterPath, glow: QColor, core: QColor, intensity: float):
        for width, alpha in ((8.0, 24), (5.0, 48), (2.7, 150)):
            color = QColor(glow)
            color.setAlpha(round(alpha * intensity))
            pen = QPen(color)
            pen.setWidthF(width)
            pen.setCapStyle(Qt.RoundCap)
            pen.setJoinStyle(Qt.RoundJoin)
            painter.setPen(pen)
            painter.drawPath(path)
        center = QColor(core)
        center.setAlpha(round(255 * intensity))
        pen = QPen(center)
        pen.setWidthF(1.15)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        painter.setPen(pen)
        painter.drawPath(path)

    def paintEvent(self, _event):
        phase = self._phase
        if phase <= 0.0:
            return
        if phase < 0.42:
            reveal = phase / 0.42
            intensity = reveal * reveal
        elif phase < 0.64:
            reveal = 1.0
            # Dois pequenos picos dão ao clarão uma aparência elétrica sem
            # transformar o detalhe em uma animação acelerada ou repetitiva.
            intensity = 1.0 if phase < 0.50 or phase > 0.56 else 0.72
        else:
            reveal = 1.0
            intensity = max(0.0, (1.0 - phase) / 0.36)
        intensity *= 0.62

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
        painter.setClipRect(0, 0, self.width(), max(1, round(self.height() * reveal + 3)))

        glow = QColor("#2FB8FF" if self.dark_mode else "#36C995")
        core = QColor("#EAFDFF" if self.dark_mode else "#FFF2A8")
        branch = QColor("#71E9FF" if self.dark_mode else "#76E2B9")
        main_path = self._bolt_path(((12, 1), (8, 10), (12, 17), (6, 25), (11, 30), (7, 39), (13, 51)))
        self._draw_glowing_path(painter, main_path, glow, core, intensity)

        branch_intensity = intensity * 0.68
        for points in (
            ((9, 11), (4, 17), (6, 22)),
            ((8, 26), (3, 31), (5, 35)),
            ((9, 38), (17, 42), (16, 47)),
        ):
            self._draw_glowing_path(
                painter, self._bolt_path(points), branch, core, branch_intensity,
            )
        painter.end()


class AtlasSAccent(LightningAccent):
    """Letra S clássica, com corrente elétrica contínua e desenho vetorial."""

    def __init__(self, dark_mode: bool, parent=None, large: bool = False):
        super().__init__(dark_mode, parent)
        self.setObjectName("brandSAccent")
        self.setFixedSize(48 if large else 34, 60 if large else 42)
        self.setAccessibleName("Letra S elétrica da marca ATLAS")
        self._flash_animation.setDuration(2400)
        self._flash_animation.setLoopCount(-1)
        self._flash_animation.setEasingCurve(QEasingCurve.Linear)
        font = QFont("Georgia")
        font.setPixelSize(92)
        self._glyph = QPainterPath()
        self._glyph.addText(0, 0, font, "S")
        self._glyph_bounds = self._glyph.boundingRect()

    def _schedule_next_flash(self):
        # O S permanece vivo enquanto aparece na tela, sem pausas ou timer extra.
        pass

    def showEvent(self, event):
        super().showEvent(event)
        self._flash_animation.start()

    def hideEvent(self, event):
        self._flash_animation.stop()
        super().hideEvent(event)

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        phase = self._phase
        pulse = 0.5 + 0.5 * math.sin(2 * math.pi * phase)
        # Aproxima o S do A sem mudar o tamanho da letra nem cortar as descargas.
        join_offset = 4 if self.width() > 40 else 3

        # Descargas curtas, assimétricas e pouco frequentes acompanham o contorno.
        painter.save()
        painter.translate(-join_offset, 0)
        painter.scale(self.width() / 34.0, self.height() / 42.0)
        for index, (trunk, fork) in enumerate((
            (((11, 9), (8, 7), (9, 5), (6, 4)), ((8, 7), (6, 9))),
            (((23, 10), (26, 8), (25, 6), (28, 5)), ((26, 8), (28, 10))),
            (((24, 20), (27, 18), (26, 16), (29, 15)), ((27, 18), (29, 20))),
            (((10, 31), (7, 33), (8, 35), (5, 37)), ((7, 33), (5, 31))),
        )):
            wave = 0.5 + 0.5 * math.sin(2 * math.pi * (3 * phase) + index * 1.7)
            activity = 0.18 + 0.82 * wave ** 5
            painter.setBrush(Qt.NoBrush)
            for points, attenuation in ((trunk, 1.0), (fork, 0.52)):
                path = self._bolt_path(points)
                for width, alpha in ((3.0, 24), (1.2, 105), (0.55, 145)):
                    color = QColor("#4BCFFF" if width > 1 else "#DDF9FF")
                    color.setAlpha(round(alpha * activity * attenuation))
                    pen = QPen(color, width)
                    pen.setCapStyle(Qt.RoundCap)
                    pen.setJoinStyle(Qt.RoundJoin)
                    painter.setPen(pen)
                    painter.drawPath(path)
        painter.restore()

        # O contorno do próprio glifo forma o S; a eletricidade corre sobre ele.
        glyph = self._glyph
        bounds = self._glyph_bounds
        if bounds.isEmpty():
            painter.end()
            return
        scale = min((self.width() - 12) / bounds.width(), (self.height() - 12) / bounds.height())
        painter.save()
        painter.translate((self.width() - bounds.width() * scale) / 2 - join_offset,
                          (self.height() - bounds.height() * scale) / 2)
        painter.scale(scale, scale)
        painter.translate(-bounds.left(), -bounds.top())
        painter.setBrush(Qt.NoBrush)
        for width, alpha in ((10, 14), (4, 32), (1.7, 72)):
            color = QColor("#2CCFFF")
            color.setAlpha(round(alpha * (0.65 + 0.35 * pulse)))
            pen = QPen(color, width)
            pen.setJoinStyle(Qt.RoundJoin)
            painter.setPen(pen)
            painter.drawPath(glyph)
        gradient = QLinearGradient(bounds.left(), bounds.top(), bounds.left(), bounds.bottom())
        gradient.setColorAt(0, QColor("#FFFFFF"))
        gradient.setColorAt(0.58, QColor("#ECFCFF"))
        gradient.setColorAt(1, QColor("#B7EDFF"))
        painter.setPen(Qt.NoPen)
        painter.setBrush(gradient)
        painter.drawPath(glyph)
        painter.restore()
        painter.end()


class LoginPage(QWidget):
    selected = Signal(str, str, str)
    reset_requested = Signal()
    lateral_requested = Signal()
    exit_requested = Signal()

    def __init__(self):
        super().__init__()
        root = QGridLayout(self)
        self.login_root = root
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.setColumnStretch(0, 5)
        root.setColumnStretch(1, 6)

        self.hero = QFrame(objectName="hero")
        hero = self.hero
        hero_box = QVBoxLayout(hero)
        hero_box.setContentsMargins(48, 34, 48, 36)
        hero_box.addStretch()
        logo = QLabel()
        self.hero_logo = logo
        logo.setObjectName("heroBrandMark")
        logo.setFixedSize(300, 300)
        logo.setPixmap(atlas_brand_pixmap(
            "logo_full_dark.png" if bool(load_json_cache(theme_settings_path()).get("dark", False))
            else "logo_full_light.png", 300,
        ))
        hero_box.addWidget(logo, 0, Qt.AlignLeft)
        eyebrow = QLabel("CENTRAL DE OPERAÇÕES TÉCNICAS")
        eyebrow.setObjectName("heroEyebrow")
        hero_box.addWidget(eyebrow)
        hero_title_row = QHBoxLayout()
        hero_title_row.setContentsMargins(0, 0, 0, 0)
        hero_title_row.setSpacing(2)
        title = QLabel("ATLA")
        title.setObjectName("heroTitle")
        hero_title_row.addWidget(title, 0, Qt.AlignVCenter)
        self.hero_lightning = AtlasSAccent(True, hero, large=True)
        hero_title_row.addWidget(self.hero_lightning, 0, Qt.AlignVCenter)
        hero_title_row.addStretch(1)
        hero_box.addLayout(hero_title_row)
        hero_subtitle = QLabel("SUPORTE AVANÇADO")
        hero_subtitle.setObjectName("heroSubtitle")
        hero_box.addWidget(hero_subtitle)
        desc = QLabel("Diagnóstico, suporte remoto e gestão segura do ambiente corporativo em uma experiência única.")
        desc.setWordWrap(True)
        desc.setObjectName("heroDescription")
        hero_box.addWidget(desc)
        hero_box.addStretch()
        stripe = QFrame(objectName="stripe")
        stripe.setFixedHeight(8)
        hero_box.addWidget(stripe)
        root.addWidget(hero, 0, 0)

        self.panel = QFrame(objectName="loginPanel")
        panel = self.panel
        panel_outer = QHBoxLayout(panel)
        panel_outer.setContentsMargins(0, 0, 0, 0)
        panel_outer.addStretch(1)
        self.login_content = QWidget(panel)
        self.login_content.setMaximumWidth(650)
        self.login_content.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        panel_outer.addWidget(self.login_content)
        panel_outer.addStretch(1)
        self.login_box = QVBoxLayout(self.login_content)
        box = self.login_box
        box.setContentsMargins(70, 55, 70, 55)
        self.dark_mode = bool(load_json_cache(theme_settings_path()).get("dark", False))
        self.pending_theme_mode = None
        self.login_theme_button = ThemeSwitch(self.dark_mode, self.panel)
        self.login_theme_button.toggled.connect(self.set_login_theme)
        self.login_theme_label = QLabel("Modo escuro", self.panel)
        self.login_theme_label.setObjectName("themeLabel")
        self.login_settings_button = QPushButton(self.panel)
        self.login_settings_button.setObjectName("loginTopActionButton")
        self.login_settings_button.setFixedSize(28, 28)
        self.login_settings_button.setToolTip("Configurações")
        self.login_settings_button.setAccessibleName("Configurações do Atlas")
        self.login_settings_button.clicked.connect(lambda: open_browser_settings_dialog(self))
        self.login_exit_software_button = QPushButton(self.panel)
        self.login_exit_software_button.setObjectName("loginExitSoftwareButton")
        self.login_exit_software_button.setFixedSize(44, 44)
        self.login_exit_software_button.setToolTip("Sair do software e encerrar a sessão do Capri")
        self.login_exit_software_button.setAccessibleName("Sair do software e encerrar a sessão do Capri")
        self.login_exit_software_button.clicked.connect(self.exit_requested.emit)
        self.refresh_login_theme_icon()
        self.login_settings_button.raise_()
        self.login_exit_software_button.raise_()
        self.login_theme_button.raise_()
        box.addStretch()
        self.compact_logo = QLabel()
        self._compact_brand_size = 176
        self.compact_logo.setFixedSize(self._compact_brand_size, self._compact_brand_size)
        self.compact_logo.setPixmap(atlas_brand_pixmap(
            "logo_compact_dark.png" if self.dark_mode else "logo_compact_light.png",
            self._compact_brand_size,
        ))
        self.compact_logo.hide()
        box.addWidget(self.compact_logo, 0, Qt.AlignHCenter)
        eyebrow = QLabel("PORTAL DE ACESSO SEGURO")
        eyebrow.setObjectName("loginEyebrow")
        box.addWidget(eyebrow)
        heading = QLabel("Bem-vindo ao Atlas")
        heading.setObjectName("pageTitle")
        box.addWidget(heading)
        sub = QLabel("Assistência Técnica e Lógica de Apoio ao Senado")
        sub.setObjectName("muted")
        box.addWidget(sub)
        identity = QFrame()
        identity.setObjectName("identityCard")
        identity_row = QHBoxLayout(identity)
        identity_row.setContentsMargins(15, 13, 15, 13)
        identity_row.setSpacing(12)
        identity_icon = QLabel()
        identity_icon.setObjectName("loginCardIcon")
        identity_icon.setFixedSize(38, 38)
        identity_icon.setAlignment(Qt.AlignCenter)
        identity_icon.setPixmap(modern_icon("user", GREEN, 20).pixmap(20, 20))
        identity_row.addWidget(identity_icon)
        identity_text = QVBoxLayout()
        identity_text.setSpacing(2)
        identity_caption = QLabel("IDENTIDADE ATUAL")
        identity_caption.setObjectName("loginCardCaption")
        identity_text.addWidget(identity_caption)
        identity_value = QLabel(windows_identity())
        identity_value.setObjectName("loginCardValue")
        identity_text.addWidget(identity_value)
        identity_row.addLayout(identity_text, 1)
        identity_ok = QLabel()
        identity_ok.setObjectName("loginCardStatusIcon")
        identity_ok.setFixedSize(28, 28)
        identity_ok.setAlignment(Qt.AlignCenter)
        identity_ok.setPixmap(modern_icon("check", GREEN, 15).pixmap(15, 15))
        identity_row.addWidget(identity_ok)
        box.addSpacing(20)
        box.addWidget(identity)
        self.standard_user, self.ins_user = profile_usernames()
        current = windows_identity().lower()

        ins_card = QFrame(objectName="loginProfileCard")
        ins_box = QVBoxLayout(ins_card)
        ins_box.setContentsMargins(15, 13, 15, 13)
        ins_box.setSpacing(4)
        ins_header = QHBoxLayout()
        ins_icon = QLabel()
        ins_icon.setObjectName("loginCardIcon")
        ins_icon.setFixedSize(34, 34)
        ins_icon.setAlignment(Qt.AlignCenter)
        ins_icon.setPixmap(modern_icon("shield", BLUE_2, 18).pixmap(18, 18))
        ins_header.addWidget(ins_icon)
        ins_header_text = QVBoxLayout()
        ins_header_text.setSpacing(1)
        ins_name = QLabel("SESSÃO ADMINISTRATIVA INS")
        ins_name.setObjectName("profileName")
        ins_header_text.addWidget(ins_name)
        ins_account = QLabel(self.ins_user)
        ins_account.setObjectName("profileAccount")
        ins_header_text.addWidget(ins_account)
        ins_header.addLayout(ins_header_text, 1)
        ins_box.addLayout(ins_header)
        ins_status = "Sessão atual — entrada imediata" if current == self.ins_user.lower() else (
            "Acesso salvo no Windows" if credential_read(self.ins_user) else "A senha será solicitada somente no primeiro acesso"
        )
        ins_hint = QLabel(ins_status)
        ins_hint.setObjectName("profileStatus")
        ins_hint.setWordWrap(True)
        ins_box.addWidget(ins_hint)
        box.addWidget(ins_card)
        ins = QPushButton("Autenticar como INS")
        ins.setObjectName("primaryButton")
        set_button_icon(ins, "lock", "#FFFFFF", 17)
        ins.clicked.connect(lambda: self.selected.emit("ins", self.ins_user, ""))
        box.addWidget(ins)
        note = QLabel("As credenciais são protegidas pelo Gerenciador de Credenciais do Windows e não são gravadas nos arquivos da ferramenta.")
        note.setWordWrap(True)
        note.setObjectName("smallMuted")
        box.addSpacing(8)
        box.addWidget(note)
        reset = QPushButton("Redefinir acessos salvos")
        reset.setObjectName("linkButton")
        set_button_icon(reset, "refresh", GREEN, 15)
        reset.clicked.connect(self.reset_requested.emit)
        box.addWidget(reset)

        self.side_arrow = AnimatedSideModeButton(
            self,
            core_color="#00305C",
            hover_color="#0E527F",
            glow_color="#0E527F",
        )
        self.side_arrow.clicked.connect(self.lateral_requested.emit)
        self.side_arrow.raise_()
        self.refresh_login_theme_icon()
        box.addStretch()
        footer = QLabel(
            f"Atlas  •  v{VERSION}<br>"
            "Software desenvolvido por "
            '<a style="color:#22B982; text-decoration:none;" href="https://www.linkedin.com/in/alemagnobr/">Alexandre Linhares</a> e '
            '<a style="color:#22B982; text-decoration:none;" href="https://www.linkedin.com/in/joaocerq/">João Cerqueira</a>'
        )
        footer.setObjectName("loginFooter")
        footer.setTextFormat(Qt.RichText)
        footer.setTextInteractionFlags(Qt.TextBrowserInteraction)
        footer.setOpenExternalLinks(False)
        footer.linkActivated.connect(self.open_credit_link)
        box.addWidget(footer)
        root.addWidget(panel, 0, 1)

    def open_credit_link(self, url: str):
        opened, _used_browser, _used_fallback = launch_external_url(url)
        if not opened:
            show_notice(self, "Não foi possível abrir o perfil do LinkedIn.")

    def resizeEvent(self, event):
        super().resizeEvent(event)
        compact = self.width() < 900
        self.hero.setVisible(not compact)
        self.login_root.setColumnStretch(0, 0 if compact else 5)
        self.login_root.setColumnStretch(1, 1 if compact else 6)
        self.compact_logo.setVisible(compact)
        if compact:
            size = 192 if self.height() >= 900 else (166 if self.height() >= 720 else 128)
            if size != self._compact_brand_size:
                self._compact_brand_size = size
                self.compact_logo.setFixedSize(size, size)
                self.compact_logo.setPixmap(atlas_brand_pixmap(
                    "logo_compact_dark.png" if self.dark_mode else "logo_compact_light.png", size,
                ))
        margin = 24 if compact else 70
        vertical = 22 if compact else 55
        self.login_box.setContentsMargins(margin, vertical, margin, vertical)
        # Reserva o rodapé para os créditos e mantém a seta logo acima deles.
        self.side_arrow.move(20, max(8, self.height() - self.side_arrow.height() - 82))
        self.side_arrow.raise_()
        self.position_login_top_controls()
        self.login_settings_button.raise_()
        self.login_exit_software_button.move(
            max(12, self.panel.width() - self.login_exit_software_button.width() - 16),
            max(12, self.panel.height() - self.login_exit_software_button.height() - 16),
        )
        self.login_exit_software_button.raise_()
        self.login_theme_label.raise_()
        self.login_theme_button.raise_()

    def position_login_top_controls(self):
        self.login_theme_button.move(max(12, self.panel.width() - 58), 16)
        self.login_theme_label.adjustSize()
        label_x = max(48, self.login_theme_button.x() - self.login_theme_label.width() - 9)
        self.login_theme_label.move(label_x, 19)
        self.login_settings_button.move(max(10, label_x - 36), 14)

    def refresh_login_theme_icon(self):
        self.login_theme_button.setChecked(self.dark_mode)
        self.login_theme_label.setText("Modo claro" if self.dark_mode else "Modo escuro")
        set_button_icon(
            self.login_settings_button, "gear",
            "#63D4F2" if self.dark_mode else BLUE, 15,
        )
        set_button_icon(
            self.login_exit_software_button, "power",
            "#FF9DAA" if self.dark_mode else RED, 21,
        )
        if hasattr(self, "side_arrow"):
            self.side_arrow.core_color = "#35BCEB" if self.dark_mode else BLUE
            self.side_arrow.hover_color = "#59D4F5" if self.dark_mode else "#0E527F"
            self.side_arrow.glow_color = "#35BCEB" if self.dark_mode else "#0E527F"
            self.side_arrow.update()

    def set_login_theme(self, enabled: bool):
        if self.pending_theme_mode is not None:
            return
        self.pending_theme_mode = bool(enabled)
        self.login_theme_button.set_loading(True)
        self.position_login_top_controls()
        fade_theme_change(
            self, self.panel,
            self.apply_pending_login_theme,
            self.finish_login_theme_change,
        )

    def apply_pending_login_theme(self):
        if self.pending_theme_mode is None:
            return
        self.dark_mode = self.pending_theme_mode
        apply_application_theme(self.dark_mode, refresh_icons=False)
        self.hero_logo.setPixmap(atlas_brand_pixmap(
            "logo_full_dark.png" if self.dark_mode else "logo_full_light.png", 300,
        ))
        self.compact_logo.setPixmap(atlas_brand_pixmap(
            "logo_compact_dark.png" if self.dark_mode else "logo_compact_light.png",
            self._compact_brand_size,
        ))
        save_json_cache(theme_settings_path(), {"dark": self.dark_mode})
        refresh_themed_button_icons()

    def finish_login_theme_change(self):
        self.pending_theme_mode = None
        self.refresh_login_theme_icon()
        self.login_theme_button.set_loading(False)
        self.position_login_top_controls()

    def set_side_direction(self, direction: int):
        self.side_arrow.set_direction(direction)

class BusySpinner(QWidget):
    """Indicador circular leve, desenhado sem imagens externas."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.angle = 0
        self.setFixedSize(30, 30)
        self.timer = QTimer(self)
        self.timer.setInterval(75)
        self.timer.timeout.connect(self.advance)

    def start(self):
        self.angle = 0
        self.timer.start()
        self.show()

    def stop(self):
        self.timer.stop()
        self.hide()

    def advance(self):
        self.angle = (self.angle + 1) % 10
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.translate(self.width() / 2, self.height() / 2)
        for index in range(10):
            distance = (index - self.angle) % 10
            color = QColor(GREEN_2)
            color.setAlpha(max(45, 255 - distance * 22))
            painter.setBrush(color)
            painter.setPen(Qt.NoPen)
            painter.save()
            painter.rotate(index * 36)
            painter.drawEllipse(9, -2, 4, 4)
            painter.restore()


class HoverFadeButton(QPushButton):
    """Botão lateral com transição de opacidade leve no hover."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.hover_effect = QGraphicsOpacityEffect(self)
        self.hover_effect.setOpacity(0.88)
        self.setGraphicsEffect(self.hover_effect)
        self.hover_fade = QPropertyAnimation(self.hover_effect, b"opacity", self)
        self.hover_fade.setDuration(190)
        self.hover_fade.setEasingCurve(QEasingCurve.InOutCubic)

    def _fade_to(self, value: float):
        self.hover_fade.stop()
        self.hover_fade.setStartValue(self.hover_effect.opacity())
        self.hover_fade.setEndValue(value)
        self.hover_fade.start()

    def enterEvent(self, event):
        self._fade_to(1.0)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._fade_to(0.88)
        super().leaveEvent(event)


class BalancedTabBar(QTabBar):
    """Divide a largura disponível igualmente entre todas as abas."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setExpanding(True)
        self.setUsesScrollButtons(False)
        self.setElideMode(Qt.ElideRight)
        self.setMinimumWidth(0)
        self.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        self.setMinimumHeight(38)

    def tabSizeHint(self, index: int) -> QSize:
        size = super().tabSizeHint(index)
        count = self.count()
        host = self.parentWidget()
        # A largura do próprio QTabBar pode ser 1 ou 2 px durante a primeira
        # negociação do layout. Usá-la aqui fazia as duas abas desaparecerem.
        # O QTabWidget já possui a largura útil correta e é a única referência.
        available = host.contentsRect().width() if host is not None else 0
        if count > 0 and available > 2:
            size.setWidth(max(1, available // count))
        return size

    def minimumTabSizeHint(self, index: int) -> QSize:
        # Nunca herda a largura anterior do QTabWidget. A implementação
        # anterior devolvia metade da janela normal como mínimo de cada aba e
        # impedia todo o painel de encolher ao entrar no modo lateral.
        size = super().minimumTabSizeHint(index)
        size.setWidth(0)
        return size

    def minimumSizeHint(self) -> QSize:
        size = super().minimumSizeHint()
        size.setWidth(0)
        return size

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.updateGeometry()


class BalancedTabWidget(QTabWidget):
    """Mantém a barra de abas ocupando toda a largura real do card."""

    def _fit_tab_bar(self):
        bar = self.tabBar()
        available = max(0, self.contentsRect().width())
        if available > 2 and bar.width() != available:
            bar.setFixedWidth(available)
        bar.updateGeometry()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._fit_tab_bar()

    def showEvent(self, event):
        super().showEvent(event)
        QTimer.singleShot(0, self._fit_tab_bar)


class QuickActionButton(QPushButton):
    """Atalho lateral compacto com resposta visual ao clique."""

    def __init__(self, icon_name: str, tooltip: str, parent=None):
        super().__init__(parent)
        self.icon_name = icon_name
        self.icon_color = "#FFFFFF"
        self.loading = False
        self.loading_started = 0.0
        self.spinner_step = 0
        set_button_icon(self, icon_name, self.icon_color, 20)
        self.setObjectName("quickActionButton")
        self.setToolTip(tooltip)
        self.setAccessibleName(tooltip)
        self.setFixedSize(44, 42)
        self.effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.effect)
        self.animation = QPropertyAnimation(self.effect, b"opacity", self)
        self.animation.setDuration(360)
        self.animation.setKeyValueAt(0.0, 1.0)
        self.animation.setKeyValueAt(0.45, 0.28)
        self.animation.setKeyValueAt(1.0, 1.0)
        self.animation.setEasingCurve(QEasingCurve.InOutSine)
        self.clicked.connect(self.animate_click)
        self.clicked.connect(self.begin_loading)
        self.spinner_timer = QTimer(self)
        self.spinner_timer.setInterval(70)
        self.spinner_timer.timeout.connect(self.advance_spinner)
        self.hover_animation = QPropertyAnimation(self.effect, b"opacity", self)
        self.hover_animation.setDuration(180)
        self.hover_animation.setEasingCurve(QEasingCurve.InOutCubic)

    def _hover_to(self, value: float):
        if self.loading:
            return
        self.hover_animation.stop()
        self.hover_animation.setStartValue(self.effect.opacity())
        self.hover_animation.setEndValue(value)
        self.hover_animation.start()

    def enterEvent(self, event):
        self._hover_to(1.0)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hover_to(0.82)
        super().leaveEvent(event)

    def animate_click(self):
        self.hover_animation.stop()
        self.animation.stop()
        self.animation.start()

    def begin_loading(self):
        if self.loading:
            return
        self.loading = True
        self.loading_started = time.monotonic()
        self.spinner_step = 0
        self.spinner_timer.start()
        self.advance_spinner()

    def advance_spinner(self):
        pixmap = QPixmap(22, 22)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.translate(11, 11)
        for index in range(10):
            distance = (index - self.spinner_step) % 10
            color = QColor("#73F7BB")
            color.setAlpha(max(45, 255 - distance * 23))
            painter.setBrush(color)
            painter.setPen(Qt.NoPen)
            painter.save()
            painter.rotate(index * 36)
            painter.drawEllipse(7, -2, 4, 4)
            painter.restore()
        painter.end()
        self.setIcon(QIcon(pixmap))
        self.setIconSize(QSize(22, 22))
        self.spinner_step = (self.spinner_step + 1) % 10

    def end_loading(self):
        if not self.loading:
            return
        remaining = max(0, int(520 - (time.monotonic() - self.loading_started) * 1000))
        if remaining:
            QTimer.singleShot(remaining, self._finish_loading)
        else:
            self._finish_loading()

    def _finish_loading(self):
        self.spinner_timer.stop()
        self.loading = False
        set_button_icon(self, self.icon_name, self.icon_color, 20)

    def set_icon_state(self, icon_name: str, color: str = "#FFFFFF"):
        self.icon_name = icon_name
        self.icon_color = color
        if not self.loading:
            set_button_icon(self, icon_name, color, 20)


class CopyableInfoFrame(QFrame):
    """Superfície informativa que copia seu valor sem capturar botões internos."""

    def __init__(self, parent=None, **kwargs):
        super().__init__(parent, **kwargs)
        self._copy_value = ""
        self._copy_enabled = True
        self.setCursor(Qt.PointingHandCursor)
        self.setAccessibleDescription("Clique para copiar esta informação")

    def set_copy_enabled(self, enabled: bool):
        self._copy_enabled = enabled
        self.setCursor(Qt.PointingHandCursor if enabled else Qt.ArrowCursor)
        self.setAccessibleDescription("Clique para copiar esta informação" if enabled else "")

    def register_copy_surface(self, widget: QWidget):
        """Inclui apenas áreas de leitura; controles de ação ficam independentes."""
        widget.installEventFilter(self)

    def set_copy_value(self, value: object):
        self._copy_value = str(value or "").strip()

    def copy_information(self, *_args, global_position=None):
        if not self._copy_enabled or not self._copy_value:
            return
        QApplication.clipboard().setText(self._copy_value)
        position = global_position or self.mapToGlobal(self.rect().center())
        QToolTip.showText(position, "Informação copiada", self, self.rect(), 950)

    def eventFilter(self, watched, event):
        if self._copy_enabled and event.type() == QEvent.Type.MouseButtonRelease and event.button() == Qt.LeftButton:
            self.copy_information(global_position=event.globalPosition().toPoint())
            return True
        return super().eventFilter(watched, event)

    def mouseReleaseEvent(self, event):
        if self._copy_enabled and event.button() == Qt.LeftButton:
            self.copy_information(global_position=event.globalPosition().toPoint())
            event.accept()
            return
        super().mouseReleaseEvent(event)


class UserDataFieldCard(CopyableInfoFrame):
    """Campo compacto do painel de usuário, com leitura e seleção acessíveis."""

    def __init__(self, caption: str, parent=None, copy_on_click: bool = True):
        super().__init__(parent)
        self.caption = caption
        self.set_copy_enabled(copy_on_click)
        self.setObjectName("userFieldCard")
        self.setMinimumWidth(0)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 7, 10, 8)
        layout.setSpacing(3)
        self.caption_label = QLabel(caption)
        self.caption_label.setObjectName("userFieldCaption")
        self.caption_label.setWordWrap(True)
        layout.addWidget(self.caption_label)
        self.value_label = QLabel("Não informado")
        self.value_label.setObjectName("userFieldValue")
        self.value_label.setTextFormat(Qt.PlainText)
        self.value_label.setWordWrap(True)
        self.value_label.setMinimumWidth(0)
        self.value_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.value_label)
        self.register_copy_surface(self.caption_label)
        self.register_copy_surface(self.value_label)
        self.set_copy_value(f"{caption}: Não informado")
        if copy_on_click:
            self.setToolTip("Clique no cartão para copiar título e informação")

    def set_value(self, value: object):
        visible = str(value or "").strip() or "Não informado"
        self.value_label.setText(visible)
        self.set_copy_value(f"{self.caption}: {visible}")
        self.value_label.setToolTip(visible if len(visible) > 34 else "")


class StationDataFieldCard(QFrame):
    """Campo compacto da estação com título e valor em hierarquia visual."""

    def __init__(self, caption: str, parent=None, action_icon: str = "", action_tooltip: str = ""):
        super().__init__(parent)
        self.setObjectName("stationDataFieldCard")
        self.setMinimumWidth(0)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(7, 4, 7, 5)
        layout.setSpacing(7)
        text_layout = QVBoxLayout()
        text_layout.setSpacing(1)
        self.caption_label = QLabel(caption)
        self.caption_label.setObjectName("statusFieldCaption")
        self.caption_label.setWordWrap(True)
        text_layout.addWidget(self.caption_label)
        self.value_label = QLabel("—")
        self.value_label.setObjectName("statusFieldValue")
        self.value_label.setTextFormat(Qt.PlainText)
        self.value_label.setWordWrap(True)
        self.value_label.setMinimumWidth(0)
        self.value_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        text_layout.addWidget(self.value_label)
        layout.addLayout(text_layout, 1)
        self.action_button = None
        self.actions_layout = QHBoxLayout()
        self.actions_layout.setSpacing(4)
        if action_icon:
            self.action_button = QPushButton()
            self.action_button.setObjectName("printerQuickButton")
            self.action_button.setFixedSize(26, 26)
            self.action_button.setToolTip(action_tooltip)
            self.action_button.setAccessibleName(action_tooltip)
            self.action_button.setEnabled(False)
            set_button_icon(self.action_button, action_icon, GREEN, 14)
            self.actions_layout.addWidget(self.action_button)
        layout.addLayout(self.actions_layout, 0)

    def set_value(self, value: object):
        visible = str(value or "").strip() or "—"
        self.value_label.setText(visible)
        self.value_label.setToolTip(visible if len(visible) > 34 else "")


class PasswordExpiryStatusCard(CopyableInfoFrame):
    """Status do AD com ações para recuperação por e-mail e acesso ao PWM."""

    recovery_requested = Signal()
    pwm_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("userPasswordExpiryCard")
        self.setMinimumWidth(0)
        self.expired = False
        self.recovery_available = False
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 7, 10, 8)
        layout.setSpacing(3)
        caption = QLabel("Senha expirada")
        caption.setObjectName("userFieldCaption")
        layout.addWidget(caption)
        self.register_copy_surface(caption)
        value_row = QHBoxLayout()
        value_row.setContentsMargins(0, 0, 0, 0)
        value_row.setSpacing(6)
        self.action = QPushButton("Não informado")
        self.action.setObjectName("passwordExpiryAction")
        self.action.setProperty("expiryState", "unknown")
        self.action.setFlat(True)
        self.action.setCursor(Qt.PointingHandCursor)
        self.action.setAccessibleName("Estado de expiração da senha")
        self.action.clicked.connect(self.copy_information)
        value_row.addWidget(self.action, 1, Qt.AlignLeft)
        self.recovery_button = QPushButton()
        self.recovery_button.setObjectName("passwordRecoveryButton")
        self.recovery_button.setFixedSize(26, 26)
        self.recovery_button.setEnabled(False)
        self.recovery_button.setCursor(Qt.ArrowCursor)
        self.recovery_button.setToolTip("Encaminhar e-mail de redefinição de senha")
        self.recovery_button.setAccessibleName("Encaminhar e-mail de redefinição de senha")
        set_button_icon(self.recovery_button, "mail", GREEN, 13)
        self.recovery_button.clicked.connect(self._activate)
        value_row.addWidget(self.recovery_button, 0, Qt.AlignRight | Qt.AlignVCenter)
        self.pwm_button = QPushButton("PWM")
        self.pwm_button.setObjectName("passwordManagerOpenButton")
        self.pwm_button.setFixedSize(43, 26)
        self.pwm_button.setCursor(Qt.PointingHandCursor)
        self.pwm_button.setToolTip("Abrir o Gestor de Senhas (PWM) no navegador configurado")
        self.pwm_button.setAccessibleName("Abrir o Gestor de Senhas PWM")
        self.pwm_button.clicked.connect(self.pwm_requested.emit)
        value_row.addWidget(self.pwm_button, 0, Qt.AlignRight | Qt.AlignVCenter)
        layout.addLayout(value_row)
        self.opacity = QGraphicsOpacityEffect(self.action)
        self.action.setGraphicsEffect(self.opacity)
        self.pulse = QPropertyAnimation(self.opacity, b"opacity", self)
        self.pulse.setDuration(1250)
        self.pulse.setLoopCount(-1)
        self.pulse.setEasingCurve(QEasingCurve.InOutSine)
        self.pulse.setKeyValueAt(0.0, 1.0)
        self.pulse.setKeyValueAt(0.5, 0.38)
        self.pulse.setKeyValueAt(1.0, 1.0)

    @staticmethod
    def _normalized(value: object) -> str:
        normalized = unicodedata.normalize("NFKD", str(value or "").strip())
        return "".join(char for char in normalized if not unicodedata.combining(char)).casefold()

    def set_state(self, value: object):
        visible_value = str(value or "").strip()
        normalized = self._normalized(value)
        self.pulse.stop()
        self.opacity.setOpacity(1.0)
        if normalized in {"true", "verdadeiro", "sim", "yes"}:
            self.expired = True
            text, state = "SIM", "expired"
            tooltip = "A senha está expirada segundo o Active Directory."
        elif normalized in {"false", "falso", "nao", "no"}:
            self.expired = False
            text, state = "NÃO", "valid"
            tooltip = "A senha está vigente segundo o Active Directory."
        else:
            self.expired = False
            text = visible_value or "Não informado"
            state = "unknown"
            tooltip = "O Active Directory não informou o estado da senha."
        self.action.setText(text)
        self.set_copy_value(f"Senha expirada: {text}")
        self.action.setProperty("expiryState", state)
        self.action.setToolTip(tooltip)
        self.action.setCursor(Qt.PointingHandCursor)
        self.action.style().unpolish(self.action)
        self.action.style().polish(self.action)
        self.recovery_available = state in {"expired", "valid"}
        self.recovery_button.setEnabled(self.recovery_available)
        self.recovery_button.setCursor(Qt.PointingHandCursor if self.recovery_available else Qt.ArrowCursor)
        if state in {"expired", "valid"}:
            self.pulse.start()

    def _activate(self):
        if self.recovery_available:
            self.recovery_requested.emit()


class AdminStatusWidget(QFrame):
    toggle_requested = Signal()

    def __init__(self, caption: str, parent=None):
        super().__init__(parent)
        self.setObjectName("stationDataFieldCard")
        self.is_admin = None
        row = QHBoxLayout(self)
        row.setContentsMargins(7, 4, 7, 5)
        row.setSpacing(7)
        text_layout = QVBoxLayout()
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(1)
        self.caption_label = QLabel(caption)
        self.caption_label.setObjectName("statusFieldCaption")
        self.caption_label.setWordWrap(True)
        text_layout.addWidget(self.caption_label)
        self.value_label = QLabel("—")
        self.value_label.setObjectName("statusFieldValue")
        self.value_label.setWordWrap(True)
        self.value_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        text_layout.addWidget(self.value_label)
        row.addLayout(text_layout, 1)

        indicator = QHBoxLayout()
        indicator.setSpacing(3)
        self.dot = QLabel("●")
        self.dot.setObjectName("adminNeutralDot")
        self.dot.setAlignment(Qt.AlignCenter)
        self.dot.setFixedSize(14, 18)
        indicator.addWidget(self.dot)
        self.lock_button = QPushButton()
        self.lock_button.setObjectName("adminLockButton")
        self.lock_button.setFixedSize(26, 26)
        self.lock_button.setEnabled(False)
        self.lock_button.clicked.connect(self.toggle_requested.emit)
        # O status_card já usa QGraphicsOpacityEffect. Efeitos gráficos
        # aninhados apagam o cadeado no Windows; alternar só a cor do glifo
        # conserva o pulso visual do botão de impressoras.
        self.lock_pulse_timer = QTimer(self)
        self.lock_pulse_timer.setInterval(50)
        self.lock_pulse_timer.timeout.connect(self.advance_lock_pulse)
        self.lock_pulse_phase = 0
        indicator.addWidget(self.lock_button)
        row.addLayout(indicator)

    def advance_lock_pulse(self):
        if self.is_admin is None or not self.lock_button.isEnabled():
            self.lock_pulse_timer.stop()
            return
        self.lock_pulse_phase = (self.lock_pulse_phase + 1) % 25
        self.paint_lock_state()

    def paint_lock_state(self):
        if not self.lock_button.isEnabled():
            color = "#778B99"
            icon = "lock" if self.is_admin is not False else "unlock"
        elif self.is_admin is True:
            color = self._pulse_color("#11A866", "#75DDB0")
            icon = "lock"
        elif self.is_admin is False:
            color = self._pulse_color("#D74757", "#F2919B")
            icon = "unlock"
        else:
            color = "#778B99"
            icon = "lock"
        set_button_icon(self.lock_button, icon, color, 16)
        self.dot.setStyleSheet(f"color: {color}; background: transparent; border: none;")

    def _pulse_color(self, bright: str, faded: str) -> str:
        progress = (1.0 - math.cos(2.0 * math.pi * self.lock_pulse_phase / 25)) / 2.0
        first, second = QColor(bright), QColor(faded)
        return QColor(
            round(first.red() * (1 - progress) + second.red() * progress),
            round(first.green() * (1 - progress) + second.green() * progress),
            round(first.blue() * (1 - progress) + second.blue() * progress),
        ).name()

    def set_status(self, caption: str, value: str):
        self.caption_label.setText(caption)
        self.value_label.setText(value)
        normalized = value.strip().upper()
        self.is_admin = True if normalized.startswith("SIM") else False if normalized in {"NÃO", "NAO"} else None
        self.lock_pulse_phase = 0
        self.paint_lock_state()
        if self.is_admin is True:
            self.lock_button.setToolTip("Remover de Admin local e atualizar informações")
            object_name = "adminGreenDot"
        elif self.is_admin is False:
            self.lock_button.setToolTip("Adicionar como Admin local e atualizar informações")
            object_name = "adminRedDot"
        else:
            self.lock_button.setToolTip("Atualizar informações de Admin local")
            object_name = "adminNeutralDot"
        self.dot.setObjectName(object_name)
        self.dot.style().unpolish(self.dot)
        self.dot.style().polish(self.dot)
        if self.is_admin is None:
            self.lock_pulse_timer.stop()

    def set_connected(self, connected: bool):
        self.lock_button.setEnabled(connected)
        if connected and self.is_admin is not None:
            if not self.lock_pulse_timer.isActive():
                self.lock_pulse_phase = 0
                self.paint_lock_state()
                self.lock_pulse_timer.start()
        else:
            self.lock_pulse_timer.stop()
            self.lock_pulse_phase = 0
            self.paint_lock_state()


class ActionCard(QFrame):
    triggered = Signal(object)

    def __init__(self, action: Action):
        super().__init__(objectName="actionCard")
        self.action = action
        self.setProperty("featuredRepair", action.command == "atlas_repair")
        self.setProperty("available", True)
        self.compact = False
        self.setCursor(Qt.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.card_layout = QGridLayout(self)
        icons = {
            "connect_toggle": "remote", "cmrc": "remote", "ping": "ping", "open_remote": "settings",
            "admin": "lock", "local_users": "users", "ad": "user", "ad_groups": "users",
            "disk_profiles": "disk", "inetcpl": "internet", "refresh": "refresh",
            "browser_open_chrome_cleanup": "internet", "browser_open_edge_cleanup": "internet",
            "browser_close_chrome": "close", "browser_close_edge": "close", "cert_list": "shield",
            "return_standard": "logout", "close_app": "close", "outlook": "mail",
            "dns": "dns", "gpupdate": "refresh", "logoff": "logout", "restart": "power",
            "temp": "trash", "trellix_config": "shield", "atlas_repair": "gear", "legacy_tool": "legacy", "install_printer": "printer", "remove_printer": "trash",
            "remote_process_list": "management", "user_software_list": "software",
            "remove_hp_driver": "minus", "install_hp_driver": "plus", "test_print": "printer",
            "set_default_printer": "check", "spooler": "trash", "open_main": "back",
        }
        self.icon_name = icons.get(action.command, "info")
        self.glyph = QLabel()
        self.glyph.setObjectName("glyph")
        self.glyph.setAlignment(Qt.AlignCenter)
        self.title_label = QLabel(action.title.split("  ", 1)[-1])
        self.title_label.setObjectName("cardTitle")
        self.title_label.setWordWrap(True)
        self.title_label.setMinimumWidth(0)
        self.title_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.title_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.subtitle_label = QLabel(action.subtitle)
        self.subtitle_label.setObjectName("cardSubtitle")
        self.subtitle_label.setWordWrap(True)
        self.subtitle_label.setMinimumWidth(0)
        self.subtitle_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.subtitle_label.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.action_button = QPushButton()
        self.action_button.setObjectName("cardArrow")
        self.action_button.setFixedSize(30, 30)
        set_button_icon(self.action_button, "external", "#258DC2", 14)
        self.action_button.clicked.connect(lambda: self.triggered.emit(self.action))
        self.spinner = BusySpinner()
        self.spinner.hide()
        self.action_slot = QStackedWidget()
        self.action_slot.setFixedSize(30, 30)
        self.action_slot.addWidget(self.action_button)
        self.action_slot.addWidget(self.spinner)
        self.remote_progress_label = None
        self.remote_progress_bar = None
        if (action.category == "Suporte remoto" and action.command != "open_main") or action.command in {"logoff", "restart"}:
            self.remote_progress_label = QLabel("Processando…  3%")
            self.remote_progress_label.setObjectName("operationProgressLabel")
            self.remote_progress_label.hide()
            self.remote_progress_bar = QProgressBar()
            self.remote_progress_bar.setObjectName("operationProgressBar")
            self.remote_progress_bar.setRange(0, 100)
            self.remote_progress_bar.setValue(3)
            self.remote_progress_bar.setTextVisible(False)
            self.remote_progress_bar.setFixedHeight(7)
            self.remote_progress_bar.hide()
        self.remote_progress_generation = 0
        self.remote_progress_started = 0.0
        self.remote_progress_timer = QTimer(self)
        self.remote_progress_timer.setInterval(150)
        self.remote_progress_timer.timeout.connect(self.advance_remote_progress)
        self.set_compact(False)

    def set_compact(self, compact: bool):
        """Reorganiza o conteúdo para a largura disponível da grade externa."""
        if self.compact == compact and self.card_layout.count():
            return
        self.compact = compact
        for widget in (self.glyph, self.title_label, self.subtitle_label, self.action_slot,
                       self.remote_progress_label, self.remote_progress_bar):
            if widget is None:
                continue
            self.card_layout.removeWidget(widget)

        if compact:
            self.setMinimumHeight(96)
            self.card_layout.setContentsMargins(11, 10, 11, 10)
            self.card_layout.setHorizontalSpacing(8)
            self.card_layout.setVerticalSpacing(2)
            self.glyph.setFixedSize(34, 34)
            self.glyph.setMask(QRegion(self.glyph.rect(), QRegion.Ellipse))
            self.glyph.setPixmap(modern_icon(self.icon_name, GREEN, 17).pixmap(17, 17))
            self.action_button.setFixedSize(26, 26)
            self.action_button.setMask(QRegion(self.action_button.rect(), QRegion.Ellipse))
            self.spinner.setFixedSize(26, 26)
            self.action_slot.setFixedSize(26, 26)
            self.card_layout.addWidget(self.glyph, 0, 0, 2, 1, Qt.AlignVCenter)
            self.card_layout.addWidget(self.title_label, 0, 1)
            self.card_layout.addWidget(self.subtitle_label, 1, 1)
            self.card_layout.addWidget(self.action_slot, 0, 2, 2, 1, Qt.AlignVCenter)
        else:
            self.setMinimumHeight(100)
            self.card_layout.setContentsMargins(14, 12, 14, 12)
            self.card_layout.setHorizontalSpacing(10)
            self.card_layout.setVerticalSpacing(2)
            self.glyph.setFixedSize(40, 40)
            self.glyph.setMask(QRegion(self.glyph.rect(), QRegion.Ellipse))
            self.glyph.setPixmap(modern_icon(self.icon_name, GREEN, 20).pixmap(20, 20))
            self.action_button.setFixedSize(28, 28)
            self.action_button.setMask(QRegion(self.action_button.rect(), QRegion.Ellipse))
            self.spinner.setFixedSize(28, 28)
            self.action_slot.setFixedSize(28, 28)
            self.card_layout.addWidget(self.glyph, 0, 0, 2, 1, Qt.AlignVCenter)
            self.card_layout.addWidget(self.title_label, 0, 1)
            self.card_layout.addWidget(self.subtitle_label, 1, 1)
            self.card_layout.addWidget(self.action_slot, 0, 2, 2, 1, Qt.AlignVCenter)
        self.card_layout.setColumnStretch(1, 1)
        if self.remote_progress_label is not None:
            self.card_layout.addWidget(self.remote_progress_label, 2, 0, 1, 3)
            self.card_layout.addWidget(self.remote_progress_bar, 3, 0, 1, 3)
        self.setProperty("compact", compact)
        for widget in (self, self.glyph, self.title_label, self.subtitle_label, self.action_button):
            widget.style().unpolish(widget)
            widget.style().polish(widget)

    def changeEvent(self, event):
        super().changeEvent(event)
        if event.type() == QEvent.Type.EnabledChange:
            self.setProperty("available", self.isEnabled())
            for widget in (self, self.glyph, self.title_label, self.subtitle_label, self.action_button):
                widget.style().unpolish(widget)
                widget.style().polish(widget)
                widget.update()

    def set_loading(self, loading: bool):
        self.setEnabled(not loading)
        if loading:
            self.action_slot.setCurrentWidget(self.spinner)
            self.spinner.start()
        else:
            self.spinner.stop()
            self.action_slot.setCurrentWidget(self.action_button)

    def start_remote_progress(self):
        if self.remote_progress_bar is None:
            return
        self.remote_progress_generation += 1
        self.remote_progress_started = time.monotonic()
        self.remote_progress_bar.setValue(3)
        self.remote_progress_label.setText("Aguardando resposta da estação…  3%")
        self.remote_progress_label.show()
        self.remote_progress_bar.show()
        self.remote_progress_timer.start()

    def advance_remote_progress(self):
        """Estimativa visual limitada: o tempo jamais comprova conclusão remota."""
        elapsed = time.monotonic() - self.remote_progress_started
        estimate = min(90, 3 + int(87 * elapsed / 15))
        value = max(self.remote_progress_bar.value(), estimate)
        self.remote_progress_bar.setValue(value)
        self.remote_progress_label.setText(f"Aguardando resposta da estação…  {value}%")

    def finish_remote_progress(self, ok: bool, confirmed: bool):
        if self.remote_progress_bar is None or not self.remote_progress_timer.isActive():
            return
        self.remote_progress_timer.stop()
        if ok and confirmed:
            self.remote_progress_bar.setValue(100)
            message = "Processo remoto confirmado"
        else:
            self.remote_progress_bar.setValue(min(99, max(25, self.remote_progress_bar.value())))
            message = ("Comando enviado; conclusão remota não confirmada" if ok
                       else "Operação não confirmada na estação")
        self.remote_progress_label.setText(f"{message}  •  {self.remote_progress_bar.value()}%")
        generation = self.remote_progress_generation
        QTimer.singleShot(7000, lambda: self.hide_remote_progress(generation))

    def hide_remote_progress(self, generation: int):
        if generation == self.remote_progress_generation:
            self.remote_progress_label.hide()
            self.remote_progress_bar.hide()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.triggered.emit(self.action)
        super().mousePressEvent(event)


class SoftwareSuggestionDelegate(QStyledItemDelegate):
    """Sugestão compacta com os trechos pesquisados destacados em verde."""

    def __init__(self, query_provider, parent=None):
        super().__init__(parent)
        self.query_provider = query_provider

    @staticmethod
    def normalized_with_map(value: str):
        normalized, positions = "", []
        for index, char in enumerate(value):
            folded = "".join(
                item for item in unicodedata.normalize("NFKD", char)
                if not unicodedata.combining(item)
            ).casefold()
            normalized += folded
            positions.extend([index] * len(folded))
        return normalized, positions

    def paint(self, painter, option, index):
        text = str(index.data(Qt.DisplayRole) or "")
        query = str(self.query_provider() or "").strip()
        highlighted = [False] * len(text)
        normalized_text, positions = self.normalized_with_map(text)
        normalized_query, _ = self.normalized_with_map(query)
        for term in normalized_query.split():
            start = 0
            while term:
                found = normalized_text.find(term, start)
                if found < 0:
                    break
                for mapped in positions[found:found + len(term)]:
                    if 0 <= mapped < len(highlighted):
                        highlighted[mapped] = True
                start = found + len(term)

        painter.save()
        painter.setClipRect(option.rect)
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        hovered = bool(option.state & QStyle.StateFlag.State_MouseOver)
        if selected:
            painter.fillRect(option.rect, QColor(BLUE))
        elif hovered:
            painter.fillRect(option.rect, QColor("#EAF6F0"))
        else:
            painter.fillRect(option.rect, QColor("#FFFFFF"))
        painter.setPen(QPen(QColor("#E7EEF3"), 1))
        painter.drawLine(option.rect.bottomLeft(), option.rect.bottomRight())
        x = option.rect.left() + 12
        base_font = option.font
        base_font.setPixelSize(12)
        base_font.setBold(False)
        painter.setFont(base_font)
        baseline = option.rect.center().y() + painter.fontMetrics().ascent() // 2 - 1
        position = 0
        while position < len(text):
            marked = highlighted[position]
            end = position + 1
            while end < len(text) and highlighted[end] == marked:
                end += 1
            segment = text[position:end]
            font = base_font
            font.setBold(marked)
            painter.setFont(font)
            painter.setPen(QColor("#7CFFBF" if selected and marked else "#00A567" if marked else "#FFFFFF" if selected else BLUE))
            painter.drawText(x, baseline, segment)
            x += painter.fontMetrics().horizontalAdvance(segment)
            position = end
        painter.restore()

    def sizeHint(self, option, index):
        size = super().sizeHint(option, index)
        size.setHeight(34)
        return size


class AuthorizedSoftwareCard(QFrame):
    """Cartão compacto para um executável validado no catálogo do drive X:."""
    launch_requested = Signal(str, str)

    def __init__(self, software: dict, parent=None):
        super().__init__(parent)
        self.setObjectName("authorizedSoftwareCard")
        self.setProperty("softwareDynamic", True)
        path = str(software.get("path", ""))
        name = str(software.get("name") or software.get("file") or "Software")
        row = QHBoxLayout(self)
        row.setContentsMargins(12, 11, 11, 11)
        row.setSpacing(9)
        self.setMinimumHeight(78)

        branch = QFrame()
        branch.setObjectName("softwareTreeLine")
        branch.setFixedWidth(3)
        row.addWidget(branch)

        icon = QLabel()
        icon.setObjectName("softwareGlyph")
        icon.setAlignment(Qt.AlignCenter)
        icon.setFixedSize(40, 40)
        icon.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        icon.setAttribute(Qt.WA_StyledBackground, True)
        icon.setPixmap(modern_icon("software", GREEN, 18).pixmap(18, 18))
        row.addWidget(icon, 0, Qt.AlignVCenter)

        texts = QVBoxLayout()
        texts.setSpacing(3)
        title = QLabel(name)
        title.setObjectName("softwareTitle")
        title.setWordWrap(True)
        texts.addWidget(title)
        detail = QLabel(str(software.get("folder") or software.get("file") or path))
        detail.setObjectName("softwarePath")
        detail.setWordWrap(True)
        detail.setToolTip(path)
        texts.addWidget(detail)
        row.addLayout(texts, 1)

        actions = QFrame(objectName="cardActions")
        actions_box = QHBoxLayout(actions)
        actions_box.setContentsMargins(4, 4, 4, 4)
        actions_box.setSpacing(4)
        launch = QPushButton()
        launch.setObjectName("softwareLaunchButton")
        launch.setFixedSize(32, 32)
        launch.setToolTip(f"Abrir {name} na estação conectada")
        set_button_icon(launch, "external", BLUE, 15)
        launch.clicked.connect(lambda: self.launch_requested.emit(path, name))
        actions_box.addWidget(launch)
        row.addWidget(actions, 0, Qt.AlignVCenter)


class SoftwareCategoryButton(QPushButton):
    """Nó expansível da árvore de categorias do catálogo autorizado."""
    category_toggled = Signal(str)

    def __init__(self, category: str, count: int, expanded: bool, parent=None):
        super().__init__(parent)
        self.category = category
        self.setProperty("softwareDynamic", True)
        self.setObjectName("softwareCategoryExpanded" if expanded else "softwareCategoryCollapsed")
        self.setText(f"{category}   •   {count} software{'s' if count != 1 else ''}")
        set_button_icon(self, "chevron_down" if expanded else "chevron_right", GREEN_2 if expanded else BLUE, 16)
        self.setCursor(Qt.PointingHandCursor)
        self.clicked.connect(lambda: self.category_toggled.emit(self.category))


class OrientationPreviewDialog(QDialog):
    """Prévia editável do conteúdo exato que será exibido na estação remota."""
    DELETE_ORIENTATION = 2
    SAVE_ONLY = 3

    def __init__(self, orientation: dict, parent=None, allow_delete: bool = True):
        super().__init__(parent)
        self.setObjectName("orientationPreviewDialog")
        self.setWindowTitle("Revisar orientação ao usuário")
        self.setModal(True)
        self.resize(590, 520)
        self.setMinimumSize(500, 440)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 17)
        layout.setSpacing(10)

        eyebrow = QLabel("PRÉ-VISUALIZAÇÃO ANTES DO ENVIO")
        eyebrow.setObjectName("dialogSuccess")
        layout.addWidget(eyebrow)
        faq_title = QLabel(str(orientation.get("title") or "Orientação ao usuário"))
        faq_title.setObjectName("dialogTitle")
        faq_title.setWordWrap(True)
        layout.addWidget(faq_title)
        hint = QLabel(
            "Dê um título curto para identificar esta orientação e revise os campos abaixo. "
            "O título organiza a lista; somente o conteúdo da orientação será mostrado ao usuário."
        )
        hint.setObjectName("smallMuted")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        orientation_title_label = QLabel("TÍTULO DA ORIENTAÇÃO")
        orientation_title_label.setObjectName("orientationPreviewLabel")
        layout.addWidget(orientation_title_label)
        self.orientation_title_edit = QLineEdit()
        self.orientation_title_edit.setObjectName("orientationTitleInput")
        self.orientation_title_edit.setPlaceholderText("Ex.: Configurar certificado digital")
        self.orientation_title_edit.setMaxLength(90)
        self.orientation_title_edit.setText(str(orientation.get("orientation_title") or orientation.get("title") or ""))
        layout.addWidget(self.orientation_title_edit)

        self.guidance_edit = self._field(layout, "ORIENTAÇÃO", str(orientation.get("guidance") or ""), 112)
        self.path_edit = self._field(layout, "CAMINHO NA INTRANET", str(orientation.get("path") or ""), 82)
        self.contact_edit = self._field(layout, "CONTATO", str(orientation.get("contact") or ""), 76)
        self.chief_notice_check = QCheckBox("Incluir aviso: o chamado deve ser aberto pelo chefe do setor")
        self.chief_notice_check.setChecked(orientation.get("include_chief_notice", True) is not False)
        self.chief_notice_check.setToolTip("Selecione para mostrar essa observação ao usuário junto com o caminho na Intranet.")
        layout.addWidget(self.chief_notice_check)

        buttons = QHBoxLayout()
        if allow_delete:
            delete_button = QPushButton("Excluir orientação")
            delete_button.setObjectName("orientationDeleteButton")
            delete_button.setToolTip("Remove somente esta orientação; a FAQ continuará disponível")
            set_button_icon(delete_button, "trash", RED, 16)
            delete_button.clicked.connect(lambda: self.done(self.DELETE_ORIENTATION))
            buttons.addWidget(delete_button)
        buttons.addStretch(1)
        cancel = QPushButton("Cancelar")
        cancel.setObjectName("secondaryButton")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        save = QPushButton("Salvar")
        save.setObjectName("secondaryButton")
        set_button_icon(save, "check", GREEN, 16)
        save.clicked.connect(lambda: self._finish_if_valid(self.SAVE_ONLY))
        buttons.addWidget(save)
        send = QPushButton("Enviar orientação")
        send.setObjectName("primaryButton")
        set_button_icon(send, "orientation", "#FFFFFF", 17)
        send.clicked.connect(lambda: self._finish_if_valid(QDialog.Accepted))
        buttons.addWidget(send)
        layout.addLayout(buttons)

        self.fade = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade.setDuration(145)
        self.fade.setStartValue(0.0)
        self.fade.setEndValue(1.0)
        self.fade.setEasingCurve(QEasingCurve.OutCubic)

    @staticmethod
    def _field(layout: QVBoxLayout, caption: str, value: str, height: int) -> QTextEdit:
        label = QLabel(caption)
        label.setObjectName("orientationPreviewLabel")
        layout.addWidget(label)
        editor = QTextEdit()
        editor.setObjectName("orientationPreviewEditor")
        editor.setPlainText(value)
        editor.setMinimumHeight(height)
        editor.setAcceptRichText(False)
        layout.addWidget(editor)
        return editor

    def _finish_if_valid(self, result: int):
        values = self.values()
        if not values["orientation_title"]:
            show_notice(self, "Informe um título para identificar esta orientação.")
            self.orientation_title_edit.setFocus()
            return
        if not any(values[key] for key in ("guidance", "path", "contact")):
            show_notice(self, "Informe uma orientação, um caminho ou um contato antes de enviar.")
            return
        self.done(result)

    def values(self) -> dict[str, str]:
        return {
            "orientation_title": self.orientation_title_edit.text().strip(),
            "guidance": self.guidance_edit.toPlainText().strip(),
            "path": self.path_edit.toPlainText().strip(),
            "contact": self.contact_edit.toPlainText().strip(),
            "include_chief_notice": self.chief_notice_check.isChecked(),
        }

    def showEvent(self, event):
        super().showEvent(event)
        self.setWindowOpacity(0.0)
        self.fade.start()


class OrientationChooserDialog(QDialog):
    """Seleciona uma das orientações da FAQ ou inicia uma nova."""
    NEW_ORIENTATION = 2

    def __init__(self, faq_title: str, orientations: list[dict], parent=None):
        super().__init__(parent)
        self.orientations = orientations
        self.setObjectName("orientationPreviewDialog")
        self.setWindowTitle("Orientações desta FAQ")
        self.setModal(True)
        self.resize(570, 390)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 17)
        layout.setSpacing(10)
        eyebrow = QLabel("ORIENTAÇÕES VINCULADAS À FAQ")
        eyebrow.setObjectName("dialogSuccess")
        layout.addWidget(eyebrow)
        heading = QLabel(faq_title or "FAQ selecionada")
        heading.setObjectName("dialogTitle")
        heading.setWordWrap(True)
        layout.addWidget(heading)
        hint = QLabel("Selecione uma orientação para revisar, editar ou enviar. Você também pode criar outra orientação para esta mesma FAQ.")
        hint.setObjectName("smallMuted")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.list = QListWidget()
        self.list.setObjectName("orientationChoiceList")
        for index, item in enumerate(orientations, 1):
            orientation_title = str(item.get("orientation_title") or "").strip()
            if not orientation_title:
                orientation_title = f"Orientação {index}"
            summary = str(item.get("guidance") or item.get("path") or item.get("contact") or "Orientação sem resumo")
            summary = re.sub(r"\s+", " ", summary).strip()
            self.list.addItem(f"{orientation_title}  •  {summary[:95]}")
        if orientations:
            self.list.setCurrentRow(0)
            self.list.itemDoubleClicked.connect(lambda _item: self.accept())
        layout.addWidget(self.list, 1)
        buttons = QHBoxLayout()
        new_button = QPushButton("Nova orientação")
        new_button.setObjectName("specificFaqButton")
        set_button_icon(new_button, "plus", GREEN, 16)
        new_button.clicked.connect(lambda: self.done(self.NEW_ORIENTATION))
        buttons.addWidget(new_button)
        buttons.addStretch(1)
        cancel = QPushButton("Cancelar")
        cancel.setObjectName("secondaryButton")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        review = QPushButton("Revisar selecionada")
        review.setObjectName("primaryButton")
        set_button_icon(review, "orientation", "#FFFFFF", 16)
        review.setEnabled(bool(orientations))
        review.clicked.connect(self.accept)
        buttons.addWidget(review)
        layout.addLayout(buttons)

    def selected_orientation(self) -> dict | None:
        row = self.list.currentRow()
        return self.orientations[row] if 0 <= row < len(self.orientations) else None


class FreeOrientationDialog(QDialog):
    """Editor de uma orientação livre, sem vínculo obrigatório com FAQ."""

    def __init__(self, user_name: str, parent=None):
        super().__init__(parent)
        self.setObjectName("orientationPreviewDialog")
        self.setWindowTitle("Orientação livre ao usuário")
        self.setModal(True)
        self.resize(590, 390)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 17)
        layout.setSpacing(10)
        eyebrow = QLabel("ORIENTAÇÃO LIVRE")
        eyebrow.setObjectName("dialogSuccess")
        layout.addWidget(eyebrow)
        heading = QLabel(f"Mensagem para Sr(a). {user_name or 'usuário conectado'}")
        heading.setObjectName("dialogTitle")
        heading.setWordWrap(True)
        layout.addWidget(heading)
        hint = QLabel(
            "Digite somente a orientação. A identificação do usuário, o agradecimento e sua assinatura serão acrescentados automaticamente."
        )
        hint.setObjectName("smallMuted")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.editor = QTextEdit()
        self.editor.setObjectName("orientationPreviewEditor")
        self.editor.setAcceptRichText(False)
        self.editor.setPlaceholderText("Escreva aqui a orientação que será exibida na estação remota…")
        layout.addWidget(self.editor, 1)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Cancelar")
        cancel.setObjectName("secondaryButton")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        send = QPushButton("Enviar orientação")
        send.setObjectName("primaryButton")
        set_button_icon(send, "orientation", "#FFFFFF", 17)
        send.clicked.connect(self._send)
        buttons.addWidget(send)
        layout.addLayout(buttons)
        QTimer.singleShot(0, self.editor.setFocus)

    def _send(self):
        if not self.text():
            show_notice(self, "Digite a orientação que será encaminhada ao usuário.")
            return
        self.accept()

    def text(self) -> str:
        return self.editor.toPlainText().strip()


class FaqCard(QFrame):
    """Artigo oficial preservando título, categoria e endereço do Capri."""
    open_requested = Signal(str, str)
    orientation_requested = Signal(dict)
    favorite_requested = Signal(dict)

    def __init__(self, faq: dict, orientations: list[dict] | None = None,
                 favorite: bool = False, parent=None):
        super().__init__(parent)
        self.setObjectName("faqCard")
        self.setProperty("softwareDynamic", True)
        url = str(faq.get("url", ""))
        title = str(faq.get("title") or "FAQ")
        row = QHBoxLayout(self)
        row.setContentsMargins(13, 12, 11, 12)
        row.setSpacing(10)
        self.setMinimumHeight(104)
        branch = QFrame(objectName="softwareTreeLine")
        branch.setFixedWidth(3)
        row.addWidget(branch)
        icon = QLabel()
        icon.setObjectName("softwareGlyph")
        icon.setAlignment(Qt.AlignCenter)
        icon.setFixedSize(36, 36)
        icon.setMask(QRegion(icon.rect(), QRegion.Ellipse))
        icon.setPixmap(modern_icon("info", GREEN, 19).pixmap(19, 19))
        row.addWidget(icon)
        texts = QVBoxLayout()
        texts.setSpacing(3)
        faq_id = normalize_faq_number(faq.get("id"))
        self.setProperty("faqId", faq_id)
        clean_title = re.sub(r"(?i)^FAQ#?\s*:?\s*\d+\s*[-–—:]\s*", "", title).strip() or title
        number_label = QLabel(f"FAQ {faq_id}" if faq_id else "FAQ")
        number_label.setObjectName("faqNumber")
        texts.addWidget(number_label, 0, Qt.AlignLeft)
        heading = QLabel(clean_title)
        heading.setObjectName("softwareTitle")
        heading.setWordWrap(True)
        texts.addWidget(heading)
        category = str(faq.get("knowledge_category") or "Outros assuntos")
        subcategory = str(faq.get("knowledge_subcategory") or faq.get("tool") or "Orientações gerais")
        procedure = str(faq.get("knowledge_procedure") or faq.get("procedure") or "Orientações gerais")
        origin = str(faq.get("original_category") or "CENTRAL DE ATENDIMENTO")
        detail = QLabel(f"{procedure}\nOrigem: {origin}")
        detail.setObjectName("softwarePath")
        detail.setWordWrap(True)
        detail.setToolTip(url)
        texts.addWidget(detail)
        row.addLayout(texts, 1)
        actions = QFrame(objectName="cardActions")
        actions_box = QHBoxLayout(actions)
        actions_box.setContentsMargins(4, 4, 4, 4)
        actions_box.setSpacing(4)
        if faq_id:
            self.favorite_button = QPushButton()
            self.favorite_button.setObjectName("faqFavoriteButton")
            self.favorite_button.setFixedSize(32, 32)
            self.favorite_button.clicked.connect(
                lambda _checked=False, item=faq: self.favorite_requested.emit(item)
            )
            self.set_favorite_state(favorite, faq_id)
            actions_box.addWidget(self.favorite_button)
            copy_button = QPushButton()
            copy_button.setObjectName("softwareLaunchButton")
            copy_button.setFixedSize(32, 32)
            copy_button.setToolTip(f"Copiar somente o número {faq_id}")
            copy_button.setAccessibleName(f"Copiar número da FAQ {faq_id}")
            set_button_icon(copy_button, "copy", GREEN, 15)
            copy_button.clicked.connect(lambda _checked=False, value=faq_id, control=copy_button: self.copy_faq_number(value, control))
            actions_box.addWidget(copy_button)
        orientation_items = list(orientations or [])
        orientation_button = QPushButton()
        orientation_button.setObjectName("faqOrientationButton" if orientation_items else "faqOrientationAddButton")
        orientation_button.setFixedSize(34, 34)
        count = len(orientation_items)
        orientation_button.setToolTip(
            f"Gerenciar {count} orientação{'ões' if count != 1 else ''} desta FAQ"
            if count else "Criar a primeira orientação desta FAQ"
        )
        orientation_button.setAccessibleName(f"Gerenciar orientações da FAQ {faq_id}")
        set_button_icon(orientation_button, "orientation" if count else "plus", "#FFFFFF" if count else GREEN, 17)
        bundle = {"faq_id": faq_id, "title": clean_title, "orientations": orientation_items}
        orientation_button.clicked.connect(
            lambda _checked=False, item=bundle: self.orientation_requested.emit(item)
        )
        actions_box.addWidget(orientation_button)
        button = QPushButton()
        button.setObjectName("softwareLaunchButton")
        button.setFixedSize(32, 32)
        button.setToolTip("Abrir FAQ oficial no Capri")
        set_button_icon(button, "external", BLUE, 15)
        button.clicked.connect(lambda: self.open_requested.emit(url, clean_title))
        actions_box.addWidget(button)
        row.addWidget(actions, 0, Qt.AlignVCenter)

    def set_favorite_state(self, favorite: bool, faq_id: str):
        if not hasattr(self, "favorite_button"):
            return
        self.favorite_button.setProperty("favorite", favorite)
        self.favorite_button.setToolTip(
            "Remover dos favoritos" if favorite else "Adicionar aos favoritos"
        )
        self.favorite_button.setAccessibleName(
            f'{"Remover" if favorite else "Favoritar"} FAQ {faq_id}'
        )
        set_button_icon(self.favorite_button, "star", GOLD if favorite else MUTED, 15)
        self.favorite_button.style().unpolish(self.favorite_button)
        self.favorite_button.style().polish(self.favorite_button)

    @staticmethod
    def copy_faq_number(faq_id: str, button: QPushButton):
        QApplication.clipboard().setText(faq_id)
        set_button_icon(button, "check", GREEN, 15)
        button.setToolTip(f"Número {faq_id} copiado")
        QTimer.singleShot(1000, lambda: (
            set_button_icon(button, "copy", GREEN, 15),
            button.setToolTip(f"Copiar somente o número {faq_id}"),
        ))


class UserOrientationCard(QFrame):
    """Resumo operacional com ação explícita para orientar a sessão remota."""
    send_requested = Signal(dict)

    def __init__(self, orientation: dict, parent=None):
        super().__init__(parent)
        self.setObjectName("orientationCard")
        self.setProperty("softwareDynamic", True)
        self.setMinimumHeight(142)
        row = QHBoxLayout(self)
        row.setContentsMargins(13, 13, 11, 13)
        row.setSpacing(10)
        branch = QFrame(objectName="orientationTreeLine")
        branch.setFixedWidth(4)
        row.addWidget(branch)
        icon = QLabel(objectName="orientationGlyph")
        icon.setAlignment(Qt.AlignCenter)
        icon.setFixedSize(38, 38)
        icon.setPixmap(modern_icon("info", BLUE_2, 20).pixmap(20, 20))
        row.addWidget(icon, 0, Qt.AlignTop)
        texts = QVBoxLayout()
        texts.setSpacing(4)
        faq_number = str(orientation.get("faq_number") or "").strip()
        badge = QLabel(f"FAQ {faq_number}" if faq_number else "ORIENTAÇÃO")
        badge.setObjectName("orientationBadge")
        texts.addWidget(badge, 0, Qt.AlignLeft)
        title = QLabel(str(orientation.get("title") or "Orientação ao usuário"))
        title.setObjectName("orientationTitle")
        title.setWordWrap(True)
        texts.addWidget(title)
        summary = QLabel(str(orientation.get("guidance") or orientation.get("summary") or ""))
        summary.setObjectName("orientationSummary")
        summary.setWordWrap(True)
        texts.addWidget(summary)
        path = QLabel(str(orientation.get("path") or ""))
        path.setObjectName("orientationPath")
        path.setWordWrap(True)
        path.setTextInteractionFlags(Qt.TextSelectableByMouse)
        path.setVisible(bool(str(orientation.get("path") or "").strip()))
        texts.addWidget(path)
        contact_value = str(orientation.get("contact") or "").strip()
        contact = QLabel(contact_value)
        contact.setObjectName("orientationContact")
        contact.setWordWrap(True)
        contact.setTextInteractionFlags(Qt.TextSelectableByMouse)
        contact.setVisible(bool(contact_value))
        texts.addWidget(contact)
        row.addLayout(texts, 1)
        actions = QFrame(objectName="cardActions")
        actions_box = QVBoxLayout(actions)
        actions_box.setContentsMargins(4, 4, 4, 4)
        send = QPushButton()
        send.setObjectName("orientationSendButton")
        send.setFixedSize(36, 36)
        send.setToolTip("Exibir esta orientação na tela do usuário conectado")
        send.setAccessibleName("Enviar orientação ao usuário")
        set_button_icon(send, "external", "#FFFFFF", 17)
        send.clicked.connect(lambda _checked=False, item=dict(orientation): self.send_requested.emit(item))
        actions_box.addWidget(send)
        row.addWidget(actions, 0, Qt.AlignVCenter)


class FaqCategoryButton(SoftwareCategoryButton):
    def __init__(self, category: str, count: int, expanded: bool, parent=None):
        super().__init__(category, count, expanded, parent)
        self.setText(f"{category}   •   {count} FAQ{'s' if count != 1 else ''}")


class FaqRootCategoryButton(QPushButton):
    """Categoria principal recolhível da árvore temática de FAQs."""
    root_toggled = Signal(str)

    def __init__(self, category: str, count: int, expanded: bool, parent=None):
        super().__init__(parent)
        self.category = category
        self.setProperty("softwareDynamic", True)
        self.setObjectName("faqRootExpanded" if expanded else "faqRootCollapsed")
        self.setText(f"{category.upper()}   •   {count} FAQs")
        set_button_icon(self, "chevron_down" if expanded else "chevron_right", YELLOW, 17)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Recolher categoria" if expanded else "Expandir categoria")
        self.clicked.connect(lambda: self.root_toggled.emit(self.category))


class PopupInfoCard(QFrame):
    """Bloco visual reutilizável para informações de qualquer popup."""

    def __init__(self, title: str, value: str, icon_name: str = "info", parent=None, copy_value: bool = False, copy_text: str = ""):
        super().__init__(parent)
        self.setObjectName("popupInfoCard")
        row = QHBoxLayout(self)
        row.setContentsMargins(11, 9, 11, 9)
        row.setSpacing(9)
        icon = QLabel()
        icon.setObjectName("popupCardIcon")
        icon.setAlignment(Qt.AlignCenter)
        icon.setFixedSize(32, 32)
        icon.setPixmap(modern_icon(icon_name, GREEN, 17).pixmap(17, 17))
        row.addWidget(icon, 0, Qt.AlignTop)
        texts = QVBoxLayout()
        texts.setSpacing(4)
        caption = QLabel(title)
        caption.setObjectName("popupFieldCaption")
        caption.setWordWrap(True)
        texts.addWidget(caption)
        detail = QLabel(value or "Não informado")
        detail.setObjectName("popupFieldValue")
        detail.setWordWrap(True)
        detail.setTextInteractionFlags(Qt.TextSelectableByMouse)
        texts.addWidget(detail)
        row.addLayout(texts, 1)
        if copy_value:
            copy_button = QPushButton()
            copy_button.setObjectName("copyTargetButton")
            copy_button.setFixedSize(28, 28)
            copy_button.setCursor(Qt.PointingHandCursor)
            copy_button.setToolTip(f"Copiar {title}")
            copy_button.setAccessibleName(f"Copiar {title}")
            set_button_icon(copy_button, "copy", BLUE, 14)
            copy_button.clicked.connect(lambda: self._copy_field(copy_text or str(value or "Não informado"), copy_button))
            row.addWidget(copy_button, 0, Qt.AlignTop)

    @staticmethod
    def _copy_field(value: str, button: QPushButton):
        QApplication.clipboard().setText(value)
        set_button_icon(button, "check", GREEN, 14)
        button.setToolTip("Informação copiada")
        QTimer.singleShot(1100, lambda: (
            set_button_icon(button, "copy", BLUE, 14),
            button.setToolTip("Copiar informação"),
        ))


class LicenseInfoCard(QFrame):
    """Uma licença por cartão, com recursos legíveis e copiáveis."""

    def __init__(self, group: str, description: str, parent=None):
        super().__init__(parent)
        self.setObjectName("licenseCard")
        box = QVBoxLayout(self)
        box.setContentsMargins(13, 11, 13, 12)
        box.setSpacing(5)
        head = QHBoxLayout()
        title = QLabel(group)
        title.setObjectName("licenseCode")
        title.setWordWrap(True)
        title.setTextInteractionFlags(Qt.TextSelectableByMouse)
        head.addWidget(title, 1)
        copy = QPushButton()
        copy.setObjectName("copyTargetButton")
        copy.setFixedSize(28, 28)
        copy.setToolTip(f"Copiar recursos de {group}")
        set_button_icon(copy, "copy", BLUE, 14)
        copy.clicked.connect(lambda: PopupInfoCard._copy_field(f"{group}: {description}", copy))
        head.addWidget(copy)
        box.addLayout(head)
        for index, line in enumerate(description.splitlines()):
            detail = QLabel(line)
            detail.setObjectName("licenseSummary" if index == 0 else "licenseResource")
            detail.setWordWrap(True)
            detail.setTextInteractionFlags(Qt.TextSelectableByMouse)
            box.addWidget(detail)


def popup_content_widget(content: str) -> tuple[QWidget, list[str]]:
    """Transforma texto técnico em cartões, mantendo integralmente o conteúdo copiável."""
    host = QWidget()
    box = QVBoxLayout(host)
    box.setContentsMargins(4, 4, 4, 4)
    box.setSpacing(6)
    blocks = [block.strip() for block in content.replace("\r", "").split("\n\n") if block.strip()]
    if not blocks:
        blocks = ["Informação\nA consulta não retornou informações."]
    rendered = []
    for index, block in enumerate(blocks):
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if not lines:
            continue
        first = lines[0]
        if ":" in first and len(first.split(":", 1)[0]) <= 45:
            title, first_value = first.split(":", 1)
            value_lines = ([first_value.strip()] if first_value.strip() else []) + lines[1:]
            value = "\n".join(value_lines) or "Concluído"
        elif len(lines) > 1 and len(first) <= 58:
            title, value = first, "\n".join(lines[1:])
        else:
            title, value = ("Resultado" if index == 0 else f"Detalhes {index + 1}"), "\n".join(lines)
        icon = "check" if any(word in value.lower() for word in ("sucesso", "conclu", "atualiz", "limpo")) else "info"
        box.addWidget(PopupInfoCard(title, value, icon))
        rendered.extend(lines)
    box.addStretch()
    return host, rendered


class CompactConfirmDialog(QDialog):
    """Confirmação curta e elegante, sem ocupar a largura do aplicativo."""

    def __init__(self, title: str, message: str, parent=None):
        super().__init__(parent)
        self.setObjectName("compactConfirmDialog")
        self.setWindowTitle(title)
        self.setModal(True)
        self.setFixedWidth(390)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(13)
        row = QHBoxLayout()
        row.setSpacing(12)
        icon = QLabel()
        icon.setObjectName("confirmIcon")
        icon.setFixedSize(38, 38)
        icon.setAlignment(Qt.AlignCenter)
        icon.setPixmap(modern_icon("info", BLUE, 20).pixmap(20, 20))
        row.addWidget(icon, 0, Qt.AlignTop)
        texts = QVBoxLayout()
        texts.setSpacing(4)
        heading = QLabel(title)
        heading.setObjectName("confirmTitle")
        texts.addWidget(heading)
        description = QLabel(message)
        description.setObjectName("confirmMessage")
        description.setWordWrap(True)
        texts.addWidget(description)
        row.addLayout(texts, 1)
        layout.addLayout(row)
        buttons = QHBoxLayout()
        buttons.addStretch()
        cancel = QPushButton("Cancelar")
        cancel.setObjectName("secondaryButton")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        confirm = QPushButton("Confirmar")
        confirm.setObjectName("primaryButton")
        set_button_icon(confirm, "check", "#FFFFFF", 15)
        confirm.clicked.connect(self.accept)
        confirm.setDefault(True)
        buttons.addWidget(confirm)
        layout.addLayout(buttons)
        self.fade = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade.setDuration(150)
        self.fade.setStartValue(0.0)
        self.fade.setEndValue(1.0)
        self.fade.setEasingCurve(QEasingCurve.OutCubic)

    def showEvent(self, event):
        super().showEvent(event)
        self.setWindowOpacity(0.0)
        self.fade.start()


def confirm_action(parent: QWidget, title: str, message: str) -> bool:
    return CompactConfirmDialog(title, message, parent).exec() == QDialog.Accepted


class PasswordManagerSessionDialog(QDialog):
    """Decisão explícita do operador antes de cada complemento consultado no PWM."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.choice = "ad_only"
        self.setObjectName("compactConfirmDialog")
        self.setWindowTitle("Sessão do PWM")
        self.setModal(True)
        self.setFixedWidth(445)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(13)
        row = QHBoxLayout()
        row.setSpacing(12)
        icon = QLabel()
        icon.setObjectName("confirmIcon")
        icon.setFixedSize(38, 38)
        icon.setAlignment(Qt.AlignCenter)
        icon.setPixmap(modern_icon("lock", BLUE, 20).pixmap(20, 20))
        row.addWidget(icon, 0, Qt.AlignTop)
        texts = QVBoxLayout()
        texts.setSpacing(4)
        heading = QLabel("O PWM está logado?")
        heading.setObjectName("confirmTitle")
        texts.addWidget(heading)
        browser_label = dict(BROWSER_OPTIONS).get(preferred_browser(), "navegador padrão do Windows")
        description = QLabel(
            "O Active Directory já foi consultado. Escolha como deseja complementar "
            f"esta solicitação com os dados do Gestor de Senhas usando o {browser_label}."
        )
        description.setObjectName("confirmMessage")
        description.setWordWrap(True)
        texts.addWidget(description)
        row.addLayout(texts, 1)
        layout.addLayout(row)

        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        ad_only = QPushButton("Somente AD")
        ad_only.setObjectName("secondaryButton")
        ad_only.clicked.connect(lambda: self.finish("ad_only"))
        buttons.addWidget(ad_only)
        open_pwm = QPushButton(f"Não, abrir PWM no {browser_label}")
        open_pwm.setObjectName("secondaryButton")
        set_button_icon(open_pwm, "external", BLUE, 14)
        open_pwm.clicked.connect(lambda: self.finish("open"))
        buttons.addWidget(open_pwm)
        confirm = QPushButton("Sim, consultar")
        confirm.setObjectName("primaryButton")
        set_button_icon(confirm, "check", "#FFFFFF", 14)
        confirm.clicked.connect(lambda: self.finish("confirm"))
        confirm.setDefault(True)
        buttons.addWidget(confirm)
        layout.addLayout(buttons)
        self.fade = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade.setDuration(150)
        self.fade.setStartValue(0.0)
        self.fade.setEndValue(1.0)
        self.fade.setEasingCurve(QEasingCurve.OutCubic)

    def finish(self, choice: str):
        self.choice = choice
        self.accept()

    def showEvent(self, event):
        super().showEvent(event)
        self.setWindowOpacity(0.0)
        self.fade.start()


def ask_password_manager_session(parent: QWidget) -> str:
    dialog = PasswordManagerSessionDialog(parent)
    dialog.exec()
    return dialog.choice


class CompactNoticeDialog(QDialog):
    """Aviso informativo pequeno para mensagens operacionais simples."""

    def __init__(self, title: str, message: str, parent=None):
        super().__init__(parent)
        self.setObjectName("compactNoticeDialog")
        self.setWindowTitle(title)
        self.setModal(True)
        self.setFixedWidth(350)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 15)
        layout.setSpacing(12)
        row = QHBoxLayout()
        row.setSpacing(11)
        icon = QLabel()
        icon.setObjectName("noticeIcon")
        icon.setFixedSize(34, 34)
        icon.setAlignment(Qt.AlignCenter)
        icon.setPixmap(modern_icon("info", BLUE, 18).pixmap(18, 18))
        row.addWidget(icon, 0, Qt.AlignTop)
        message_label = QLabel(message)
        message_label.setObjectName("noticeMessage")
        message_label.setWordWrap(True)
        row.addWidget(message_label, 1)
        layout.addLayout(row)
        ok = QPushButton("OK")
        ok.setObjectName("primaryButton")
        ok.setFixedWidth(82)
        ok.clicked.connect(self.accept)
        ok.setDefault(True)
        layout.addWidget(ok, 0, Qt.AlignRight)
        self.fade = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade.setDuration(145)
        self.fade.setStartValue(0.0)
        self.fade.setEndValue(1.0)
        self.fade.setEasingCurve(QEasingCurve.OutCubic)

    def showEvent(self, event):
        super().showEvent(event)
        self.setWindowOpacity(0.0)
        self.fade.start()


class OperationProgressDialog(QDialog):
    """Progresso não bloqueante que só conclui após o processo real e o tempo visual mínimo."""

    completed = Signal(bool, str)

    def __init__(self, title: str, message: str, minimum_duration_ms: int, parent=None):
        super().__init__(parent)
        self.setObjectName("operationProgressDialog")
        self.setWindowTitle(title)
        self.setModal(True)
        self.setFixedWidth(410)
        self.setWindowFlag(Qt.WindowCloseButtonHint, False)
        self.minimum_duration_ms = max(250, int(minimum_duration_ms))
        self.started_at = time.monotonic()
        self.backend_done = False
        self.backend_ok = False
        self.backend_output = ""
        self.completion_confirmed = False
        self.progress_value = 2
        self._emitted = False

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 18)
        layout.setSpacing(11)
        heading = QLabel(title)
        heading.setObjectName("dialogTitle")
        layout.addWidget(heading)
        self.message_label = QLabel(message)
        self.message_label.setObjectName("dialogHint")
        self.message_label.setWordWrap(True)
        layout.addWidget(self.message_label)
        progress_header = QHBoxLayout()
        self.phase_label = QLabel("Iniciando operação…")
        self.phase_label.setObjectName("operationProgressLabel")
        progress_header.addWidget(self.phase_label)
        progress_header.addStretch(1)
        self.percent_label = QLabel("2%")
        self.percent_label.setObjectName("operationProgressPercent")
        progress_header.addWidget(self.percent_label)
        layout.addLayout(progress_header)
        self.progress_bar = QProgressBar()
        self.progress_bar.setObjectName("operationProgressBar")
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(2)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(9)
        layout.addWidget(self.progress_bar)
        self.result_label = QLabel()
        self.result_label.setObjectName("dialogHint")
        self.result_label.setWordWrap(True)
        self.result_label.hide()
        layout.addWidget(self.result_label)
        self.close_button = QPushButton("Fechar")
        self.close_button.setObjectName("secondaryButton")
        self.close_button.clicked.connect(self._complete)
        self.close_button.hide()
        layout.addWidget(self.close_button, 0, Qt.AlignRight)

        self.timer = QTimer(self)
        self.timer.setInterval(50)
        self.timer.timeout.connect(self._advance)
        self.timer.start()
        self.fade = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade.setDuration(150)
        self.fade.setStartValue(0.0)
        self.fade.setEndValue(1.0)
        self.fade.setEasingCurve(QEasingCurve.OutCubic)

    def showEvent(self, event):
        super().showEvent(event)
        self.setWindowOpacity(0.0)
        self.fade.start()

    def reject(self):
        if self._emitted:
            super().reject()

    def finish_operation(self, ok: bool, output: str, completion_confirmed: bool = False):
        self.backend_done = True
        self.backend_ok = bool(ok)
        self.backend_output = output
        self.completion_confirmed = bool(completion_confirmed)
        self.phase_label.setText("Finalizando e atualizando o painel…" if ok else "Concluindo diagnóstico…")

    def _set_progress(self, value: int):
        self.progress_value = max(self.progress_value, min(100, int(value)))
        self.progress_bar.setValue(self.progress_value)
        self.percent_label.setText(f"{self.progress_value}%")

    def _advance(self):
        elapsed_ms = int((time.monotonic() - self.started_at) * 1000)
        timed_value = 2 + int(min(1.0, elapsed_ms / self.minimum_duration_ms) * 92)
        self._set_progress(min(94, timed_value))
        if not self.backend_done:
            if self.progress_value >= 94:
                self.phase_label.setText("Aguardando confirmação da estação…")
            return
        if elapsed_ms < self.minimum_duration_ms:
            return
        if not self.backend_ok or not self.completion_confirmed:
            self.timer.stop()
            self.phase_label.setText(
                "Solicitação enviada; atualização do painel não confirmada."
                if self.backend_ok else "Não foi possível confirmar a operação."
            )
            if not self._emitted:
                self._emitted = True
                self.result_label.setText(self.backend_output or "Consulte o Console de atividades para detalhes.")
                self.result_label.show()
                self.close_button.show()
            return
        if self.progress_value < 100:
            self._set_progress(min(100, self.progress_value + 3))
            return
        self.timer.stop()
        self.phase_label.setText("Solicitação processada; painéis atualizados.")
        self.result_label.setText(self.backend_output)
        self.result_label.show()
        if self._emitted:
            return
        self._emitted = True
        QTimer.singleShot(1400, self._complete)

    def _complete(self):
        if not self._emitted:
            return
        self.completed.emit(self.backend_ok, self.backend_output)
        self.accept()


def show_notice(parent: QWidget, message: str, title: str = APP_NAME):
    CompactNoticeDialog(title, message, parent).exec()


def screen_capture_settings_path() -> Path:
    return faq_cache_path().with_name("screen_capture_preferences.json")


def default_screen_capture_folder() -> Path:
    """Downloads do usuário padrão, mesmo quando o Atlas roda no login _INS."""
    profile = interactive_user_profile()
    downloads = dict(standard_user_folders(profile)).get("Downloads")
    if downloads is not None:
        return downloads
    folder = profile / "Downloads"
    return folder if folder.is_dir() else default_capture_folder()


def configured_screen_capture_folder() -> str:
    return str(load_json_cache(screen_capture_settings_path()).get("folder") or "").strip()


def screen_capture_folder() -> Path:
    configured = configured_screen_capture_folder()
    if configured and Path(configured).is_dir():
        return Path(configured)
    return default_screen_capture_folder()


def open_browser_settings_dialog(parent: QWidget) -> str:
    """Centraliza preferências do Atlas e a verificação preventiva da instalação."""
    global _BROWSER_PREFERENCE_OVERRIDE
    dialog = QDialog(parent)
    dialog.setObjectName("resultDialog")
    dialog.setWindowTitle("Configurações do Atlas")
    dialog.setModal(True)
    dialog.setFixedWidth(430)
    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(22, 20, 22, 20)
    layout.setSpacing(12)

    title = QLabel("Navegador para abrir links")
    title.setObjectName("dialogTitle")
    layout.addWidget(title)
    hint = QLabel(
        "Escolha como o Atlas abrirá links de FAQs, chamados, perfis dos desenvolvedores "
        "e interfaces web de impressoras. Se Chrome ou Edge forem escolhidos e não estiverem "
        "disponíveis, o Atlas avisará sem trocar silenciosamente de navegador."
    )
    hint.setObjectName("dialogHint")
    hint.setWordWrap(True)
    layout.addWidget(hint)

    browser_combo = QComboBox()
    browser_combo.setObjectName("settingsBrowserCombo")
    browser_combo.setMinimumHeight(44)
    for key, label in BROWSER_OPTIONS:
        browser_combo.addItem(label, key)
    selected_index = browser_combo.findData(preferred_browser())
    browser_combo.setCurrentIndex(max(0, selected_index))
    layout.addWidget(browser_combo)

    layout.addWidget(section_separator())
    validation_title = QLabel("Manutenção e integridade periódicas")
    validation_title.setObjectName("dialogTitle")
    layout.addWidget(validation_title)
    validation_hint = QLabel(
        "Confere arquivos essenciais, scripts, catálogos, sintaxe e versão. A manutenção "
        "é local, roda fora da interface e não acessa estações, AD ou Capri."
    )
    validation_hint.setObjectName("dialogHint")
    validation_hint.setWordWrap(True)
    layout.addWidget(validation_hint)

    validation_combo = QComboBox()
    validation_combo.setObjectName("settingsValidationCombo")
    validation_combo.setMinimumHeight(44)
    for key, label, _days in VALIDATION_INTERVALS:
        validation_combo.addItem(label, key)
    validation_state = structural_validation_settings()
    validation_combo.setCurrentIndex(max(0, validation_combo.findData(validation_state["interval"])))
    layout.addWidget(validation_combo)

    cleanup_checkbox = QCheckBox("Remover resíduos regeneráveis do Atlas")
    cleanup_checkbox.setObjectName("settingsSafeCleanup")
    cleanup_checkbox.setChecked(bool(validation_state.get("safe_cleanup", True)))
    cleanup_checkbox.setToolTip(
        "Remove somente arquivos .tmp abandonados. FAQs, chamados, preferências, "
        "credenciais, sessões, scripts e versões anteriores são preservados."
    )
    layout.addWidget(cleanup_checkbox)

    validation_status = QLabel(validation_state.get("last_summary") or "Ainda não executada.")
    validation_status.setObjectName("settingsValidationStatus")
    validation_status.setProperty("status", validation_state.get("last_status", "never"))
    validation_status.setWordWrap(True)
    layout.addWidget(validation_status)

    validate_now = QPushButton("Validar agora")
    validate_now.setObjectName("secondaryButton")
    set_button_icon(validate_now, "check", GREEN, 15)

    def validate_now_requested():
        validate_now.setEnabled(False)
        QApplication.processEvents()
        result = run_structural_validation(cleanup_checkbox.isChecked())
        validation_state.update(result)
        validation_status.setText(result["last_summary"])
        validation_status.setProperty("status", result["last_status"])
        validation_status.style().unpolish(validation_status)
        validation_status.style().polish(validation_status)
        validate_now.setEnabled(True)

    validate_now.clicked.connect(validate_now_requested)
    layout.addWidget(validate_now, 0, Qt.AlignLeft)

    layout.addWidget(section_separator())
    capture_title = QLabel("Pasta das capturas de tela")
    capture_title.setObjectName("dialogTitle")
    layout.addWidget(capture_title)
    capture_hint = QLabel("O editor abre após o recorte. Destino inicial: Downloads do usuário padrão, mesmo no INS.")
    capture_hint.setObjectName("dialogHint")
    capture_hint.setWordWrap(True)
    layout.addWidget(capture_hint)
    capture_choice = {"folder": configured_screen_capture_folder()}
    capture_folder_edit = QLineEdit()
    capture_folder_edit.setObjectName("settingsCaptureFolder")
    capture_folder_edit.setReadOnly(True)
    capture_folder_edit.setMinimumHeight(40)

    def show_capture_folder():
        folder = capture_choice["folder"]
        capture_folder_edit.setText(folder or f"{default_screen_capture_folder()} (padrão)")
        capture_folder_edit.setToolTip(capture_folder_edit.text())
        capture_folder_edit.setCursorPosition(0)

    def choose_capture_folder():
        selected = QFileDialog.getExistingDirectory(
            dialog, "Pasta das capturas de tela", str(screen_capture_folder())
        )
        if selected:
            capture_choice["folder"] = str(Path(selected))
            show_capture_folder()

    def reset_capture_folder():
        capture_choice["folder"] = ""
        show_capture_folder()

    show_capture_folder()
    capture_buttons = QHBoxLayout()
    capture_buttons.setSpacing(8)
    capture_buttons.addWidget(capture_folder_edit, 1)
    choose_capture = QPushButton("")
    choose_capture.setObjectName("secondaryButton")
    choose_capture.setToolTip("Escolher pasta")
    choose_capture.setAccessibleName("Escolher pasta")
    choose_capture.setFixedSize(44, 40)
    set_button_icon(choose_capture, "folder", BLUE, 16)
    choose_capture.clicked.connect(choose_capture_folder)
    default_capture = QPushButton("")
    default_capture.setObjectName("secondaryButton")
    default_capture.setToolTip("Usar padrão (Downloads do usuário padrão)")
    default_capture.setAccessibleName("Usar padrão")
    default_capture.setFixedSize(44, 40)
    set_button_icon(default_capture, "refresh", BLUE, 16)
    default_capture.clicked.connect(reset_capture_folder)
    capture_buttons.addWidget(choose_capture)
    capture_buttons.addWidget(default_capture)
    layout.addLayout(capture_buttons)

    actions = QHBoxLayout()
    actions.addStretch()
    cancel = QPushButton("Cancelar")
    cancel.setObjectName("secondaryButton")
    save = QPushButton("Salvar")
    save.setObjectName("primaryButton")
    set_button_icon(save, "check", "#FFFFFF", 15)
    cancel.clicked.connect(dialog.reject)
    save.clicked.connect(dialog.accept)
    save.setDefault(True)
    actions.addWidget(cancel)
    actions.addWidget(save)
    layout.addLayout(actions)

    if dialog.exec() != QDialog.Accepted:
        return ""
    preference = str(browser_combo.currentData() or "system")
    if not save_json_cache(browser_settings_path(), {"browser": preference}):
        show_notice(parent, "Não foi possível salvar a preferência de navegador.")
        return ""
    _BROWSER_PREFERENCE_OVERRIDE = preference
    if getpass.getuser().lower().endswith("_ins"):
        sync_browser_preference_with_standard_session(preference)
    validation_state["interval"] = str(validation_combo.currentData() or "weekly")
    validation_state["safe_cleanup"] = cleanup_checkbox.isChecked()
    if not save_json_cache(structural_validation_settings_path(), validation_state):
        show_notice(parent, "O navegador foi salvo, mas não foi possível salvar a validação periódica.")
        return ""
    if not save_json_cache(screen_capture_settings_path(), {"folder": capture_choice["folder"]}):
        show_notice(parent, "As preferências foram salvas, mas não foi possível salvar a pasta das capturas.")
        return ""
    label = dict(BROWSER_OPTIONS).get(preference, "Padrão do Windows")
    interval_label = next(
        (text for key, text, _days in VALIDATION_INTERVALS if key == validation_state["interval"]),
        "Semanalmente",
    )
    show_notice(
        parent,
        f"Navegador: {label}.\nManutenção estrutural: {interval_label}.\n"
        f"Limpeza segura: {'ativada' if cleanup_checkbox.isChecked() else 'desativada'}.\n"
        f"Capturas de tela: {screen_capture_folder()}.",
        "Configurações",
    )
    return label


class AuthorizedPrinterDialog(QDialog):
    """Entrada de impressora com validação visual ao vivo contra os grupos do AD."""

    def __init__(self, title: str, authorized: list[str], parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        self.setFixedWidth(430)
        self.authorized = {
            self._normalize(item).casefold() for item in authorized if self._normalize(item)
        }
        self._state = "neutral"

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 18)
        layout.setSpacing(11)

        heading = QLabel("Selecione ou digite o código da impressora:")
        heading.setObjectName("confirmTitle")
        layout.addWidget(heading)

        self.combo = QComboBox()
        self.combo.setEditable(True)
        self.combo.addItems(authorized)
        self.combo.setCurrentText("")
        self.combo.setInsertPolicy(QComboBox.NoInsert)
        self.combo.setFixedHeight(52)
        self.combo.lineEdit().setPlaceholderText("Ex.: IL0062Temp")
        self.combo.lineEdit().textChanged.connect(self._validate)
        self.glow = QGraphicsDropShadowEffect(self.combo)
        self.glow.setOffset(0, 0)
        self.glow.setBlurRadius(0)
        self.combo.setGraphicsEffect(self.glow)
        self.glow_animation = QPropertyAnimation(self.glow, b"blurRadius", self)
        self.glow_animation.setDuration(1050)
        self.glow_animation.setLoopCount(-1)
        self.glow_animation.setEasingCurve(QEasingCurve.InOutSine)
        self.glow_animation.setKeyValueAt(0.0, 7.0)
        self.glow_animation.setKeyValueAt(0.5, 22.1)
        self.glow_animation.setKeyValueAt(1.0, 7.0)
        layout.addWidget(self.combo)

        self.status = QLabel("Digite ou selecione uma impressora da lista autorizada.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)

        buttons = QHBoxLayout()
        buttons.addStretch()
        cancel = QPushButton("Cancelar")
        cancel.setObjectName("secondaryButton")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        self.confirm = QPushButton("OK")
        self.confirm.setObjectName("primaryButton")
        self.confirm.setEnabled(False)
        self.confirm.clicked.connect(self.accept)
        self.confirm.setDefault(True)
        buttons.addWidget(self.confirm)
        layout.addLayout(buttons)

        self._draw_state()

    @staticmethod
    def _normalize(value: str) -> str:
        name = str(value or "").replace(" (Padrão)", "").strip().rstrip("\\/")
        if "\\" in name:
            name = name.split("\\")[-1]
        return name.strip()

    def _validate(self, text: str):
        value = self._normalize(text)
        self.confirm.setEnabled(bool(value))
        new_state = "neutral" if not value else ("allowed" if value.casefold() in self.authorized else "denied")
        if new_state != self._state:
            self._state = new_state
            if new_state == "neutral":
                self.glow_animation.stop()
                self.glow.setBlurRadius(0)
            elif self.glow_animation.state() != QAbstractAnimation.Running:
                self.glow_animation.start()
        self._draw_state()

    def _draw_state(self):
        if self._state == "allowed":
            border, background = "#00B965", "#E9FFF4"
            self.glow.setColor(QColor(0, 210, 116, 185))
            self.status.setText("●  AUTORIZADA NO AD  •  instalação liberada para o usuário")
            self.status.setStyleSheet(
                "color: #006E3D; background: #DDF8EA; border: 1px solid #8DDBB5; "
                "border-radius: 9px; padding: 8px 10px; font-weight: 800;"
            )
        elif self._state == "denied":
            border, background = "#E42343", "#FFF0F3"
            self.glow.setColor(QColor(239, 35, 70, 175))
            self.status.setText("●  NÃO AUTORIZADA  •  código ausente nos grupos do usuário")
            self.status.setStyleSheet(
                "color: #A70F2A; background: #FFE2E8; border: 1px solid #EE9CAC; "
                "border-radius: 9px; padding: 8px 10px; font-weight: 800;"
            )
        else:
            border, background = "#B8C9D5", "#FFFFFF"
            self.glow.setColor(QColor(0, 0, 0, 0))
            self.status.setText("Digite ou selecione uma impressora da lista autorizada.")
            self.status.setStyleSheet(
                "color: #637789; background: #F2F6F9; border: 1px solid #D7E2E9; "
                "border-radius: 9px; padding: 8px 10px; font-weight: 650;"
            )
        self.combo.setStyleSheet(
            f"QComboBox {{ background: {background}; border: 3px solid {border}; "
            "border-radius: 11px; padding: 5px 38px 5px 12px; min-height: 38px; "
            "font-size: 13px; font-weight: 750; color: #102638; }}"
            "QComboBox::drop-down { border: none; width: 34px; }"
            f"QComboBox QAbstractItemView {{ background: white; color: #102638; border: 1px solid {border}; "
            "selection-background-color: #E1F3EA; selection-color: #00305C; padding: 5px; }}"
        )

    def value(self) -> str:
        return self._normalize(self.combo.currentText())


class PrinterSelectionDialog(QDialog):
    """Escolha explícita de uma impressora já retornada pela estação."""

    def __init__(self, title: str, printers: list[str], default_name: str = "", parent=None):
        super().__init__(parent)
        self.setObjectName("resultDialog")
        self.setWindowTitle(title)
        self.setModal(True)
        self.setFixedWidth(430)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 18)
        layout.setSpacing(11)

        heading = QLabel("Escolha a impressora")
        heading.setObjectName("dialogTitle")
        layout.addWidget(heading)
        hint = QLabel("A ação só será iniciada depois que você confirmar uma das opções listadas pela estação.")
        hint.setObjectName("smallMuted")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        self.combo = QComboBox()
        self.combo.setObjectName("printerActionSelect")
        self.combo.setEditable(False)
        self.combo.setMinimumHeight(46)
        default_index = 0
        for index, printer in enumerate(printers):
            is_default = bool(default_name) and printer.casefold() == default_name.casefold()
            self.combo.addItem(f"{printer} (Padrão)" if is_default else printer, printer)
            if is_default:
                default_index = index
        self.combo.setCurrentIndex(default_index)
        layout.addWidget(self.combo)

        buttons = QHBoxLayout()
        buttons.addStretch()
        cancel = QPushButton("Cancelar")
        cancel.setObjectName("secondaryButton")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        confirm_text = {
            "Pingar impressora": "Executar ping",
            "Interface web da impressora": "Abrir interface",
            "Imprimir página de teste": "Imprimir teste",
        }.get(title, "Confirmar")
        confirm = QPushButton(confirm_text)
        confirm.setObjectName("primaryButton")
        set_button_icon(confirm, "check", "#FFFFFF", 15)
        confirm.clicked.connect(self.accept)
        confirm.setDefault(True)
        buttons.addWidget(confirm)
        layout.addLayout(buttons)

    def value(self) -> str:
        return str(self.combo.currentData() or "").strip()


class ResultDialog(QDialog):
    """Janela de resultado com entrada suave e conteúdo copiável."""

    def __init__(self, title: str, subtitle: str, content: str, success: bool = True, parent=None):
        super().__init__(parent)
        self.setObjectName("resultDialog")
        self.setProperty("success", success)
        self.setWindowTitle(title)
        self.setModal(True)
        self.resize(470, 330)
        self.setMinimumSize(380, 270)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 17, 18, 16)
        layout.setSpacing(9)
        header = QFrame(objectName="popupHeader")
        header_row = QHBoxLayout(header)
        header_row.setContentsMargins(12, 10, 12, 10)
        status_icon = QLabel()
        status_icon.setObjectName("popupStatusIconOk" if success else "popupStatusIconError")
        status_icon.setFixedSize(36, 36)
        status_icon.setAlignment(Qt.AlignCenter)
        status_icon.setPixmap(modern_icon("check" if success else "close", GREEN if success else RED, 21).pixmap(21, 21))
        header_row.addWidget(status_icon)
        header_text = QVBoxLayout()
        eyebrow = QLabel("AÇÃO CONCLUÍDA" if success else "AÇÃO NÃO CONCLUÍDA")
        eyebrow.setObjectName("dialogSuccess" if success else "dialogError")
        header_text.addWidget(eyebrow)
        heading = QLabel(title)
        heading.setObjectName("dialogTitle")
        heading.setWordWrap(True)
        header_text.addWidget(heading)
        header_row.addLayout(header_text, 1)
        layout.addWidget(header)
        description = QLabel(subtitle)
        description.setObjectName("smallMuted")
        description.setWordWrap(True)
        layout.addWidget(description)

        visible_content = content.strip() or "A consulta não retornou informações."
        self.raw_content = visible_content
        result_host, _rendered = popup_content_widget(visible_content)
        result_scroll = QScrollArea()
        result_scroll.setObjectName("popupResultScroll")
        result_scroll.setWidgetResizable(True)
        result_scroll.setFrameShape(QFrame.NoFrame)
        result_scroll.setWidget(result_host)
        layout.addWidget(result_scroll, 1)

        buttons = QHBoxLayout()
        buttons.addStretch()
        copy_button = QPushButton("Copiar resultado")
        copy_button.setObjectName("secondaryButton")
        set_button_icon(copy_button, "copy", BLUE, 16)
        copy_button.clicked.connect(lambda: QApplication.clipboard().setText(self.raw_content))
        buttons.addWidget(copy_button)
        close_button = QPushButton("Fechar")
        close_button.setObjectName("primaryButton")
        set_button_icon(close_button, "check", "#FFFFFF", 16)
        close_button.clicked.connect(self.accept)
        buttons.addWidget(close_button)
        layout.addLayout(buttons)

        self.fade = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade.setDuration(285)
        self.fade.setStartValue(0.0)
        self.fade.setKeyValueAt(0.45, 0.72)
        self.fade.setEndValue(1.0)
        self.fade.setEasingCurve(QEasingCurve.InOutCubic)
        fit_dialog_to_content(self, [title, subtitle, visible_content], 400, 270, 190)

    def showEvent(self, event):
        super().showEvent(event)
        self.setWindowOpacity(0.0)
        self.fade.start()


class ADUserDialog(QDialog):
    """Resumo do usuário do AD organizado em abas navegáveis."""

    def __init__(self, data: dict, parent=None):
        super().__init__(parent)
        self.setObjectName("resultDialog")
        self.setWindowTitle("Informações do usuário no AD")
        self.setModal(True)
        self.resize(540, 390)
        self.setMinimumSize(450, 320)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 17, 18, 16)
        layout.setSpacing(8)
        eyebrow = QLabel("CONSULTA AO ACTIVE DIRECTORY")
        eyebrow.setObjectName("dialogSuccess")
        layout.addWidget(eyebrow)
        heading = QLabel(str(data.get("user", "Usuário conectado")))
        heading.setObjectName("dialogTitle")
        heading.setWordWrap(True)
        layout.addWidget(heading)
        subtitle = QLabel("Informações da conta conectada à estação remota, separadas por categoria.")
        subtitle.setObjectName("smallMuted")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        self.tabs = QTabWidget()
        self.tabs.setObjectName("adTabs")
        sections = [
            ("Organização", data.get("organization", {})),
            ("Conta", data.get("account", {})),
            ("Perfil", data.get("profile", {})),
            ("Membro de", data.get("groups", [])),
        ]
        self.copy_text = []
        visible_sections = []
        for title, values in sections:
            page = QWidget()
            page_layout = QVBoxLayout(page)
            page_layout.setContentsMargins(10, 10, 10, 10)
            page_layout.setSpacing(8)
            if isinstance(values, dict):
                text = "\n\n".join(f"{key}\n{value or 'Não informado'}" for key, value in values.items())
                field_icons = ["settings", "user", "disk", "users", "info"]
                for index, (key, value) in enumerate(values.items()):
                    page_layout.addWidget(PopupInfoCard(
                        str(key), str(value or "Não informado"),
                        field_icons[index % len(field_icons)], copy_value=True,
                    ))
            else:
                if not isinstance(values, list):
                    values = [str(values)] if values else []
                text = "\n".join(
                    f"• {item}" + (f" — {ad_license_description(item)}" if ad_license_description(item) else "")
                    for item in values
                ) or "Nenhum grupo localizado."
                if values:
                    for item in values:
                        description = ad_license_description(item)
                        if description:
                            page_layout.addWidget(LicenseInfoCard(str(item), description))
                        else:
                            page_layout.addWidget(PopupInfoCard(
                                "Grupo do Active Directory", str(item), "users", copy_value=True,
                            ))
                else:
                    page_layout.addWidget(PopupInfoCard("Membro de", "Nenhum grupo localizado.", "users", copy_value=True))
                policy_title = QLabel("POLÍTICA DE USO DAS LICENÇAS")
                policy_title.setObjectName("licensePolicyTitle")
                page_layout.addWidget(policy_title)
                for audience, guideline in AD_LICENSE_POLICY:
                    page_layout.addWidget(PopupInfoCard(audience, guideline, "shield"))
                text += "\n\nPOLÍTICA DE USO DAS LICENÇAS\n" + "\n".join(
                    f"{audience}: {guideline}" for audience, guideline in AD_LICENSE_POLICY
                )
            page_layout.addStretch()
            content = QScrollArea()
            content.setObjectName("popupResultScroll")
            content.setWidgetResizable(True)
            content.setFrameShape(QFrame.NoFrame)
            content.setWidget(page)
            visible_sections.append(text)
            self.copy_text.append(f"{title.upper()}\n{text}")
            self.tabs.addTab(content, title)
        layout.addWidget(self.tabs, 1)

        buttons = QHBoxLayout()
        buttons.addStretch()
        self.copy_button = QPushButton("Copiar esta aba")
        self.copy_button.setObjectName("secondaryButton")
        self.copy_button.setToolTip("Copia somente as informações da aba selecionada")
        set_button_icon(self.copy_button, "copy", BLUE, 16)
        self.copy_button.clicked.connect(self._copy_current_tab)
        buttons.addWidget(self.copy_button)
        close_button = QPushButton("Fechar")
        close_button.setObjectName("primaryButton")
        set_button_icon(close_button, "check", "#FFFFFF", 16)
        close_button.clicked.connect(self.accept)
        buttons.addWidget(close_button)
        layout.addLayout(buttons)

        self.fade = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade.setDuration(165)
        self.fade.setStartValue(0.0)
        self.fade.setEndValue(1.0)
        self.fade.setEasingCurve(QEasingCurve.OutCubic)
        fit_dialog_to_content(self, visible_sections, 470, 320, 210)

    def _copy_current_tab(self):
        index = max(0, self.tabs.currentIndex())
        if index < len(self.copy_text):
            QApplication.clipboard().setText(self.copy_text[index])
            original = self.copy_button.text()
            self.copy_button.setText("Aba copiada")
            set_button_icon(self.copy_button, "check", GREEN, 16)
            QTimer.singleShot(1200, lambda: (
                self.copy_button.setText(original),
                set_button_icon(self.copy_button, "copy", BLUE, 16),
            ))

    def showEvent(self, event):
        super().showEvent(event)
        self.setWindowOpacity(0.0)
        self.fade.start()


class DiskProfilesDialog(QDialog):
    """Diagnóstico organizado de armazenamento e perfis da estação."""

    def __init__(self, data: dict, parent=None):
        super().__init__(parent)
        self.setObjectName("resultDialog")
        self.setWindowTitle("Discos e perfis")
        self.setModal(True)
        self.resize(570, 420)
        self.setMinimumSize(470, 340)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 17, 18, 16)
        layout.setSpacing(8)
        eyebrow = QLabel("DIAGNÓSTICO DA ESTAÇÃO")
        eyebrow.setObjectName("dialogSuccess")
        layout.addWidget(eyebrow)
        heading = QLabel(f"Discos e perfis  •  {data.get('station', 'Estação remota')}")
        heading.setObjectName("dialogTitle")
        layout.addWidget(heading)

        tabs = QTabWidget()
        tabs.setObjectName("adTabs")
        disks_page = QWidget()
        disks_layout = QVBoxLayout(disks_page)
        disks_layout.setContentsMargins(12, 12, 12, 12)
        disks_layout.setSpacing(9)
        disks = data.get("disks", [])
        if not isinstance(disks, list):
            disks = [disks] if disks else []
        for disk in disks:
            card = QFrame(objectName="diskCard")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(12, 10, 12, 10)
            kind = str(disk.get("kind", "Unidade"))
            provider = str(disk.get("provider", "") or "")
            label = str(disk.get("label", "") or "")
            size_available = bool(disk.get("size_available", True))
            capacity = (
                f"{disk.get('free_gb', 0)} GB livres de {disk.get('total_gb', 0)} GB"
                if size_available else "Capacidade não disponível para esta sessão"
            )
            drive_name = str(disk.get("drive", "Unidade"))
            display_name = str(disk.get("display_name", "") or "").strip()
            heading = f"{display_name or kind} ({drive_name})"
            title = QLabel(heading)
            title.setObjectName("diskTitle")
            title.setWordWrap(True)
            card_layout.addWidget(title)
            details_parts = [kind]
            if provider:
                details_parts.append(provider)
            details_parts.append(capacity)
            details_text = "  •  ".join(details_parts)
            details = QLabel(details_text)
            details.setObjectName("profileDetails")
            details.setWordWrap(True)
            details.setTextInteractionFlags(Qt.TextSelectableByMouse)
            card_layout.addWidget(details)
            usage = int(round(float(disk.get("used_percent", 0))))
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(max(0, min(100, usage)))
            bar.setFormat(f"{usage}% utilizado" if size_available else "Mapeamento localizado")
            card_layout.addWidget(bar)
            disks_layout.addWidget(card)
        if not disks:
            disks_layout.addWidget(QLabel("Nenhuma unidade de disco foi localizada."))
        network_disks = [disk for disk in disks if str(disk.get("kind", "")).casefold() == "unidade de rede"]
        drive_collection = str(data.get("drive_collection", "") or "").strip()
        if not network_disks and drive_collection:
            warning = QLabel(
                "Os drives do usuário não foram devolvidos pela sessão interativa.\n"
                f"Diagnóstico: {drive_collection}"
            )
            warning.setObjectName("smallMuted")
            warning.setWordWrap(True)
            warning.setStyleSheet(
                "color:#795600; background:#FFF8D9; border:1px solid #E7CA65; "
                "border-radius:9px; padding:9px 11px; font-weight:650;"
            )
            disks_layout.addWidget(warning)
        disks_layout.addStretch()
        disks_scroll = QScrollArea()
        disks_scroll.setObjectName("dialogScroll")
        disks_scroll.setWidgetResizable(True)
        disks_scroll.setFrameShape(QFrame.NoFrame)
        disks_scroll.setWidget(disks_page)
        tabs.addTab(disks_scroll, f"Discos e rede ({len(disks)})")

        profiles = data.get("profiles", [])
        if not isinstance(profiles, list):
            profiles = [profiles] if profiles else []
        profiles_page = QWidget()
        profiles_layout = QVBoxLayout(profiles_page)
        profiles_layout.setContentsMargins(12, 12, 12, 12)
        profiles_layout.setSpacing(9)
        profile_summaries = []
        for profile in profiles:
            state = "Carregado agora" if profile.get("loaded") else "Não carregado"
            size_available = bool(profile.get("size_available"))
            size_gb = float(profile.get("size_gb", 0) or 0)
            size_bytes = int(profile.get("size_bytes", 0) or 0)
            disk_percent = int(round(float(profile.get("disk_percent", 0) or 0)))
            if size_available:
                if size_bytes >= 1024 ** 3:
                    size_text = f"{size_bytes / (1024 ** 3):.2f} GB ocupados"
                elif size_bytes >= 1024 ** 2:
                    size_text = f"{size_bytes / (1024 ** 2):.1f} MB ocupados"
                else:
                    size_text = f"{size_bytes / 1024:.1f} KB ocupados"
            else:
                size_text = "Tamanho não calculado"
            card = QFrame(objectName="diskCard")
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(12, 10, 12, 10)
            profile_name = profile.get("user") or profile.get("path", "Perfil")
            title = QLabel(f"{profile_name}  •  {size_text}")
            title.setObjectName("diskTitle")
            title.setWordWrap(True)
            card_layout.addWidget(title)
            details = QLabel(
                f"{profile.get('path', 'Caminho não informado')}\n"
                f"{state}  •  Último uso: {profile.get('last_use', 'Não informado')}\n"
                f"SID: {profile.get('sid', 'Não informado')}"
            )
            details.setObjectName("profileDetails")
            details.setWordWrap(True)
            card_layout.addWidget(details)
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(max(0, min(100, disk_percent)))
            bar.setFormat(f"{size_text}  •  {disk_percent}% do disco" if size_available else size_text)
            card_layout.addWidget(bar)
            profiles_layout.addWidget(card)
            profile_summaries.append(f"{profile.get('path', 'Perfil')}\n{size_text}\n{state}\n{profile.get('last_use', '')}\n{profile.get('sid', '')}")
        if not profiles:
            profiles_layout.addWidget(QLabel("Nenhum perfil de usuário foi localizado."))
        profiles_layout.addStretch()
        profiles_scroll = QScrollArea()
        profiles_scroll.setObjectName("dialogScroll")
        profiles_scroll.setWidgetResizable(True)
        profiles_scroll.setFrameShape(QFrame.NoFrame)
        profiles_scroll.setWidget(profiles_page)
        tabs.addTab(profiles_scroll, f"Perfis ({len(profiles)})")
        layout.addWidget(tabs, 1)

        close_button = QPushButton("Fechar")
        close_button.setObjectName("primaryButton")
        set_button_icon(close_button, "check", "#FFFFFF", 16)
        close_button.clicked.connect(self.accept)
        layout.addWidget(close_button, 0, Qt.AlignRight)

        self.fade = QPropertyAnimation(self, b"windowOpacity", self)
        self.fade.setDuration(165)
        self.fade.setStartValue(0.0)
        self.fade.setEndValue(1.0)
        self.fade.setEasingCurve(QEasingCurve.OutCubic)
        disk_summaries = [f"{disk.get('drive', '')}\n{disk.get('total_gb', 0)}\n{disk.get('free_gb', 0)}\n{disk.get('used_percent', 0)}" for disk in disks]
        fit_dialog_to_content(self, ["\n".join(disk_summaries), "\n".join(profile_summaries)], 520, 380, 250)

    def showEvent(self, event):
        super().showEvent(event)
        self.setWindowOpacity(0.0)
        self.fade.start()


class RemoteInventoryDialog(QDialog):
    """Consulta transitória agrupada; nenhuma lista remota é gravada no cache."""

    def __init__(self, title: str, items: list[dict], target: str, process_mode: bool, parent=None):
        super().__init__(parent)
        self.setObjectName("remoteInventoryDialog")
        self.setWindowTitle(title)
        self.resize(780, 560)
        self.choice = "close"
        self.process_mode = process_mode
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(10)
        heading = QLabel(title)
        heading.setObjectName("dialogTitle")
        layout.addWidget(heading)
        hint = QLabel(
            f"{target} • {len(items)} processo(s) do usuário conectado. Maior consumo de memória primeiro; selecione um para encerrar."
            if process_mode else
            f"{target} • {len(items)} programa(s) registrados no perfil e na estação. Aplicativos portáteis podem não constar no Registro."
        )
        hint.setObjectName("dialogHint")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.tree = QTreeWidget()
        self.tree.setObjectName("inventoryTree")
        self.tree.setRootIsDecorated(True)
        self.tree.setAlternatingRowColors(True)
        self.tree.setUniformRowHeights(True)
        self.tree.setHeaderLabels(
            ["Software / processo", "Instâncias / PID", "Memória"]
            if process_mode else ["Programa instalado", "Origem", "Versão"]
        )
        self.tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tree.header().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        if process_mode:
            for name, processes, memory in group_processes_by_memory(items):
                parent_item = QTreeWidgetItem([name, f"{len(processes)} processo(s)", f"{memory:.1f} MB"])
                parent_item.setData(0, Qt.UserRole, {
                    "name": name, "pids": [item.get("pid") for item in processes],
                })
                self.tree.addTopLevelItem(parent_item)
                for item in processes:
                    child = QTreeWidgetItem([
                        name, f"PID {item.get('pid', '—')}",
                        f"{float(item.get('memory_mb') or 0):.1f} MB",
                    ])
                    child.setData(0, Qt.UserRole, item)
                    parent_item.addChild(child)
        else:
            groups: dict[str, list[dict]] = {}
            for item in items:
                groups.setdefault(str(item.get("scope") or "Origem não informada"), []).append(item)
            for scope in ("Perfil do usuário", "Estação (64 bits)", "Estação (32 bits)", *sorted(groups)):
                if scope not in groups:
                    continue
                programs = sorted(groups.pop(scope), key=lambda item: str(item.get("name") or "").casefold())
                parent_item = QTreeWidgetItem([scope, f"{len(programs)} programa(s)", ""])
                parent_item.setFlags(parent_item.flags() & ~Qt.ItemIsSelectable)
                self.tree.addTopLevelItem(parent_item)
                for item in programs:
                    parent_item.addChild(QTreeWidgetItem([
                        str(item.get("name") or "—"), "", str(item.get("version") or "—"),
                    ]))
                parent_item.setExpanded(True)
        layout.addWidget(self.tree, 1)
        buttons = QHBoxLayout()
        refresh = QPushButton("↻  Atualizar processos" if process_mode else "↻  Atualizar programas")
        refresh.setObjectName("secondaryButton")
        refresh.clicked.connect(lambda: self.finish("refresh"))
        buttons.addWidget(refresh)
        if process_mode:
            end = QPushButton("Encerrar selecionado")
            end.setObjectName("dangerButton")
            end.setEnabled(False)
            self.tree.currentItemChanged.connect(
                lambda row, _old: (
                    end.setEnabled(row is not None),
                    end.setText(
                        "Encerrar software" if row is not None and row.childCount()
                        else "Encerrar processo"
                    ),
                )
            )
            end.clicked.connect(lambda: self.finish("end"))
            buttons.addWidget(end)
        buttons.addStretch(1)
        close = QPushButton("Fechar")
        close.setObjectName("primaryButton")
        close.clicked.connect(self.reject)
        buttons.addWidget(close)
        layout.addLayout(buttons)

    def finish(self, choice: str):
        self.choice = choice
        self.accept()

    def selected(self):
        row = self.tree.currentItem()
        return row.data(0, Qt.UserRole) if row else None


class CertificatesDialog(QDialog):
    """Lista certificados pessoais encontrados exclusivamente na estação remota."""

    def __init__(self, data: dict, parent=None):
        super().__init__(parent)
        self.setObjectName("resultDialog")
        self.setWindowTitle("Certificados digitais remotos")
        self.setModal(True)
        self.resize(720, 520)
        self.setMinimumSize(560, 410)
        self.certificates = data.get("items", [])
        if not isinstance(self.certificates, list):
            self.certificates = [self.certificates] if self.certificates else []
        self._selected_certificate = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 20)
        layout.setSpacing(11)
        eyebrow = QLabel("CERTIFICADOS PESSOAIS DA ESTAÇÃO REMOTA")
        eyebrow.setObjectName("dialogSuccess")
        layout.addWidget(eyebrow)
        station = str(data.get("station", "Estação remota"))
        heading = QLabel(f"Certificados digitais  •  {station}")
        heading.setObjectName("dialogTitle")
        layout.addWidget(heading)
        logged_user = str(data.get("logged_user", "") or "Nenhum usuário conectado")
        session_status = str(data.get("session_status", "") or "").strip()
        diagnostic = f" {session_status}" if session_status else ""
        subtitle = QLabel(
            f"Usuário remoto: {logged_user}. Selecione um certificado para ver os detalhes ou excluí-lo. "
            f"Esta consulta não acessa os certificados do computador do analista.{diagnostic}"
        )
        subtitle.setObjectName("smallMuted")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        self.list_widget = QListWidget()
        self.list_widget.setObjectName("certificateList")
        self.list_widget.setAlternatingRowColors(True)
        for index, certificate in enumerate(self.certificates):
            display_name = str(certificate.get("display_name", "Certificado sem nome"))
            scope = str(certificate.get("scope", "Estação remota"))
            status = str(certificate.get("status", "Status não informado"))
            valid_to = str(certificate.get("valid_to", "Data não informada"))
            item = QListWidgetItem(f"{display_name}\n{scope}  •  {status}  •  válido até {valid_to}")
            item.setData(Qt.UserRole, index)
            item.setToolTip(str(certificate.get("subject", display_name)))
            self.list_widget.addItem(item)
        if self.certificates:
            self.list_widget.setCurrentRow(0)
        else:
            empty = QListWidgetItem("Nenhum certificado pessoal foi localizado na estação remota.")
            empty.setFlags(Qt.NoItemFlags)
            self.list_widget.addItem(empty)
        self.list_widget.currentItemChanged.connect(self._update_details)
        layout.addWidget(self.list_widget, 1)

        self.details = QLabel()
        self.details.setObjectName("profileDetails")
        self.details.setWordWrap(True)
        self.details.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.details.setStyleSheet(
            "background:#FFFFFF; border:1px solid #C7D6E1; border-radius:10px; "
            "padding:10px 12px; color:#29465C;"
        )
        layout.addWidget(self.details)

        buttons = QHBoxLayout()
        buttons.addStretch()
        close_button = QPushButton("Fechar")
        close_button.setObjectName("secondaryButton")
        close_button.clicked.connect(self.reject)
        buttons.addWidget(close_button)
        self.delete_button = QPushButton("Excluir selecionado")
        self.delete_button.setObjectName("dangerButton")
        set_button_icon(self.delete_button, "close", "#FFFFFF", 16)
        self.delete_button.setEnabled(bool(self.certificates))
        self.delete_button.clicked.connect(self._choose_for_deletion)
        buttons.addWidget(self.delete_button)
        layout.addLayout(buttons)
        self._update_details(self.list_widget.currentItem(), None)

    def _current_certificate(self) -> dict | None:
        item = self.list_widget.currentItem()
        if not item:
            return None
        index = item.data(Qt.UserRole)
        if not isinstance(index, int) or not (0 <= index < len(self.certificates)):
            return None
        return self.certificates[index]

    def _update_details(self, current, _previous):
        certificate = self._current_certificate()
        if not certificate:
            self.details.setText("Nenhum certificado selecionado.")
            self.delete_button.setEnabled(False)
            return
        self.delete_button.setEnabled(True)
        self.details.setText(
            f"Titular: {certificate.get('subject', 'Não informado')}\n"
            f"Emissor: {certificate.get('issuer', 'Não informado')}\n"
            f"Validade: {certificate.get('valid_from', 'Não informada')} até {certificate.get('valid_to', 'Não informada')}\n"
            f"Repositório: {certificate.get('scope', 'Estação remota')} — Pessoal (My)\n"
            f"Chave privada: {'Sim' if certificate.get('has_private_key') else 'Não'}\n"
            f"Origem da leitura: {certificate.get('storage_source', 'Não informada')}\n"
            f"Impressão digital: {certificate.get('thumbprint', 'Não informada')}"
        )

    def _choose_for_deletion(self):
        certificate = self._current_certificate()
        if certificate:
            self._selected_certificate = certificate
            self.accept()

    def selected_certificate(self) -> dict | None:
        return self._selected_certificate


class TicketCard(QFrame):
    opened = Signal(str, str)
    favorite_requested = Signal(str)
    monitored_requested = Signal(str)

    def __init__(self, ticket: dict, parent=None, favorite: bool = False, monitored: bool = False):
        super().__init__(parent)
        self.setObjectName("ticketCard")
        self.setProperty("softwareDynamic", True)
        self.setMinimumHeight(116)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        box = QVBoxLayout(self)
        box.setContentsMargins(15, 13, 15, 13)
        box.setSpacing(7)
        top = QHBoxLayout()
        number = str(ticket.get("number") or ticket.get("id") or "Chamado")
        self.ticket_number = number
        badge = QLabel(f"CHAMADO {number}")
        badge.setObjectName("ticketNumber")
        top.addWidget(badge)
        top.addStretch(1)
        state = QLabel(str(ticket.get("state") or "Estado não informado"))
        state.setObjectName({
            "open": "ticketStateOpen", "pending": "ticketStatePending",
            "closed_success": "ticketStateDone", "closed_other": "ticketStateClosed",
            "rejected": "ticketStateClosed", "customer_cancelled": "ticketStateClosed",
            "closed_unsuccessful": "ticketStateClosed",
        }.get(str(ticket.get("state_kind") or ""), "ticketStateClosed"))
        top.addWidget(state)
        box.addLayout(top)
        title_text = str(ticket.get("title") or "").strip()
        redundant_titles = {
            self._normalized(number), self._normalized(f"Chamado {number}"),
            self._normalized(f"Chamado#{number}"),
        }
        if self._normalized(title_text) not in redundant_titles:
            title = QLabel(title_text or "Sem título informado")
            title.setObjectName("ticketTitle")
            title.setWordWrap(True)
            box.addWidget(title)
        details = "  •  ".join(filter(None, (
            str(ticket.get("queue") or "").strip(), str(ticket.get("category") or "").strip(),
            (f"Criado por: {ticket.get('creator')}" if ticket.get("creator") else ""),
            (f"Proprietário: {ticket.get('owner')}" if ticket.get("owner") else ""),
            (f"Responsável: {ticket.get('responsible')}" if ticket.get("responsible") else ""),
            (f"Usuário: {ticket.get('customer')}" if ticket.get("customer") else ""),
        )))
        if details:
            label = QLabel(details)
            label.setObjectName("ticketDetails")
            label.setWordWrap(True)
            box.addWidget(label)
        bottom = QHBoxLayout()
        bottom.setSpacing(6)
        stage_age = self._stage_age(ticket)
        date_parts = list(filter(None, (str(ticket.get("created") or ""), str(ticket.get("changed") or ""))))
        if stage_age:
            date_parts.append(f"Nesta etapa: {stage_age}")
        dates = QLabel("  •  ".join(date_parts))
        dates.setObjectName("ticketDetails")
        bottom.addWidget(dates, 1)
        self.bookmark_buttons = {}
        for kind, active, icon_name, signal, label in (
            ("favorite", favorite, "star", self.favorite_requested, "favoritos"),
            ("monitored", monitored, "eye", self.monitored_requested, "monitorados"),
        ):
            button = QPushButton()
            button.setObjectName("ticketBookmarkButton")
            button.setProperty("active", active)
            button.setFixedSize(34, 34)
            button.setToolTip(f"{'Remover dos' if active else 'Adicionar aos'} {label}")
            button.setAccessibleName(f"{'Remover' if active else 'Adicionar'} chamado {number} {'dos' if active else 'aos'} {label}")
            set_button_icon(button, icon_name, GOLD if active and kind == "favorite" else GREEN if active else MUTED, 15)
            button.clicked.connect(lambda _checked=False, value=number, selected=signal: selected.emit(value))
            self.bookmark_buttons[kind] = button
            bottom.addWidget(button)
        copy_number = QPushButton()
        copy_number.setObjectName("softwareLaunchButton")
        copy_number.setFixedSize(34, 34)
        copy_number.setToolTip(f"Copiar somente o número {number}")
        copy_number.setAccessibleName(f"Copiar número do chamado {number}")
        set_button_icon(copy_number, "copy", BLUE, 15)
        copy_number.clicked.connect(lambda _checked=False, value=number, control=copy_number: self.copy_ticket_number(value, control))
        bottom.addWidget(copy_number)
        url = str(ticket.get("url") or "")
        open_button = QPushButton()
        open_button.setObjectName("softwareLaunchButton")
        open_button.setFixedSize(34, 34)
        open_button.setToolTip("Abrir chamado no Capri")
        set_button_icon(open_button, "open", BLUE, 16)
        open_button.setEnabled(url.startswith("https://capri.senado.leg.br/"))
        open_button.clicked.connect(lambda: self.opened.emit(url, number))
        bottom.addWidget(open_button)
        box.addLayout(bottom)

    def set_bookmark_state(self, kind: str, active: bool):
        button = self.bookmark_buttons.get(kind)
        if button is None:
            return
        label = "favoritos" if kind == "favorite" else "monitorados"
        button.setProperty("active", active)
        button.setToolTip(f"{'Remover dos' if active else 'Adicionar aos'} {label}")
        button.setAccessibleName(f"{'Remover' if active else 'Adicionar'} chamado {self.ticket_number} {'dos' if active else 'aos'} {label}")
        set_button_icon(button, "star" if kind == "favorite" else "eye",
                        GOLD if active and kind == "favorite" else GREEN if active else MUTED, 15)
        button.style().unpolish(button)
        button.style().polish(button)

    @staticmethod
    def copy_ticket_number(number: str, button: QPushButton):
        QApplication.clipboard().setText(number)
        set_button_icon(button, "check", GREEN, 15)
        button.setToolTip(f"Número {number} copiado")
        QTimer.singleShot(1000, lambda: (set_button_icon(button, "copy", GREEN, 15), button.setToolTip(f"Copiar somente o número {number}")))

    @staticmethod
    def _normalized(value: object) -> str:
        return re.sub(r"[^a-z0-9]+", "", unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode().casefold())

    @staticmethod
    def _stage_age(ticket: dict) -> str:
        source = str(ticket.get("state_since") or ticket.get("changed") or ticket.get("created") or "").strip()
        parsed = None
        for pattern in ("%d/%m/%Y %H:%M", "%d.%m.%Y %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
            try:
                parsed = datetime.strptime(source[:19], pattern)
                break
            except ValueError:
                continue
        if not parsed:
            return "não informado"
        seconds = max(0, int((datetime.now() - parsed).total_seconds()))
        days, remainder = divmod(seconds, 86400)
        hours, remainder = divmod(remainder, 3600)
        minutes = remainder // 60
        if days:
            return f"{days}d {hours}h"
        if hours:
            return f"{hours}h {minutes}min"
        return f"{minutes}min"


class UserTicketsPreviewCard(QFrame):
    """Resumo clicável dos chamados temporários do usuário consultado."""

    activated = Signal()
    refresh_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("userTicketPreviewCard")
        self.setMinimumWidth(0)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(11, 9, 10, 9)
        layout.setSpacing(9)
        text_layout = QVBoxLayout()
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(4)
        self.caption_label = QLabel("Chamados do usuário")
        self.caption_label.setObjectName("userFieldCaption")
        text_layout.addWidget(self.caption_label)
        self.status_label = QLabel("Aguardando consulta")
        self.status_label.setObjectName("userFieldValue")
        self.status_label.setWordWrap(True)
        text_layout.addWidget(self.status_label)
        layout.addLayout(text_layout, 1)
        self.refresh_button = QPushButton()
        self.refresh_button.setObjectName("userTicketRefreshButton")
        self.refresh_button.setFixedSize(30, 30)
        self.refresh_button.setToolTip("Atualizar os chamados no Capri")
        self.refresh_button.setAccessibleName("Atualizar chamados recentes no Capri")
        set_button_icon(self.refresh_button, "refresh", BLUE_2, 15)
        self.refresh_button.clicked.connect(lambda _checked=False: self.refresh_requested.emit())
        layout.addWidget(self.refresh_button, 0, Qt.AlignRight | Qt.AlignVCenter)
        self.open_button = QPushButton()
        self.open_button.setObjectName("userTicketPreviewButton")
        self.open_button.setFixedSize(30, 30)
        self.open_button.setToolTip("Abrir chamados recentes do usuário")
        self.open_button.setAccessibleName("Abrir chamados recentes do usuário")
        set_button_icon(self.open_button, "open", BLUE_2, 15)
        self.open_button.clicked.connect(self.activated.emit)
        layout.addWidget(self.open_button, 0, Qt.AlignRight | Qt.AlignVCenter)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Consultar os últimos chamados do usuário no Capri")

    def set_identity(self, full_name: object):
        name = re.sub(r"\s+", " ", str(full_name or "")).strip()
        first_name = name.split(" ", 1)[0] if name else "usuário"
        self.caption_label.setText(f"Chamados recentes de {first_name}")

    def set_status(self, message: str):
        self.status_label.setText(message)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            self.activated.emit()
        super().mouseReleaseEvent(event)


class UserTicketsDialog(QDialog):
    """Exibe até 25 chamados; somente favoritos/monitorados são preservados."""

    refresh_requested = Signal()

    def __init__(self, full_name: str, on_ticket_opened, on_bookmark, is_bookmarked, parent=None):
        super().__init__(parent)
        self.setObjectName("userTicketsDialog")
        self.setWindowTitle(f"Chamados de {full_name or 'usuário'}")
        self.resize(720, 650)
        self.setMinimumSize(500, 420)
        self.items = []
        self.applied_query = ""
        self.applied_status = 1
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(9)
        title = QLabel("CHAMADOS RECENTES DO USUÁRIO")
        title.setObjectName("dialogTitle")
        layout.addWidget(title)
        self.subtitle = QLabel(f"Até 25 chamados do Capri para {full_name or 'o usuário consultado'}.")
        self.subtitle.setObjectName("smallMuted")
        self.subtitle.setWordWrap(True)
        layout.addWidget(self.subtitle)
        self.progress_text = QLabel("Aguardando consulta ao Capri…")
        self.progress_text.setObjectName("ticketRenderProgressLabel")
        self.progress_text.setWordWrap(True)
        self.progress_text.hide()
        self.progress_bar = QProgressBar()
        self.progress_bar.setObjectName("userTicketProgressBar")
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(5)
        self.progress_bar.hide()
        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setObjectName("ticketSearchInput")
        self.search_input.setPlaceholderText("Buscar número, título, fila, situação ou conteúdo…")
        self.search_input.setClearButtonEnabled(True)
        self.search_input.returnPressed.connect(self.apply_search)
        search_row.addWidget(self.search_input, 1)
        self.refresh_button = QPushButton()
        self.refresh_button.setObjectName("userTicketRefreshButton")
        self.refresh_button.setFixedSize(28, 28)
        self.refresh_button.setToolTip("Atualizar os chamados novamente no Capri")
        self.refresh_button.setAccessibleName("Atualizar chamados recentes no Capri")
        set_button_icon(self.refresh_button, "refresh", BLUE_2, 12)
        self.refresh_button.clicked.connect(lambda _checked=False: self.refresh_requested.emit())
        search_row.addWidget(self.refresh_button)
        self.search_button = QPushButton("Pesquisar")
        self.search_button.setObjectName("ticketSearchButton")
        set_button_icon(self.search_button, "search", "#FFFFFF", 14)
        self.search_button.clicked.connect(self.apply_search)
        search_row.addWidget(self.search_button)
        layout.addLayout(search_row)
        progress_row = QHBoxLayout()
        progress_row.setContentsMargins(0, 0, 0, 0)
        progress_row.setSpacing(7)
        progress_row.addWidget(self.progress_text, 1)
        self.progress_percent = QLabel("0%")
        self.progress_percent.setObjectName("userTicketProgressPercent")
        self.progress_percent.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        progress_row.addWidget(self.progress_percent)
        self.progress_percent.hide()
        layout.addLayout(progress_row)
        layout.addWidget(self.progress_bar)
        filter_row = QHBoxLayout()
        filter_row.addWidget(QLabel("Situação"))
        self.status_combo = NoWheelComboBox()
        self.status_combo.setObjectName("userTicketStatusFilter")
        self.status_combo.addItems([
            "", "Todos", "Abertos", "Pendentes", "Fechados com êxito",
            "Rejeitados", "Cancelados pelo cliente", "Fechados sem êxito",
        ])
        self.status_combo.setCurrentIndex(1)
        filter_row.addWidget(self.status_combo, 1)
        self.filter_button = QPushButton("Filtrar")
        self.filter_button.setObjectName("ticketFilterButton")
        set_button_icon(self.filter_button, "filter", "#FFFFFF", 14)
        self.filter_button.clicked.connect(self.apply_status_filter)
        filter_row.addWidget(self.filter_button)
        layout.addLayout(filter_row)
        self.result_count = QLabel("0 chamados")
        self.result_count.setObjectName("ticketResultCount")
        layout.addWidget(self.result_count, 0, Qt.AlignRight)
        self.results_scroll = QScrollArea()
        self.results_scroll.setObjectName("ticketResultsScroll")
        self.results_scroll.setWidgetResizable(True)
        self.results_scroll.setFrameShape(QFrame.NoFrame)
        self.results_scroll.setObjectName("userTicketResultsScroll")
        self.results_host = QWidget()
        self.results_host.setObjectName("userTicketResultsHost")
        self.results_layout = QVBoxLayout(self.results_host)
        self.results_layout.setContentsMargins(0, 0, 4, 0)
        self.results_layout.setSpacing(8)
        self.results_scroll.setWidget(self.results_host)
        layout.addWidget(self.results_scroll, 1)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        close_button = QPushButton("Fechar")
        close_button.setObjectName("secondaryButton")
        close_button.clicked.connect(self.accept)
        buttons.addWidget(close_button)
        layout.addLayout(buttons)
        self.on_ticket_opened = on_ticket_opened
        self.on_bookmark = on_bookmark
        self.is_bookmarked = is_bookmarked

    def set_progress(self, value: int, message: str):
        percent = max(0, min(99, int(value)))
        self.progress_bar.setValue(percent)
        self.progress_percent.setText(f"{percent}%")
        self.progress_text.setText(message)
        self.progress_text.show()
        self.progress_percent.show()
        self.progress_bar.show()
        self.refresh_button.setEnabled(False)
        set_refresh_icon_busy(self.refresh_button, True)
        self.search_input.setEnabled(False)
        self.search_button.setEnabled(False)
        self.status_combo.setEnabled(False)
        self.filter_button.setEnabled(False)

    def set_error(self, message: str):
        self.progress_text.setText(message or "Não foi possível consultar o Capri.")
        self.progress_text.show()
        self.progress_percent.hide()
        self.progress_bar.hide()
        self.result_count.setText("Consulta não concluída")
        self.refresh_button.setEnabled(True)
        set_refresh_icon_busy(self.refresh_button, False)
        set_button_icon(self.refresh_button, "refresh", BLUE_2, 12)
        self.search_input.setEnabled(True)
        self.search_button.setEnabled(True)
        self.status_combo.setEnabled(True)
        self.filter_button.setEnabled(True)
        self._clear_results()

    def set_tickets(self, items: list[dict]):
        self.items = list(items[:25])
        self.progress_text.hide()
        self.progress_percent.hide()
        self.progress_bar.hide()
        self.refresh_button.setEnabled(True)
        set_refresh_icon_busy(self.refresh_button, False)
        set_button_icon(self.refresh_button, "refresh", BLUE_2, 12)
        self.search_input.setEnabled(True)
        self.search_button.setEnabled(True)
        self.status_combo.setEnabled(True)
        self.filter_button.setEnabled(True)
        self._render_results()

    def apply_search(self):
        self.applied_query = self._normalize(self.search_input.text())
        self._render_results()

    def apply_status_filter(self):
        self.applied_status = self.status_combo.currentIndex()
        self._render_results()

    @staticmethod
    def _normalize(value: object) -> str:
        text = unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode().casefold()
        return re.sub(r"[^a-z0-9]+", " ", text).strip()

    def _clear_results(self):
        while self.results_layout.count():
            item = self.results_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def _render_results(self):
        self._clear_results()
        wanted_state = {
            2: "open", 3: "pending", 4: "closed_success", 5: "rejected",
            6: "customer_cancelled", 7: "closed_unsuccessful",
        }.get(self.applied_status)
        terms = self.applied_query.split()
        matches = []
        for ticket in self.items:
            if wanted_state and str(ticket.get("state_kind") or "other") != wanted_state:
                continue
            searchable = self._normalize(" ".join(str(ticket.get(key, "")) for key in (
                "number", "title", "state", "queue", "category", "customer", "creator",
                "owner", "responsible", "content", "created", "changed",
            )))
            if terms and not all(term in searchable for term in terms):
                continue
            matches.append(ticket)
        self.result_count.setText(f"{len(matches)} de {len(self.items)} chamados")
        if not matches:
            empty = QLabel("Nenhum chamado corresponde aos filtros locais.")
            empty.setObjectName("softwareNotice")
            empty.setWordWrap(True)
            self.results_layout.addWidget(empty)
        for ticket in matches:
            number = ticket_number(ticket.get("number") or ticket.get("id"))
            card = TicketCard(
                ticket, self.results_host,
                favorite=self.is_bookmarked("favorites", number),
                monitored=self.is_bookmarked("monitored", number),
            )
            card.opened.connect(self.on_ticket_opened)
            card.favorite_requested.connect(
                lambda _value, item=ticket, control=card: self._toggle_bookmark("favorites", item, control)
            )
            card.monitored_requested.connect(
                lambda _value, item=ticket, control=card: self._toggle_bookmark("monitored", item, control)
            )
            self.results_layout.addWidget(card)
        self.results_layout.addStretch(1)

    def _toggle_bookmark(self, kind: str, ticket: dict, card: TicketCard):
        added = self.on_bookmark(kind, ticket)
        if added is not None:
            card.set_bookmark_state("favorite" if kind == "favorites" else "monitored", added)


class Dashboard(QWidget):
    logout = Signal()
    password_manager_browser_ready = Signal(bool, int, str, bool)
    password_manager_profile_reset = Signal(bool, str)
    screen_capture_saved = Signal(bool, str)

    def __init__(self, profile: str, capri_username: str = "", capri_password: str = ""):
        super().__init__()
        self.profile = profile
        self.target = ""
        self.connection_active = False
        self.connection_query_active = False
        self.runner = PowerShellRunner(self)
        self.runner.output.connect(self.append_log)
        self.runner.completed.connect(self.execution_done)
        # Coleta de FAQs/chamados roda em processo separado para não bloquear
        # as demais ações do painel durante consultas longas ao Capri.
        self.background_runner = PowerShellRunner(self)
        self._background_output_chunks = []
        self.background_pending_action = ""
        self.background_runner.output.connect(self._append_background_output)
        self.background_runner.completed.connect(self._background_execution_done)
        # Controle de usuários possui processo próprio: AD, Gestor de Senhas e
        # recuperação nunca bloqueiam a estação nem as consultas do Capri.
        self.user_runner = PowerShellRunner(self)
        self.user_output = ""
        self.user_pending_action = ""
        self.user_pending_payload = {}
        self.user_runner.output.connect(self._append_user_output)
        self.user_runner.completed.connect(self._user_execution_done)
        # A consulta de usuário é inteiramente baseada no Active Directory.
        # O PWM só é acessado pela ação explícita de recuperação de senha.
        self.user_query_active = False
        self.user_query_progress_generation = 0
        self.user_lookup_complete = False
        self.user_control_compact = False
        self.user_control_data = {}
        self.user_control_cache = {}
        self.user_ticket_preview_items = []
        self.user_ticket_preview_login = ""
        self.user_ticket_preview_name = ""
        self.user_ticket_preview_status = "idle"
        self.user_ticket_preview_loading = False
        self.user_ticket_preview_generation = 0
        self.user_ticket_preview_percent = 2
        self.user_ticket_preview_wait_started = 0.0
        self.background_user_ticket_generation = 0
        self.user_ticket_dialog = None
        self.station_enrichment_active = False
        self.station_enrichment_login = ""
        self.station_load_cycle_active = False
        self.station_load_partial = False
        self.station_card_refresh_only = False
        self._station_query_before = {}
        self.connection_progress_target = 0
        self.station_enrichment_finish_timer = QTimer(self)
        self.station_enrichment_finish_timer.setSingleShot(True)
        self.station_enrichment_finish_timer.timeout.connect(self.hide_station_enrichment_progress)
        self.last_auto_user_login = ""
        self.pending_station_user_login = ""
        self.password_expiration_source = ""
        self.password_recovery_cooldown_until = 0.0
        self.password_manager_browser_starting = False
        self.pending_pwm_lookup_login = ""
        self.pending_pwm_cookie_sync_login = ""
        self.password_manager_lookup_skipped = False
        self.pwm_lookup_reauth_attempted = False
        self.current_section = "Menu principal"
        self.current_columns = 0
        self.current_status_compact = None
        self.current_action_compact = None
        self.pending_action = ""
        self.pending_popup_title = ""
        self.pending_popup_subtitle = ""
        self.loading_command = ""
        self.printer_operation_progress = None
        self.printer_operation_command = ""
        self.printer_operation_refresh_pending = False
        self.printer_operation_result = ""
        self.remote_progress_card = None
        self.remote_progress_command = ""
        self.printer_refresh_scope = "summary"
        self.command_output = ""
        self._background_log_pending = ""
        self._background_log_skipping = False
        self.last_status_data = {}
        self.disk_profiles_cache = {}
        self.software_catalog = {}
        self.software_loading = False
        self.software_search_text = ""
        self.software_expanded_categories = set()
        self.faq_catalog = load_faq_cache()
        self.faq_favorites = load_favorites(faq_favorites_path())
        self.ticket_bookmarks = load_bookmarks(ticket_bookmarks_path())
        self.ticket_bookmark_popup = None
        self.ticket_bookmark_kind = "favorites"
        self.ticket_bookmark_refreshing = False
        self.ticket_catalog = load_ticket_cache()
        self.ticket_search_text = ""
        self.ticket_status_index = 3
        self.ticket_status_before_search = 3
        self.ticket_loading = False
        self.ticket_sync_progress_value = 0
        self.ticket_sync_progress_timer = QTimer(self)
        self.ticket_sync_progress_timer.setInterval(180)
        self.ticket_sync_progress_timer.timeout.connect(self.advance_ticket_sync_progress)
        self.ticket_feedback_mode = ""
        self.ticket_entry_render_pending = False
        self.ticket_entry_render_generation = 0
        self.ticket_card_render_generation = 0
        self.ticket_card_render_queue = []
        self.ticket_search_cache = {}
        self.ticket_period = "all"
        self.ticket_local_period_active = False
        self.ticket_status = "all"
        self.ticket_mapping_month_key = ""
        self.faq_loading = False
        self.faq_search_text = ""
        self.faq_title_search = False
        self.faq_expanded_categories = set()
        self.faq_expanded_roots = set()
        self.orientation_catalog = load_orientation_catalog() or bundled_orientation_catalog()
        self.orientation_preferences = load_json_cache(faq_orientation_preferences_path())
        self.orientation_by_faq = {}
        self.orientation_search_text = ""
        self.orientation_expanded_categories = set()
        self.orientation_search_timer = QTimer(self)
        self.orientation_search_timer.setSingleShot(True)
        self.orientation_search_timer.setInterval(85)
        self.orientation_search_timer.timeout.connect(self.apply_orientation_search)
        self.capri_username = normalize_capri_login(capri_username or getpass.getuser())
        self._capri_session_password = capri_password
        self.password_manager_username = normalize_capri_login(getpass.getuser())
        self._password_manager_session_password = ""
        self._password_manager_pending_password = ""
        self._password_manager_saved_attempt = False
        self.password_manager_connected = False
        self.password_manager_lookup_failed = False
        self.faq_auth_prompt_open = False
        self.faq_search_timer = QTimer(self)
        self.faq_search_timer.setSingleShot(True)
        self.faq_search_timer.setInterval(85)
        self.faq_search_timer.timeout.connect(self.apply_faq_search)
        self.faq_search_index = []
        self.orientation_search_index = []
        self.faq_search_cache = {}
        self.orientation_search_cache = {}
        self.pending_specific_section = ""
        self.pending_specific_faq = ""
        self.rebuild_orientation_lookup()
        self.rebuild_local_search_indexes()
        self.compact_mode = False
        self.nav_transition = None
        self.nav_transition_effects = []
        self.build_ui()
        self.update_action_card_availability()
        self.update_faq_suggestions()
        QTimer.singleShot(0, self.update_side_mode_direction)

    def compact_transient_caches(self) -> int:
        """Limita somente caches reconstruíveis; dados persistentes não são alterados."""
        removed = 0
        now = time.monotonic()
        expired = [
            key for key, value in self.disk_profiles_cache.items()
            if now - float(value.get("time", 0)) > 300
        ]
        for key in expired:
            self.disk_profiles_cache.pop(key, None)
            removed += 1
        while len(self.disk_profiles_cache) > 32:
            self.disk_profiles_cache.pop(next(iter(self.disk_profiles_cache)))
            removed += 1
        for cache in (self.faq_search_cache, self.orientation_search_cache):
            if len(cache) > 60:
                removed += len(cache)
                cache.clear()
        ticket_count = len(self.ticket_catalog.get("items") or [])
        if len(self.ticket_search_cache) > ticket_count + 32:
            removed += len(self.ticket_search_cache)
            self.ticket_search_cache.clear()
        return removed

    def build_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        self.sidebar = QFrame(objectName="sidebar")
        self.sidebar.setFixedWidth(216)
        sidebar = self.sidebar
        side = QVBoxLayout(sidebar)
        self.side_layout = side
        side.setContentsMargins(20, 26, 20, 22)
        brand = QVBoxLayout()
        brand.setContentsMargins(0, 0, 0, 0)
        brand.setSpacing(3)
        mark = QLabel()
        self.brand_mark = mark
        mark.setFixedSize(140, 140)
        mark.setAlignment(Qt.AlignCenter)
        mark.setPixmap(atlas_brand_pixmap(
            "logo_compact_dark.png" if bool(load_json_cache(theme_settings_path()).get("dark", False))
            else "logo_compact_light.png", 140,
        ))
        brand.addWidget(mark, 0, Qt.AlignHCenter)
        brand_word = QHBoxLayout()
        brand_word.setContentsMargins(0, 0, 0, 0)
        brand_word.setSpacing(0)
        brand_word.addStretch(1)
        brand_text = QLabel("ATLA")
        brand_text.setObjectName("brandTitle")
        brand_text.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        brand_word.addWidget(brand_text, 0, Qt.AlignVCenter)
        self.brand_lightning = AtlasSAccent(
            bool(load_json_cache(theme_settings_path()).get("dark", False))
        )
        brand_word.addWidget(self.brand_lightning, 0, Qt.AlignVCenter)
        brand_word.addStretch(1)
        brand.addLayout(brand_word)
        side.addLayout(brand)
        suite = QLabel("CENTRAL DE OPERAÇÕES")
        suite.setObjectName("brandSubtitle")
        suite.setAlignment(Qt.AlignHCenter)
        self.brand_subtitle = suite
        side.addWidget(suite)
        side.addSpacing(16)
        self.nav_buttons = {}
        navigation = [
            ("Menu principal", "Informações"),
            ("Suporte remoto", "Suporte remoto"),
            ("Impressoras", "Impressoras"),
            ("Softwares autorizados", "Softwares (X:)"),
            ("FAQs", "FAQs"),
            ("Chamados", "Chamados"),
        ]
        navigation_icons = {
            "Menu principal": "home", "Suporte remoto": "remote", "Impressoras": "printer",
            "Softwares autorizados": "software", "FAQs": "info", "Chamados": "ticket",
        }
        for route, label in navigation:
            item = HoverFadeButton(label)
            item.setObjectName("navItem" if route != "Menu principal" else "navActive")
            set_button_icon(item, navigation_icons[route], "#D9E9F3", 17)
            item.clicked.connect(lambda _checked=False, name=route: self.request_section_access(name))
            if route in {"Suporte remoto", "Impressoras"}:
                item.setEnabled(False)
                item.setToolTip("Conecte uma estação para utilizar estas ações")
            if route == "Softwares autorizados":
                item.setEnabled(False)
                item.setToolTip("Disponível quando o usuário conectado possuir acesso ao drive X:")
            if route in {"FAQs", "Chamados"}:
                faq_nav_row = QHBoxLayout()
                faq_nav_row.setContentsMargins(0, 0, 0, 0)
                faq_nav_row.setSpacing(3)
                faq_nav_row.addWidget(item, 1)
                if route == "FAQs":
                    self.faq_favorites_button = QPushButton()
                    self.faq_favorites_button.setObjectName("faqFavoritesToggle")
                    self.faq_favorites_button.setFixedSize(25, 27)
                    self.faq_favorites_button.setToolTip("Abrir minhas FAQs favoritas")
                    self.faq_favorites_button.setAccessibleName("Minhas FAQs favoritas")
                    set_button_icon(self.faq_favorites_button, "star", GOLD, 12)
                    self.faq_favorites_button.clicked.connect(self.toggle_faq_favorites_popup)
                    faq_nav_row.addWidget(self.faq_favorites_button)
                else:
                    self.ticket_favorites_button = QPushButton()
                    self.ticket_monitored_button = QPushButton()
                    for control, icon_name, caption, kind in (
                        (self.ticket_favorites_button, "star", "Favoritos", "favorites"),
                        (self.ticket_monitored_button, "eye", "Monitorados", "monitored"),
                    ):
                        control.setObjectName("faqFavoritesToggle")
                        control.setFixedSize(25, 27)
                        control.setToolTip(f"Abrir chamados {caption.lower()}")
                        control.setAccessibleName(f"Chamados {caption.lower()}")
                        set_button_icon(control, icon_name, GOLD if kind == "favorites" else GREEN_2, 12)
                        control.clicked.connect(lambda _checked=False, selected=kind: self.open_ticket_bookmarks(selected))
                        faq_nav_row.addWidget(control)
                side.addLayout(faq_nav_row)
            else:
                side.addWidget(item)
            self.nav_buttons[route] = item

        self.build_faq_favorites_popup()
        self.build_ticket_bookmarks_popup()

        side.addSpacing(14)
        quick_separator = QFrame(objectName="quickSeparator")
        quick_separator.setFixedHeight(2)
        side.addWidget(quick_separator)
        side.addSpacing(10)
        quick_grid = QGridLayout()
        quick_grid.setHorizontalSpacing(8)
        quick_grid.setVerticalSpacing(8)
        self.quick_disk_button = QuickActionButton("disk", "Discos e perfis — Shift+clique força nova consulta")
        self.quick_disk_button.setEnabled(False)
        self.quick_disk_button.clicked.connect(self.quick_disk_profiles)
        quick_grid.addWidget(self.quick_disk_button, 0, 0)
        self.quick_internet_button = QuickActionButton("internet", "Internet e certificados")
        self.quick_internet_button.setEnabled(False)
        self.quick_internet_button.clicked.connect(self.quick_open_internet)
        quick_grid.addWidget(self.quick_internet_button, 0, 1)
        self.quick_local_users_button = QuickActionButton("users", "Usuários e grupos locais")
        self.quick_local_users_button.setEnabled(False)
        self.quick_local_users_button.clicked.connect(self.quick_local_users)
        quick_grid.addWidget(self.quick_local_users_button, 0, 2)
        self.quick_dsa_button = QuickActionButton("directory", "Abrir Usuários e Computadores do Active Directory")
        self.quick_dsa_button.clicked.connect(self.quick_open_dsa)
        quick_grid.addWidget(self.quick_dsa_button, 1, 0)
        self.quick_cmd_button = QuickActionButton("terminal", "Abrir Prompt de Comando")
        self.quick_cmd_button.clicked.connect(self.quick_open_cmd)
        quick_grid.addWidget(self.quick_cmd_button, 1, 1)
        self.quick_compmgmt_button = QuickActionButton("management", "Abrir Gerenciamento do Computador conectado ou local")
        self.quick_compmgmt_button.clicked.connect(self.quick_open_compmgmt)
        quick_grid.addWidget(self.quick_compmgmt_button, 1, 2)
        self.quick_sccm_button = QuickActionButton("remote", "Abrir controle remoto SCCM da estação")
        self.quick_sccm_button.setProperty("emphasis", True)
        self.quick_sccm_button.set_icon_state("remote", "#74E9D1")
        self.quick_sccm_button.setEnabled(False)
        self.quick_sccm_button.clicked.connect(self.quick_sidebar_sccm)
        quick_grid.addWidget(self.quick_sccm_button, 2, 0)
        self.quick_ad_user_button = QuickActionButton("user", "Informações do usuário no AD")
        self.quick_ad_user_button.setProperty("emphasis", True)
        self.quick_ad_user_button.set_icon_state("user", "#A9DBFF")
        self.quick_ad_user_button.setEnabled(False)
        self.quick_ad_user_button.clicked.connect(self.quick_sidebar_ad_user_info)
        quick_grid.addWidget(self.quick_ad_user_button, 2, 1)
        self.quick_admin_button = QuickActionButton("lock", "Estado de Admin local ainda não disponível")
        self.quick_admin_button.set_icon_state("lock", "#778B99")
        self.quick_admin_button.setEnabled(False)
        self.quick_admin_button.clicked.connect(self.quick_sidebar_admin)
        quick_grid.addWidget(self.quick_admin_button, 2, 2)
        self.quick_admin_pulse_on = False
        self.quick_admin_pulse_timer = QTimer(self)
        self.quick_admin_pulse_timer.setInterval(800)
        self.quick_admin_pulse_timer.timeout.connect(self.pulse_quick_admin)
        self.quick_buttons = [
            self.quick_disk_button, self.quick_internet_button, self.quick_local_users_button,
            self.quick_dsa_button, self.quick_cmd_button, self.quick_compmgmt_button,
            self.quick_sccm_button, self.quick_ad_user_button, self.quick_admin_button,
        ]
        side.addLayout(quick_grid)
        side.addSpacing(14)
        links_separator = QFrame(objectName="quickSeparator")
        links_separator.setFixedHeight(2)
        side.addWidget(links_separator)
        side.addSpacing(8)
        self.useful_links_toggle = HoverFadeButton("Links úteis  ▾")
        self.useful_links_toggle.setObjectName("usefulLinksToggle")
        self.useful_links_toggle.setAccessibleName("Abrir links úteis")
        side.addWidget(self.useful_links_toggle)
        self.useful_links_popup = QDialog(self)
        self.useful_links_popup.setObjectName("usefulLinksPopup")
        self.useful_links_popup.setWindowFlags(Qt.Popup | Qt.FramelessWindowHint)
        popup_layout = QVBoxLayout(self.useful_links_popup)
        popup_layout.setContentsMargins(12, 10, 12, 12)
        popup_layout.setSpacing(7)
        popup_heading = QHBoxLayout()
        popup_title = QLabel("LINKS ÚTEIS")
        popup_title.setObjectName("usefulLinksPopupTitle")
        popup_heading.addWidget(popup_title)
        popup_heading.addStretch(1)
        popup_close = QPushButton("×")
        popup_close.setObjectName("usefulLinksPopupClose")
        popup_close.setFixedSize(28, 28)
        popup_close.setAccessibleName("Fechar links úteis")
        popup_close.clicked.connect(self.useful_links_popup.close)
        popup_heading.addWidget(popup_close)
        popup_layout.addLayout(popup_heading)
        self.useful_links_panel = QFrame(objectName="usefulLinksPanel")
        links_layout = QVBoxLayout(self.useful_links_panel)
        links_layout.setContentsMargins(4, 4, 4, 4)
        links_layout.setSpacing(4)
        self.useful_links = load_useful_links()
        self.useful_links_scroll = QScrollArea()
        self.useful_links_scroll.setObjectName("usefulLinksScroll")
        self.useful_links_scroll.setFrameShape(QFrame.NoFrame)
        self.useful_links_scroll.setWidgetResizable(True)
        self.useful_links_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.useful_links_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.useful_links_scroll.setMinimumSize(0, 0)
        self.useful_links_scroll.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        # O viewport e o conteúdo recebem fundo explícito: o QScrollArea do
        # Windows mantém branco por padrão mesmo dentro da lateral escura.
        self.useful_links_scroll.viewport().setObjectName("usefulLinksViewport")
        self.useful_links_scroll.viewport().setStyleSheet(
            "#usefulLinksViewport { background: #0B2031; border: none; }"
        )
        self.useful_links_body = QWidget(objectName="usefulLinksBody")
        self.useful_links_body.setStyleSheet(
            "#usefulLinksBody { background: #0B2031; border: none; }"
        )
        self.useful_links_list_layout = QVBoxLayout(self.useful_links_body)
        self.useful_links_list_layout.setContentsMargins(0, 0, 0, 0)
        self.useful_links_list_layout.setSpacing(2)
        self.useful_links_scroll.setWidget(self.useful_links_body)
        links_layout.addWidget(self.useful_links_scroll)
        self.useful_links_add_button = HoverFadeButton("＋ Adicionar link")
        self.useful_links_add_button.setObjectName("usefulLinksAddButton")
        self.useful_links_add_button.clicked.connect(self.add_useful_link)
        links_layout.addWidget(self.useful_links_add_button)
        self.render_useful_links()
        popup_layout.addWidget(self.useful_links_panel, 1)
        self.useful_links_toggle.clicked.connect(self.toggle_useful_links)
        self.templates_toggle = HoverFadeButton("Meus templates  ▾")
        self.templates_toggle.setObjectName("templatesToggle")
        self.templates_toggle.setAccessibleName("Abrir meus templates")
        side.addWidget(self.templates_toggle)
        self.templates_popup = TicketTemplatesPopup(
            self, operator_template_signature, saved_templates_path(),
        )
        self.templates_popup.copied.connect(self.on_template_copied)
        self.templates_toggle.clicked.connect(self.toggle_templates)
        side.addStretch()
        footer_tools = QHBoxLayout()
        footer_tools.setSpacing(5)
        self.side_mode_button = AnimatedSideModeButton(framed=True)
        self.side_mode_button.clicked.connect(self.enable_compact_mode)
        footer_tools.addWidget(self.side_mode_button)
        footer_tools.addStretch(1)
        settings = HoverFadeButton("")
        settings.setObjectName("footerIconButton")
        settings.setToolTip("Configurações do Atlas")
        settings.setAccessibleName("Configurações do Atlas")
        settings.setFixedSize(44, 34)
        set_button_icon(settings, "gear", "#FFFFFF", 17)
        settings.clicked.connect(self.open_settings)
        footer_tools.addWidget(settings)
        footer_tools.addStretch(1)
        self.screen_capture_button = HoverFadeButton("")
        self.screen_capture_button.setObjectName("footerIconButton")
        self.screen_capture_button.setToolTip("Capturar Tela — selecionar uma área com o mouse")
        self.screen_capture_button.setAccessibleName("Capturar Tela")
        self.screen_capture_button.setFixedSize(44, 34)
        set_button_icon(self.screen_capture_button, "camera", "#FFFFFF", 17)
        self.screen_capture_button.clicked.connect(self.start_screen_capture)
        footer_tools.addWidget(self.screen_capture_button)
        self.screen_capture_session = None
        self.screen_capture_opacity = 1.0
        self.screen_capture_saved.connect(self.finish_screen_capture_save)
        side.addLayout(footer_tools)
        footer_exits = QHBoxLayout()
        footer_exits.setSpacing(8)
        if self.profile == "ins":
            self.capri_logout_button = HoverFadeButton("Capri")
            self.capri_logout_button.setObjectName("capriSidebarLogoutButton")
            self.capri_logout_button.setToolTip("Encerrar somente a sessão web do Capri")
            self.capri_logout_button.setAccessibleName("Encerrar sessão do Capri")
            self.capri_logout_button.setEnabled(bool(self._capri_session_password))
            set_button_icon(self.capri_logout_button, "logout", "#9ED4EC", 17)
            self.capri_logout_button.clicked.connect(self.end_capri_session)
            footer_exits.addWidget(self.capri_logout_button, 1)
        exit_btn = HoverFadeButton("INS" if self.profile == "ins" else "Trocar perfil")
        exit_btn.setObjectName("exitInsButton" if self.profile == "ins" else "navItem")
        exit_btn.setToolTip("Sair do INS" if self.profile == "ins" else "Trocar perfil")
        exit_btn.setAccessibleName("Sair do INS" if self.profile == "ins" else "Trocar perfil")
        set_button_icon(exit_btn, "logout", "#FFFFFF", 17)
        exit_btn.clicked.connect(self.logout.emit)
        footer_exits.addWidget(exit_btn, 1)
        side.addLayout(footer_exits)
        root.addWidget(sidebar)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        content = QWidget(objectName="content")
        content.setMinimumWidth(0)
        page = QVBoxLayout(content)
        self.page_layout = page
        page.setContentsMargins(30, 25, 30, 34)
        page.setSpacing(17)

        self.top_layout = QGridLayout()
        self.hello_label = QLabel(f"Olá, {operator_friendly_name()}")
        self.hello_label.setObjectName("pageTitle")
        self.hello_host = QWidget(objectName="helloHost")
        hello_row = QHBoxLayout(self.hello_host); hello_row.setContentsMargins(0, 0, 0, 0); hello_row.setSpacing(8)
        hello_row.addWidget(self.hello_label, 0, Qt.AlignVCenter)
        hello_row.addStretch()
        self.top_layout.addWidget(self.hello_host, 0, 0)
        profile_text = "SESSÃO INS" if self.profile == "ins" else "SESSÃO PADRÃO"
        self.profile_badge = QLabel(profile_text)
        self.profile_badge.setObjectName("insBadge" if self.profile == "ins" else "standardBadge")
        self.session_effect = QGraphicsOpacityEffect(self.profile_badge)
        self.profile_badge.setGraphicsEffect(self.session_effect)
        self.session_animation = QPropertyAnimation(self.session_effect, b"opacity", self)
        self.session_animation.setDuration(1900)
        self.session_animation.setLoopCount(-1)
        self.session_animation.setEasingCurve(QEasingCurve.InOutSine)
        self.session_animation.setKeyValueAt(0.0, 1.0)
        self.session_animation.setKeyValueAt(0.5, 0.48)
        self.session_animation.setKeyValueAt(1.0, 1.0)
        self.session_animation.start()
        self.top_actions_host = QWidget(objectName="topActionsHost")
        top_actions = QHBoxLayout(self.top_actions_host)
        self.top_actions_layout = top_actions
        top_actions.setContentsMargins(0, 0, 0, 0)
        top_actions.setSpacing(7)
        self.dark_mode = bool(load_json_cache(theme_settings_path()).get("dark", False))
        self.pending_theme_mode = None
        self.theme_button = ThemeSwitch(self.dark_mode)
        self.theme_button.toggled.connect(self.set_theme)
        self.theme_label = QLabel("Modo escuro")
        self.theme_label.setObjectName("themeLabel")
        top_actions.addWidget(self.theme_label)
        self.refresh_theme_icon()
        top_actions.addWidget(self.theme_button)
        self.top_layout.addWidget(self.top_actions_host, 0, 1, Qt.AlignRight | Qt.AlignVCenter)
        self.profile_host = QWidget(objectName="profileActionsHost")
        profile_row = QHBoxLayout(self.profile_host)
        profile_row.setContentsMargins(0, 0, 0, 0)
        profile_row.setSpacing(8)
        profile_row.addWidget(self.profile_badge)
        if self.profile == "ins":
            self.escalation_button = QPushButton(objectName="escalationButton")
            self.escalation_button.setFixedSize(34, 32)
            self.escalation_button.setToolTip("Solicitar apoio técnico por ordem de escalonamento")
            self.escalation_button.setAccessibleName("Abrir escalonamento de apoio técnico")
            set_button_icon(self.escalation_button, "alert", "#FF6976", 20)
            self.escalation_button.clicked.connect(self.open_escalation)
            profile_row.addWidget(self.escalation_button)
            targets_path = resource_path("data/escalation_targets.json")
            self.escalation_targets = json.loads(targets_path.read_text(encoding="utf-8"))
            self.escalation_popup = EscalationPopup(self.escalation_targets, self)
            self.escalation_popup.selected.connect(self.send_support_escalation)
        profile_row.addStretch()
        self.top_layout.addWidget(self.profile_host, 1, 0, Qt.AlignLeft)
        page.addLayout(self.top_layout)
        intro = QLabel("AMBIENTE DE OPERAÇÕES  /  SENADO FEDERAL")
        intro.setObjectName("muted")
        page.addWidget(intro)

        connect = QFrame(objectName="connectionCard")
        self.connection_card = connect
        self.connection_card.setMinimumWidth(0)
        self.connection_card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        control_shell = QVBoxLayout(connect)
        control_shell.setContentsMargins(0, 0, 0, 0)
        control_shell.setSpacing(0)
        self.control_tabs = BalancedTabWidget()
        self.control_tabs.setObjectName("controlTabs")
        self.control_tabs.setDocumentMode(True)
        self.control_tabs.setMinimumWidth(0)
        self.control_tabs.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        self.control_tabs.setTabBar(BalancedTabBar(self.control_tabs))
        station_control_page = QWidget()
        station_control_page.setObjectName("stationControlPage")
        self.connection_layout = QGridLayout(station_control_page)
        cbox = self.connection_layout
        cbox.setContentsMargins(22, 17, 22, 18)
        cbox.setHorizontalSpacing(9)
        cbox.setVerticalSpacing(9)
        # Mantido somente como estado interno por compatibilidade. O título
        # visual já está representado pela própria aba e não deve se repetir.
        self.connection_status = QLabel("CONTROLE DA ESTAÇÃO")
        self.connection_status.hide()
        self.connection_tools = QFrame(objectName="connectionTools")
        connection_tools_layout = QHBoxLayout(self.connection_tools)
        connection_tools_layout.setContentsMargins(3, 3, 3, 3)
        connection_tools_layout.setSpacing(5)
        self.cancel_station_query_button = QPushButton()
        self.cancel_station_query_button.setObjectName("refreshIconButton")
        self.cancel_station_query_button.setToolTip("Cancelar consulta da estação")
        self.cancel_station_query_button.setAccessibleName("Cancelar consulta da estação")
        self.cancel_station_query_button.setFixedSize(28, 28)
        set_button_icon(self.cancel_station_query_button, "close", RED, 14)
        self.cancel_station_query_button.clicked.connect(self.cancel_station_query)
        connection_tools_layout.addWidget(self.cancel_station_query_button)
        self.connection_tools.hide()
        self.refresh_button = QPushButton()
        self.refresh_button.setObjectName("refreshIconButton")
        self.refresh_button.setToolTip("Atualizar informações da estação")
        self.refresh_button.setAccessibleName("Atualizar painel")
        self.refresh_button.setFixedSize(28, 28)
        set_button_icon(self.refresh_button, "refresh", GREEN, 15)
        self.refresh_button.setEnabled(False)
        self.refresh_button.clicked.connect(self.refresh_panel)
        self.copy_target_button = QPushButton()
        self.copy_target_button.setObjectName("copyTargetButton")
        self.copy_target_button.setToolTip("Copiar nome ou IP da estação")
        self.copy_target_button.setAccessibleName("Copiar endereço da estação remota")
        self.copy_target_button.setFixedSize(24, 24)
        set_button_icon(self.copy_target_button, "copy", BLUE, 14)
        self.copy_target_button.setEnabled(False)
        self.copy_target_button.clicked.connect(self.copy_target_address)
        self.target_input = QLineEdit()
        self.target_input.setPlaceholderText("Nome ou IP do computador")
        self.target_input.returnPressed.connect(self.connect_target)
        cbox.addWidget(self.target_input, 0, 0)
        self.connect_button = QPushButton("Conectar")
        self.connect_button.setObjectName("primaryButton")
        self.connect_button.setAccessibleName("Conectar à estação")
        self.connect_button.clicked.connect(self.connect_target)
        cbox.addWidget(self.connect_button, 0, 1)
        cbox.addWidget(self.connection_tools, 0, 2, Qt.AlignRight | Qt.AlignVCenter)
        cbox.setColumnStretch(0, 1)
        self.connect_sync_angle = 0
        self.connect_sync_icon = modern_icon("refresh", "#FFFFFF", 18).pixmap(18, 18)
        self.connect_sync_timer = QTimer(self)
        self.connect_sync_timer.setInterval(70)
        self.connect_sync_timer.timeout.connect(self.advance_connect_sync)
        self.connection_label = QLabel("Informe o nome ou IP da estação para iniciar.")
        self.connection_label.setObjectName("smallMuted")
        self.connection_label.setWordWrap(True)
        cbox.addWidget(self.connection_label, 1, 0, 1, 3)
        self.connection_progress = QProgressBar()
        self.connection_progress.setObjectName("connectionProgress")
        self.connection_progress.setRange(0, 100)
        self.connection_progress.setValue(0)
        self.connection_progress.setTextVisible(True)
        self.connection_progress.hide()
        cbox.addWidget(self.connection_progress, 1, 0, 1, 3)
        self.connection_progress_value = 0
        self.connection_progress_timer = QTimer(self)
        self.connection_progress_timer.setInterval(55)
        self.connection_progress_timer.timeout.connect(self.advance_connection_progress)
        self.control_tabs.addTab(station_control_page, "Controle da estação")

        self.user_control_page = QWidget()
        self.user_control_page.setObjectName("userControlPage")
        user_control_layout = QGridLayout(self.user_control_page)
        self.user_control_layout = user_control_layout
        user_control_layout.setContentsMargins(22, 17, 22, 18)
        user_control_layout.setHorizontalSpacing(9)
        user_control_layout.setVerticalSpacing(9)
        self.user_login_input = QLineEdit()
        self.user_login_input.setPlaceholderText("Login de rede do usuário")
        self.user_login_input.setClearButtonEnabled(True)
        self.user_login_input.setAccessibleName("Login de rede para consulta")
        self.user_login_input.returnPressed.connect(self.handle_user_lookup_button)
        self.user_login_input.textEdited.connect(self.user_login_edited)
        user_control_layout.addWidget(self.user_login_input, 0, 0)
        self.user_lookup_button = QPushButton("Consultar usuário")
        self.user_lookup_button.setObjectName("primaryButton")
        self.user_lookup_button.setAccessibleName("Consultar usuário no Active Directory")
        set_button_icon(self.user_lookup_button, "search", "#FFFFFF", 15)
        self.user_lookup_button.clicked.connect(self.handle_user_lookup_button)
        user_control_layout.addWidget(self.user_lookup_button, 0, 1)
        user_control_layout.setColumnStretch(0, 1)
        self.user_query_label = QLabel(
            "Os dados da conta, da senha e do vencimento são consultados diretamente no Active Directory."
        )
        self.user_query_label.setObjectName("smallMuted")
        self.user_query_label.setWordWrap(True)
        user_control_layout.addWidget(self.user_query_label, 1, 0, 1, 2)
        self.user_query_progress = QProgressBar()
        self.user_query_progress.setObjectName("connectionProgress")
        self.user_query_progress.setRange(0, 100)
        self.user_query_progress.setValue(0)
        self.user_query_progress.setTextVisible(True)
        self.user_query_progress.hide()
        user_control_layout.addWidget(self.user_query_progress, 1, 0, 1, 2)
        self.user_query_progress_value = 0
        self.user_query_progress_timer = QTimer(self)
        self.user_query_progress_timer.setInterval(70)
        self.user_query_progress_timer.timeout.connect(self.advance_user_query_progress)
        self.control_tabs.addTab(self.user_control_page, "Controle de usuários")
        self.control_tabs.currentChanged.connect(self.control_tab_changed)
        control_shell.addWidget(self.control_tabs)
        page.addWidget(connect)

        self.user_result_card = QFrame(objectName="userResultCard")
        self.user_result_card.setMinimumWidth(0)
        self.user_result_card.setProperty("connected", True)
        user_result_layout = QVBoxLayout(self.user_result_card)
        self.user_result_layout = user_result_layout
        user_result_layout.setContentsMargins(18, 16, 18, 18)
        user_result_layout.setSpacing(11)
        user_result_header = QHBoxLayout()
        self.user_result_pulse = QLabel()
        self.user_result_pulse.setObjectName("connectedUserPulse")
        self.user_result_pulse.setFixedSize(34, 34)
        self.user_result_pulse.setAlignment(Qt.AlignCenter)
        self.user_result_pulse.setPixmap(modern_icon("user", GREEN, 20).pixmap(20, 20))
        self.user_result_pulse.setToolTip("Informações do usuário carregadas")
        self.user_result_pulse_opacity = QGraphicsOpacityEffect(self.user_result_pulse)
        self.user_result_pulse.setGraphicsEffect(self.user_result_pulse_opacity)
        self.user_result_pulse_animation = QPropertyAnimation(
            self.user_result_pulse_opacity, b"opacity", self.user_result_pulse,
        )
        self.user_result_pulse_animation.setDuration(1450)
        self.user_result_pulse_animation.setLoopCount(-1)
        self.user_result_pulse_animation.setEasingCurve(QEasingCurve.InOutSine)
        self.user_result_pulse_animation.setKeyValueAt(0.0, 1.0)
        self.user_result_pulse_animation.setKeyValueAt(0.5, 0.32)
        self.user_result_pulse_animation.setKeyValueAt(1.0, 1.0)
        self.user_result_pulse_animation.start()
        user_result_header.addWidget(self.user_result_pulse)
        self.user_result_heading = QLabel("INFORMAÇÕES DO USUÁRIO")
        self.user_result_heading.setObjectName("userResultTitle")
        user_result_header.addWidget(self.user_result_heading, 1)
        self.user_information_refresh_button = QPushButton()
        self.user_information_refresh_button.setObjectName("userHeaderRefreshButton")
        self.user_information_refresh_button.setFixedSize(30, 30)
        self.user_information_refresh_button.setToolTip("Atualizar todas as informações deste usuário")
        self.user_information_refresh_button.setAccessibleName("Atualizar informações do usuário")
        self.user_information_refresh_button.setEnabled(False)
        set_button_icon(self.user_information_refresh_button, "refresh", BLUE_2, 14)
        self.user_information_refresh_button.clicked.connect(self.refresh_user_information)
        user_result_header.addWidget(self.user_information_refresh_button, 0, Qt.AlignRight | Qt.AlignVCenter)
        user_result_layout.addLayout(user_result_header)
        self.user_result_identity = QFrame(objectName="userIdentityBar")
        user_identity_layout = QGridLayout(self.user_result_identity)
        self.user_identity_layout = user_identity_layout
        user_identity_layout.setContentsMargins(9, 8, 9, 8)
        user_identity_layout.setHorizontalSpacing(9)
        self.user_identity_name_host = CopyableInfoFrame(objectName="userIdentityItem")
        self.user_identity_name_host.setToolTip("Clique para copiar nome completo e valor")
        user_name_layout = QHBoxLayout(self.user_identity_name_host)
        user_name_layout.setContentsMargins(10, 7, 7, 7)
        user_name_layout.setSpacing(7)
        self.user_identity_name = QLabel("USUÁRIO\nNenhum usuário consultado")
        self.user_identity_name.setObjectName("userIdentityText")
        self.user_identity_name.setWordWrap(True)
        self.user_identity_name.setMinimumWidth(0)
        self.user_identity_name.setTextInteractionFlags(Qt.TextSelectableByMouse)
        user_name_layout.addWidget(self.user_identity_name, 1)
        self.user_identity_name_host.register_copy_surface(self.user_identity_name)
        self.quick_ad_button = QPushButton()
        self.quick_ad_button.setObjectName("userLoginCopyButton")
        self.quick_ad_button.setFixedSize(27, 27)
        self.quick_ad_button.setToolTip("Informações do usuário no AD")
        self.quick_ad_button.setAccessibleName("Consultar informações do usuário no AD")
        set_button_icon(self.quick_ad_button, "user", BLUE_2, 14)
        self.quick_ad_button.setEnabled(False)
        self.quick_ad_button.clicked.connect(self.quick_ad_user_info)
        user_name_layout.addWidget(self.quick_ad_button, 0, Qt.AlignRight | Qt.AlignVCenter)
        user_identity_layout.addWidget(self.user_identity_name_host, 0, 0)
        self.user_identity_login_host = CopyableInfoFrame(objectName="userIdentityItem")
        self.user_identity_login_host.set_copy_enabled(False)
        user_login_layout = QHBoxLayout(self.user_identity_login_host)
        user_login_layout.setContentsMargins(10, 7, 7, 7)
        user_login_layout.setSpacing(7)
        self.user_identity_login = QLabel("LOGIN DE REDE\nNão informado")
        self.user_identity_login.setObjectName("userIdentityText")
        self.user_identity_login.setWordWrap(True)
        self.user_identity_login.setMinimumWidth(0)
        self.user_identity_login.setTextInteractionFlags(Qt.TextSelectableByMouse)
        user_login_layout.addWidget(self.user_identity_login, 1)
        self.user_identity_login_host.register_copy_surface(self.user_identity_login)
        self.user_login_copy_button = QPushButton()
        self.user_login_copy_button.setObjectName("userLoginCopyButton")
        self.user_login_copy_button.setFixedSize(27, 27)
        self.user_login_copy_button.setToolTip("Copiar login de rede")
        self.user_login_copy_button.setAccessibleName("Copiar login de rede")
        set_button_icon(self.user_login_copy_button, "copy", BLUE_2, 13)
        self.user_login_copy_button.clicked.connect(self.copy_user_login)
        user_login_layout.addWidget(self.user_login_copy_button, 0, Qt.AlignRight | Qt.AlignVCenter)
        user_identity_layout.addWidget(self.user_identity_login_host, 0, 1)
        user_identity_layout.setColumnStretch(0, 2)
        user_identity_layout.setColumnStretch(1, 1)
        user_result_layout.addWidget(self.user_result_identity)
        self.user_fields_grid = QGridLayout()
        self.user_fields_grid.setHorizontalSpacing(10)
        self.user_fields_grid.setVerticalSpacing(9)
        self.user_field_cards = {}
        user_fields = (
            ("status", "Status da conta", 0, 0),
            ("company", "Empresa", 0, 1),
            ("department", "Departamento", 1, 0),
            ("title", "Cargo", 1, 1),
            ("unit_room", "Unidade-Sala", 2, 0),
            ("manager", "Gestor", 2, 1),
            ("institutional_email", "E-mail institucional", 3, 0),
            ("logon_script", "Script de logon", 3, 1),
        )
        for key, caption, row, column in user_fields:
            card = UserDataFieldCard(caption)
            self.user_field_cards[key] = card
            self.user_fields_grid.addWidget(card, row, column)
        self.password_expiry_status = PasswordExpiryStatusCard()
        self.password_expiry_status.recovery_requested.connect(self.preview_password_recovery)
        self.password_expiry_status.pwm_requested.connect(self.open_password_manager_page)
        self.user_fields_grid.addWidget(self.password_expiry_status, 4, 1)
        self.password_expiration_card = UserDataFieldCard("Vencimento da senha")
        self.user_fields_grid.addWidget(self.password_expiration_card, 4, 0)
        self.user_phones_card = UserDataFieldCard("Telefones")
        self.user_fields_grid.addWidget(self.user_phones_card, 5, 0, 1, 2)
        self.user_notes_card = UserDataFieldCard("Observações")
        self.user_fields_grid.addWidget(self.user_notes_card, 6, 0, 1, 2)
        self.user_tickets_card = UserTicketsPreviewCard()
        self.user_tickets_card.activated.connect(self.open_user_ticket_preview)
        self.user_tickets_card.refresh_requested.connect(self.refresh_user_ticket_preview)
        self.user_fields_grid.addWidget(self.user_tickets_card, 7, 0, 1, 2)
        self.user_fields_grid.setColumnStretch(0, 1)
        self.user_fields_grid.setColumnStretch(1, 1)
        user_result_layout.addLayout(self.user_fields_grid)
        self.password_expiration_timer = QTimer(self)
        self.password_expiration_timer.setInterval(60 * 60 * 1000)
        self.password_expiration_timer.timeout.connect(self.update_password_expiration_countdown)
        self.password_expiration_timer.start()
        self.user_result_card.hide()
        self.information_cards = QHBoxLayout()
        self.information_cards.setSpacing(14)
        page.addLayout(self.information_cards)

        self.status_card = QFrame(objectName="statusCard")
        self.status_opacity = QGraphicsOpacityEffect(self.status_card)
        self.status_card.setGraphicsEffect(self.status_opacity)
        self.status_animation = QPropertyAnimation(self.status_opacity, b"opacity", self)
        self.status_animation.setDuration(220)
        self.status_animation.setEasingCurve(QEasingCurve.OutCubic)
        status_box = QVBoxLayout(self.status_card)
        self.status_box = status_box
        status_box.setContentsMargins(20, 16, 20, 16)
        status_header = QHBoxLayout()
        self.status_pulse = QLabel()
        self.status_pulse.setObjectName("connectedComputerPulse")
        self.status_pulse.setFixedSize(34, 34)
        self.status_pulse.setAlignment(Qt.AlignCenter)
        self.status_pulse.setPixmap(modern_icon("remote", GREEN, 20).pixmap(20, 20))
        self.status_pulse.setToolTip("Estação conectada")
        # Não usa QGraphicsOpacityEffect aqui: o cartão já possui seu próprio
        # efeito e efeitos gráficos aninhados podem ocultar o ícone no Windows.
        self.station_pulse_step = 0
        self._station_icon_signature = None
        self.station_pulse_timer = QTimer(self)
        self.station_pulse_timer.setInterval(480)
        self.station_pulse_timer.timeout.connect(self.advance_station_pulse)
        status_header.addWidget(self.status_pulse)
        self.status_title = QLabel("RESUMO DA ESTAÇÃO")
        self.status_title.setObjectName("statusTitle")
        self.status_title.setWordWrap(True)
        status_header.addWidget(self.status_title, 1)
        self.evaluation_button = QPushButton()
        self.evaluation_button.setObjectName("copyTargetButton")
        self.evaluation_button.setFixedSize(30, 30)
        self.evaluation_button.setToolTip("Solicitar avaliação do atendimento ao usuário conectado")
        self.evaluation_button.setAccessibleName("Enviar solicitação de avaliação")
        self.evaluation_button.setCursor(Qt.PointingHandCursor)
        set_button_icon(self.evaluation_button, "feedback", GREEN, 17)
        self.evaluation_button.clicked.connect(self.send_remote_evaluation)
        self.evaluation_button.setEnabled(False)
        status_header.addWidget(self.evaluation_button, 0, Qt.AlignVCenter)
        self.refresh_button.setToolTip("Atualizar somente o cartão Estação conectada")
        self.refresh_button.setAccessibleName("Atualizar Estação conectada")
        self.refresh_button.setFixedSize(30, 30)
        status_header.addWidget(self.refresh_button, 0, Qt.AlignVCenter)
        status_box.addLayout(status_header)
        self.station_identity = QFrame(objectName="stationIdentityBar")
        identity_layout = QGridLayout(self.station_identity)
        self.identity_layout = identity_layout
        identity_layout.setContentsMargins(7, 6, 7, 6)
        identity_layout.setHorizontalSpacing(8)
        self.station_identity_machine_host = QFrame(objectName="stationIdentityItem")
        machine_identity_layout = QHBoxLayout(self.station_identity_machine_host)
        machine_identity_layout.setContentsMargins(7, 4, 5, 4)
        machine_identity_layout.setSpacing(5)
        machine_text_layout = QVBoxLayout()
        machine_text_layout.setContentsMargins(0, 0, 0, 0)
        machine_text_layout.setSpacing(0)
        machine_caption = QLabel("MICRO")
        machine_caption.setObjectName("stationIdentityText")
        machine_text_layout.addWidget(machine_caption)
        self.station_identity_machine = QLabel("—")
        self.station_identity_machine.setObjectName("stationIdentityText")
        self.station_identity_machine.setWordWrap(True)
        self.station_identity_machine.setTextFormat(Qt.PlainText)
        self.station_identity_machine.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        machine_name_row = QHBoxLayout()
        machine_name_row.setContentsMargins(0, 0, 0, 0)
        machine_name_row.setSpacing(5)
        machine_name_row.addWidget(self.station_identity_machine, 0)
        machine_name_row.addWidget(self.copy_target_button, 0, Qt.AlignVCenter)
        machine_name_row.addStretch(1)
        machine_text_layout.addLayout(machine_name_row)
        machine_identity_layout.addLayout(machine_text_layout, 1)
        machine_actions_layout = QVBoxLayout()
        machine_actions_layout.setContentsMargins(0, 0, 0, 0)
        machine_actions_layout.setSpacing(2)
        machine_buttons_row = QHBoxLayout()
        machine_buttons_row.setContentsMargins(0, 0, 0, 0)
        machine_buttons_row.setSpacing(5)
        self.station_ping_result = QLabel()
        self.station_ping_result.setObjectName("stationPingResult")
        self.station_ping_result.setTextFormat(Qt.PlainText)
        self.station_ping_result.setAlignment(Qt.AlignCenter)
        self.station_ping_result.setWordWrap(True)
        self.station_ping_result.setMaximumWidth(105)
        self.station_ping_result.hide()
        self.station_ping_state = "unknown"
        self.station_ping_button = QPushButton()
        self.station_ping_button.setObjectName("printerQuickButton")
        self.station_ping_button.setFixedSize(24, 24)
        self.station_ping_button.setToolTip("Ping contínuo da estação conectada")
        self.station_ping_button.setAccessibleName("Iniciar ping contínuo da estação")
        set_button_icon(self.station_ping_button, "ping", GREEN, 13)
        self.station_ping_button.setEnabled(False)
        self.station_ping_button.clicked.connect(self.quick_ping_station)
        machine_buttons_row.addWidget(self.station_ping_button)
        self.station_remote_button = QPushButton()
        self.station_remote_button.setObjectName("printerQuickButton")
        self.station_remote_button.setFixedSize(24, 24)
        self.station_remote_button.setToolTip("Abrir controle remoto SCCM da estação")
        self.station_remote_button.setAccessibleName("Abrir acesso remoto à estação")
        set_button_icon(self.station_remote_button, "remote", GREEN, 13)
        self.station_remote_button.setEnabled(False)
        self.station_remote_button.clicked.connect(self.quick_open_sccm)
        machine_buttons_row.addWidget(self.station_remote_button)
        machine_actions_layout.addLayout(machine_buttons_row)
        machine_actions_layout.addWidget(self.station_ping_result, 0, Qt.AlignHCenter)
        machine_identity_layout.addLayout(machine_actions_layout)
        identity_layout.addWidget(self.station_identity_machine_host, 0, 0)
        self.station_identity_user_host = QFrame(objectName="stationIdentityItem")
        user_identity_layout = QHBoxLayout(self.station_identity_user_host)
        user_identity_layout.setContentsMargins(7, 4, 5, 4)
        user_identity_layout.setSpacing(5)
        self.station_identity_user_name = QLabel("USUÁRIO\n—")
        self.station_identity_user_name.setObjectName("stationIdentityText")
        self.station_identity_user_name.setProperty("nameResolved", False)
        self.station_identity_user_name.setTextFormat(Qt.PlainText)
        self.station_identity_user_name.setWordWrap(True)
        self.station_identity_user_name.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        user_identity_layout.addWidget(self.station_identity_user_name, 1)
        self.free_orientation_button = QPushButton()
        self.free_orientation_button.setObjectName("freeOrientationButton")
        self.free_orientation_button.setFixedSize(24, 24)
        self.free_orientation_button.setToolTip("Enviar uma orientação livre ao usuário conectado")
        self.free_orientation_button.setAccessibleName("Criar orientação livre para o usuário")
        self.free_orientation_button.setEnabled(False)
        set_button_icon(self.free_orientation_button, "orientation", BLUE_2, 13)
        self.free_orientation_button.clicked.connect(self.open_free_orientation)
        user_identity_layout.addWidget(self.free_orientation_button, 0, Qt.AlignRight | Qt.AlignVCenter)
        identity_layout.addWidget(self.station_identity_user_host, 0, 1)
        identity_layout.setColumnStretch(0, 1)
        identity_layout.setColumnStretch(1, 1)
        status_box.addWidget(self.station_identity)
        self.status_grid = QGridLayout()
        self.status_grid.setHorizontalSpacing(18)
        self.status_grid.setVerticalSpacing(7)
        self.status_grid.setColumnStretch(0, 1)
        self.status_grid.setColumnStretch(1, 1)
        status_box.addLayout(self.status_grid)
        self.status_labels = {}
        fields = [
            ("windows", "Windows"),
            ("admin", "Admin local"), ("rdp", "Usuários da área de trabalho remota"),
            ("uptime", "Tempo ligado"), ("disk_d", "Espaço Dados (D:)"),
            ("sccm", "Agente SCCM"), ("printers", "Impressoras de rede"),
            ("printer_groups", "Grupos de impressoras no AD"),
        ]
        for index, (key, caption) in enumerate(fields):
            if key == "admin":
                self.admin_status_widget = AdminStatusWidget(caption)
                self.admin_status_widget.toggle_requested.connect(self.handle_admin_lock)
                display_widget = self.admin_status_widget
                label = self.admin_status_widget.value_label
            elif key == "printers":
                display_widget = QFrame(objectName="stationDataFieldCard")
                printer_row = QHBoxLayout(display_widget)
                printer_row.setContentsMargins(7, 4, 7, 5)
                printer_row.setSpacing(7)
                printer_text = QVBoxLayout()
                printer_text.setContentsMargins(0, 0, 0, 0)
                printer_text.setSpacing(1)
                printer_caption = QLabel(caption)
                printer_caption.setObjectName("statusFieldCaption")
                printer_caption.setWordWrap(True)
                printer_text.addWidget(printer_caption)
                label = QLabel("—")
                label.setObjectName("statusFieldValue")
                label.setTextFormat(Qt.RichText)
                label.setWordWrap(True)
                label.setTextInteractionFlags(Qt.TextSelectableByMouse)
                printer_text.addWidget(label)
                color_row = QHBoxLayout()
                color_row.setContentsMargins(0, 2, 0, 0)
                color_row.setSpacing(5)
                self.printer_color_status = QLabel("Impressão colorida: aguardando usuário no AD")
                self.printer_color_status.setObjectName("printerColorStatus")
                self.printer_color_status.setProperty("permissionState", "pending")
                self.printer_color_status.setWordWrap(False)
                self.printer_color_status.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Preferred)
                color_row.addWidget(self.printer_color_status, 0, Qt.AlignVCenter)
                self.printer_color_faq_button = QPushButton()
                self.printer_color_faq_button.setObjectName("printerQuickButton")
                self.printer_color_faq_button.setFixedSize(22, 22)
                self.printer_color_faq_button.setToolTip("FAQ 1007: impressoras com contrato")
                self.printer_color_faq_button.setAccessibleName("Abrir FAQ das impressoras com contrato")
                set_button_icon(self.printer_color_faq_button, "info", BLUE_2, 13)
                self.printer_color_faq_button.clicked.connect(
                    lambda: self.open_external_link(COLOR_PRINTER_FAQ_URL)
                )
                color_row.addWidget(self.printer_color_faq_button)
                color_row.addStretch(1)
                printer_text.addLayout(color_row)
                printer_row.addLayout(printer_text, 1)
                controls = QVBoxLayout()
                controls.setSpacing(5)
                self.printer_ping_button = QPushButton()
                self.printer_ping_button.setObjectName("printerQuickButton")
                self.printer_ping_button.setToolTip("Pingar impressora")
                self.printer_ping_button.setFixedSize(28, 28)
                set_button_icon(self.printer_ping_button, "ping", GREEN, 15)
                self.printer_ping_button.setEnabled(False)
                self.printer_ping_button.clicked.connect(self.ping_printer)
                controls.addWidget(self.printer_ping_button)
                self.printer_web_button = QPushButton()
                self.printer_web_button.setObjectName("printerQuickButton")
                self.printer_web_button.setToolTip("Abrir interface web da impressora")
                self.printer_web_button.setFixedSize(28, 28)
                set_button_icon(self.printer_web_button, "external", GREEN, 15)
                self.printer_web_button.setEnabled(False)
                self.printer_web_button.clicked.connect(self.open_printer_web)
                controls.addWidget(self.printer_web_button)
                printer_row.addLayout(controls)
            else:
                display_widget = StationDataFieldCard(
                    caption,
                    action_icon={"disk_d": "disk", "windows": "logout"}.get(key, ""),
                    action_tooltip={"disk_d": "Abrir discos e perfis da estação", "windows": "Encerrar sessão do usuário remoto"}.get(key, ""),
                )
                if key == "disk_d":
                    self.disk_d_button = display_widget.action_button
                    self.disk_d_button.clicked.connect(self.quick_disk_profiles)
                    self.disk_temp_button = QPushButton()
                    self.disk_temp_button.setObjectName("printerQuickButton")
                    self.disk_temp_button.setFixedSize(26, 26)
                    self.disk_temp_button.setToolTip("Limpar arquivos temporários da estação")
                    self.disk_temp_button.setAccessibleName("Limpar arquivos temporários")
                    self.disk_temp_button.setEnabled(False)
                    set_button_icon(self.disk_temp_button, "trash", BLUE_2, 14)
                    self.disk_temp_button.clicked.connect(self.request_temp_cleanup)
                    display_widget.actions_layout.addWidget(self.disk_temp_button)
                if key == "windows":
                    self.windows_logoff_button = display_widget.action_button
                    self.windows_logoff_button.clicked.connect(self.request_printer_logoff)
                    self.windows_restart_button = QPushButton()
                    self.windows_restart_button.setObjectName("printerQuickButton")
                    self.windows_restart_button.setFixedSize(26, 26)
                    self.windows_restart_button.setToolTip("Reiniciar estação remota")
                    self.windows_restart_button.setAccessibleName("Reiniciar estação remota")
                    self.windows_restart_button.setEnabled(False)
                    set_button_icon(self.windows_restart_button, "power", RED, 14)
                    self.windows_restart_button.clicked.connect(self.request_station_restart)
                    display_widget.actions_layout.addWidget(self.windows_restart_button)
                if key == "rdp":
                    display_widget.caption_label.setToolTip("Membros do grupo local nesta estação")
                label = display_widget.value_label
            self.status_labels[key] = (caption, label, display_widget)
            self.status_grid.addWidget(display_widget, index // 2, index % 2)
        self.status_card.hide()
        # No modo amplo, estação à esquerda e usuário à direita. Cada cartão
        # mantém sua altura natural, sem esticar os campos da estação até a
        # altura das observações e dos chamados do usuário.
        self.information_cards.addWidget(self.status_card, 1, Qt.AlignTop)
        self.information_cards.addWidget(self.user_result_card, 1, Qt.AlignTop)

        self.section_title = QLabel("Ações rápidas")
        self.section_title.setObjectName("sectionTitle")
        self.heading_opacity = QGraphicsOpacityEffect(self.section_title)
        self.section_title.setGraphicsEffect(self.heading_opacity)
        self.heading_animation = QPropertyAnimation(self.heading_opacity, b"opacity", self)
        self.heading_animation.setDuration(105)
        self.heading_animation.setEasingCurve(QEasingCurve.OutCubic)
        page.addWidget(self.section_title)
        self.section_description = QLabel("Atalhos recomendados para o seu perfil e para o atendimento atual.")
        self.section_description.setObjectName("sectionDescription")
        self.section_description.setWordWrap(True)
        self.description_opacity = QGraphicsOpacityEffect(self.section_description)
        self.section_description.setGraphicsEffect(self.description_opacity)
        self.description_animation = QPropertyAnimation(self.description_opacity, b"opacity", self)
        self.description_animation.setDuration(100)
        self.description_animation.setEasingCurve(QEasingCurve.OutQuart)
        page.addWidget(self.section_description)
        self.section_separator = section_separator()
        page.addWidget(self.section_separator)

        self.printer_summary = QFrame(objectName="statusCard")
        self.printer_summary.setMinimumWidth(0)
        printer_summary_box = QVBoxLayout(self.printer_summary)
        self.printer_summary_box = printer_summary_box
        printer_summary_box.setContentsMargins(16, 13, 16, 14)
        printer_summary_box.setSpacing(9)
        printer_summary_title = QLabel("IMPRESSORAS DA ESTAÇÃO")
        printer_summary_title.setObjectName("statusTitle")
        printer_summary_box.addWidget(printer_summary_title)
        self.printer_summary_station = QLabel("Conecte uma estação para consultar suas impressoras.")
        self.printer_summary_station.setObjectName("smallMuted")
        self.printer_summary_station.setTextFormat(Qt.PlainText)
        self.printer_summary_station.setWordWrap(True)
        printer_summary_box.addWidget(self.printer_summary_station)
        printer_summary_network = QFrame(objectName="statusValue")
        printer_summary_network_row = QHBoxLayout(printer_summary_network)
        self.printer_summary_network_layout = printer_summary_network_row
        printer_summary_network_row.setContentsMargins(10, 8, 7, 8)
        printer_summary_network_row.setSpacing(7)
        self.printer_summary_names = QLabel()
        self.printer_summary_names.setObjectName("statusValueText")
        self.printer_summary_names.setTextFormat(Qt.RichText)
        self.printer_summary_names.setWordWrap(True)
        self.printer_summary_names.setMinimumWidth(0)
        printer_summary_network_row.addWidget(self.printer_summary_names, 1)
        printer_summary_controls = QGridLayout()
        self.printer_summary_controls = printer_summary_controls
        printer_summary_controls.setContentsMargins(0, 0, 0, 0)
        printer_summary_controls.setHorizontalSpacing(5)
        printer_summary_controls.setVerticalSpacing(5)
        self.printer_summary_refresh = QPushButton()
        self.printer_summary_refresh.setObjectName("printerQuickButton")
        self.printer_summary_refresh.setToolTip("Atualizar somente as impressoras da estação")
        self.printer_summary_refresh.setAccessibleName("Atualizar impressoras da estação")
        self.printer_summary_refresh.setFixedSize(28, 28)
        set_button_icon(self.printer_summary_refresh, "refresh", GREEN, 15)
        self.printer_summary_refresh.clicked.connect(lambda: self.refresh_printer_status("summary"))
        printer_summary_controls.addWidget(self.printer_summary_refresh, 0, 0)
        self.printer_summary_ping = QPushButton()
        self.printer_summary_ping.setObjectName("printerQuickButton")
        self.printer_summary_ping.setToolTip("Pingar impressora")
        self.printer_summary_ping.setAccessibleName("Pingar impressora da estação")
        self.printer_summary_ping.setFixedSize(28, 28)
        set_button_icon(self.printer_summary_ping, "ping", GREEN, 15)
        self.printer_summary_ping.clicked.connect(self.ping_printer)
        printer_summary_controls.addWidget(self.printer_summary_ping, 0, 1)
        self.printer_summary_web = QPushButton()
        self.printer_summary_web.setObjectName("printerQuickButton")
        self.printer_summary_web.setToolTip("Abrir interface web da impressora")
        self.printer_summary_web.setAccessibleName("Abrir interface web da impressora da estação")
        self.printer_summary_web.setFixedSize(28, 28)
        set_button_icon(self.printer_summary_web, "external", GREEN, 15)
        self.printer_summary_web.clicked.connect(self.open_printer_web)
        printer_summary_controls.addWidget(self.printer_summary_web, 0, 2)
        self.printer_summary_test_page = QPushButton()
        self.printer_summary_test_page.setObjectName("printerQuickButton")
        self.printer_summary_test_page.setToolTip("Imprimir página de teste")
        self.printer_summary_test_page.setAccessibleName("Imprimir página de teste")
        self.printer_summary_test_page.setFixedSize(28, 28)
        set_button_icon(self.printer_summary_test_page, "printer", GREEN, 15)
        self.printer_summary_test_page.clicked.connect(self.print_test_page)
        printer_summary_controls.addWidget(self.printer_summary_test_page, 1, 0)
        self.printer_summary_admin = QPushButton()
        self.printer_summary_admin.setObjectName("printerAdminButton")
        self.printer_summary_admin.setAccessibleName("Alterar estado de administrador local")
        self.printer_summary_admin.setFixedSize(28, 28)
        self.printer_summary_admin.clicked.connect(self.handle_admin_lock)
        self.printer_admin_opacity = QGraphicsOpacityEffect(self.printer_summary_admin)
        self.printer_summary_admin.setGraphicsEffect(self.printer_admin_opacity)
        self.printer_admin_pulse = QPropertyAnimation(self.printer_admin_opacity, b"opacity", self)
        self.printer_admin_pulse.setDuration(1250)
        self.printer_admin_pulse.setLoopCount(-1)
        self.printer_admin_pulse.setEasingCurve(QEasingCurve.InOutSine)
        self.printer_admin_pulse.setKeyValueAt(0.0, 1.0)
        self.printer_admin_pulse.setKeyValueAt(0.5, 0.38)
        self.printer_admin_pulse.setKeyValueAt(1.0, 1.0)
        printer_summary_controls.addWidget(self.printer_summary_admin, 1, 1)
        self.printer_summary_logoff = QPushButton()
        self.printer_summary_logoff.setObjectName("printerQuickButton")
        self.printer_summary_logoff.setToolTip("Encerrar a sessão do usuário")
        self.printer_summary_logoff.setAccessibleName("Fazer logoff na estação")
        self.printer_summary_logoff.setFixedSize(28, 28)
        set_button_icon(self.printer_summary_logoff, "logout", RED, 15)
        self.printer_summary_logoff.clicked.connect(self.request_printer_logoff)
        printer_summary_controls.addWidget(self.printer_summary_logoff, 1, 2)
        printer_summary_network_row.addLayout(printer_summary_controls)
        printer_summary_box.addWidget(printer_summary_network)
        self.printer_summary_groups = QLabel()
        self.printer_summary_groups.setObjectName("statusValue")
        self.printer_summary_groups.setTextFormat(Qt.PlainText)
        self.printer_summary_groups.setWordWrap(True)
        self.printer_summary_groups.setMinimumWidth(0)
        printer_summary_box.addWidget(self.printer_summary_groups)
        self.printer_summary.hide()
        page.addWidget(self.printer_summary)
        self.update_printer_summary()

        self.software_search_frame = QFrame(objectName="softwareSearchFrame")
        search_row = QHBoxLayout(self.software_search_frame)
        search_row.setContentsMargins(12, 8, 12, 8)
        search_row.setSpacing(9)
        search_icon = QLabel()
        search_icon.setPixmap(modern_icon("search", BLUE, 18).pixmap(18, 18))
        search_row.addWidget(search_icon)
        self.software_search = QLineEdit()
        self.software_search.setObjectName("softwareSearchInput")
        self.software_search.setPlaceholderText("Pesquisar por nome, executável, pasta ou categoria…")
        self.software_search.setClearButtonEnabled(True)
        self.software_search.textChanged.connect(self.filter_authorized_software)
        search_row.addWidget(self.software_search, 1)
        self.software_result_count = QLabel("0 softwares")
        self.software_result_count.setObjectName("softwareResultCount")
        search_row.addWidget(self.software_result_count)
        self.software_suggestion_model = QStringListModel(self)
        self.software_completer = QCompleter(self.software_suggestion_model, self)
        self.software_completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.software_completer.setFilterMode(Qt.MatchContains)
        self.software_completer.setCompletionMode(QCompleter.PopupCompletion)
        self.software_completer.setMaxVisibleItems(7)
        suggestion_popup = self.software_completer.popup()
        suggestion_popup.setObjectName("softwareSuggestionPopup")
        suggestion_popup.setTextElideMode(Qt.ElideRight)
        suggestion_popup.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.software_suggestion_delegate = SoftwareSuggestionDelegate(
            lambda: self.software_search.text(), suggestion_popup
        )
        suggestion_popup.setItemDelegate(self.software_suggestion_delegate)
        self.software_search.setCompleter(self.software_completer)
        self.software_search_frame.hide()
        page.addWidget(self.software_search_frame)

        self.faq_search_frame = QFrame(objectName="faqSearchPanel")
        faq_search_box = QVBoxLayout(self.faq_search_frame)
        self.faq_search_box = faq_search_box
        faq_search_box.setContentsMargins(14, 12, 14, 13)
        faq_search_box.setSpacing(7)
        faq_search_header = QHBoxLayout()
        faq_search_header.setSpacing(8)
        faq_search_title = QLabel("PESQUISAR FAQs")
        self.faq_search_title = faq_search_title
        faq_search_title.setObjectName("faqSearchTitle")
        faq_search_header.addWidget(faq_search_title)
        faq_search_header.addStretch(1)
        faq_search_badge = QLabel("PESQUISA LOCAL")
        self.faq_search_badge = faq_search_badge
        faq_search_badge.setObjectName("faqSearchBadge")
        faq_search_header.addWidget(faq_search_badge)
        self.faq_capri_status = QLabel("Capri conectado" if self._capri_session_password else "Capri não conectado")
        self.faq_capri_status.setObjectName("capriSessionStatus")
        self.faq_capri_status.setProperty("connected", bool(self._capri_session_password))
        faq_search_header.addWidget(self.faq_capri_status)
        self.faq_clear_cache_button = QPushButton("Limpar cache")
        self.faq_clear_cache_button.setObjectName("cacheClearButton")
        self.faq_clear_cache_button.setToolTip("Apagar somente o catálogo local de FAQs")
        set_button_icon(self.faq_clear_cache_button, "trash", MUTED, 12)
        self.faq_clear_cache_button.clicked.connect(self.clear_faq_cache)
        faq_search_header.addWidget(self.faq_clear_cache_button)
        self.faq_incremental_button = QPushButton("Atualizar")
        self.faq_incremental_button.setObjectName("cacheRefreshButton")
        self.faq_incremental_button.setFixedHeight(28)
        self.faq_incremental_button.setToolTip("Buscar somente FAQs novas no Capri")
        self.faq_incremental_button.setAccessibleName("Atualizar FAQs novas")
        set_button_icon(self.faq_incremental_button, "refresh", BLUE, 12)
        self.faq_incremental_button.clicked.connect(
            lambda: self.request_faq_catalog(True, self.faq_incremental_button)
        )
        faq_search_header.addWidget(self.faq_incremental_button)
        faq_search_box.addLayout(faq_search_header)
        faq_search_hint = QLabel(
            "Digite como você lembrar: palavras incompletas, termos relacionados e pequenas variações já são considerados instantaneamente. A pesquisa usa somente a base local."
        )
        self.faq_search_hint = faq_search_hint
        faq_search_hint.setObjectName("faqSearchHint")
        faq_search_hint.setWordWrap(True)
        faq_search_box.addWidget(faq_search_hint)
        faq_search_mode_row = QHBoxLayout()
        faq_search_mode_row.setSpacing(8)
        faq_search_mode_label = QLabel("MODO DA BUSCA")
        self.faq_search_mode_label = faq_search_mode_label
        faq_search_mode_label.setObjectName("faqSearchModeLabel")
        faq_search_mode_row.addWidget(faq_search_mode_label)
        faq_search_mode_row.addStretch(1)
        faq_search_mode_selector = QFrame(objectName="faqSearchModeSelector")
        self.faq_search_mode_selector = faq_search_mode_selector
        faq_search_mode_buttons = QHBoxLayout(faq_search_mode_selector)
        faq_search_mode_buttons.setContentsMargins(2, 2, 2, 2)
        faq_search_mode_buttons.setSpacing(2)
        self.faq_related_search_button = QPushButton("Relacionada")
        self.faq_related_search_button.setObjectName("faqSearchModeButton")
        self.faq_related_search_button.setCheckable(True)
        self.faq_related_search_button.setChecked(True)
        self.faq_related_search_button.setToolTip("Busca inteligente: aceita termos parciais, relacionados e erros de digitação, priorizando os melhores resultados")
        self.faq_title_search_button = QPushButton("No título")
        self.faq_title_search_button.setObjectName("faqSearchModeButton")
        self.faq_title_search_button.setCheckable(True)
        self.faq_title_search_button.setToolTip("Localiza a expressão completa somente no título ou o número exato da FAQ")
        self.faq_search_mode_group = QButtonGroup(self)
        self.faq_search_mode_group.setExclusive(True)
        self.faq_search_mode_group.addButton(self.faq_related_search_button)
        self.faq_search_mode_group.addButton(self.faq_title_search_button)
        self.faq_related_search_button.clicked.connect(lambda: self.set_faq_search_mode(False))
        self.faq_title_search_button.clicked.connect(lambda: self.set_faq_search_mode(True))
        faq_search_mode_buttons.addWidget(self.faq_related_search_button)
        faq_search_mode_buttons.addWidget(self.faq_title_search_button)
        faq_search_mode_row.addWidget(faq_search_mode_selector)
        faq_search_box.addLayout(faq_search_mode_row)
        faq_search_input_frame = QFrame(objectName="faqSearchInputFrame")
        self.faq_search_input_frame = faq_search_input_frame
        faq_search_row = QHBoxLayout(faq_search_input_frame)
        self.faq_search_row = faq_search_row
        faq_search_row.setContentsMargins(11, 6, 11, 6)
        faq_search_row.setSpacing(9)
        self.faq_search_icon = QLabel()
        self.faq_search_icon.setPixmap(modern_icon("search", BLUE, 18).pixmap(18, 18))
        self.faq_search_icon.setToolTip("Pesquisar no catálogo local de FAQs")
        faq_search_row.addWidget(self.faq_search_icon)
        self.faq_search = QLineEdit()
        self.faq_search.setObjectName("faqSearchInput")
        self.faq_search.setPlaceholderText("Digite como lembrar: impressora, certificado, vpn, senha, erro…")
        self.faq_search.setAccessibleName("Pesquisar FAQs salvas")
        self.faq_search.setClearButtonEnabled(True)
        self.faq_search.textChanged.connect(self.filter_faqs)
        faq_search_row.addWidget(self.faq_search, 1)
        self.faq_result_count = QLabel("0 FAQs")
        self.faq_result_count.setObjectName("faqResultCount")
        faq_search_row.addWidget(self.faq_result_count)
        faq_search_box.addWidget(faq_search_input_frame)
        self.faq_suggestion_model = QStringListModel(self)
        # A pesquisa já usa o índice local com tolerância a erros. Não associa
        # QCompleter para impedir janelas flutuantes repetidas durante a digitação.
        self.faq_search_frame.hide()
        page.addWidget(self.faq_search_frame)

        self.faq_specific_frame = QFrame(objectName="faqMaintenanceFrame")
        faq_maintenance_box = QVBoxLayout(self.faq_specific_frame)
        faq_maintenance_box.setContentsMargins(14, 11, 14, 13)
        faq_maintenance_box.setSpacing(7)
        faq_maintenance_header = QHBoxLayout()
        faq_maintenance_title = QLabel("ATUALIZAR A BASE")
        faq_maintenance_title.setObjectName("faqMaintenanceTitle")
        faq_maintenance_header.addWidget(faq_maintenance_title)
        faq_maintenance_header.addStretch(1)
        faq_maintenance_box.addLayout(faq_maintenance_header)
        faq_maintenance_hint = QLabel(
            "Use esta área somente para consultar o Capri, atualizar uma FAQ específica ou reconstruir o catálogo completo."
        )
        faq_maintenance_hint.setObjectName("faqMaintenanceHint")
        faq_maintenance_hint.setWordWrap(True)
        faq_maintenance_box.addWidget(faq_maintenance_hint)
        faq_maintenance_actions = QHBoxLayout()
        faq_maintenance_actions.setSpacing(9)
        self.faq_login_button = QPushButton("Acesso ao Capri")
        self.faq_login_button.setObjectName("faqCapriAccessButton")
        self.faq_login_button.setToolTip("Informar ou atualizar a autenticação do Capri")
        set_button_icon(self.faq_login_button, "lock", BLUE, 14)
        self.faq_login_button.clicked.connect(lambda: self.open_capri_login(True))
        faq_maintenance_actions.addWidget(self.faq_login_button)
        self.faq_refresh_button = QPushButton("Remapear todas as FAQs")
        self.faq_refresh_button.setObjectName("faqRemapAllButton")
        self.faq_refresh_button.setToolTip("Consultar novamente e reconstruir o catálogo completo de FAQs do Capri")
        set_button_icon(self.faq_refresh_button, "refresh", BLUE, 14)
        self.faq_refresh_button.clicked.connect(
            lambda: self.request_faq_catalog(True, self.faq_refresh_button)
        )
        faq_maintenance_actions.addWidget(self.faq_refresh_button)
        faq_maintenance_actions.addStretch(1)
        faq_maintenance_box.addLayout(faq_maintenance_actions)
        faq_specific_row = QHBoxLayout()
        faq_specific_row.setContentsMargins(0, 2, 0, 0)
        faq_specific_row.setSpacing(9)
        faq_specific_label = QLabel("Número da FAQ")
        faq_specific_label.setObjectName("faqMaintenanceFieldLabel")
        faq_specific_row.addWidget(faq_specific_label)
        self.faq_specific_input = QLineEdit()
        self.faq_specific_input.setObjectName("specificFaqInput")
        self.faq_specific_input.setPlaceholderText("Informe exatamente o número publicado no Capri")
        self.faq_specific_input.setAccessibleName("Número da FAQ que será atualizada")
        self.faq_specific_input.setClearButtonEnabled(True)
        self.faq_specific_input.setMaxLength(12)
        self.faq_specific_input.returnPressed.connect(lambda: self.request_single_faq_update("FAQs"))
        faq_specific_row.addWidget(self.faq_specific_input, 1)
        self.faq_specific_button = QPushButton("Atualizar FAQ específica")
        self.faq_specific_button.setObjectName("specificFaqButton")
        self.faq_specific_button.setToolTip("Consultar no Capri e atualizar somente esta FAQ")
        set_button_icon(self.faq_specific_button, "refresh", GREEN, 15)
        self.faq_specific_button.clicked.connect(lambda: self.request_single_faq_update("FAQs"))
        faq_specific_row.addWidget(self.faq_specific_button)
        faq_maintenance_box.addLayout(faq_specific_row)
        self.faq_specific_frame.hide()
        page.addWidget(self.faq_specific_frame)

        self.orientation_search_frame = QFrame(objectName="orientationSearchPanel")
        orientation_search_box = QVBoxLayout(self.orientation_search_frame)
        orientation_search_box.setContentsMargins(14, 12, 14, 13)
        orientation_search_box.setSpacing(7)
        orientation_search_header = QHBoxLayout()
        orientation_search_header.setSpacing(8)
        orientation_search_title = QLabel("PESQUISAR ORIENTAÇÕES")
        orientation_search_title.setObjectName("orientationSearchTitle")
        orientation_search_header.addWidget(orientation_search_title)
        orientation_search_header.addStretch(1)
        orientation_search_badge = QLabel("PESQUISA LOCAL")
        orientation_search_badge.setObjectName("orientationSearchBadge")
        orientation_search_header.addWidget(orientation_search_badge)
        orientation_search_box.addLayout(orientation_search_header)
        orientation_search_hint = QLabel(
            "Digite abaixo para filtrar imediatamente as orientações já salvas. Esta pesquisa não atualiza nem remapeia a base."
        )
        orientation_search_hint.setObjectName("orientationSearchHint")
        orientation_search_hint.setWordWrap(True)
        orientation_search_box.addWidget(orientation_search_hint)
        orientation_search_input_frame = QFrame(objectName="orientationSearchInputFrame")
        orientation_search_row = QHBoxLayout(orientation_search_input_frame)
        orientation_search_row.setContentsMargins(11, 6, 11, 6)
        orientation_search_row.setSpacing(9)
        orientation_search_icon = QLabel()
        orientation_search_icon.setPixmap(modern_icon("search", BLUE, 18).pixmap(18, 18))
        orientation_search_icon.setToolTip("Pesquisar no catálogo local de orientações")
        orientation_search_row.addWidget(orientation_search_icon)
        self.orientation_search = QLineEdit()
        self.orientation_search.setObjectName("orientationSearchInput")
        self.orientation_search.setPlaceholderText("Pesquisar solicitação, assunto, caminho ou número da FAQ…")
        self.orientation_search.setAccessibleName("Pesquisar orientações salvas")
        self.orientation_search.setClearButtonEnabled(True)
        self.orientation_search.setCompleter(None)
        self.orientation_search.setInputMethodHints(Qt.ImhNoPredictiveText)
        self.orientation_search.textChanged.connect(self.filter_orientations)
        orientation_search_row.addWidget(self.orientation_search, 1)
        self.orientation_result_count = QLabel("0 orientações")
        self.orientation_result_count.setObjectName("orientationResultCount")
        orientation_search_row.addWidget(self.orientation_result_count)
        orientation_search_box.addWidget(orientation_search_input_frame)
        # Sem modelo de sugestões nem QCompleter: os resultados são atualizados
        # somente na árvore abaixo, como ocorre no campo de FAQs.
        self.orientation_search_frame.hide()
        page.addWidget(self.orientation_search_frame)

        self.specific_orientation_frame = QFrame(objectName="orientationMaintenanceFrame")
        maintenance_box = QVBoxLayout(self.specific_orientation_frame)
        maintenance_box.setContentsMargins(14, 11, 14, 13)
        maintenance_box.setSpacing(7)
        maintenance_header = QHBoxLayout()
        maintenance_header.setSpacing(8)
        maintenance_title = QLabel("ATUALIZAR A BASE")
        maintenance_title.setObjectName("orientationMaintenanceTitle")
        maintenance_header.addWidget(maintenance_title)
        maintenance_header.addStretch(1)
        self.orientation_refresh_button = QPushButton("Remapear catálogo completo")
        self.orientation_refresh_button.setObjectName("orientationRemapAllButton")
        self.orientation_refresh_button.setToolTip("Recriar todas as orientações usando as FAQs locais")
        set_button_icon(self.orientation_refresh_button, "refresh", BLUE, 14)
        self.orientation_refresh_button.clicked.connect(self.remap_orientations_with_feedback)
        maintenance_header.addWidget(self.orientation_refresh_button)
        maintenance_box.addLayout(maintenance_header)
        maintenance_hint = QLabel(
            "Use esta área somente quando uma FAQ tiver sido alterada no Capri ou quando for necessário reconstruir o catálogo."
        )
        maintenance_hint.setObjectName("orientationMaintenanceHint")
        maintenance_hint.setWordWrap(True)
        maintenance_box.addWidget(maintenance_hint)
        specific_row = QHBoxLayout()
        specific_row.setContentsMargins(0, 2, 0, 0)
        specific_row.setSpacing(9)
        specific_label = QLabel("Número da FAQ")
        specific_label.setObjectName("orientationMaintenanceFieldLabel")
        specific_row.addWidget(specific_label)
        self.specific_faq_input = QLineEdit()
        self.specific_faq_input.setObjectName("specificFaqInput")
        self.specific_faq_input.setPlaceholderText("Informe exatamente o número publicado no Capri")
        self.specific_faq_input.setAccessibleName("Número da FAQ que será atualizada")
        self.specific_faq_input.setClearButtonEnabled(True)
        self.specific_faq_input.setMaxLength(12)
        self.specific_faq_input.returnPressed.connect(
            lambda: self.request_single_faq_update("Orientações ao usuário")
        )
        specific_row.addWidget(self.specific_faq_input, 1)
        self.specific_faq_button = QPushButton("Atualizar FAQ específica")
        self.specific_faq_button.setObjectName("specificFaqButton")
        self.specific_faq_button.setToolTip("Consultar esta FAQ no Capri e refazer somente sua orientação")
        set_button_icon(self.specific_faq_button, "refresh", GREEN, 15)
        self.specific_faq_button.clicked.connect(lambda: self.request_single_faq_update("Orientações ao usuário"))
        specific_row.addWidget(self.specific_faq_button)
        maintenance_box.addLayout(specific_row)
        self.specific_orientation_frame.hide()
        page.addWidget(self.specific_orientation_frame)

        self.ticket_filter_frame = QFrame(objectName="ticketFilterPanel")
        self.ticket_filter_frame.setMinimumWidth(0)
        ticket_box = QVBoxLayout(self.ticket_filter_frame)
        ticket_box.setContentsMargins(14, 13, 14, 14)
        ticket_box.setSpacing(10)
        ticket_head = QHBoxLayout()
        ticket_head.setSpacing(10)
        ticket_head_icon = QLabel()
        ticket_head_icon.setObjectName("ticketHeaderIcon")
        ticket_head_icon.setFixedSize(34, 34)
        ticket_head_icon.setAlignment(Qt.AlignCenter)
        ticket_head_icon.setPixmap(modern_icon("ticket", "#258DC2", 19).pixmap(19, 19))
        ticket_head.addWidget(ticket_head_icon)
        ticket_titles = QVBoxLayout()
        ticket_titles.setSpacing(1)
        ticket_title = QLabel("Central de chamados")
        self.ticket_panel_title = ticket_title
        ticket_title.setObjectName("ticketPanelTitle")
        ticket_titles.addWidget(ticket_title)
        ticket_hint = QLabel("Consulte o cache instantaneamente ou atualize os dados no Capri quando precisar.")
        self.ticket_panel_hint = ticket_hint
        ticket_hint.setObjectName("ticketPanelHint")
        ticket_hint.setWordWrap(True)
        ticket_titles.setStretch(0, 0)
        ticket_titles.setStretch(1, 1)
        ticket_titles.addWidget(ticket_hint)
        ticket_head.addLayout(ticket_titles)
        self.ticket_capri_status = QLabel("Capri conectado" if self._capri_session_password else "Capri não conectado")
        self.ticket_capri_status.setObjectName("capriSessionStatus")
        self.ticket_capri_status.setProperty("connected", bool(self._capri_session_password))
        self.ticket_capri_status.setAlignment(Qt.AlignCenter)
        self.ticket_capri_status.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        ticket_head.addWidget(self.ticket_capri_status, 0, Qt.AlignVCenter)
        ticket_head.addStretch(1)
        self.ticket_clear_cache_button = QPushButton("Limpar cache")
        self.ticket_clear_cache_button.setObjectName("cacheClearButton")
        self.ticket_clear_cache_button.setFixedHeight(28)
        self.ticket_clear_cache_button.setToolTip("Limpar o cache local de chamados")
        self.ticket_clear_cache_button.setAccessibleName("Limpar cache de chamados")
        set_button_icon(self.ticket_clear_cache_button, "trash", MUTED, 12)
        self.ticket_clear_cache_button.clicked.connect(self.clear_ticket_cache)
        ticket_head.addWidget(self.ticket_clear_cache_button, 0, Qt.AlignVCenter)
        self.ticket_refresh_cache_button = QPushButton("Atualizar")
        self.ticket_refresh_cache_button.setObjectName("cacheRefreshButton")
        self.ticket_refresh_cache_button.setFixedHeight(28)
        self.ticket_refresh_cache_button.setToolTip("Mapear ontem e hoje e conferir os chamados abertos ou pendentes no Capri")
        self.ticket_refresh_cache_button.setAccessibleName("Atualizar chamados recentes e conferir estados em aberto")
        set_button_icon(self.ticket_refresh_cache_button, "refresh", BLUE, 12)
        self.ticket_refresh_cache_button.clicked.connect(self.refresh_recent_tickets)
        ticket_head.addWidget(self.ticket_refresh_cache_button, 0, Qt.AlignVCenter)
        self.ticket_result_count = QLabel("0 chamados")
        self.ticket_result_count.setObjectName("ticketResultCount")
        ticket_head.addWidget(self.ticket_result_count, 0, Qt.AlignVCenter)
        ticket_box.addLayout(ticket_head)
        ticket_search_frame = QFrame(objectName="ticketSearchFrame")
        ticket_search_row = QHBoxLayout(ticket_search_frame)
        ticket_search_row.setContentsMargins(12, 5, 12, 5)
        search_glyph = QLabel()
        search_glyph.setPixmap(modern_icon("search", "#258DC2", 18).pixmap(18, 18))
        ticket_search_row.addWidget(search_glyph)
        self.ticket_search = QLineEdit()
        self.ticket_search.setMinimumWidth(0)
        self.ticket_search.setObjectName("ticketSearchInput")
        self.ticket_search.setPlaceholderText("Buscar número, título, usuário, fila, categoria ou conteúdo…")
        self.ticket_search.setClearButtonEnabled(True)
        self.ticket_search.returnPressed.connect(self.search_tickets)
        ticket_search_row.addWidget(self.ticket_search, 1)
        self.ticket_search_button = QPushButton("Pesquisar")
        self.ticket_search_button.setObjectName("ticketSearchButton")
        self.ticket_search_button.setToolTip("Pesquisar em todos os chamados preservados no cache local")
        set_button_icon(self.ticket_search_button, "search", "#FFFFFF", 15)
        self.ticket_search_button.clicked.connect(self.search_tickets)
        ticket_search_row.addWidget(self.ticket_search_button)
        self.ticket_search_frame = ticket_search_frame
        ticket_box.addWidget(self.ticket_search_frame)

        self.ticket_scope = QComboBox()
        self.ticket_scope.addItem("Meus chamados")
        self.ticket_user = QLineEdit()
        self.ticket_user.setEnabled(False)
        self.ticket_from = QDateEdit(QDate.currentDate().addDays(-1))
        self.ticket_to = QDateEdit(QDate.currentDate())

        self.ticket_status_frame = QFrame(objectName="ticketStatusPanel")
        status_row = QHBoxLayout(self.ticket_status_frame)
        status_row.setContentsMargins(10, 8, 10, 8)
        status_row.setSpacing(8)
        status_title = QLabel("FILTRAR RESULTADOS")
        self.ticket_status_title = status_title
        status_title.setObjectName("ticketSectionLabel")
        status_row.addWidget(status_title)
        self.ticket_status_combo = NoWheelComboBox()
        self.ticket_status_combo.setToolTip("Selecione a situação pelo clique; a roda do mouse apenas rola a página")
        self.ticket_status_combo.addItems([
            "", "Todos", "Abertos", "Pendentes", "Fechados com êxito",
            "Rejeitada", "Cancelado pelo cliente", "Fechado sem êxito",
        ])
        self.ticket_status_combo.setCurrentIndex(3)
        self.ticket_status_combo.setAccessibleName("Filtro de situação dos chamados")
        status_row.addWidget(self.ticket_status_combo, 1)
        self.ticket_filter_button = QPushButton("Filtrar")
        self.ticket_filter_button.setObjectName("ticketFilterButton")
        self.ticket_filter_button.setToolTip("Aplicar somente a situação selecionada")
        set_button_icon(self.ticket_filter_button, "filter", "#FFFFFF", 15)
        self.ticket_filter_button.clicked.connect(self.filter_tickets)
        status_row.addWidget(self.ticket_filter_button)
        self.ticket_local_period_button = QPushButton()
        self.ticket_local_period_button.setObjectName("ticketLocalPeriodButton")
        self.ticket_local_period_button.setFixedSize(36, 36)
        self.ticket_local_period_button.setToolTip("Filtrar por período nos chamados já mapeados")
        self.ticket_local_period_button.setAccessibleName("Escolher período dos chamados locais")
        set_button_icon(self.ticket_local_period_button, "time_filter", BLUE, 17)
        self.ticket_local_period_button.clicked.connect(self.open_local_ticket_period_dialog)
        status_row.addWidget(self.ticket_local_period_button)
        self.ticket_status_frame.hide()
        self.ticket_search_frame.hide()
        ticket_box.addWidget(self.ticket_status_frame)

        self.ticket_render_progress = QFrame(objectName="ticketRenderProgress")
        ticket_progress_box = QVBoxLayout(self.ticket_render_progress)
        ticket_progress_box.setContentsMargins(11, 8, 11, 9)
        ticket_progress_box.setSpacing(6)
        self.ticket_render_progress_label = QLabel("Organizando todos os chamados…")
        self.ticket_render_progress_label.setObjectName("ticketRenderProgressLabel")
        self.ticket_render_progress_label.setWordWrap(True)
        ticket_progress_box.addWidget(self.ticket_render_progress_label)
        self.ticket_render_progress_bar = QProgressBar()
        self.ticket_render_progress_bar.setObjectName("ticketRenderProgressBar")
        self.ticket_render_progress_bar.setRange(0, 0)
        self.ticket_render_progress_bar.setTextVisible(False)
        self.ticket_render_progress_bar.setFixedHeight(7)
        ticket_progress_box.addWidget(self.ticket_render_progress_bar)
        self.ticket_render_progress.hide()

        ticket_actions = QGridLayout()
        self.ticket_actions_layout = ticket_actions
        ticket_actions.setSpacing(9)
        self.ticket_map_button = QPushButton("Escolher período e mapear")
        self.ticket_map_button.setObjectName("primaryButton")
        set_button_icon(self.ticket_map_button, "calendar", "#FFFFFF", 16)
        self.ticket_map_button.clicked.connect(self.open_ticket_period_dialog)
        ticket_actions.addWidget(self.ticket_map_button, 0, 1, Qt.AlignCenter)
        self.ticket_query_button = self.ticket_map_button
        self.ticket_map_button.setMinimumWidth(220)
        self.ticket_map_button.setMaximumWidth(330)
        self.ticket_map_button.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        ticket_actions.setColumnStretch(0, 1)
        ticket_actions.setColumnStretch(2, 1)
        ticket_box.addLayout(ticket_actions)
        self.ticket_filter_frame.hide()
        page.addWidget(self.ticket_filter_frame)
        page.addWidget(self.ticket_render_progress)

        self.actions_host = QWidget(objectName="actionsHost")
        self.actions_host.setMinimumWidth(0)
        self.action_grid = QGridLayout()
        # A grade pode conter centenas de chamados: seu mínimo precisa chegar
        # até a área de rolagem para que as linhas não sejam comprimidas.
        self.action_grid.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        self.action_grid.setContentsMargins(0, 0, 0, 0)
        self.action_grid.setHorizontalSpacing(14)
        self.action_grid.setVerticalSpacing(14)
        self.actions_host.setLayout(self.action_grid)
        self.actions_opacity = QGraphicsOpacityEffect(self.actions_host)
        self.actions_opacity.setOpacity(1.0)
        self.actions_host.setGraphicsEffect(self.actions_opacity)
        self.fade_animation = QPropertyAnimation(self.actions_opacity, b"opacity", self)
        self.fade_animation.setDuration(110)
        self.fade_animation.setEasingCurve(QEasingCurve.OutQuart)
        self.cards = []
        for action in ACTIONS:
            card = ActionCard(action)
            card.triggered.connect(self.execute_action)
            self.cards.append((action, card))
        page.addWidget(self.actions_host)

        terminal_header = QHBoxLayout()
        terminal_header.addWidget(QLabel("Console de atividades"))
        terminal_header.addStretch()
        clear = QPushButton("Limpar histórico")
        clear.setObjectName("linkButton")
        clear.clicked.connect(lambda: self.log.clear())
        terminal_header.addWidget(clear)
        page.addLayout(terminal_header)
        self.log = QTextEdit()
        self.log.setObjectName("terminal")
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(180)
        self.log.setText("Sistema pronto. Selecione uma estação para iniciar.\n")
        page.addWidget(self.log)
        self.page_developer_footer = QLabel(
            "Software desenvolvido por "
            '<a style="text-decoration:none;" href="https://www.linkedin.com/in/alemagnobr/">Alexandre Linhares</a> e '
            '<a style="text-decoration:none;" href="https://www.linkedin.com/in/joaocerq/">João Cerqueira</a>'
        )
        self.page_developer_footer.setObjectName("pageDeveloperFooter")
        self.page_developer_footer.setTextFormat(Qt.RichText)
        self.page_developer_footer.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self.page_developer_footer.setOpenExternalLinks(False)
        self.page_developer_footer.setWordWrap(True)
        self.page_developer_footer.setAlignment(Qt.AlignCenter)
        self.page_developer_footer.setAccessibleName("Créditos de desenvolvimento do Atlas")
        self.page_developer_footer.linkActivated.connect(self.open_external_link)
        page.addSpacing(4)
        page.addWidget(self.page_developer_footer)
        scroll.setWidget(content)
        self.scroll = scroll
        root.addWidget(scroll, 1)
        self.apply_filter("Menu principal")
        self.reflow(1)
        # O tamanho final só existe após o painel entrar na janela principal.
        # Refazer o fluxo nesse momento impede que as abas herdem a largura da
        # tela anterior e elimina o corte inicial de "Controle de usuários".
        QTimer.singleShot(0, self._finalize_initial_control_layout)

    def _finalize_initial_control_layout(self):
        self.current_columns = 0
        self.control_tabs.setMinimumWidth(0)
        self.control_tabs.tabBar().updateGeometry()
        self.control_tabs.tabBar().update()
        self.reflow()

    def section_actions(self):
        if self.current_section in {"Softwares autorizados", "FAQs", "Orientações ao usuário", "Chamados"}:
            return []
        allowed = [(a, c) for a, c in self.cards if self.profile == "ins" or not a.admin_only]
        if self.current_section == "Menu principal":
            featured = {
                "ins": {
                    "dns", "gpupdate", "install_printer", "ad_groups",
                },
                "standard": {
                    "inetcpl",
                },
            }
            return [(a, c) for a, c in allowed if a.command in featured[self.profile]]
        if self.current_section == "Impressoras":
            # A grade de duas colunas usa pares consecutivos na mesma linha.
            order = (
                "install_printer", "remove_printer",
                "set_default_printer", "test_print",
                "install_hp_driver", "remove_hp_driver",
                "spooler",
            )
            by_command = {action.command: (action, card) for action, card in allowed}
            return [by_command[command] for command in order if command in by_command]
        if self.current_section == "Suporte remoto":
            remote_computer = {"outlook", "dns", "gpupdate", "temp", "trellix_config", "atlas_repair", "cert_list", "remote_process_list", "user_software_list", "browser_open_chrome_cleanup", "browser_open_edge_cleanup", "browser_close_chrome", "browser_close_edge", "logoff", "restart"}
            return [(a, c) for a, c in allowed if a.command in remote_computer]
        return allowed

    def request_section_access(self, section: str):
        """Protege Chamados com uma autenticação do Capri válida somente nesta execução."""
        if section in {"Chamados", "FAQs"} and not self._capri_session_password:
            if section == "FAQs":
                self.open_capri_login(True, False, False, True)
            else:
                self.open_capri_login(False, True, True)
            return
        self.apply_filter(section)

    def clear_faq_cache(self):
        if not confirm_action(
            self, "Limpar cache de FAQs",
            "Deseja apagar o catálogo local de FAQs? O conteúdo poderá ser mapeado novamente pelo Capri.",
        ):
            return
        try:
            faq_cache_path().unlink(missing_ok=True)
        except OSError as error:
            show_notice(self, f"Não foi possível limpar o cache de FAQs: {error}")
            return
        self.faq_catalog = {}
        self.faq_expanded_roots.clear()
        self.faq_expanded_categories.clear()
        self.faq_search_cache.clear()
        self.rebuild_local_search_indexes()
        self.update_faq_suggestions()
        self.append_log("\n[FAQ] Cache local removido pelo operador.\n")
        self.current_columns = 0
        self.reflow()

    def clear_ticket_cache(self):
        if self.ticket_loading:
            show_notice(self, "Aguarde a consulta atual terminar antes de limpar o cache.")
            return
        if not confirm_action(
            self, "Limpar cache de chamados",
            "Deseja apagar os chamados armazenados localmente? A sessão do Capri permanecerá ativa.",
        ):
            return
        try:
            ticket_cache_path().unlink(missing_ok=True)
        except OSError as error:
            show_notice(self, f"Não foi possível limpar o cache de chamados: {error}")
            return
        self.ticket_catalog = {}
        self.ticket_search_cache.clear()
        self.ticket_search_text = ""
        self.ticket_search.clear()
        self.append_log("\n[CHAMADOS] Cache local removido pelo operador.\n")
        self.current_columns = 0
        self.reflow()

    def apply_filter(self, section: str):
        previous_section = self.current_section
        entering_tickets = section == "Chamados" and previous_section != "Chamados"
        entering_faqs = section == "FAQs" and previous_section != "FAQs"
        self.current_section = section
        # Um efeito gráfico no contêiner inteiro criaria uma imagem de dezenas
        # de milhares de pixels quando Todos mostra o catálogo completo.
        self.fade_animation.stop()
        self.actions_opacity.setOpacity(1.0)
        self.actions_opacity.setEnabled(section != "Chamados")
        if section == "Menu principal":
            self.section_title.setText("Informações e ações frequentes")
            profile_name = "INS" if self.profile == "ins" else "padrão"
            self.section_description.setText(
                f"Comandos mais utilizados no perfil {profile_name}. O resumo da estação fica concentrado nesta página."
            )
        elif section == "Softwares autorizados":
            self.section_title.setText("Softwares autorizados")
            self.section_description.setText(
                "Catálogo do drive X: disponível para o usuário conectado, organizado automaticamente por finalidade."
            )
        elif section == "FAQs":
            self.section_title.setText("FAQs — Central de conhecimento")
            count = int(self.faq_catalog.get("count", 0) or 0)
            updated = str(self.faq_catalog.get("updated_at", "")).replace("T", " ")
            if count:
                suffix = f" • mapeado em {updated}" if updated else ""
                self.section_description.setText(
                    f"{count} FAQs salvas localmente, com orientações incorporadas e organizadas por categoria, ferramenta e procedimento{suffix}."
                )
            else:
                self.section_description.setText(
                    "Nenhum catálogo salvo. Use o botão de mapear para consultar todas as FAQs do Capri."
                )
        elif section == "Chamados":
            self.ticket_status_combo.blockSignals(True)
            self.ticket_status_combo.setCurrentIndex(3)
            self.ticket_status_combo.blockSignals(False)
            self.ticket_status_index = 3
            self.ticket_period = "all"
            self.ticket_local_period_active = False
            self.update_local_ticket_period_button()
            self.ticket_search.blockSignals(True)
            self.ticket_search.clear()
            self.ticket_search.blockSignals(False)
            self.ticket_search_text = ""
            count = int(self.ticket_catalog.get("count", 0) or 0)
            updated = str(self.ticket_catalog.get("updated_at", "")).replace("T", " ")
            self.section_title.setText("Chamados — Atendimento no Capri")
            self.section_description.setText(
                f"{count} chamados preservados no cache local{f' • atualizado em {updated}' if updated else ''}. "
                "Filtros e pesquisa não consultam o Capri; use os botões somente quando desejar atualizar a base."
                if count else "Nenhum chamado mapeado. Acesse o Capri e escolha o período da consulta."
            )
        elif section == "Orientações ao usuário":
            count = int(self.orientation_catalog.get("count", 0) or 0)
            sources = int(self.orientation_catalog.get("source_faq_count", 0) or 0)
            self.section_title.setText("Orientações ao usuário")
            self.section_description.setText(
                f"{count} orientações extraídas de {sources} FAQs e preservadas localmente para pesquisa rápida."
                if count else "Nenhuma orientação mapeada. Clique em atualizar para analisar as FAQs e salvar somente orientações apropriadas ao usuário."
            )
        else:
            self.section_title.setText(section)
            self.section_description.setText(
                "Todos os comandos desta categoria, organizados para acesso rápido durante o atendimento."
            )
        user_mode = self.control_tabs.currentIndex() == 1
        self.update_information_cards_visibility()
        self.printer_summary.setVisible(section == "Impressoras")
        self.software_search_frame.setVisible(section == "Softwares autorizados")
        self.faq_search_frame.setVisible(section == "FAQs")
        self.faq_specific_frame.setVisible(False)
        self.ticket_filter_frame.setVisible(section == "Chamados")
        self.orientation_search_frame.setVisible(section == "Orientações ao usuário")
        self.specific_orientation_frame.setVisible(section == "Orientações ao usuário")
        if section != "Chamados":
            self.ticket_entry_render_generation += 1
            self.ticket_entry_render_pending = False
            self.ticket_render_progress.hide()
            self.set_ticket_filter_controls_enabled(True)
        # Somente os dois botões que mudam de estado precisam de repolimento.
        for name in {previous_section, section}:
            button = self.nav_buttons.get(name)
            if button is None:
                continue
            button.setObjectName("navActive" if name == section else "navItem")
            button.style().unpolish(button)
            button.style().polish(button)
        self.animate_navigation_selection(previous_section, section)
        self.current_columns = 0
        if entering_tickets and bool(self.ticket_catalog.get("items")):
            self.begin_ticket_render("Organizando todos os chamados…")
        else:
            self.reflow()
        if entering_faqs:
            self.request_faq_catalog()
        QTimer.singleShot(0, self.reset_horizontal_scroll)
        self.animate_category()
        if section == "Softwares autorizados" and not self.software_catalog and not self.software_loading:
            QTimer.singleShot(0, self.request_authorized_software)
        # O catálogo do Capri é carregado somente pelo botão de mapeamento.
        # Ao abrir a seção, usa exclusivamente a cópia persistente disponível.

    def set_ticket_filter_controls_enabled(self, enabled: bool):
        for control_name in ("ticket_search", "ticket_status_combo", "ticket_search_button", "ticket_filter_button", "ticket_local_period_button"):
            control = getattr(self, control_name, None)
            if control is not None:
                control.setEnabled(enabled)

    def begin_ticket_render(self, message: str):
        self.ticket_entry_render_generation += 1
        render_generation = self.ticket_entry_render_generation
        self.ticket_entry_render_pending = True
        self.ticket_render_progress_label.setText(message)
        self.ticket_render_progress.show()
        self.set_ticket_filter_controls_enabled(False)
        self.clear_grid()
        QTimer.singleShot(
            90,
            lambda generation=render_generation: self.finish_ticket_entry_render(generation),
        )

    def finish_ticket_entry_render(self, generation: int):
        if generation != self.ticket_entry_render_generation:
            return
        if not self.ticket_entry_render_pending or self.current_section != "Chamados":
            self.ticket_entry_render_pending = False
            self.ticket_render_progress.hide()
            self.set_ticket_filter_controls_enabled(True)
            return
        self.ticket_entry_render_pending = False
        self.current_columns = 0
        self.reflow()
        QTimer.singleShot(
            80,
            lambda current_generation=generation: self.finish_ticket_render_progress(current_generation),
        )

    def finish_ticket_render_progress(self, generation: int):
        if generation != self.ticket_entry_render_generation:
            return
        self.ticket_entry_render_pending = False
        self.ticket_render_progress.hide()
        self.set_ticket_filter_controls_enabled(True)

    def animate_navigation_selection(self, previous: str, current: str):
        """Faz o seletor trocar de campo com entrada e saída suaves."""
        if self.nav_transition:
            self.nav_transition.stop()
        for button, effect in self.nav_transition_effects:
            effect.setOpacity(1.0)
            button.setGraphicsEffect(None)
        self.nav_transition_effects = []

        incoming = self.nav_buttons.get(current)
        outgoing = self.nav_buttons.get(previous) if previous != current else None
        group = QParallelAnimationGroup(self)

        if outgoing:
            old_effect = QGraphicsOpacityEffect(outgoing)
            old_effect.setOpacity(1.0)
            outgoing.setGraphicsEffect(old_effect)
            old_animation = QPropertyAnimation(old_effect, b"opacity", group)
            old_animation.setDuration(105)
            old_animation.setStartValue(1.0)
            old_animation.setKeyValueAt(0.55, 0.38)
            old_animation.setEndValue(1.0)
            old_animation.setEasingCurve(QEasingCurve.OutCubic)
            group.addAnimation(old_animation)
            self.nav_transition_effects.append((outgoing, old_effect))

        if incoming:
            new_effect = QGraphicsOpacityEffect(incoming)
            new_effect.setOpacity(0.18)
            incoming.setGraphicsEffect(new_effect)
            new_animation = QPropertyAnimation(new_effect, b"opacity", group)
            new_animation.setDuration(105)
            new_animation.setStartValue(0.18)
            new_animation.setEndValue(1.0)
            new_animation.setEasingCurve(QEasingCurve.OutCubic)
            group.addAnimation(new_animation)
            self.nav_transition_effects.append((incoming, new_effect))

        def finish_transition():
            for button, effect in self.nav_transition_effects:
                effect.setOpacity(1.0)
                button.setGraphicsEffect(None)
            self.nav_transition_effects = []

        group.finished.connect(finish_transition)
        self.nav_transition = group
        group.start()

    def animate_category(self):
        """Aplica uma entrada suave sem bloquear cliques ou a execução dos comandos."""
        self.fade_animation.stop()
        if self.actions_opacity.isEnabled():
            self.actions_opacity.setOpacity(0.35)
            self.fade_animation.setStartValue(0.35)
            self.fade_animation.setEndValue(1.0)
            self.fade_animation.start()
        self.heading_animation.stop()
        self.heading_opacity.setOpacity(0.45)
        self.heading_animation.setStartValue(0.45)
        self.heading_animation.setEndValue(1.0)
        self.heading_animation.start()
        self.description_animation.stop()
        self.description_opacity.setOpacity(0.40)
        self.description_animation.setStartValue(0.40)
        self.description_animation.setEndValue(1.0)
        self.description_animation.start()
        if self.status_card.isVisible():
            self.status_animation.stop()
            self.status_opacity.setOpacity(0.12)
            self.status_animation.setStartValue(0.12)
            self.status_animation.setEndValue(1.0)
            self.status_animation.start()

    def clear_grid(self):
        self.ticket_card_render_generation += 1
        self.ticket_card_render_queue = []
        while self.action_grid.count():
            item = self.action_grid.takeAt(0)
            if item.widget():
                if item.widget().property("groupHeader") or item.widget().property("softwareDynamic"):
                    item.widget().deleteLater()
                else:
                    item.widget().hide()

    def render_software_catalog(self, columns: int):
        """Renderiza categorias expansíveis e resultados instantâneos da busca."""
        viewport_width = self.scroll.viewport().width() if hasattr(self, "scroll") else self.width()
        catalog_columns = 1 if viewport_width < 760 else min(columns, 2)
        if self.software_loading:
            self.software_result_count.setText("Consultando…")
            notice = QLabel("Consultando o drive X: e organizando os executáveis autorizados…")
            notice.setObjectName("softwareNotice")
            notice.setProperty("softwareDynamic", True)
            notice.setWordWrap(True)
            self.action_grid.addWidget(notice, 0, 0, 1, catalog_columns)
            return
        raw_items = self.software_catalog.get("items") or []
        all_items = [raw_items] if isinstance(raw_items, dict) else list(raw_items)
        if not all_items:
            self.software_result_count.setText("0 softwares")
            notice = QLabel("Nenhum executável autorizado foi localizado no drive X: desta sessão.")
            notice.setObjectName("softwareNotice")
            notice.setProperty("softwareDynamic", True)
            notice.setWordWrap(True)
            self.action_grid.addWidget(notice, 0, 0, 1, catalog_columns)
            return
        query = self.normalize_software_search(self.software_search_text)
        if query:
            query_terms = query.split()
            items = []
            for software in all_items:
                searchable = self.normalize_software_search(" ".join(
                    str(software.get(key, "")) for key in ("name", "file", "folder", "path", "category")
                ))
                if all(term in searchable for term in query_terms):
                    items.append(software)
        else:
            items = all_items
        self.software_result_count.setText(f"{len(items)} de {len(all_items)}")
        if not items:
            notice = QLabel(f"Nenhum software corresponde a “{self.software_search_text}”. Continue digitando ou limpe a pesquisa.")
            notice.setObjectName("softwareNotice")
            notice.setProperty("softwareDynamic", True)
            notice.setWordWrap(True)
            self.action_grid.addWidget(notice, 0, 0, 1, catalog_columns)
            return
        categories = []
        for software in items:
            category = str(software.get("category") or "Outros softwares")
            if category not in categories:
                categories.append(category)
        preferred_order = [
            "Sistemas Corporativos", "Produtividade e Escritório", "Comunicação e Colaboração",
            "Navegadores e Internet", "Segurança e Acesso", "Suporte e Acesso Remoto",
            "Desenvolvimento", "Drivers e Hardware", "Compactação e Utilitários", "Outros softwares",
        ]
        categories.sort(key=lambda value: (preferred_order.index(value) if value in preferred_order else len(preferred_order), value))
        row = 0
        for category in categories:
            category_items = [item for item in items if str(item.get("category") or "Outros softwares") == category]
            expanded = bool(query) or category in self.software_expanded_categories
            header = SoftwareCategoryButton(category, len(category_items), expanded, self.actions_host)
            header.category_toggled.connect(self.toggle_software_category)
            self.action_grid.addWidget(header, row, 0, 1, catalog_columns)
            row += 1
            if not expanded:
                continue
            for index, software in enumerate(category_items):
                card = AuthorizedSoftwareCard(software, self.actions_host)
                card.launch_requested.connect(self.launch_authorized_software)
                self.action_grid.addWidget(card, row + index // catalog_columns, index % catalog_columns)
            row += (len(category_items) + catalog_columns - 1) // catalog_columns

    @staticmethod
    def normalize_software_search(value: str) -> str:
        normalized = unicodedata.normalize("NFKD", str(value or ""))
        normalized = "".join(char for char in normalized if not unicodedata.combining(char)).casefold()
        return re.sub(r"\s+", " ", normalized).strip()

    @classmethod
    def prepare_search_entry(cls, item: dict, text: str, title: str = ""):
        normalized = cls.normalize_software_search(text)
        tokens = frozenset(re.findall(r"[a-z0-9]{2,}", normalized))
        return item, normalized, tokens, cls.normalize_software_search(title)

    def rebuild_local_search_indexes(self):
        """Cria índices imutáveis; pesquisar não relê JSON, TXT, Capri ou rede."""
        procedure_texts = load_bundled_faq_search_texts()
        raw_faqs = self.faq_catalog.get("items") or []
        faqs = [raw_faqs] if isinstance(raw_faqs, dict) else list(raw_faqs)
        self.faq_search_index = []
        for faq in faqs:
            faq_id = normalize_faq_number(faq.get("id"))
            orientation_text = " ".join(
                str(item.get(key, ""))
                for item in self.orientation_by_faq.get(faq_id, [])
                for key in ("guidance", "path", "contact")
            )
            text = " ".join([
                faq_id,
                *(str(faq.get(key, "")) for key in (
                    "id", "title", "tool", "procedure", "knowledge_category",
                    "knowledge_subcategory", "knowledge_procedure", "original_category",
                )),
                procedure_texts.get(faq_id, ""),
                orientation_text,
            ])
            self.faq_search_index.append(self.prepare_search_entry(faq, text, str(faq.get("title", ""))))

        raw_orientations = self.orientation_catalog.get("items") or []
        orientations = [raw_orientations] if isinstance(raw_orientations, dict) else list(raw_orientations)
        self.orientation_search_index = []
        for orientation in orientations:
            text = str(orientation.get("search_text") or " ".join(
                str(orientation.get(key, "")) for key in (
                    "faq_number", "title", "category", "topic", "subject", "summary",
                    "path", "contact", "source_category", "service",
                )
            ))
            self.orientation_search_index.append(
                self.prepare_search_entry(orientation, text, str(orientation.get("title", "")))
            )
        self.faq_search_cache.clear()
        self.orientation_search_cache.clear()

    @staticmethod
    def _faq_term_variants(term: str) -> tuple[str, ...]:
        """Gera variações leves para a busca sem depender de serviços externos."""
        aliases = {
            "imprimir": ("impressora", "impressao", "imprimir"),
            "impressao": ("impressora", "imprimir", "impressao"),
            "impressora": ("impressora", "impressao", "imprimir"),
            "senha": ("senha", "password", "credencial", "acesso"),
            "login": ("login", "acesso", "autenticacao", "entrar"),
            "acesso": ("acesso", "login", "autenticacao"),
            "certificado": ("certificado", "certificacao", "token"),
            "internet": ("internet", "rede", "navegacao", "proxy"),
            "rede": ("rede", "internet", "conexao"),
            "email": ("email", "e-mail", "outlook", "correio"),
            "outlook": ("outlook", "email", "correio"),
            "vpn": ("vpn", "remoto", "acesso"),
            "wifi": ("wifi", "wireless", "wi-fi", "rede"),
            "wireless": ("wireless", "wifi", "wi-fi", "rede"),
            "bloqueado": ("bloqueado", "bloqueio", "desbloquear"),
            "desbloquear": ("desbloquear", "bloqueado", "bloqueio"),
            "instalar": ("instalar", "instalacao", "configurar"),
            "instalacao": ("instalacao", "instalar", "configurar"),
            "configurar": ("configurar", "configuracao", "instalar"),
            "erro": ("erro", "falha", "problema"),
            "falha": ("falha", "erro", "problema"),
        }
        variants = [term]
        variants.extend(aliases.get(term, ()))
        # Singular/plural e terminações comuns ajudam quando o usuário lembra só parte do termo.
        if len(term) >= 5:
            if term.endswith("s"):
                variants.append(term[:-1])
            else:
                variants.append(term + "s")
        return tuple(dict.fromkeys(value for value in variants if value))

    @classmethod
    def fuzzy_term_score(cls, term: str, searchable: str, tokens: frozenset[str]) -> float | None:
        best_score = None
        for variant in cls._faq_term_variants(term):
            if variant in searchable:
                score = 3.2 + min(1.2, len(variant) / 10)
                best_score = max(best_score or 0.0, score)
                continue
            # Prefixos tornam a busca útil antes mesmo de terminar de digitar a palavra.
            if len(variant) >= 3:
                prefix_hits = [token for token in tokens if token.startswith(variant) or variant.startswith(token)]
                if prefix_hits:
                    score = 2.2 + min(0.9, len(variant) / 12)
                    best_score = max(best_score or 0.0, score)
            if len(variant) < 4:
                continue
            candidates = (
                token for token in tokens
                if abs(len(token) - len(variant)) <= 3 and token[:1] == variant[:1]
            )
            best_ratio = 0.0
            for token in candidates:
                ratio = difflib.SequenceMatcher(None, variant, token, autojunk=False).ratio()
                if ratio > best_ratio:
                    best_ratio = ratio
                if best_ratio >= 0.94:
                    break
            threshold = 0.72 if len(variant) >= 7 else 0.77
            if best_ratio >= threshold:
                best_score = max(best_score or 0.0, 1.0 + best_ratio)
        return best_score

    def ranked_catalog_search(self, index, query: str, cache: dict, limit: int = 48,
                              title_only: bool = False):
        if not query:
            return [entry[0] for entry in index], len(index)
        cache_key = ("title" if title_only else "related", query)
        cached = cache.get(cache_key)
        if cached is None:
            ranked = []
            for item, searchable, tokens, title in index:
                if title_only:
                    pattern = rf"(?<![a-z0-9]){re.escape(query)}(?![a-z0-9])"
                    title_match = re.search(pattern, title)
                    item_number = normalize_faq_number(item.get("id"))
                    number_match = query.isdigit() and query == item_number
                    if not title_match and not number_match:
                        continue
                    score = 8.0 if title_match else 7.0
                    ranked.append((score, title, item))
                    continue

                terms = [term for term in query.split() if len(term) >= 2 or term.isdigit()]
                if not terms:
                    continue
                score = 0.0
                matched_terms = 0
                title_hits = 0
                for term in terms:
                    term_score = self.fuzzy_term_score(term, searchable, tokens)
                    if term_score is None:
                        continue
                    matched_terms += 1
                    score += term_score
                    if term in title:
                        title_hits += 1
                        score += 3.2
                    elif any(token.startswith(term) for token in tokens):
                        score += 1.0

                # Não exige mais que TODAS as palavras coincidam. Isso permite buscar
                # "certificado chrome erro" e ainda encontrar a FAQ correta mesmo
                # que um dos termos não exista literalmente no texto.
                required = 1 if len(terms) <= 2 else max(1, (len(terms) + 1) // 2)
                if matched_terms < required:
                    continue
                coverage = matched_terms / len(terms)
                score += coverage * 4.0 + title_hits * 0.8
                if matched_terms == len(terms):
                    score += 3.5
                if query in searchable:
                    score += 4.5
                ranked.append((score, title, item))
            ranked.sort(key=lambda value: (-value[0], value[1]))
            cached = [value[2] for value in ranked]
            if len(cache) >= 60:
                cache.clear()
            cache[cache_key] = cached
        return cached[:limit], len(cached)

    def filter_authorized_software(self, text: str):
        self.software_search_text = text
        if self.current_section == "Softwares autorizados":
            self.current_columns = 0
            self.reflow()

    def toggle_software_category(self, category: str):
        if self.software_search_text:
            self.software_search.blockSignals(True)
            self.software_search.clear()
            self.software_search.blockSignals(False)
            self.software_search_text = ""
            self.software_expanded_categories.add(category)
        elif category in self.software_expanded_categories:
            self.software_expanded_categories.remove(category)
        else:
            self.software_expanded_categories.add(category)
        self.current_columns = 0
        self.reflow()

    def update_software_suggestions(self):
        raw_items = self.software_catalog.get("items") or []
        items = [raw_items] if isinstance(raw_items, dict) else list(raw_items)
        suggestions = []
        for software in items:
            value = str(software.get("name") or software.get("file") or "").strip()
            if value and value not in suggestions:
                suggestions.append(value)
        suggestions.sort(key=str.casefold)
        self.software_suggestion_model.setStringList(suggestions)

    def render_faq_catalog(self, columns: int):
        viewport_width = self.scroll.viewport().width() if hasattr(self, "scroll") else self.width()
        catalog_columns = 1 if viewport_width < 820 else min(columns, 2)
        if self.faq_loading:
            self.faq_result_count.setText("Mapeando…")
            notice = QFrame(objectName="faqMappingProgress")
            notice.setProperty("softwareDynamic", True)
            notice_box = QVBoxLayout(notice)
            notice_box.setContentsMargins(18, 14, 18, 14)
            notice_box.setSpacing(8)
            notice_text = QLabel("Mapeando o Capri e organizando todas as FAQs por categoria, ferramenta e procedimento…")
            notice_text.setObjectName("faqMappingProgressText")
            notice_text.setWordWrap(True)
            notice_box.addWidget(notice_text)
            progress_header = QHBoxLayout()
            progress_label = QLabel("Andamento do mapeamento")
            progress_label.setObjectName("faqMappingProgressLabel")
            progress_header.addWidget(progress_label)
            progress_header.addStretch(1)
            self.faq_mapping_progress_percent = QLabel(f"{getattr(self, 'faq_mapping_progress_value', 0)}%")
            self.faq_mapping_progress_percent.setObjectName("faqMappingProgressPercent")
            progress_header.addWidget(self.faq_mapping_progress_percent)
            notice_box.addLayout(progress_header)
            self.faq_mapping_progress_bar = QProgressBar()
            self.faq_mapping_progress_bar.setObjectName("faqMappingProgressBar")
            self.faq_mapping_progress_bar.setRange(0, 100)
            self.faq_mapping_progress_bar.setValue(getattr(self, "faq_mapping_progress_value", 0))
            self.faq_mapping_progress_bar.setTextVisible(False)
            self.faq_mapping_progress_bar.setFixedHeight(8)
            notice_box.addWidget(self.faq_mapping_progress_bar)
            self.action_grid.addWidget(notice, 0, 0, 1, catalog_columns)
            return
        raw = self.faq_catalog.get("items") or []
        all_items = [raw] if isinstance(raw, dict) else list(raw)
        query = self.normalize_software_search(self.faq_search_text)
        if len(self.faq_search_index) != len(all_items):
            self.rebuild_local_search_indexes()
        items, matched_count = self.ranked_catalog_search(
            self.faq_search_index, query, self.faq_search_cache,
            title_only=self.faq_title_search,
        )
        if query and self.faq_title_search:
            count_text = (f"{matched_count} no título • {len(items)} exibidos"
                          if matched_count > len(items) else f"{matched_count} no título")
        else:
            count_text = (f"{matched_count} encontrados • {len(items)} exibidos"
                          if query and matched_count > len(items) else f"{matched_count} de {len(all_items)}")
        self.faq_result_count.setText(count_text)
        self.faq_result_count.setToolTip(
            "Modo: somente no título ou número exato" if self.faq_title_search else "Modo: pesquisa relacionada"
        )
        if not items:
            message = (f"Nenhuma FAQ corresponde a “{self.faq_search_text}”." if query
                       else "Nenhum catálogo salvo. Clique no botão de mapear para consultar todas as FAQs do Capri.")
            notice = QLabel(message)
            notice.setObjectName("softwareNotice")
            notice.setProperty("softwareDynamic", True)
            notice.setWordWrap(True)
            self.action_grid.addWidget(notice, 0, 0, 1, catalog_columns)
            return
        # Estrutura o catálogo em uma única passagem. Além de ser mais rápido,
        # isso separa claramente categoria, ferramenta/assunto e procedimento.
        hierarchy = {}
        for faq in items:
            major = str(faq.get("knowledge_category") or "Outros assuntos").strip()
            subcategory = str(faq.get("knowledge_subcategory") or faq.get("tool") or "Orientações gerais").strip()
            procedure = str(faq.get("knowledge_procedure") or faq.get("procedure") or "Orientações gerais").strip()
            hierarchy.setdefault(major, {}).setdefault(subcategory, {}).setdefault(procedure, []).append(faq)
        favorite_ids = self.faq_favorite_ids()
        row = 0
        for major in sorted(hierarchy, key=str.casefold):
            subcategories = hierarchy[major]
            major_total = sum(len(faqs) for procedures in subcategories.values() for faqs in procedures.values())
            root_expanded = bool(query) or major in self.faq_expanded_roots
            major_header = FaqRootCategoryButton(major, major_total, root_expanded, self.actions_host)
            major_header.root_toggled.connect(self.toggle_faq_root)
            self.action_grid.addWidget(major_header, row, 0, 1, catalog_columns)
            row += 1
            if not root_expanded:
                continue
            for subcategory in sorted(subcategories, key=str.casefold):
                procedures = subcategories[subcategory]
                sub_total = sum(len(faqs) for faqs in procedures.values())
                branch_key = f"{major}  ›  {subcategory}"
                expanded = bool(query) or branch_key in self.faq_expanded_categories
                header = FaqCategoryButton(branch_key, sub_total, expanded, self.actions_host)
                header.setText(f"{subcategory}   •   {sub_total} FAQ{'s' if sub_total != 1 else ''}")
                header.category_toggled.connect(self.toggle_faq_category)
                self.action_grid.addWidget(header, row, 0, 1, catalog_columns)
                row += 1
                if not expanded:
                    continue
                for procedure in sorted(procedures, key=str.casefold):
                    procedure_items = sorted(
                        procedures[procedure],
                        key=lambda faq: (str(faq.get("title", "")).casefold(), str(faq.get("id", ""))),
                    )
                    procedure_header = QLabel(f"{procedure.upper()}   •   {len(procedure_items)}")
                    procedure_header.setObjectName("faqProcedureHeader")
                    procedure_header.setProperty("softwareDynamic", True)
                    self.action_grid.addWidget(procedure_header, row, 0, 1, catalog_columns)
                    row += 1
                    for index, faq in enumerate(procedure_items):
                        faq_id = normalize_faq_number(faq.get("id"))
                        orientations = self.orientation_by_faq.get(faq_id, [])
                        card = FaqCard(
                            faq, orientations, faq_id in favorite_ids, self.actions_host,
                        )
                        card.open_requested.connect(self.open_faq)
                        card.orientation_requested.connect(self.review_user_orientation)
                        card.favorite_requested.connect(self.toggle_faq_favorite)
                        self.action_grid.addWidget(card, row + index // catalog_columns, index % catalog_columns)
                    row += (len(procedure_items) + catalog_columns - 1) // catalog_columns

    def filter_faqs(self, text: str):
        self.faq_search_text = text
        self.faq_search_timer.start()

    def set_faq_search_mode(self, title_only: bool):
        self.faq_title_search = bool(title_only)
        self.faq_related_search_button.setChecked(not self.faq_title_search)
        self.faq_title_search_button.setChecked(self.faq_title_search)
        if self.current_section == "FAQs":
            self.faq_search_timer.start()

    def render_orientation_catalog(self, columns: int):
        viewport_width = self.scroll.viewport().width() if hasattr(self, "scroll") else self.width()
        catalog_columns = 1 if viewport_width < 900 else min(columns, 2)
        raw = self.orientation_catalog.get("items") or []
        all_items = [raw] if isinstance(raw, dict) else list(raw)
        query = self.normalize_software_search(self.orientation_search_text)
        if len(self.orientation_search_index) != len(all_items):
            self.rebuild_local_search_indexes()
        items, matched_count = self.ranked_catalog_search(
            self.orientation_search_index, query, self.orientation_search_cache,
        )
        self.orientation_result_count.setText(
            f"{matched_count} encontrados • {len(items)} exibidos"
            if query and matched_count > len(items) else f"{matched_count} de {len(all_items)}"
        )
        if not items:
            message = (f"Nenhuma orientação corresponde a “{self.orientation_search_text}”."
                       if query else "Nenhuma orientação foi encontrada no catálogo local.")
            notice = QLabel(message)
            notice.setObjectName("softwareNotice")
            notice.setProperty("softwareDynamic", True)
            notice.setWordWrap(True)
            self.action_grid.addWidget(notice, 0, 0, 1, catalog_columns)
            return
        hierarchy = {}
        for item in items:
            category = str(item.get("category") or "Outras orientações").strip()
            topic = str(item.get("topic") or "Procedimentos").strip()
            hierarchy.setdefault(category, {}).setdefault(topic, []).append(item)
        row = 0
        for category in sorted(hierarchy, key=str.casefold):
            topics = hierarchy[category]
            total = sum(len(values) for values in topics.values())
            expanded = bool(query) or category in self.orientation_expanded_categories
            header = SoftwareCategoryButton(category, total, expanded, self.actions_host)
            header.setText(f"{category}   •   {total} orientação{'ões' if total != 1 else ''}")
            header.category_toggled.connect(self.toggle_orientation_category)
            self.action_grid.addWidget(header, row, 0, 1, catalog_columns)
            row += 1
            if not expanded:
                continue
            for topic in sorted(topics, key=str.casefold):
                topic_items = sorted(topics[topic], key=lambda value: (
                    str(value.get("title", "")).casefold(), str(value.get("faq_number", ""))
                ))
                topic_header = QLabel(f"{topic.upper()}   •   {len(topic_items)}")
                topic_header.setObjectName("orientationTopicHeader")
                topic_header.setProperty("softwareDynamic", True)
                self.action_grid.addWidget(topic_header, row, 0, 1, catalog_columns)
                row += 1
                for index, orientation in enumerate(topic_items):
                    card = UserOrientationCard(orientation, self.actions_host)
                    card.send_requested.connect(self.send_user_orientation)
                    self.action_grid.addWidget(card, row + index // catalog_columns, index % catalog_columns)
                row += (len(topic_items) + catalog_columns - 1) // catalog_columns

    def filter_orientations(self, text: str):
        self.orientation_search_text = text
        self.orientation_search_timer.start()

    def apply_orientation_search(self):
        if self.current_section == "Orientações ao usuário":
            self.current_columns = 0
            self.reflow()

    def toggle_orientation_category(self, category: str):
        if self.orientation_search_text:
            self.orientation_search.blockSignals(True)
            self.orientation_search.clear()
            self.orientation_search.blockSignals(False)
            self.orientation_search_text = ""
            self.orientation_expanded_categories.add(category)
        elif category in self.orientation_expanded_categories:
            self.orientation_expanded_categories.remove(category)
        else:
            self.orientation_expanded_categories.add(category)
        self.current_columns = 0
        self.reflow()

    def map_all_orientations(self):
        """Reconstrói e persiste as orientações usando a mesma base das FAQs."""
        source = bundled_orientation_catalog()
        items = list(source.get("items") or [])
        faq_ids = {
            normalize_faq_number(item.get("id"))
            for item in self.faq_catalog.get("items") or []
            if normalize_faq_number(item.get("id"))
        }
        if faq_ids:
            items = [item for item in items if normalize_faq_number(item.get("faq_number")) in faq_ids]
        overrides = load_json_cache(faq_content_overrides_path())
        for faq_id, record in overrides.items():
            official = normalize_faq_number(faq_id)
            items = [item for item in items if normalize_faq_number(item.get("faq_number")) != official]
            content = str(record.get("content", "")) if isinstance(record, dict) else str(record)
            mapped = map_specific_faq_orientation(official, content)
            if mapped and not mapped.get("unmappable"):
                if isinstance(record, dict) and record.get("title"):
                    mapped["title"] = str(record["title"])
                items.append(mapped)
        items.sort(key=lambda item: (
            str(item.get("category", "")).casefold(), str(item.get("topic", "")).casefold(),
            str(item.get("title", "")).casefold(), str(item.get("faq_number", "")),
        ))
        self.orientation_catalog = {
            "schema": 3, "source_faq_count": len(faq_ids) or int(source.get("source_faq_count", 697)),
            "count": len(items), "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"), "items": items,
        }
        save_json_cache(orientation_cache_path(), self.orientation_catalog)
        self.rebuild_orientation_lookup()
        self.orientation_expanded_categories.clear()
        self.rebuild_local_search_indexes()
        self.section_description.setText(
            f"{len(items)} orientações apropriadas ao usuário foram preservadas localmente."
        )
        if self.current_section == "Orientações ao usuário":
            self.current_columns = 0
            self.reflow()
        self.append_log(f"\n[ORIENTAÇÕES] {len(items)} orientações mapeadas e salvas localmente.\n")

    def remap_orientations_with_feedback(self):
        self.orientation_refresh_button.setEnabled(False)
        set_refresh_icon_busy(self.orientation_refresh_button, True)

        def rebuild():
            try:
                self.map_all_orientations()
            finally:
                set_refresh_icon_busy(self.orientation_refresh_button, False)
                self.orientation_refresh_button.setEnabled(True)

        QTimer.singleShot(34, rebuild)

    def rebuild_orientation_lookup(self):
        """Cria um índice O(1), aceitando várias orientações por FAQ."""
        preferences = self.orientation_preferences if isinstance(self.orientation_preferences, dict) else {}
        excluded = {normalize_faq_number(value) for value in preferences.get("excluded", [])}
        overrides = preferences.get("overrides", {}) if isinstance(preferences.get("overrides", {}), dict) else {}
        additional = preferences.get("additional", {}) if isinstance(preferences.get("additional", {}), dict) else {}
        lookup = {}
        for item in self.orientation_catalog.get("items") or []:
            faq_id = normalize_faq_number(item.get("faq_number"))
            if not faq_id or faq_id in excluded:
                continue
            merged = dict(item)
            merged["_orientation_kind"] = "base"
            merged["_orientation_id"] = "base"
            custom = overrides.get(faq_id)
            if isinstance(custom, dict):
                for key in ("orientation_title", "guidance", "path", "contact", "include_chief_notice"):
                    if key in custom:
                        merged[key] = custom[key] if key == "include_chief_notice" else str(custom.get(key) or "")
            lookup.setdefault(faq_id, []).append(merged)
        for faq_id_raw, custom_items in additional.items():
            faq_id = normalize_faq_number(faq_id_raw)
            if not faq_id or not isinstance(custom_items, list):
                continue
            for custom in custom_items:
                if not isinstance(custom, dict):
                    continue
                item = dict(custom)
                item["faq_number"] = faq_id
                item["_orientation_kind"] = "additional"
                item["_orientation_id"] = str(item.get("id") or "")
                lookup.setdefault(faq_id, []).append(item)
        self.orientation_by_faq = lookup

    def save_orientation_preferences(self):
        self.orientation_preferences["schema"] = 3
        self.orientation_preferences["updated_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        return save_json_cache(faq_orientation_preferences_path(), self.orientation_preferences)

    def review_user_orientation(self, bundle: dict):
        """Seleciona/cria uma orientação e sempre mostra a prévia antes do envio."""
        faq_id = normalize_faq_number(bundle.get("faq_id"))
        title = str(bundle.get("title") or "FAQ selecionada")
        orientations = list(self.orientation_by_faq.get(faq_id, []))
        chooser = OrientationChooserDialog(title, orientations, self)
        choice = chooser.exec()
        creating = choice == OrientationChooserDialog.NEW_ORIENTATION
        if choice == QDialog.Rejected:
            return
        orientation = {
            "faq_number": faq_id, "title": title, "orientation_title": "",
            "guidance": "", "path": "", "contact": "",
            "_orientation_kind": "additional", "_orientation_id": "",
        } if creating else chooser.selected_orientation()
        if not orientation:
            return
        dialog = OrientationPreviewDialog(orientation, self, allow_delete=not creating)
        result = dialog.exec()
        if result == OrientationPreviewDialog.DELETE_ORIENTATION:
            if not confirm_action(
                self, "Excluir orientação",
                f"Deseja remover somente a orientação vinculada à FAQ {faq_id}? A FAQ continuará disponível.",
            ):
                return
            kind = str(orientation.get("_orientation_kind") or "base")
            if kind == "base":
                excluded = {normalize_faq_number(value) for value in self.orientation_preferences.get("excluded", [])}
                excluded.add(faq_id)
                self.orientation_preferences["excluded"] = sorted(value for value in excluded if value)
                overrides = self.orientation_preferences.setdefault("overrides", {})
                if isinstance(overrides, dict):
                    overrides.pop(faq_id, None)
            else:
                orientation_id = str(orientation.get("_orientation_id") or orientation.get("id") or "")
                additional = self.orientation_preferences.setdefault("additional", {})
                current = additional.get(faq_id, []) if isinstance(additional, dict) else []
                additional[faq_id] = [item for item in current if str(item.get("id") or "") != orientation_id]
            self.save_orientation_preferences()
            self.rebuild_orientation_lookup()
            self.rebuild_local_search_indexes()
            self.current_columns = 0
            self.reflow()
            self.append_log(f"\n[ORIENTAÇÃO] Uma orientação da FAQ {faq_id} foi excluída do catálogo local.\n")
            return
        if result not in {QDialog.Accepted, OrientationPreviewDialog.SAVE_ONLY}:
            return
        values = dialog.values()
        edited = dict(orientation)
        edited.update(values)
        kind = str(orientation.get("_orientation_kind") or "additional")
        if creating or kind == "additional":
            additional = self.orientation_preferences.setdefault("additional", {})
            entries = additional.setdefault(faq_id, [])
            if not isinstance(entries, list):
                entries = []
                additional[faq_id] = entries
            orientation_id = str(orientation.get("_orientation_id") or orientation.get("id") or f"custom-{int(time.time() * 1000)}")
            record = {"id": orientation_id, "title": title, "faq_number": faq_id, **values}
            replaced = False
            for index, current in enumerate(entries):
                if str(current.get("id") or "") == orientation_id:
                    entries[index] = record
                    replaced = True
                    break
            if not replaced:
                entries.append(record)
            edited.update(record)
            edited["_orientation_kind"] = "additional"
            edited["_orientation_id"] = orientation_id
        else:
            overrides = self.orientation_preferences.setdefault("overrides", {})
            if isinstance(overrides, dict):
                overrides[faq_id] = dict(values)
        self.save_orientation_preferences()
        self.rebuild_orientation_lookup()
        self.rebuild_local_search_indexes()
        self.current_columns = 0
        self.reflow()
        if result == OrientationPreviewDialog.SAVE_ONLY:
            self.append_log(f"\n[ORIENTAÇÃO] Orientação da FAQ {faq_id} salva localmente.\n")
            show_notice(self, "Orientação salva. Ela continuará disponível nesta FAQ.")
            return
        self.send_user_orientation(edited, previewed=True)

    def request_single_faq_update(self, section: str):
        field = self.faq_specific_input if section == "FAQs" else self.specific_faq_input
        faq_number = normalize_faq_number(field.text())
        if not faq_number:
            show_notice(self, "Informe exatamente o número publicado no Capri.")
            field.setFocus()
            return
        faq = next((item for item in self.faq_catalog.get("items") or []
                    if normalize_faq_number(item.get("id")) == faq_number), {})
        url = str(faq.get("url") or "")
        if not url:
            show_notice(self, "Essa FAQ ainda não está no catálogo local. Remapeie o catálogo para descobrir seu endereço real no Capri.")
            return
        password = self._capri_session_password or credential_read(self.capri_username, "capri") or ""
        if not password:
            show_notice(self, "Autentique sua conta do Capri pelo cadeado antes de atualizar a FAQ.")
            self.open_capri_login()
            return
        self.pending_specific_section = section
        self.pending_specific_faq = faq_number
        set_refresh_icon_busy(
            self.faq_specific_button if section == "FAQs" else self.specific_faq_button,
            True,
        )
        payload = json.dumps({"id": faq_number, "url": url, "title": str(faq.get("title") or "")}, ensure_ascii=False)
        self.append_log(f"\n[FAQ] Atualizando somente a FAQ {faq_number} no Capri…\n")
        if self.run_bridge("faq_single", "", payload):
            self.faq_specific_button.setEnabled(False)
            self.specific_faq_button.setEnabled(False)
        else:
            set_refresh_icon_busy(self.faq_specific_button, False)
            set_refresh_icon_busy(self.specific_faq_button, False)

    def apply_single_faq_update(self, record: dict):
        global _FAQ_PROCEDURE_TEXT_CACHE
        faq_number = normalize_faq_number(record.get("id") or self.pending_specific_faq)
        if not faq_number or not str(record.get("content") or "").strip():
            return False
        overrides = load_json_cache(faq_content_overrides_path())
        overrides[faq_number] = record
        save_json_cache(faq_content_overrides_path(), overrides)
        _FAQ_PROCEDURE_TEXT_CACHE = None
        for faq in self.faq_catalog.get("items") or []:
            if normalize_faq_number(faq.get("id")) == faq_number:
                if record.get("title"):
                    faq["title"] = str(record["title"])
                faq["content_updated_at"] = str(record.get("updated") or time.strftime("%Y-%m-%dT%H:%M:%S"))
                break
        if self.faq_catalog:
            save_faq_cache(self.faq_catalog)
        self.map_all_orientations()
        self.rebuild_local_search_indexes()
        if self.pending_specific_section == "FAQs":
            self.faq_search.blockSignals(True)
            self.faq_search.setText(faq_number)
            self.faq_search.blockSignals(False)
            self.faq_search_text = faq_number
        else:
            self.orientation_search.blockSignals(True)
            self.orientation_search.setText(faq_number)
            self.orientation_search.blockSignals(False)
            self.orientation_search_text = faq_number
        self.current_columns = 0
        self.reflow()
        return True

    def map_specific_orientation(self):
        faq_number = normalize_faq_number(self.specific_faq_input.text())
        if len(faq_number) != 8:
            show_notice(self, "Informe o número completo da FAQ com oito dígitos.")
            self.specific_faq_input.setFocus()
            return
        existing = next(
            (item for item in self.orientation_catalog.get("items") or []
             if normalize_faq_number(item.get("faq_number")) == faq_number),
            None,
        )
        orientation = existing or map_specific_faq_orientation(faq_number)
        if orientation is None:
            show_notice(self, f"A FAQ {faq_number} não foi localizada no catálogo local das 697 FAQs.")
            return
        if orientation.get("unmappable"):
            show_notice(
                self,
                f"A FAQ {faq_number} foi localizada, mas não contém caminho da Central de Serviços nem contato para exibir ao usuário.",
            )
            return
        if existing is None:
            items = self.orientation_catalog.setdefault("items", [])
            items.insert(0, orientation)
            self.orientation_catalog["count"] = len(items)
            self.rebuild_local_search_indexes()
        self.orientation_search.blockSignals(True)
        self.orientation_search.setText(faq_number)
        self.orientation_search.blockSignals(False)
        self.orientation_search_text = faq_number
        self.current_columns = 0
        self.reflow()
        self.specific_faq_input.clear()
        self.append_log(f"\n[ORIENTAÇÃO] FAQ específica {faq_number} mapeada localmente.\n")

    def send_user_orientation(self, orientation: dict, previewed: bool = False):
        if not self.connection_active or not self.target:
            show_notice(self, "Conecte uma estação remota antes de enviar a orientação.")
            return
        expected_user = self.station_user_login(self.last_status_data.get("user"))
        if not expected_user:
            show_notice(self, "Atualize a estação para identificar o usuário conectado antes de enviar a orientação.")
            return
        if not previewed:
            self.review_user_orientation({
                "faq_id": normalize_faq_number(orientation.get("faq_number")),
                "title": str(orientation.get("title") or "FAQ selecionada"),
                "orientations": [orientation],
            })
            return
        payload = json.dumps({
            "title": str(orientation.get("title") or ""),
            "guidance": str(orientation.get("guidance") or ""),
            "path": str(orientation.get("path") or ""),
            "contact": str(orientation.get("contact") or ""),
            "include_chief_notice": orientation.get("include_chief_notice", True) is not False,
            "display_name": str(self.last_status_data.get("user_ad_name") or self.last_status_data.get("user_display") or ""),
            "expected_user": expected_user,
            "operator_name": operator_friendly_name(),
        }, ensure_ascii=False, separators=(",", ":"))
        self.append_log(f"\n[ORIENTAÇÃO] Enviando FAQ {orientation.get('faq_number', '—')} para {self.target}…\n")
        self.run_bridge(
            "user_orientation_show", self.target, payload,
            popup_title="Orientação ao usuário",
            popup_subtitle=f"Resultado do envio à sessão em {self.target}; a leitura pelo usuário não pode ser confirmada.",
        )

    def send_remote_evaluation(self):
        user = str(self.last_status_data.get("user") or "").strip()
        if not self.connection_active or not self.target or not user or user == "Nenhum usuário logado":
            show_notice(self, "Conecte uma estação com usuário logado para solicitar a avaliação.")
            return
        name = str(self.last_status_data.get("user_ad_name") or self.last_status_data.get("user_display") or "").strip()
        if not confirm_action(self, "Avaliação do atendimento", f"Exibir solicitação de avaliação para {name or user} em {self.target} por 3 minutos?"):
            return
        payload = json.dumps({
            "expected_user": user.split("\\")[-1],
            "display_name": name or user.split("\\")[-1],
            "operator_name": operator_full_name(),
            "operator_title": operator_job_title(),
        }, ensure_ascii=False, separators=(",", ":"))
        self.run_bridge(
            "user_evaluation_show", self.target, payload,
            popup_title="Solicitação de avaliação",
            popup_subtitle="Resultado do envio à sessão remota; a leitura pelo usuário não pode ser confirmada.",
        )

    def open_escalation(self):
        if self.profile != "ins":
            return
        anchor = self.escalation_button.mapToGlobal(QPoint(0, self.escalation_button.height() + 5))
        self.escalation_popup.open_at(anchor)

    def send_support_escalation(self, key: str, schedule_override: bool = False):
        if self.profile != "ins":
            return
        target = next((item for item in self.escalation_targets if item["key"] == key), None)
        if not target:
            return
        if not schedule_override and not may_escalate(
            target, self.escalation_targets,
            leader_contacted=self.escalation_popup.contacted.isChecked(),
            reason=self.escalation_popup.reason.text(),
        ):
            show_notice(self, "Esta pessoa está fora do horário ou da ordem de escalonamento.")
            return
        full_name, _role = operator_template_signature()
        if not full_name:
            show_notice(self, "O nome do analista não foi confirmado no AD. Tente novamente após consultar seu perfil.")
            return
        parts = full_name.split()
        analyst = f"{parts[0]} {parts[-1]}" if len(parts) > 1 else parts[0]
        source_computer = (os.environ.get("COMPUTERNAME") or socket.gethostname()).strip().split(".")[0].upper()
        if not confirm_action(
            self, "Solicitar apoio técnico",
            f"Exibir na estação {target['computer']} uma solicitação de apoio para {target['name']}?"
            + ("\nHorário alterado: destino escolhido manualmente." if schedule_override else ""),
        ):
            return
        payload = json.dumps({
            "display_name": target["name"],
            "operator_name": analyst,
            "source_computer": source_computer,
        }, ensure_ascii=False, separators=(",", ":"))
        started = self.run_bridge(
            "support_escalation_show", target["computer"], payload,
            popup_title="Escalonamento de apoio técnico",
            popup_subtitle="Despacho da mensagem remota; a leitura pela pessoa não pode ser confirmada.",
        )
        if started:
            self.escalation_popup.override_dialog.hide()
            self.escalation_popup.hide()
            self.append_log(f"\n[ESCALONAMENTO] Solicitando apoio de {target['name']} em {target['computer']}…\n")
            if schedule_override:
                self.append_log("[ESCALONAMENTO] Horário alterado; destino escolhido manualmente.\n")
            if key != "leader" and self.escalation_popup.contacted.isChecked():
                self.append_log(f"[ESCALONAMENTO] Líder contatado; motivo informado: {self.escalation_popup.reason.text().strip()}\n")

    def apply_faq_search(self):
        if self.current_section == "FAQs":
            self.current_columns = 0
            self.reflow()

    def toggle_faq_category(self, category: str):
        if self.faq_search_text:
            self.faq_search.blockSignals(True)
            self.faq_search.clear()
            self.faq_search.blockSignals(False)
            self.faq_search_text = ""
            self.faq_expanded_categories.add(category)
        elif category in self.faq_expanded_categories:
            self.faq_expanded_categories.remove(category)
        else:
            self.faq_expanded_categories.add(category)
        self.current_columns = 0
        self.reflow()

    def toggle_faq_root(self, category: str):
        if self.faq_search_text:
            self.faq_search.blockSignals(True)
            self.faq_search.clear()
            self.faq_search.blockSignals(False)
            self.faq_search_text = ""
            self.faq_expanded_roots.add(category)
        elif category in self.faq_expanded_roots:
            self.faq_expanded_roots.remove(category)
        else:
            self.faq_expanded_roots.add(category)
        self.current_columns = 0
        self.reflow()

    def update_faq_suggestions(self):
        raw = self.faq_catalog.get("items") or []
        items = [raw] if isinstance(raw, dict) else list(raw)
        values = []
        for faq in items:
            for key in ("title", "knowledge_category", "knowledge_subcategory", "knowledge_procedure"):
                value = str(faq.get(key, "")).strip()
                if value and value not in values:
                    values.append(value)
        values.sort(key=str.casefold)
        self.faq_suggestion_model.setStringList(values)

    def request_faq_catalog(self, force: bool = False, feedback_button: QPushButton | None = None):
        if self.faq_loading:
            return
        if self.faq_catalog.get("items") and not force:
            self.append_log("\n[FAQ] Cache local carregado; nenhuma FAQ já mapeada será consultada novamente.\n")
            self.current_columns = 0
            self.reflow()
            return
        saved_password = self._capri_session_password or credential_read(self.capri_username, "capri") or ""
        if not saved_password:
            self.section_description.setText(
                "Para consultar as FAQs, autentique sua conta do Capri na janela protegida."
            )
            if not self.faq_auth_prompt_open:
                self.faq_auth_prompt_open = True
                QTimer.singleShot(0, self.open_capri_login)
            return
        self.faq_loading = True
        self.faq_mapping_progress_value = 0
        self.faq_refresh_feedback_button = feedback_button
        if feedback_button is not None:
            set_refresh_icon_busy(feedback_button, True)
        self.faq_refresh_button.setEnabled(False)
        self.faq_incremental_button.setEnabled(False)
        self.current_columns = 0
        self.reflow()
        self.append_log("\n[FAQ] Mapeando a central de conhecimento do Capri…\n")
        faq_payload = json.dumps({"cache_path": str(faq_cache_path())}, ensure_ascii=False, separators=(",", ":"))
        if not self.run_background_bridge("faq_catalog", "", faq_payload):
            if feedback_button is not None:
                set_refresh_icon_busy(feedback_button, False)
            self.faq_refresh_feedback_button = None
            self.faq_loading = False
            self.faq_refresh_button.setEnabled(True)
            self.faq_incremental_button.setEnabled(True)


    def refresh_theme_icon(self):
        self.theme_button.setChecked(self.dark_mode)
        self.theme_label.setText("Modo claro" if self.dark_mode else "Modo escuro")
        if hasattr(self, "faq_search_icon"):
            color = "#73CFF3" if self.dark_mode else BLUE
            self.faq_search_icon.setPixmap(modern_icon("search", color, 18).pixmap(18, 18))

    def set_theme(self, enabled: bool):
        if self.pending_theme_mode is not None:
            return
        self.pending_theme_mode = bool(enabled)
        self.theme_button.set_loading(True)
        fade_theme_change(
            self, self,
            self.apply_pending_theme,
            self.finish_theme_change,
            apply_delay_ms=16,
        )

    def apply_pending_theme(self):
        if self.pending_theme_mode is None:
            return
        self.dark_mode = self.pending_theme_mode
        apply_application_theme(self.dark_mode, refresh_icons=False)
        save_json_cache(theme_settings_path(), {"dark": self.dark_mode})
        self.brand_lightning.set_dark_mode(self.dark_mode)
        self.brand_mark.setPixmap(atlas_brand_pixmap(
            "logo_compact_dark.png" if self.dark_mode else "logo_compact_light.png", self.brand_mark.width(),
        ))
        # O painel logado pode conter centenas de cartões. Recolorir todos os
        # ícones no mesmo quadro interrompia a animação; os lotes cedem tempo
        # ao loop gráfico entre pequenos grupos de controles.
        refresh_themed_button_icons_chunked(self, 28)

    def finish_theme_change(self):
        self.pending_theme_mode = None
        self.refresh_theme_icon()
        if hasattr(self, "status_pulse"):
            self.paint_station_icon(self.connection_active)
        self.theme_button.set_loading(False)

    def reset_horizontal_scroll(self):
        if hasattr(self, "scroll"):
            self.scroll.horizontalScrollBar().setValue(0)

    def update_ticket_scope(self, text: str):
        self.ticket_user.setText(operator_full_name())

    def set_ticket_period(self, period: str):
        today = QDate.currentDate()
        ranges = {
            "before_yesterday": (today.addDays(-2), today.addDays(-2)),
            "yesterday": (today.addDays(-1), today.addDays(-1)),
            "today": (today, today),
            "this_week": (today.addDays(1 - today.dayOfWeek()), today),
            "last_week": (today.addDays(1 - today.dayOfWeek() - 7), today.addDays(-today.dayOfWeek())),
        }
        start, end = ranges[period]
        self.ticket_from.setDate(start)
        self.ticket_to.setDate(end)
        self.ticket_period = period
        self.ticket_local_period_active = True
        self.update_local_ticket_period_button()
        self.filter_tickets()

    def toggle_ticket_advanced(self, expanded: bool):
        return

    def search_tickets(self, *_args):
        if self.current_section != "Chamados" or self.ticket_entry_render_pending:
            return
        query = self.ticket_search.text().strip()
        had_query = bool(self.ticket_search_text)
        self.ticket_search_text = query
        if query:
            if not had_query:
                current_index = self.ticket_status_combo.currentIndex()
                self.ticket_status_before_search = current_index if current_index > 0 else 3
            self.ticket_status_combo.blockSignals(True)
            self.ticket_status_combo.setCurrentIndex(1)
            self.ticket_status_combo.blockSignals(False)
            self.ticket_status_index = 1
            if not self.ticket_local_period_active:
                self.ticket_period = "all"
            search_summary = query
            if len(search_summary) > 56:
                search_summary = search_summary[:53].rstrip() + "…"
            message = f"Pesquisando em todos os chamados locais por “{search_summary}”…"
        elif had_query:
            restore_index = self.ticket_status_before_search if self.ticket_status_before_search > 0 else 3
            self.ticket_status_combo.blockSignals(True)
            self.ticket_status_combo.setCurrentIndex(restore_index)
            self.ticket_status_combo.blockSignals(False)
            self.ticket_status_index = restore_index
            message = f"Restaurando filtro: {self.ticket_status_combo.currentText()}…"
        elif self.ticket_status_index:
            applied_status = self.ticket_status_combo.itemText(self.ticket_status_index)
            message = f"Atualizando a pesquisa em {applied_status}…"
        else:
            self.current_columns = 0
            self.reflow()
            return
        self.begin_ticket_render(message)

    def filter_tickets(self, *_args):
        if self.current_section != "Chamados" or self.ticket_entry_render_pending:
            return
        self.ticket_status_index = self.ticket_status_combo.currentIndex()
        if self.ticket_status_index:
            message = f"Aplicando filtro: {self.ticket_status_combo.currentText()}…"
        else:
            self.current_columns = 0
            self.reflow()
            show_notice(self, "Selecione uma situação para exibir os chamados.")
            return
        self.begin_ticket_render(message)

    @staticmethod
    def normalize_ticket_search(value: object) -> str:
        text = unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode().casefold()
        return re.sub(r"[^a-z0-9]+", " ", text).strip()

    def indexed_ticket_text(self, item: dict) -> tuple[str, tuple[str, ...]]:
        """Normaliza cada chamado uma única vez enquanto o catálogo não mudar."""
        cache_key = id(item)
        cached = self.ticket_search_cache.get(cache_key)
        if cached is not None:
            return cached
        searchable = self.normalize_ticket_search(" ".join(str(item.get(key, "")) for key in (
            "number", "title", "state", "queue", "category", "customer", "creator",
            "owner", "responsible", "content", "created", "changed",
        )))
        indexed = (searchable, tuple(searchable.split()))
        self.ticket_search_cache[cache_key] = indexed
        return indexed

    def visible_tickets(self) -> list[dict]:
        raw = self.ticket_catalog.get("items") or []
        items = [raw] if isinstance(raw, dict) else list(raw)
        query = self.normalize_ticket_search(self.ticket_search_text)
        terms = query.split()
        status_index = self.ticket_status_index
        if status_index == 0 and not terms:
            return []
        wanted_state = {
            2: "open", 3: "pending", 4: "closed_success", 5: "rejected",
            6: "customer_cancelled", 7: "closed_unsuccessful",
        }.get(status_index)
        result = []
        for item in items:
            if wanted_state and str(item.get("state_kind") or "other") != wanted_state:
                continue
            if self.ticket_period != "all":
                parsed_date = ticket_created_date(item.get("created"))
                if parsed_date is None:
                    if self.ticket_local_period_active:
                        continue
                else:
                    created_date = QDate(parsed_date.year, parsed_date.month, parsed_date.day)
                    if created_date < self.ticket_from.date() or created_date > self.ticket_to.date():
                        continue
            searchable, words = self.indexed_ticket_text(item)
            exact_hits = sum(term in searchable for term in terms)
            fuzzy_hits = sum(bool(difflib.get_close_matches(term, words, n=1, cutoff=.72)) for term in terms if term not in searchable)
            if terms and exact_hits + fuzzy_hits < len(terms):
                continue
            prefix_hits = sum(any(word.startswith(term) for word in words) for term in terms)
            score = exact_hits * 20 + prefix_hits * 6 + fuzzy_hits * 3
            result.append((score, item))
        return [item for _score, item in sorted(result, key=lambda pair: pair[0], reverse=True)]

    def render_ticket_catalog(self, columns: int):
        items = self.visible_tickets()
        total = len(self.ticket_catalog.get("items") or [])
        has_catalog = total > 0
        self.ticket_search_frame.setVisible(has_catalog)
        self.ticket_status_frame.setVisible(has_catalog)
        self.ticket_result_count.setText(f"{len(items)} de {total}")
        if self.ticket_loading:
            notice = QFrame(objectName="ticketSyncProgress")
            notice.setProperty("softwareDynamic", True)
            notice_box = QVBoxLayout(notice)
            notice_box.setContentsMargins(18, 14, 18, 14)
            notice_box.setSpacing(8)
            notice_text = QLabel("Consultando o Capri sob seu comando. O catálogo anterior continuará preservado até a conclusão…")
            notice_text.setObjectName("ticketSyncProgressText")
            notice_text.setWordWrap(True)
            notice_box.addWidget(notice_text)
            progress_header = QHBoxLayout()
            progress_label = QLabel("Andamento da atualização")
            progress_label.setObjectName("ticketSyncProgressLabel")
            progress_header.addWidget(progress_label)
            progress_header.addStretch(1)
            self.ticket_sync_progress_percent = QLabel(f"{self.ticket_sync_progress_value}%")
            self.ticket_sync_progress_percent.setObjectName("ticketSyncProgressPercent")
            progress_header.addWidget(self.ticket_sync_progress_percent)
            notice_box.addLayout(progress_header)
            self.ticket_sync_progress_bar = QProgressBar()
            self.ticket_sync_progress_bar.setObjectName("ticketSyncProgressBar")
            self.ticket_sync_progress_bar.setRange(0, 100)
            self.ticket_sync_progress_bar.setValue(self.ticket_sync_progress_value)
            self.ticket_sync_progress_bar.setTextVisible(False)
            self.ticket_sync_progress_bar.setFixedHeight(8)
            notice_box.addWidget(self.ticket_sync_progress_bar)
            self.action_grid.addWidget(notice, 0, 0, 1, columns)
            return
        if not items:
            if total and self.ticket_status_index == 0 and not self.ticket_search_text:
                empty_text = "Selecione uma situação em Filtrar resultados para exibir os chamados."
            else:
                empty_text = "Nenhum chamado corresponde aos filtros locais." if total else "Clique em “Mapear meus chamados” para criar o primeiro catálogo local."
            notice = QLabel(empty_text)
            notice.setObjectName("softwareNotice"); notice.setProperty("softwareDynamic", True); notice.setWordWrap(True)
            self.action_grid.addWidget(notice, 0, 0, 1, columns)
            return
        groups = {}
        for item in items:
            state_group = {
                "open": "Abertos", "pending": "Pendentes",
                "closed_success": "Finalizados com êxito", "closed_other": "Outros finalizados",
                "rejected": "Rejeitados", "customer_cancelled": "Cancelados pelo cliente",
                "closed_unsuccessful": "Fechados sem êxito",
            }.get(str(item.get("state_kind") or ""), "Estado não identificado")
            category = str(item.get("queue") or item.get("category") or "Outros")
            groups.setdefault((state_group, category), []).append(item)
        row = 0
        state_order = {
            "Abertos": 0, "Pendentes": 1, "Finalizados com êxito": 2,
            "Rejeitados": 3, "Cancelados pelo cliente": 4, "Fechados sem êxito": 5,
            "Outros finalizados": 6, "Estado não identificado": 7,
        }
        ordered_groups = sorted(groups.items(), key=lambda entry: (state_order.get(entry[0][0], 9), entry[0][1].casefold()))
        pending_cards = []
        for (state_group, category), group_items in ordered_groups:
            header = QLabel(f"{state_group.upper()}  /  {category}  •  {len(group_items)}")
            header.setObjectName("groupHeader"); header.setProperty("groupHeader", True)
            self.action_grid.addWidget(header, row, 0, 1, columns); row += 1
            for index, ticket in enumerate(group_items):
                pending_cards.append((ticket, row + index // columns, index % columns))
            row += (len(group_items) + columns - 1) // columns
        self.ticket_card_render_generation += 1
        generation = self.ticket_card_render_generation
        self.ticket_card_render_queue = pending_cards
        self._ticket_cards_total = len(pending_cards)
        self._ticket_cards_rendered = 0
        self.render_ticket_card_batch(generation)

    def render_ticket_card_batch(self, generation: int):
        """Cria cartões em pequenos lotes para manter cliques e animações responsivos."""
        if generation != self.ticket_card_render_generation or self.current_section != "Chamados":
            return
        batch = self.ticket_card_render_queue[:16]
        del self.ticket_card_render_queue[:16]
        for ticket, row, column in batch:
            number = ticket_number(ticket.get("number") or ticket.get("id"))
            card = TicketCard(ticket, self.actions_host,
                              favorite=number in self.ticket_bookmarks["favorites"],
                              monitored=number in self.ticket_bookmarks["monitored"])
            card.opened.connect(self.open_ticket)
            card.favorite_requested.connect(lambda value: self.toggle_ticket_bookmark("favorites", value))
            card.monitored_requested.connect(lambda value: self.toggle_ticket_bookmark("monitored", value))
            self.action_grid.addWidget(card, row, column)
        self._ticket_cards_rendered += len(batch)
        if self.ticket_card_render_queue:
            self.ticket_result_count.setText(
                f"Exibindo {self._ticket_cards_rendered} de {self._ticket_cards_total}…"
            )
            QTimer.singleShot(0, lambda current=generation: self.render_ticket_card_batch(current))
            return
        total_catalog = len(self.ticket_catalog.get("items") or [])
        self.ticket_result_count.setText(f"{self._ticket_cards_total} de {total_catalog}")
        # A troca global do tema nesta etapa recolhia a altura dos cartões
        # recém-criados; só a grade de Chamados precisa concluir o layout.
        self.action_grid.invalidate()
        self.action_grid.activate()
        self.actions_host.updateGeometry()
        self.actions_host.update()

    def open_external_link(self, url: str) -> bool:
        opened, used_browser, _used_fallback = launch_external_url(url)
        if not opened:
            requested_label = dict(BROWSER_OPTIONS).get(preferred_browser(), "navegador escolhido")
            show_notice(self, f"Não foi possível abrir o endereço no {requested_label}.")
            return False
        browser_label = dict(BROWSER_OPTIONS).get(used_browser, "Padrão do Windows")
        self.append_log(f"\n[NAVEGADOR] Link aberto com {browser_label}.\n")
        return True

    def open_ticket(self, url: str, number: str):
        if not url.startswith("https://capri.senado.leg.br/"):
            show_notice(self, "O endereço do chamado não pertence ao Capri.")
            return
        if self.open_external_link(url):
            self.append_log(f"\n[CHAMADO] Abrindo {number} no Capri.\n")

    def request_tickets(self, filtered: bool, feedback_mode: str = ""):
        password = self._capri_session_password
        if not password:
            show_notice(self, "A sessão do Capri não está ativa. Entre novamente para acessar Chamados.")
            self.open_capri_login(False, True, True)
            return
        scope = self.ticket_scope.currentText()
        user = self.ticket_user.text().strip()
        if scope == "Meus chamados":
            user = operator_full_name()
        elif scope == "Usuário da estação conectada":
            user = str(self.last_status_data.get("logged_user") or self.last_status_data.get("user") or self.ticket_user.text()).strip()
        if scope != "Meus chamados" and not user:
            show_notice(self, "Informe o usuário que será pesquisado.")
            return
        recheck_numbers = []
        if feedback_mode == "recent":
            recheck_numbers = open_ticket_numbers(
                self.ticket_catalog.get("items") or [], classify_ticket_state,
            )
        payload = build_ticket_payload(
            scope="operator" if scope == "Meus chamados" else "customer",
            display_name=user,
            operator_login=re.sub(r"(?i)_ins$", "", getpass.getuser().strip()),
            date_from=self.ticket_from.date().toString("yyyy-MM-dd") if filtered else "",
            date_to=self.ticket_to.date().toString("yyyy-MM-dd") if filtered else "",
            cache_path=str(ticket_cache_path()),
            refresh_existing=feedback_mode in {"recent", "reconcile_mapped"},
            recheck_numbers=recheck_numbers,
        )
        self.ticket_feedback_mode = feedback_mode
        self.ticket_loading = True
        set_refresh_icon_busy(self.ticket_refresh_cache_button, True)
        self.ticket_sync_progress_value = 2
        self.ticket_sync_progress_timer.start()
        self.ticket_map_button.setEnabled(False); self.ticket_query_button.setEnabled(False)
        self.ticket_refresh_cache_button.setEnabled(False)
        self.current_columns = 0; self.reflow()
        self.append_log(f"\n[CHAMADOS] Consulta explícita no Capri para {user}…\n")
        if not self.run_background_bridge(TICKET_CATALOG, "", payload):
            set_refresh_icon_busy(self.ticket_refresh_cache_button, False)
            self.ticket_sync_progress_timer.stop()
            self.ticket_loading = False
            self.ticket_feedback_mode = ""
            self.ticket_refresh_cache_button.setEnabled(True)

    def advance_ticket_sync_progress(self):
        """Mantém feedback vivo sem anunciar conclusão antes da resposta real do Capri."""
        if not self.ticket_loading:
            self.ticket_sync_progress_timer.stop()
            return
        if self.ticket_sync_progress_value < 92:
            increment = 2 if self.ticket_sync_progress_value < 55 else 1
            self.ticket_sync_progress_value = min(92, self.ticket_sync_progress_value + increment)
        if hasattr(self, "ticket_sync_progress_bar"):
            self.ticket_sync_progress_bar.setValue(self.ticket_sync_progress_value)
        if hasattr(self, "ticket_sync_progress_percent"):
            self.ticket_sync_progress_percent.setText(f"{self.ticket_sync_progress_value}%")

    def refresh_recent_tickets(self):
        """Atualiza ontem e hoje e reconfere o estado dos abertos/pendentes do cache."""
        today = QDate.currentDate()
        yesterday = today.addDays(-1)
        self.ticket_from.setDate(yesterday)
        self.ticket_to.setDate(today)
        self.ticket_period = "custom"
        self.ticket_local_period_active = False
        self.update_local_ticket_period_button()
        self.append_log(
            f"\n[CHAMADOS] Atualizando somente ontem ({yesterday.toString('dd/MM/yyyy')}) "
            f"e hoje ({today.toString('dd/MM/yyyy')}) e reconferindo abertos/pendentes do cache.\n"
        )
        self.request_tickets(True, "recent")

    def update_local_ticket_period_button(self):
        button = self.ticket_local_period_button
        active = self.ticket_local_period_active
        button.setProperty("active", active)
        button.setToolTip(
            f"Período local: {self.ticket_from.date().toString('dd/MM/yyyy')} a "
            f"{self.ticket_to.date().toString('dd/MM/yyyy')} — clique para alterar ou limpar"
            if active else "Filtrar por período nos chamados já mapeados"
        )
        button.style().unpolish(button)
        button.style().polish(button)

    def open_local_ticket_period_dialog(self):
        """Filtra apenas o catálogo persistido, sem autenticar ou consultar o Capri."""
        if not self.ticket_catalog.get("items"):
            show_notice(self, "Nenhum chamado mapeado está disponível para filtrar.")
            return
        dialog = QDialog(self)
        dialog.setObjectName("ticketPeriodDialog")
        dialog.setWindowTitle("Período dos chamados locais")
        dialog.setModal(True)
        dialog.setMinimumWidth(425)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)
        title = QLabel("FILTRAR CHAMADOS MAPEADOS")
        title.setObjectName("dialogTitle")
        layout.addWidget(title)
        hint = QLabel("Escolha as datas de abertura. Esta pesquisa usa somente os chamados já salvos no ATLAS.")
        hint.setObjectName("dialogHint")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        dates = QGridLayout()
        dates.setHorizontalSpacing(10)
        for column, caption in enumerate(("DE", "ATÉ")):
            label = QLabel(caption)
            label.setObjectName("ticketFieldLabel")
            dates.addWidget(label, 0, column)
        start = QDateEdit(self.ticket_from.date() if self.ticket_local_period_active else QDate.currentDate().addDays(-7))
        end = QDateEdit(self.ticket_to.date() if self.ticket_local_period_active else QDate.currentDate())
        for column, field in enumerate((start, end)):
            field.setObjectName("ticketPeriodDate")
            field.setCalendarPopup(True)
            field.setDisplayFormat("dd/MM/yyyy")
            field.setMinimumHeight(44)
            field.setMinimumWidth(150)
            calendar = field.calendarWidget()
            calendar.setObjectName("ticketCalendar")
            calendar.setGridVisible(False)
            calendar.setMinimumSize(372, 300)
            calendar.setVerticalHeaderFormat(QCalendarWidget.NoVerticalHeader)
            calendar.setHorizontalHeaderFormat(QCalendarWidget.ShortDayNames)
            calendar.setNavigationBarVisible(True)
            dates.addWidget(field, 1, column)
        layout.addLayout(dates)
        actions = QHBoxLayout()
        clear = QPushButton("Mostrar todos")
        clear.setObjectName("secondaryButton")
        clear.clicked.connect(lambda: dialog.done(2))
        actions.addWidget(clear)
        actions.addStretch(1)
        cancel = QPushButton("Cancelar")
        cancel.setObjectName("secondaryButton")
        cancel.clicked.connect(dialog.reject)
        actions.addWidget(cancel)
        apply = QPushButton("Filtrar cache")
        apply.setObjectName("primaryButton")
        set_button_icon(apply, "time_filter", "#FFFFFF", 15)
        apply.clicked.connect(dialog.accept)
        actions.addWidget(apply)
        layout.addLayout(actions)
        choice = dialog.exec()
        if choice == QDialog.Rejected:
            return
        if choice == 2:
            self.ticket_local_period_active = False
            self.ticket_period = "all"
        else:
            if start.date() > end.date():
                show_notice(self, "A data inicial não pode ser posterior à data final.")
                return
            self.ticket_from.setDate(start.date())
            self.ticket_to.setDate(end.date())
            self.ticket_period = "custom"
            self.ticket_local_period_active = True
        self.update_local_ticket_period_button()
        self.ticket_search.blockSignals(True)
        self.ticket_search.clear()
        self.ticket_search.blockSignals(False)
        self.ticket_search_text = ""
        self.ticket_status_combo.setCurrentIndex(1)
        self.ticket_status_index = 1
        self.begin_ticket_render(
            "Filtrando chamados já mapeados por período…" if self.ticket_local_period_active
            else "Exibindo todos os chamados locais…"
        )

    def open_ticket_period_dialog(self):
        password = self._capri_session_password
        if not password:
            self.open_capri_login(False, True, True)
            return
        dialog = QDialog(self)
        dialog.setObjectName("ticketPeriodDialog")
        dialog.setWindowTitle("Período dos chamados")
        dialog.setModal(True)
        dialog.setMinimumWidth(430)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)
        title = QLabel("Selecione o período")
        title.setObjectName("dialogTitle")
        layout.addWidget(title)
        hint = QLabel("Escolha um mês completo ou informe um intervalo. O Atlas consultará somente esse período e confirmará o campo Criado por.")
        hint.setObjectName("dialogHint")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        period_tabs = QTabWidget()
        period_tabs.setObjectName("ticketPeriodTabs")

        month_page = QWidget()
        month_layout = QVBoxLayout(month_page)
        month_layout.setContentsMargins(12, 14, 12, 14)
        month_layout.setSpacing(8)
        month_hint = QLabel("MAPEAR O MÊS INTEIRO")
        month_hint.setObjectName("ticketFieldLabel")
        month_layout.addWidget(month_hint)
        month_row = QHBoxLayout()
        month_row.setSpacing(10)
        month = QComboBox()
        month.setObjectName("ticketMonthSelect")
        month_names = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]
        month.addItems(month_names)
        today = QDate.currentDate()
        month.setCurrentIndex(today.month() - 1)
        year = QComboBox()
        year.setObjectName("ticketYearSelect")
        for value in range(today.year() + 1, today.year() - 11, -1):
            year.addItem(str(value), value)
        year.setCurrentText(str(today.year()))

        mapped_months = {
            str(value) for value in (self.ticket_catalog.get("mapped_months") or [])
            if re.fullmatch(r"\d{4}-\d{2}", str(value))
        }

        def refresh_mapped_months():
            selected_year = int(year.currentData())
            first_available = -1
            for index, name in enumerate(month_names):
                item = month.model().item(index)
                mapped = f"{selected_year:04d}-{index + 1:02d}" in mapped_months
                item.setText(f"✓ {name} — mapeado" if mapped else name)
                item.setEnabled(not mapped)
                item.setData(QColor("#7890A0") if mapped else QColor("#EAF4FA"), Qt.ForegroundRole)
                if not mapped and first_available < 0:
                    first_available = index
            current_item = month.model().item(month.currentIndex()) if month.currentIndex() >= 0 else None
            if current_item is None or not current_item.isEnabled():
                month.setCurrentIndex(first_available)

        year.currentIndexChanged.connect(refresh_mapped_months)
        refresh_mapped_months()
        month_row.addWidget(month, 2)
        month_row.addWidget(year, 1)
        month_layout.addLayout(month_row)
        period_tabs.addTab(month_page, "Mês e ano")

        range_page = QWidget()
        range_layout = QVBoxLayout(range_page)
        range_layout.setContentsMargins(12, 14, 12, 14)
        dates = QGridLayout()
        dates.setHorizontalSpacing(10)
        start_label = QLabel("DE")
        start_label.setObjectName("ticketFieldLabel")
        end_label = QLabel("ATÉ")
        end_label.setObjectName("ticketFieldLabel")
        dates.addWidget(start_label, 0, 0)
        dates.addWidget(end_label, 0, 1)
        start = QDateEdit(today.addDays(-1))
        end = QDateEdit(today)
        for field in (start, end):
            field.setObjectName("ticketPeriodDate")
            field.setCalendarPopup(True)
            field.setDisplayFormat("dd/MM/yyyy")
            field.setMinimumHeight(44)
            field.setMinimumWidth(150)
            calendar = field.calendarWidget()
            calendar.setObjectName("ticketCalendar")
            calendar.setGridVisible(False)
            calendar.setMinimumSize(372, 300)
            calendar.setVerticalHeaderFormat(QCalendarWidget.NoVerticalHeader)
            calendar.setHorizontalHeaderFormat(QCalendarWidget.ShortDayNames)
            calendar.setNavigationBarVisible(True)
        dates.addWidget(start, 1, 0)
        dates.addWidget(end, 1, 1)
        range_layout.addLayout(dates)
        period_tabs.addTab(range_page, "Intervalo personalizado")
        layout.addWidget(period_tabs)
        actions = QHBoxLayout()
        cancel = QPushButton("Cancelar")
        cancel.setObjectName("secondaryButton")
        confirm = QPushButton("Mapear período")
        confirm.setObjectName("primaryButton")
        set_button_icon(confirm, "calendar", "#FFFFFF", 15)
        cancel.clicked.connect(dialog.reject)
        confirm.clicked.connect(dialog.accept)
        actions.addWidget(cancel)
        actions.addWidget(confirm)
        layout.addLayout(actions)

        def update_period_confirmation():
            month_item = month.model().item(month.currentIndex()) if month.currentIndex() >= 0 else None
            confirm.setEnabled(period_tabs.currentIndex() != 0 or bool(month_item and month_item.isEnabled()))

        period_tabs.currentChanged.connect(update_period_confirmation)
        month.currentIndexChanged.connect(update_period_confirmation)
        update_period_confirmation()
        if dialog.exec() != QDialog.Accepted:
            return
        if period_tabs.currentIndex() == 0:
            selected_year = int(year.currentData())
            selected_month = month.currentIndex() + 1
            self.ticket_mapping_month_key = f"{selected_year:04d}-{selected_month:02d}"
            selected_start = QDate(selected_year, selected_month, 1)
            selected_end = QDate(selected_year, selected_month, selected_start.daysInMonth())
        else:
            self.ticket_mapping_month_key = ""
            selected_start = start.date()
            selected_end = end.date()
        if selected_start > selected_end:
            show_notice(self, "A data inicial não pode ser posterior à data final.")
            return
        self.ticket_from.setDate(selected_start)
        self.ticket_to.setDate(selected_end)
        self.ticket_period = "custom"
        self.ticket_local_period_active = False
        self.update_local_ticket_period_button()
        self.ticket_status_combo.setCurrentIndex(3)
        self.ticket_status_index = 3
        self.ticket_search.blockSignals(True)
        self.ticket_search.clear()
        self.ticket_search.blockSignals(False)
        self.ticket_search_text = ""
        self.request_tickets(True)

    def open_faq(self, url: str, title: str):
        if not url.lower().startswith("https://capri.senado.leg.br/"):
            show_notice(self, "O endereço da FAQ não pertence ao domínio oficial do Capri.")
            return
        if self.open_external_link(url):
            self.append_log(f"\n[FAQ] Abrindo: {title}\n")

    def faq_favorite_ids(self) -> set[str]:
        return {item["id"] for item in self.faq_favorites}

    def build_faq_favorites_popup(self):
        popup = QDialog(self)
        popup.setObjectName("faqFavoritesPopup")
        popup.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint)
        popup_layout = QVBoxLayout(popup)
        popup_layout.setContentsMargins(14, 13, 14, 14)
        popup_layout.setSpacing(10)
        heading = QHBoxLayout()
        title = QLabel("MINHAS FAQs FAVORITAS")
        title.setObjectName("faqFavoritesTitle")
        heading.addWidget(title, 1)
        close = QPushButton("×")
        close.setObjectName("faqFavoritesClose")
        close.setFixedSize(28, 28)
        close.setAccessibleName("Fechar FAQs favoritas")
        close.clicked.connect(popup.hide)
        heading.addWidget(close)
        popup_layout.addLayout(heading)
        self.faq_favorites_count = QLabel("")
        self.faq_favorites_count.setObjectName("faqFavoritesHint")
        popup_layout.addWidget(self.faq_favorites_count)
        self.faq_favorites_search = QLineEdit()
        self.faq_favorites_search.setObjectName("faqFavoritesSearch")
        self.faq_favorites_search.setPlaceholderText("Buscar número ou título da FAQ favorita…")
        self.faq_favorites_search.setAccessibleName("Buscar nas FAQs favoritas")
        self.faq_favorites_search.setClearButtonEnabled(True)
        self.faq_favorites_search.addAction(modern_icon("search", "#6DBDD9", 16), QLineEdit.ActionPosition.LeadingPosition)
        self.faq_favorites_search.textChanged.connect(self.render_faq_favorites_popup)
        popup_layout.addWidget(self.faq_favorites_search)
        scroll = QScrollArea()
        scroll.setObjectName("faqFavoritesScroll")
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        body = QWidget()
        body.setObjectName("faqFavoritesBody")
        self.faq_favorites_rows = QVBoxLayout(body)
        self.faq_favorites_rows.setContentsMargins(1, 1, 4, 1)
        self.faq_favorites_rows.setSpacing(7)
        scroll.setWidget(body)
        popup_layout.addWidget(scroll, 1)
        self.faq_favorites_popup = popup

    def render_faq_favorites_popup(self):
        rows = self.faq_favorites_rows
        while rows.count():
            item = rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        count = len(self.faq_favorites)
        terms = self.normalize_ticket_search(self.faq_favorites_search.text()).split()
        visible = [entry for entry in reversed(self.faq_favorites)
                   if all(term in self.normalize_ticket_search(
                       f"{entry['id']} {entry['title']}") for term in terms)]
        self.faq_favorites_count.setText(
            f"{len(visible)} de {count} FAQ{'s' if count != 1 else ''} favorita{'s' if count != 1 else ''}."
            if terms else f"{count} FAQ{'s' if count != 1 else ''} salva{'s' if count != 1 else ''} neste perfil."
        )
        self.faq_favorites_button.setToolTip(f"Abrir minhas FAQs favoritas ({count})")
        if not count:
            hint = QLabel("Use a estrela nos cards das FAQs para adicionar seus favoritos.")
            hint.setObjectName("faqFavoritesHint")
            hint.setWordWrap(True)
            rows.addWidget(hint)
        elif not visible:
            hint = QLabel("Nenhuma FAQ favorita corresponde à busca.")
            hint.setObjectName("faqFavoritesHint")
            rows.addWidget(hint)
        for entry in visible:
            row = QFrame(objectName="faqFavoriteRow")
            box = QHBoxLayout(row)
            box.setContentsMargins(7, 5, 5, 5)
            box.setSpacing(5)
            open_button = QPushButton(f"FAQ {entry['id']}  •  {entry['title']}")
            open_button.setObjectName("faqFavoriteOpen")
            open_button.setToolTip(entry["title"])
            open_button.setAccessibleName(f"Abrir FAQ favorita {entry['id']}")
            open_button.clicked.connect(
                lambda _checked=False, saved=entry: self.open_faq(saved["url"], saved["title"])
            )
            box.addWidget(open_button, 1)
            faq_id = entry["id"]
            copy_number = QPushButton()
            copy_number.setObjectName("faqFavoriteAction")
            copy_number.setFixedSize(28, 28)
            copy_number.setToolTip(f"Copiar somente o número {faq_id}")
            copy_number.setAccessibleName(f"Copiar número da FAQ {faq_id}")
            set_button_icon(copy_number, "copy", GREEN, 15)
            copy_number.clicked.connect(
                lambda _checked=False, value=faq_id, control=copy_number:
                    self.copy_favorite_faq_number(value, control)
            )
            box.addWidget(copy_number)
            orientation = QPushButton()
            orientation.setObjectName("faqFavoriteAction")
            orientation.setFixedSize(28, 28)
            has_orientation = bool(self.orientation_by_faq.get(faq_id))
            orientation.setToolTip(
                "Gerenciar orientações desta FAQ" if has_orientation
                else "Criar orientação para esta FAQ"
            )
            orientation.setAccessibleName(f"Orientações da FAQ {faq_id}")
            set_button_icon(orientation, "orientation" if has_orientation else "plus", GREEN, 15)
            orientation.clicked.connect(
                lambda _checked=False, saved=entry: self.open_favorite_orientation(saved)
            )
            box.addWidget(orientation)
            remove = QPushButton()
            remove.setObjectName("faqFavoriteRemove")
            remove.setFixedSize(28, 28)
            remove.setToolTip("Remover dos favoritos")
            remove.setAccessibleName(f"Remover FAQ {entry['id']} dos favoritos")
            set_button_icon(remove, "star", GOLD, 13)
            remove.clicked.connect(
                lambda _checked=False, saved=entry: self.toggle_faq_favorite(saved)
            )
            box.addWidget(remove)
            rows.addWidget(row)
        rows.addStretch(1)

    def copy_favorite_faq_number(self, faq_id: str, button: QPushButton):
        QApplication.clipboard().setText(faq_id)
        set_button_icon(button, "check", GREEN, 15)
        button.setToolTip(f"Número {faq_id} copiado")

    def open_favorite_orientation(self, entry: dict):
        self.faq_favorites_popup.hide()
        self.review_user_orientation({"faq_id": entry["id"], "title": entry["title"]})

    def toggle_faq_favorites_popup(self):
        popup = self.faq_favorites_popup
        if popup.isVisible():
            popup.hide()
            return
        self.render_faq_favorites_popup()
        anchor = self.faq_favorites_button.mapToGlobal(
            QPoint(self.faq_favorites_button.width() + 9, 0)
        )
        screen = QApplication.screenAt(anchor) or self.screen() or QApplication.primaryScreen()
        bounds = screen.availableGeometry()
        width = min(440, max(280, bounds.width() - 24))
        height = min(550, max(220, bounds.height() - 24))
        popup.resize(width, height)
        popup.move(
            max(bounds.left() + 12, min(anchor.x(), bounds.right() - width - 11)),
            max(bounds.top() + 12, min(anchor.y(), bounds.bottom() - height - 11)),
        )
        popup.show()
        popup.raise_()
        self.faq_favorites_search.setFocus()

    def toggle_faq_favorite(self, faq: dict):
        try:
            _added, updated = toggle_favorite(faq_favorites_path(), faq)
        except (ValueError, OSError) as exc:
            show_notice(self, str(exc))
            return
        self.faq_favorites = updated
        number = normalize_faq_number(faq.get("id"))
        favorite = number in self.faq_favorite_ids()
        for card in self.actions_host.findChildren(FaqCard):
            if normalize_faq_number(card.property("faqId")) == number:
                card.set_favorite_state(favorite, number)
        if self.faq_favorites_popup.isVisible():
            self.render_faq_favorites_popup()

    def build_ticket_bookmarks_popup(self):
        popup = QDialog(self)
        popup.setObjectName("ticketBookmarksPopup")
        popup.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint)
        layout = QVBoxLayout(popup)
        layout.setContentsMargins(15, 14, 15, 14)
        layout.setSpacing(10)
        header = QHBoxLayout()
        self.ticket_bookmark_heading = QLabel()
        self.ticket_bookmark_heading.setObjectName("faqFavoritesTitle")
        header.addWidget(self.ticket_bookmark_heading, 1)
        close = QPushButton("×")
        close.setObjectName("faqFavoritesClose")
        close.setFixedSize(28, 28)
        close.clicked.connect(popup.hide)
        header.addWidget(close)
        layout.addLayout(header)
        self.ticket_bookmark_count = QLabel()
        self.ticket_bookmark_count.setObjectName("faqFavoritesHint")
        self.ticket_bookmark_count.setWordWrap(True)
        layout.addWidget(self.ticket_bookmark_count)
        self.ticket_bookmark_update_result = QLabel("")
        self.ticket_bookmark_update_result.setObjectName("faqFavoritesHint")
        self.ticket_bookmark_update_result.setWordWrap(True)
        layout.addWidget(self.ticket_bookmark_update_result)
        search = QLineEdit()
        search.setObjectName("faqFavoritesSearch")
        search.setPlaceholderText("Pesquisar número, título, fila, usuário ou situação…")
        search.setClearButtonEnabled(True)
        search.addAction(modern_icon("search", BLUE_2, 16), QLineEdit.ActionPosition.LeadingPosition)
        search.textChanged.connect(self.render_ticket_bookmarks_popup)
        self.ticket_bookmark_search = search
        layout.addWidget(search)
        scroll = QScrollArea()
        scroll.setObjectName("faqFavoritesScroll")
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setWidgetResizable(True)
        body = QWidget()
        body.setObjectName("faqFavoritesBody")
        self.ticket_bookmark_rows = QVBoxLayout(body)
        self.ticket_bookmark_rows.setContentsMargins(1, 1, 4, 1)
        self.ticket_bookmark_rows.setSpacing(7)
        scroll.setWidget(body)
        layout.addWidget(scroll, 1)
        controls = QHBoxLayout()
        self.ticket_bookmark_refresh = QPushButton("Atualizar situações no Capri")
        self.ticket_bookmark_refresh.setObjectName("cacheRefreshButton")
        set_button_icon(self.ticket_bookmark_refresh, "refresh", BLUE, 14)
        self.ticket_bookmark_refresh.clicked.connect(self.refresh_ticket_bookmarks)
        controls.addWidget(self.ticket_bookmark_refresh)
        controls.addStretch(1)
        layout.addLayout(controls)
        self.ticket_bookmark_popup = popup

    def open_ticket_bookmarks(self, kind: str):
        popup = self.ticket_bookmark_popup
        if popup.isVisible() and self.ticket_bookmark_kind == kind:
            popup.hide()
            return
        self.ticket_bookmark_kind = kind
        self.ticket_bookmark_search.clear()
        self.ticket_bookmark_update_result.clear()
        self.render_ticket_bookmarks_popup()
        anchor_button = self.ticket_favorites_button if kind == "favorites" else self.ticket_monitored_button
        anchor = anchor_button.mapToGlobal(QPoint(anchor_button.width() + 9, 0))
        screen = QApplication.screenAt(anchor) or self.screen() or QApplication.primaryScreen()
        bounds = screen.availableGeometry()
        width = min(530, max(320, bounds.width() - 24))
        height = min(590, max(240, bounds.height() - 24))
        popup.resize(width, height)
        popup.move(max(bounds.left() + 12, min(anchor.x(), bounds.right() - width - 11)),
                   max(bounds.top() + 12, min(anchor.y(), bounds.bottom() - height - 11)))
        popup.show()
        popup.raise_()
        self.ticket_bookmark_search.setFocus()

    def render_ticket_bookmarks_popup(self):
        if self.ticket_bookmark_popup is None:
            return
        rows = self.ticket_bookmark_rows
        while rows.count():
            item = rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        kind = self.ticket_bookmark_kind
        label = "FAVORITOS" if kind == "favorites" else "MONITORADOS"
        self.ticket_bookmark_heading.setText(f"CHAMADOS {label}")
        mapped = mapped_bookmarks(self.ticket_catalog, self.ticket_bookmarks, kind)
        terms = self.normalize_ticket_search(self.ticket_bookmark_search.text()).split()
        visible = [ticket for ticket in mapped if all(
            term in self.indexed_ticket_text(ticket)[0] for term in terms
        )]
        self.ticket_bookmark_count.setText(
            f"{len(visible)} de {len(mapped)} chamado(s) salvo(s). "
            "A situação mostrada é a última registrada localmente."
        )
        self.ticket_bookmark_refresh.setEnabled(not self.ticket_bookmark_refreshing and bool(mapped))
        if not visible:
            hint = QLabel("Nenhum chamado desta lista corresponde à busca." if mapped else
                          "Use a estrela ou o olho nos chamados mapeados ou recentes do usuário.")
            hint.setObjectName("faqFavoritesHint")
            hint.setWordWrap(True)
            rows.addWidget(hint)
        for ticket in visible:
            number = ticket_number(ticket.get("number") or ticket.get("id"))
            row = QFrame(objectName="faqFavoriteRow")
            box = QHBoxLayout(row)
            box.setContentsMargins(8, 7, 7, 7)
            box.setSpacing(6)
            information = QVBoxLayout()
            information.setContentsMargins(0, 0, 0, 0)
            information.setSpacing(3)
            open_button = QPushButton(f"#{number}  •  {ticket.get('title') or 'Sem título'}")
            open_button.setObjectName("faqFavoriteOpen")
            open_button.setToolTip("Abrir este chamado no Capri")
            open_button.setAccessibleName(f"Abrir chamado {number} no Capri")
            open_button.clicked.connect(lambda _checked=False, saved=ticket: self.open_ticket(
                str(saved.get("url") or ""), ticket_number(saved.get("number") or saved.get("id"))))
            information.addWidget(open_button)
            status_row = QHBoxLayout()
            status_row.setContentsMargins(7, 0, 0, 0)
            status_row.setSpacing(7)
            state_text = str(ticket.get("state") or "Não informada")
            state = QLabel(f"Situação: {state_text}")
            state.setObjectName({
                "open": "ticketStateOpen", "pending": "ticketStatePending",
                "closed_success": "ticketStateDone", "closed_other": "ticketStateClosed",
                "rejected": "ticketStateClosed", "customer_cancelled": "ticketStateClosed",
                "closed_unsuccessful": "ticketStateClosed",
            }.get(str(ticket.get("state_kind") or ""), "ticketStateClosed"))
            state.setToolTip(f"Última situação salva no catálogo local: {state_text}")
            status_row.addWidget(state, 0, Qt.AlignLeft)
            queue = QLabel(str(ticket.get("queue") or ticket.get("customer") or "Sem fila"))
            queue.setObjectName("ticketBookmarkQueue")
            queue.setWordWrap(True)
            status_row.addWidget(queue, 1)
            information.addLayout(status_row)
            box.addLayout(information, 1)
            remove = QPushButton()
            remove.setObjectName("faqFavoriteRemove")
            remove.setFixedSize(34, 34)
            remove.setToolTip("Remover desta lista")
            remove.setAccessibleName(f"Remover chamado {number} desta lista")
            set_button_icon(remove, "star" if kind == "favorites" else "eye", GOLD if kind == "favorites" else GREEN, 15)
            remove.clicked.connect(lambda _checked=False, value=number, selected=kind:
                                   self.toggle_ticket_bookmark(selected, value))
            box.addWidget(remove, 0, Qt.AlignVCenter)
            rows.addWidget(row)
        rows.addStretch(1)

    def toggle_ticket_bookmark(self, kind: str, number: str, ticket: dict | None = None):
        if number not in {ticket_number(item.get("number") or item.get("id"))
                          for item in self.ticket_catalog.get("items", []) if isinstance(item, dict)
                          } and number not in self.ticket_bookmarks.get("snapshots", {}) and ticket is None:
            show_notice(self, "Este chamado não está disponível nas consultas locais.")
            return None
        try:
            added, saved = toggle_bookmark(ticket_bookmarks_path(), kind, number, ticket=ticket)
        except (ValueError, OSError) as exc:
            show_notice(self, str(exc))
            return None
        self.ticket_bookmarks = saved
        if self.ticket_bookmark_popup.isVisible():
            self.render_ticket_bookmarks_popup()
        if self.current_section == "Chamados":
            self.current_columns = 0
            self.reflow()
        return added

    def refresh_ticket_bookmarks(self):
        if self.ticket_bookmark_refreshing or self.background_runner.state() != QProcess.NotRunning:
            show_notice(self, "Aguarde a atualização atual do Capri terminar.")
            return
        numbers = [ticket_number(item.get("number") or item.get("id")) for item in mapped_bookmarks(
            self.ticket_catalog, self.ticket_bookmarks, self.ticket_bookmark_kind)]
        if not numbers:
            return
        if not self._capri_session_password:
            show_notice(self, "Entre novamente no Capri para conferir as situações.")
            return
        self.ticket_bookmark_refreshing = True
        self.ticket_bookmark_refresh.setEnabled(False)
        set_refresh_icon_busy(self.ticket_bookmark_refresh, True)
        self.ticket_bookmark_count.setText(f"Consultando {len(numbers)} situação(ões) no Capri…")
        payload = json.dumps({"status_only": True, "recheck_numbers": numbers}, ensure_ascii=False)
        if not self.run_background_bridge(TICKET_CATALOG, "", payload):
            self.ticket_bookmark_refreshing = False
            set_refresh_icon_busy(self.ticket_bookmark_refresh, False)
            self.render_ticket_bookmarks_popup()


    def open_capri_login(
        self, map_after: bool = True, ticket_period_after: bool = False,
        enter_tickets_after: bool = False, enter_faqs_after: bool = False,
    ):
        self.faq_auth_prompt_open = True
        username, accepted = QInputDialog.getText(
            self, "Autenticação do Capri", "Usuário de rede do Capri:",
            QLineEdit.Normal, self.capri_username,
        )
        username = normalize_capri_login(username)
        if not accepted or not username:
            self.faq_auth_prompt_open = False
            return
        password, accepted = QInputDialog.getText(
            self, "Autenticação do Capri",
            "Senha do Capri (válida somente durante esta sessão do Atlas):",
            QLineEdit.Password,
        )
        if not accepted or not password:
            self.faq_auth_prompt_open = False
            return
        self.capri_username = username
        credential_write(username, password, "capri")
        self._capri_session_password = password
        password = ""
        self.faq_auth_prompt_open = False
        self.append_log("\n[CAPRI] Sessão autenticada até o fechamento do Atlas.\n")
        self.set_capri_connection_state(True)
        if enter_tickets_after:
            self.apply_filter("Chamados")
        if enter_faqs_after:
            self.apply_filter("FAQs")
        if map_after:
            self.request_faq_catalog(False)
        elif ticket_period_after:
            QTimer.singleShot(0, self.open_ticket_period_dialog)

    def set_capri_connection_state(self, connected: bool):
        for attribute in ("faq_capri_status", "ticket_capri_status"):
            label = getattr(self, attribute, None)
            if label is None:
                continue
            label.setText("Capri conectado" if connected else "Capri não conectado")
            label.setProperty("connected", connected)
            label.style().unpolish(label)
            label.style().polish(label)
        button = getattr(self, "capri_logout_button", None)
        if button is not None:
            button.setEnabled(connected)

    def run_capri_logout(self) -> tuple[bool, str]:
        QApplication.setOverrideCursor(Qt.WaitCursor)
        QApplication.processEvents()
        try:
            ok, details = terminate_capri_session()
        finally:
            QApplication.restoreOverrideCursor()
        if ok:
            self._capri_session_password = ""
            self.set_capri_connection_state(False)
            self.append_log("\n[CAPRI] Sessão web encerrada e confirmada pelo servidor.\n")
        return ok, details

    def end_capri_session(self):
        if not confirm_action(
            self,
            "Encerrar sessão Capri",
            "Deseja encerrar somente a sessão web do Capri? O perfil INS permanecerá aberto.",
        ):
            return
        ok, details = self.run_capri_logout()
        if ok:
            show_notice(self, "Sessão do Capri encerrada. O perfil INS permanece ativo.")
            return
        QMessageBox.warning(
            self,
            "Sessão do Capri ainda ativa",
            "O servidor não confirmou o logout. O perfil INS permanece aberto e não foi alterado.\n\n"
            f"Detalhes: {details or 'sem retorno do servidor'}",
        )

    def action_group(self, action: Action):
        if self.current_section == "Menu principal":
            return "MAIS UTILIZADOS NESTE PERFIL"
        if action.category == "Menu principal":
            if action.command in {"connect_toggle", "cmrc", "ping", "open_remote", "logoff", "restart"}:
                return "CONEXÃO E CONTROLE"
            if action.command in {"admin", "local_users", "ad", "ad_groups"}:
                return "USUÁRIOS E DIRETÓRIO"
            if action.command in {"disk_profiles", "inetcpl", "refresh"}:
                return "DIAGNÓSTICO E FERRAMENTAS"
            return "SESSÃO"
        if action.category == "Suporte remoto":
            if action.command in {"browser_open_chrome_cleanup", "browser_open_edge_cleanup", "browser_close_chrome", "browser_close_edge", "cert_list"}:
                return "NAVEGADORES E CERTIFICADOS"
            if action.command in {"ping", "outlook", "dns", "gpupdate", "temp", "trellix_config", "atlas_repair", "remote_process_list", "user_software_list"}:
                return "SUPORTE AO COMPUTADOR"
            if action.command == "open_main":
                return "NAVEGAÇÃO"
            return "SUPORTE A IMPRESSORAS"
        return self.current_section.upper()

    def apply_ticket_compact_layout(self, compact: bool):
        """Reorganiza a Central de chamados para caber integralmente no modo lateral."""
        if not hasattr(self, "ticket_actions_layout"):
            return
        self.ticket_panel_hint.setVisible(not compact)
        self.ticket_status_title.setVisible(not compact)
        self.ticket_clear_cache_button.setText("" if compact else "Limpar cache")
        self.ticket_refresh_cache_button.setText("" if compact else "Atualizar")
        self.ticket_search_button.setText("" if compact else "Pesquisar")
        for button in (self.ticket_clear_cache_button, self.ticket_refresh_cache_button):
            button.setFixedWidth(34 if compact else 0)
            button.setMinimumWidth(34 if compact else 0)
            button.setMaximumWidth(34 if compact else 16777215)
        self.ticket_search_button.setFixedWidth(42 if compact else 0)
        self.ticket_search_button.setMinimumWidth(42 if compact else 0)
        self.ticket_search_button.setMaximumWidth(42 if compact else 16777215)
        self.ticket_map_button.setText("Período e mapear" if compact else "Escolher período e mapear")
        actions = self.ticket_actions_layout
        actions.addWidget(self.ticket_map_button, 0, 1, Qt.AlignCenter)
        actions.setColumnStretch(0, 1)
        actions.setColumnStretch(2, 1)

    def apply_user_control_compact_layout(self, compact: bool):
        """Evita largura mínima excessiva no controle de usuários lateral."""
        self.user_control_compact = compact
        layout = self.user_control_layout
        for widget in (
            self.user_login_input, self.user_lookup_button,
            self.user_query_label, self.user_query_progress,
        ):
            layout.removeWidget(widget)

        if compact:
            layout.setContentsMargins(14, 12, 14, 13)
            layout.setHorizontalSpacing(7)
            layout.setVerticalSpacing(7)
            layout.addWidget(self.user_login_input, 0, 0, 1, 2)
            layout.addWidget(self.user_lookup_button, 1, 0, 1, 2)
            layout.addWidget(self.user_query_label, 2, 0, 1, 2)
            layout.addWidget(self.user_query_progress, 2, 0, 1, 2)
            layout.setColumnStretch(0, 1)
            layout.setColumnStretch(1, 1)
        else:
            layout.setContentsMargins(22, 17, 22, 18)
            layout.setHorizontalSpacing(9)
            layout.setVerticalSpacing(9)
            layout.addWidget(self.user_login_input, 0, 0)
            layout.addWidget(self.user_lookup_button, 0, 1)
            layout.addWidget(self.user_query_label, 1, 0, 1, 2)
            layout.addWidget(self.user_query_progress, 1, 0, 1, 2)
            layout.setColumnStretch(0, 1)
            layout.setColumnStretch(1, 0)
        self.refresh_user_lookup_button()

    def apply_station_control_compact_layout(self, compact: bool):
        """Mantém campo, ação e ferramentas dentro da largura lateral."""
        layout = self.connection_layout
        for widget in (
            self.connection_tools, self.target_input, self.connect_button,
            self.connection_label, self.connection_progress,
        ):
            layout.removeWidget(widget)

        if compact:
            layout.setContentsMargins(14, 12, 14, 13)
            layout.setHorizontalSpacing(7)
            layout.setVerticalSpacing(7)
            layout.addWidget(self.target_input, 0, 0, 1, 2)
            layout.addWidget(self.connect_button, 1, 0)
            layout.addWidget(self.connection_tools, 1, 1, Qt.AlignRight | Qt.AlignVCenter)
            layout.addWidget(self.connection_label, 2, 0, 1, 2)
            layout.addWidget(self.connection_progress, 2, 0, 1, 2)
            layout.setColumnStretch(0, 1)
            layout.setColumnStretch(1, 0)
            layout.setColumnStretch(2, 0)
        else:
            layout.setContentsMargins(22, 17, 22, 18)
            layout.setHorizontalSpacing(9)
            layout.setVerticalSpacing(9)
            layout.addWidget(self.target_input, 0, 0)
            layout.addWidget(self.connect_button, 0, 1)
            layout.addWidget(self.connection_tools, 0, 2, Qt.AlignRight | Qt.AlignVCenter)
            layout.addWidget(self.connection_label, 1, 0, 1, 3)
            layout.addWidget(self.connection_progress, 1, 0, 1, 3)
            layout.setColumnStretch(0, 1)
            layout.setColumnStretch(1, 0)
            layout.setColumnStretch(2, 0)

    def apply_user_result_compact_layout(self, compact: bool):
        """Compacta o painel de usuário preservando a grade informativa em duas colunas."""
        identity = self.user_identity_layout
        for widget in (self.user_identity_name_host, self.user_identity_login_host):
            identity.removeWidget(widget)

        available = self.scroll.viewport().width() if hasattr(self, "scroll") else self.width()
        stack_identity = compact and available < 430
        if compact:
            self.user_result_layout.setContentsMargins(12, 10, 12, 11)
            self.user_result_layout.setSpacing(7)
            self.user_fields_grid.setHorizontalSpacing(7)
            self.user_fields_grid.setVerticalSpacing(6)
            identity.setContentsMargins(5, 4, 5, 4)
        else:
            self.user_result_layout.setContentsMargins(18, 14, 18, 15)
            self.user_result_layout.setSpacing(8)
            self.user_fields_grid.setHorizontalSpacing(9)
            self.user_fields_grid.setVerticalSpacing(7)
            identity.setContentsMargins(6, 5, 6, 5)

        if stack_identity:
            identity.setHorizontalSpacing(0)
            identity.setVerticalSpacing(5)
            identity.addWidget(self.user_identity_name_host, 0, 0)
            identity.addWidget(self.user_identity_login_host, 1, 0)
            identity.setColumnStretch(0, 1)
            identity.setColumnStretch(1, 0)
        else:
            identity.setHorizontalSpacing(7)
            identity.setVerticalSpacing(0)
            identity.addWidget(self.user_identity_name_host, 0, 0)
            identity.addWidget(self.user_identity_login_host, 0, 1)
            identity.setColumnStretch(0, 1)
            identity.setColumnStretch(1, 1)

    def apply_printer_summary_compact_layout(self, compact: bool):
        """Reduz a barra de impressoras preservando os seis comandos."""
        controls = self.printer_summary_controls
        buttons = (
            self.printer_summary_refresh, self.printer_summary_ping, self.printer_summary_web,
            self.printer_summary_test_page, self.printer_summary_admin, self.printer_summary_logoff,
        )
        for button in buttons:
            controls.removeWidget(button)
        if compact:
            self.printer_summary_box.setContentsMargins(12, 11, 12, 12)
            self.printer_summary_network_layout.setContentsMargins(8, 7, 6, 7)
            for index, button in enumerate(buttons):
                button.setFixedSize(24, 24)
                controls.addWidget(button, index // 2, index % 2)
        else:
            self.printer_summary_box.setContentsMargins(16, 13, 16, 14)
            self.printer_summary_network_layout.setContentsMargins(10, 8, 7, 8)
            for index, button in enumerate(buttons):
                button.setFixedSize(28, 28)
                controls.addWidget(button, index // 3, index % 3)

    def reflow(self, forced_columns: int | None = None):
        if self.current_section == "Chamados" and self.ticket_entry_render_pending and forced_columns is None:
            return
        width = self.scroll.viewport().width() if hasattr(self, "scroll") else self.width()
        narrow = width < 620
        screen = self.window().screen() or QApplication.primaryScreen()
        available_width = screen.availableGeometry().width() if screen else self.window().width()
        snapped_half_screen = self.window().width() <= int(available_width * 0.72)
        # A organização do resumo depende somente do espaço disponível, nunca
        # do botão Modo lateral. Abrange meia tela e encaixes de 2/3 da tela.
        compact_status = width < 1200 or snapped_half_screen
        # A grade depende somente da largura real. Login INS, encaixe do
        # Windows e modo lateral passam a compartilhar o mesmo arranjo 2 x N.
        ticket_narrow = self.current_section == "Chamados" and width < 680
        if self.current_section == "Chamados":
            self.apply_ticket_compact_layout(ticket_narrow)
        self.apply_user_control_compact_layout(narrow)
        self.apply_station_control_compact_layout(narrow)
        self.apply_user_result_compact_layout(narrow)
        self.apply_printer_summary_compact_layout(narrow)
        # O painel lateral comporta dois cartões compactos. Uma coluna fica
        # reservada apenas para áreas realmente estreitas ou para Chamados.
        columns = forced_columns or (1 if width < 420 or ticket_narrow else 2)
        compact_actions = narrow
        if (columns == self.current_columns and self.current_status_compact == compact_status
                and self.current_action_compact == compact_actions
                and forced_columns is None):
            return
        self.current_columns = columns
        self.current_status_compact = compact_status
        self.current_action_compact = compact_actions
        self.action_grid.setHorizontalSpacing(10 if compact_actions else 12)
        self.action_grid.setVerticalSpacing(10 if compact_actions else 12)
        for _action, card in getattr(self, "cards", []):
            card.set_compact(compact_actions)
        self.clear_grid()
        if self.current_section == "Softwares autorizados":
            self.render_software_catalog(columns)
        elif self.current_section == "FAQs":
            self.render_faq_catalog(columns)
        elif self.current_section == "Orientações ao usuário":
            self.render_orientation_catalog(columns)
        elif self.current_section == "Chamados":
            self.render_ticket_catalog(columns)
        else:
            row = 0
            items = self.section_actions()
            groups = []
            for action, _card in items:
                group = self.action_group(action)
                if group not in groups:
                    groups.append(group)
            for group in groups:
                header = QLabel(group)
                header.setProperty("groupHeader", True)
                header.setObjectName("groupHeader")
                self.action_grid.addWidget(header, row, 0, 1, columns)
                row += 1
                group_items = [(a, c) for a, c in items if self.action_group(a) == group]
                if self.current_section == "Suporte remoto" and group == "SUPORTE AO COMPUTADOR":
                    computer_order = (
                        "atlas_repair", "gpupdate", "dns", "temp", "trellix_config", "outlook",
                    )
                    positions = {command: index for index, command in enumerate(computer_order)}
                    group_items.sort(key=lambda item: positions.get(item[0].command, len(positions)))
                for index, (_action, card) in enumerate(group_items):
                    card.show()
                    self.action_grid.addWidget(card, row + index // columns, index % columns)
                row += (len(group_items) + columns - 1) // columns
        QTimer.singleShot(0, self.reset_horizontal_scroll)
        # No modo lateral, a barra precisa continuar larga o suficiente para
        # preservar os rótulos; o espaço é recuperado reduzindo as margens.
        # Sem o ícone no rótulo mais longo, 204 px preservam o nome completo
        # e devolvem um pouco de largura ao catálogo no modo lateral.
        self.sidebar.setFixedWidth(178 if narrow else 216)
        self.side_layout.setContentsMargins(10 if narrow else 20, 20 if narrow else 26,
                                            10 if narrow else 20, 16 if narrow else 22)
        brand_size = 120 if narrow else 140
        if self.brand_mark.width() != brand_size:
            self.brand_mark.setFixedSize(brand_size, brand_size)
            self.brand_mark.setPixmap(atlas_brand_pixmap(
                "logo_compact_dark.png" if self.dark_mode else "logo_compact_light.png", brand_size,
            ))
        self.page_layout.setContentsMargins(12 if narrow else 30, 18 if narrow else 25,
                                            12 if narrow else 30, 24 if narrow else 34)
        self.brand_subtitle.setVisible(not narrow)

        # FAQs: no modo lateral o painel continua compacto, porém preserva as
        # informações e ações disponíveis no modo normal (status, origem da
        # pesquisa, cache e atualização). Somente os rótulos são abreviados.
        if hasattr(self, "faq_search_box"):
            self.faq_search_box.setContentsMargins(*( (10, 7, 10, 8) if narrow else (14, 12, 14, 13) ))
            self.faq_search_box.setSpacing(4 if narrow else 7)
            self.faq_search_hint.setVisible(True)
            self.faq_search_badge.setVisible(True)
            self.faq_capri_status.setVisible(True)
            self.faq_clear_cache_button.setVisible(True)
            self.faq_incremental_button.setVisible(True)
            self.faq_search_mode_label.setVisible(True)
            self.faq_search_hint.setText(
                "Filtra as FAQs salvas localmente." if narrow else
                "Digite abaixo para filtrar imediatamente as FAQs já salvas. Esta pesquisa não consulta o Capri nem altera a base."
            )
            self.faq_search_badge.setText("LOCAL" if narrow else "PESQUISA LOCAL")
            self.faq_search_mode_label.setText("BUSCA" if narrow else "MODO DA BUSCA")
            self.faq_clear_cache_button.setText("Cache" if narrow else "Limpar cache")
            self.faq_incremental_button.setText("Atualizar")
            self.faq_clear_cache_button.setFixedHeight(26 if narrow else 28)
            self.faq_incremental_button.setFixedHeight(26 if narrow else 28)
            self.faq_search_row.setContentsMargins(*( (8, 4, 8, 4) if narrow else (11, 6, 11, 6) ))
            self.faq_search_row.setSpacing(7 if narrow else 9)
            self.faq_search_input_frame.setMaximumHeight(38 if narrow else 16777215)
            self.faq_search.setPlaceholderText(
                "Pesquisar FAQs…" if narrow else
                "Pesquisar ferramenta, procedimento, título, categoria ou número da FAQ…"
            )
            self.faq_related_search_button.setText("Relacionada" if not narrow else "Relacionada")
            self.faq_title_search_button.setText("No título")

        self.hello_label.setProperty("compact", narrow)
        self.hello_label.style().unpolish(self.hello_label)
        self.hello_label.style().polish(self.hello_label)
        self.hello_label.show()
        for widget in (self.hello_host, self.top_actions_host, self.profile_host):
            self.top_layout.removeWidget(widget)
        if narrow:
            self.top_layout.addWidget(self.hello_host, 0, 0, 1, 2)
            self.top_layout.addWidget(self.profile_host, 1, 0, Qt.AlignLeft | Qt.AlignVCenter)
            self.top_layout.addWidget(self.top_actions_host, 1, 1, Qt.AlignRight | Qt.AlignVCenter)
        else:
            self.top_layout.addWidget(self.hello_host, 0, 0)
            self.top_layout.addWidget(self.top_actions_host, 0, 1, Qt.AlignRight | Qt.AlignVCenter)
            self.top_layout.addWidget(self.profile_host, 1, 0, Qt.AlignLeft)
        self.top_layout.setColumnStretch(0, 1)
        self.top_layout.setColumnStretch(1, 0)
        for _caption, _label, display_widget in self.status_labels.values():
            self.status_grid.removeWidget(display_widget)
        self.status_card.setProperty("compact", compact_status)
        self.status_card.style().unpolish(self.status_card)
        self.status_card.style().polish(self.status_card)
        self.status_box.setContentsMargins(*( (12, 9, 12, 10) if compact_status else (18, 14, 18, 14) ))
        self.status_box.setSpacing(6 if compact_status else 9)
        self.identity_layout.setContentsMargins(*( (5, 4, 5, 4) if compact_status else (7, 6, 7, 6) ))
        self.identity_layout.setHorizontalSpacing(7 if compact_status else 8)
        self.status_grid.setHorizontalSpacing(9 if compact_status else 18)
        self.status_grid.setVerticalSpacing(5 if compact_status else 7)
        self.admin_status_widget.layout().setContentsMargins(*( (6, 4, 5, 4) if compact_status else (8, 6, 6, 6) ))
        self.admin_status_widget.lock_button.setFixedSize(*( (22, 22) if compact_status else (24, 24) ))
        printers_widget = self.status_labels["printers"][2]
        printers_widget.layout().setContentsMargins(*( (7, 5, 5, 5) if compact_status else (9, 7, 6, 7) ))
        quick_size = 24 if compact_status else 28
        self.printer_ping_button.setFixedSize(quick_size, quick_size)
        self.printer_web_button.setFixedSize(quick_size, quick_size)
        pulse_size = 28 if compact_status else 34
        pulse_icon_size = 17 if compact_status else 20
        self.status_pulse.setFixedSize(pulse_size, pulse_size)
        self.paint_station_icon(self.connection_active, pulse_icon_size)
        if compact_status:
            # Informações curtas em 2 colunas; listas extensas usam toda a
            # largura para continuar legíveis sem alongar demais o painel.
            short_keys = ("windows", "admin", "rdp", "uptime", "disk_d", "sccm")
            for index, key in enumerate(short_keys):
                self.status_grid.addWidget(self.status_labels[key][2], index // 2, index % 2)
            self.status_grid.addWidget(self.status_labels["printers"][2], 3, 0, 1, 2)
            self.status_grid.addWidget(self.status_labels["printer_groups"][2], 4, 0, 1, 2)
            if self.last_status_data:
                station = str(self.last_status_data.get("station", self.target))
                if str(self.last_status_data.get("status", "")).lower() == "conectado":
                    self.status_title.setText("ESTAÇÃO CONECTADA")
                else:
                    self.status_title.setText(f"ESTAÇÃO SEM RESPOSTA  •  {station}")
        else:
            for index, (_caption, _label, display_widget) in enumerate(self.status_labels.values()):
                self.status_grid.addWidget(display_widget, index // 2, index % 2)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "useful_links_popup") and self.useful_links_popup.isVisible():
            self.useful_links_popup.hide()
        if hasattr(self, "templates_popup") and self.templates_popup.isVisible():
            self.templates_popup.hide()
        self.reflow()

    def enable_compact_mode(self):
        window = self.window()
        self.compact_mode = True
        target_screen, target_side = next_lateral_slot(window)
        window.enter_lateral_mode(target_screen, target_side)
        # O resizeEvent reorganiza somente se a quantidade de colunas mudar;
        # evita reconstruir catálogos já renderizados ao trocar de monitor.
        self.reflow()
        QTimer.singleShot(0, self.update_side_mode_direction)

    def update_side_mode_direction(self):
        """Mantém a seta do painel apontada para o próximo monitor."""
        if not hasattr(self, "side_mode_button"):
            return
        window = self.window()
        target_screen, target_side = next_lateral_slot(window)
        self.side_mode_button.set_direction(lateral_slot_direction(window, target_screen, target_side))

    def append_log(self, text: str):
        self.command_output += text
        self.log.moveCursor(QTextCursor.End)
        self.log.insertPlainText(text)
        self.log.ensureCursorVisible()
        if (
            self.pending_action == "status"
            and not getattr(self, "_status_core_received", False)
            and "@@STATUS@@" in self.command_output
        ):
            self.update_status_panel(self.command_output)
            if self.connection_active:
                self._status_core_received = True
                self.set_connection_progress_stage(
                    35, "Dados principais do micro carregados; concluindo detalhes da estação…"
                )
                self.connection_label.setText("Dados principais carregados; concluindo detalhes da estação…")

    def _append_user_log(self, text: str):
        """Registra somente mensagens operacionais, nunca marcadores ou dados privados."""
        visible = re.sub(
            r"@@(?:USERCONTROL|PASSWORD_MANAGER_USER|PASSWORD_MANAGER_SESSION|PASSWORD_MANAGER_CHROME_SESSION|PASSWORD_MANAGER_LOGOUT|"
            r"PASSWORD_MANAGER_EXPIRED|PASSWORD_RECOVERY_PREVIEW|PASSWORD_RECOVERY_SENT)@@[^\r\n]*",
            "", text,
        )
        visible = visible.strip()
        if not visible:
            return
        self.log.moveCursor(QTextCursor.End)
        self.log.insertPlainText(visible + "\n")
        self.log.ensureCursorVisible()

    @staticmethod
    def normalize_user_lookup_login(value: str) -> str:
        login = str(value or "").strip()
        if "\\" in login:
            login = login.rsplit("\\", 1)[-1]
        if "@" in login:
            login = login.split("@", 1)[0]
        return login.strip()

    @staticmethod
    def masked_email(value: object) -> str:
        email = str(value or "").strip()
        if not email or email == "Não informado" or "@" not in email:
            return email or "Não informado"
        if "*" in email:
            return email
        local, domain = email.split("@", 1)
        local_mask = (local[:1] or "*") + "*" * max(4, len(local) - 1)
        domain_parts = domain.split(".")
        domain_head = domain_parts[0]
        protected_head = (domain_head[:1] or "*") + "*" * max(3, len(domain_head) - 1)
        suffix = "." + ".".join(domain_parts[1:]) if len(domain_parts) > 1 else ""
        return f"{local_mask}@{protected_head}{suffix}"

    def control_tab_changed(self, index: int):
        self.update_information_cards_visibility()
        if index == 1:
            QTimer.singleShot(0, self.user_login_input.setFocus)

    def update_information_cards_visibility(self):
        user_mode = self.control_tabs.currentIndex() == 1
        on_information = self.current_section == "Menu principal"
        full = bool(getattr(self.window(), "is_full_display_mode", lambda: False)())
        self.status_card.setVisible(on_information and (full or not user_mode) and bool(self.last_status_data))
        self.user_result_card.setVisible(on_information and (full or user_mode) and bool(self.user_control_data))

    def refresh_user_lookup_button(self):
        """Mantém a ação coerente entre Consultar e Nova consulta."""
        if self.user_lookup_complete:
            self.user_lookup_button.setText("Nova consulta")
            self.user_lookup_button.setObjectName("disconnectButton")
            self.user_lookup_button.setAccessibleName("Iniciar uma nova consulta de usuário")
            set_button_icon(self.user_lookup_button, "refresh", "#FFFFFF", 14)
        else:
            label = "Consultar" if self.user_control_compact else "Consultar usuário"
            self.user_lookup_button.setText(label)
            self.user_lookup_button.setObjectName("primaryButton")
            self.user_lookup_button.setAccessibleName("Consultar usuário no Active Directory")
            set_button_icon(self.user_lookup_button, "search", "#FFFFFF", 14)
        self.user_lookup_button.style().unpolish(self.user_lookup_button)
        self.user_lookup_button.style().polish(self.user_lookup_button)

    def handle_user_lookup_button(self):
        if self.user_query_active:
            return
        if self.user_lookup_complete:
            self.start_new_user_query()
            return
        self.lookup_user_control()

    def refresh_user_information(self):
        """Repete a consulta do usuário exibido, ignorando o cache de curta duração."""
        if self.user_query_active:
            return
        login = self.normalize_user_lookup_login(
            self.user_control_data.get("login") or self.user_login_input.text()
        )
        if not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", login):
            show_notice(self, "Não há um usuário válido para atualizar.")
            return
        self.user_login_input.setText(login)
        self.reset_user_ticket_preview("Atualizando informações e chamados do usuário…")
        self.user_query_progress_value = 4
        self.lookup_user_control(force_refresh=True)

    def user_login_edited(self, value: str):
        """Uma edição manual já caracteriza a preparação de uma nova consulta."""
        if not self.user_lookup_complete:
            return
        loaded_login = str(self.user_control_data.get("login") or "").casefold()
        if self.normalize_user_lookup_login(value).casefold() != loaded_login:
            self.user_lookup_complete = False
            self.refresh_user_lookup_button()

    def start_new_user_query(self):
        self.user_lookup_complete = False
        self.user_control_data = {}
        self.update_printer_color_permission()
        self.reset_user_ticket_preview("Aguardando nova consulta de usuário.")
        self.password_expiration_source = ""
        self.user_login_input.clear()
        self.user_result_card.hide()
        self.user_information_refresh_button.setEnabled(False)
        self.user_query_label.setText(
            "Os dados da conta, da senha e do vencimento são consultados diretamente no Active Directory."
        )
        self.refresh_user_lookup_button()
        self.update_quick_ad_availability()
        self.user_login_input.setFocus()

    def copy_user_login(self):
        login = str(self.user_control_data.get("login") or "").strip()
        if not login:
            return
        QApplication.clipboard().setText(login)
        set_button_icon(self.user_login_copy_button, "check", GREEN, 11)
        self.user_login_copy_button.setToolTip(f"Login copiado: {login}")
        QTimer.singleShot(1200, self.restore_user_login_copy_button)

    def restore_user_login_copy_button(self):
        set_button_icon(self.user_login_copy_button, "copy", BLUE_2, 11)
        self.user_login_copy_button.setToolTip("Copiar login de rede")

    def update_quick_ad_availability(self):
        has_user = bool(str(self.user_control_data.get("login") or "").strip())
        available = has_user or (self.connection_active and bool(self.station_user_login(self.last_status_data.get("user"))))
        self.quick_ad_button.setEnabled(available)
        self.quick_ad_user_button.setEnabled(available)

    def advance_user_query_progress(self):
        if not self.user_query_active:
            self.user_query_progress_timer.stop()
            return
        increment = 2 if self.user_query_progress_value < 60 else 1
        self.user_query_progress_value = min(94, self.user_query_progress_value + increment)
        self.user_query_progress.setValue(self.user_query_progress_value)

    def set_user_query_state(self, active: bool, message: str = "", completed: bool = True):
        was_active = self.user_query_active
        self.user_query_active = active
        for widget in (self.user_login_input, self.user_lookup_button):
            widget.setEnabled(not active)
        if hasattr(self, "user_information_refresh_button"):
            self.user_information_refresh_button.setEnabled(not active and bool(self.user_control_data))
            set_refresh_icon_busy(self.user_information_refresh_button, active)
        if active:
            if not was_active:
                self.user_query_progress_generation += 1
            self.user_query_label.hide()
            self.user_query_progress_value = max(4, self.user_query_progress_value)
            self.user_query_progress.setValue(self.user_query_progress_value)
            self.user_query_progress.setFormat(message or "Consultando usuário…")
            self.user_query_progress.show()
            self.user_query_progress_timer.start()
        else:
            self.user_query_progress_timer.stop()
            generation = self.user_query_progress_generation
            if completed:
                self.user_query_progress.setValue(100)
                self.user_query_progress.setFormat(message or "Consulta concluída.  •  %p%")
                self.user_query_progress.show()
                QTimer.singleShot(800, lambda g=generation: self.hide_user_query_progress(g))
            else:
                self.user_query_progress_value = min(99, max(25, self.user_query_progress_value))
                self.user_query_progress.setValue(self.user_query_progress_value)
                self.user_query_progress.setFormat(message or "Consulta concluída parcialmente.")
                self.user_query_progress.show()
                QTimer.singleShot(2200, lambda g=generation: self.hide_user_query_progress(g))
            self.user_query_label.show()
            self.user_login_input.setEnabled(True)
            self.user_lookup_button.setEnabled(True)

    def hide_user_query_progress(self, generation: int):
        if generation == self.user_query_progress_generation and not self.user_query_active:
            self.user_query_progress.hide()

    def set_password_manager_connection_state(self, connected: bool, message: str = ""):
        self.password_manager_connected = connected
        if connected:
            self.password_manager_lookup_failed = False
        self.password_manager_status.setText(
            message or ("Gestor de Senhas conectado" if connected else "Gestor de Senhas não conectado")
        )
        self.password_manager_status.setProperty("connected", connected)
        self.password_manager_status.style().unpolish(self.password_manager_status)
        self.password_manager_status.style().polish(self.password_manager_status)
        if not self.user_query_active:
            self.password_manager_button.setEnabled(True)
        if connected:
            self.password_manager_button.setToolTip("Encerrar somente a sessão do Gestor de Senhas (PWM)")
            self.password_manager_button.setAccessibleName("Encerrar sessão do Gestor de Senhas PWM")
            set_button_icon(self.password_manager_button, "logout", "#9ED4EC", 16)
        else:
            self.password_manager_button.setToolTip("Conectar ao Gestor de Senhas (PWM)")
            self.password_manager_button.setAccessibleName("Conectar ao Gestor de Senhas PWM")
            set_button_icon(self.password_manager_button, "lock", "#9ED4EC", 16)

    def toggle_password_manager_session(self):
        """Usa um único controle PWM para conectar ou encerrar a sessão isolada."""
        if self.user_query_active:
            return
        if self.password_manager_connected:
            self.end_password_manager_session()
        else:
            self.connect_password_manager()

    def run_user_bridge(
        self, action: str, value: str = "", environment: dict[str, str] | None = None,
        payload: dict | None = None, timeout_ms: int = 60000,
    ) -> bool:
        if self.user_runner.state() != QProcess.NotRunning:
            show_notice(self, "Aguarde a consulta de usuário atual terminar.")
            return False
        self.user_pending_action = action
        self.user_pending_payload = dict(payload or {})
        self.user_output = ""
        launcher = str(resource_path("scripts/bridge_launcher.ps1"))
        bridge = str(resource_path("scripts/bridge.ps1"))
        args = ["-Script", bridge, "-Action", action, "-Computer", "", "-Value", value]
        return self.user_runner.run_script(launcher, args, environment or {}, timeout_ms=timeout_ms)

    def _append_user_output(self, text: str):
        self.user_output += text
        self._append_user_log(text)

    def _request_pwm_browser_session(self, login: str):
        """Solicita os cookies da aba PWM no navegador definido nas configurações."""
        self.pending_pwm_cookie_sync_login = login
        if not self.pwm_chrome_relay.request_cookie_sync(login):
            self.set_user_query_state(False)
            self.set_password_manager_connection_state(False, "A ponte do Chrome não está disponível")
            show_notice(self, "Não foi possível iniciar a ponte local do PWM.")
            return
        browser_label = dict(BROWSER_OPTIONS).get(preferred_browser(), "navegador padrão do Windows")
        self.set_user_query_state(True, f"Abrindo o PWM no {browser_label}…")
        self.append_log(f"\n[PWM] Solicitando a sessão ativa no {browser_label}…\n")
        opened, _browser, _fallback = open_password_manager_in_selected_browser()
        if not opened:
            self.set_user_query_state(False)
            self.set_password_manager_connection_state(False, f"Não foi possível abrir o PWM no {browser_label}")
            show_notice(self, f"O {browser_label} não pôde ser aberto para validar a sessão ativa do PWM.")
            return
        QTimer.singleShot(30000, self._pwm_chrome_sync_timeout)

    def _pwm_chrome_sync_timeout(self):
        if not self.pending_pwm_cookie_sync_login:
            return
        login = self.pending_pwm_cookie_sync_login
        self.pending_pwm_cookie_sync_login = ""
        self.set_user_query_state(False)
        self.set_password_manager_connection_state(False, "PWM não autenticado no Chrome")
        self.append_log("[PWM] Nenhuma sessão autenticada foi recebida do Chrome.\n")
        if self.user_control_data:
            self.password_manager_lookup_failed = True
            self.render_user_control_data()
        self.user_query_label.setText(
            "O navegador escolhido não entregou uma sessão ativa do PWM."
            if login == "__connect__"
            else f"O navegador escolhido não entregou uma sessão ativa do PWM para SENADO\\{login}."
        )

    def _pwm_chrome_cookies_received(self, payload: dict):
        if not self.pending_pwm_cookie_sync_login:
            return
        login = self.pending_pwm_cookie_sync_login
        cookies = payload.get("cookies") if isinstance(payload, dict) else None
        if not payload.get("ok") or not isinstance(cookies, list) or not cookies:
            self._pwm_chrome_sync_timeout()
            return
        self.pending_pwm_cookie_sync_login = ""
        value = json.dumps(cookies, ensure_ascii=False, separators=(",", ":"))
        self.set_user_query_state(True, "Validando a sessão ativa do PWM no Chrome…")
        if not self.run_user_bridge(
            "password_manager_import_cookies", value,
            payload={"login": login}, timeout_ms=25000,
        ):
            self.set_user_query_state(False)

    def connect_password_manager(self):
        if self.user_query_active:
            return
        self.pending_pwm_lookup_login = ""
        self._request_pwm_browser_session("__connect__")

    def _begin_password_manager_browser(self, interactive: bool):
        if self.password_manager_browser_starting:
            return
        self.password_manager_browser_starting = True

        def launch():
            ok, port, detail = request_password_manager_browser(interactive)
            self.password_manager_browser_ready.emit(ok, port, detail, interactive)

        threading.Thread(target=launch, name="atlas-pwm-browser", daemon=True).start()

    def _password_manager_browser_started(self, ok: bool, port: int, detail: str, interactive: bool):
        self.password_manager_browser_starting = False
        if not ok or not port:
            self.pending_pwm_lookup_login = ""
            self.pwm_lookup_reauth_attempted = False
            self.set_user_query_state(False)
            self.set_password_manager_connection_state(False, "Não foi possível abrir o perfil exclusivo do PWM")
            show_notice(self, detail or "O navegador exclusivo do PWM não pôde ser iniciado.")
            return
        if interactive:
            self.user_query_progress.setFormat("Faça o login na janela exclusiva do PWM…")
            self.append_log("[PWM] Janela exclusiva aberta; aguardando a autenticação do operador…\n")
        value = json.dumps({"port": port, "interactive": interactive}, separators=(",", ":"))
        timeout = 310000 if interactive else 30000
        if not self.run_user_bridge(
            "password_manager_browser_session", value,
            payload={"interactive": interactive}, timeout_ms=timeout,
        ):
            self.set_user_query_state(False)

    def end_password_manager_session(self):
        if not confirm_action(
            self, "Encerrar Gestor de Senhas",
            "Deseja remover somente a sessão protegida do ATLAS? O Chrome continuará logado no PWM.",
        ):
            return
        self.pending_pwm_cookie_sync_login = ""
        self.pending_pwm_lookup_login = ""
        try:
            password_manager_session_path().unlink(missing_ok=True)
        except OSError:
            pass
        self.set_password_manager_connection_state(False, "PWM desconectado somente do ATLAS")
        self.set_user_query_state(False)
        self.user_control_data.pop("password_manager", None)
        if self.user_control_data:
            self.render_user_control_data()

    def _reset_password_manager_profile_async(self):
        def reset():
            ok, detail = reset_password_manager_browser_profile()
            self.password_manager_profile_reset.emit(ok, detail)

        threading.Thread(target=reset, name="atlas-pwm-reset", daemon=True).start()

    def _password_manager_profile_reset_done(self, ok: bool, detail: str):
        if ok:
            show_notice(self, "Sessão e perfil exclusivo do PWM encerrados. Capri e INS permanecem ativos.")
        else:
            show_notice(self, f"A sessão local foi encerrada, mas o perfil do navegador não pôde ser removido.\n\n{detail}")

    def lookup_user_control(self, force_refresh: bool = False):
        if self.user_query_active:
            return
        login = self.normalize_user_lookup_login(self.user_login_input.text())
        if not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", login):
            show_notice(self, "Informe um login de rede válido.")
            self.user_login_input.setFocus()
            return
        self.user_login_input.setText(login)
        loaded_login = str(self.user_control_data.get("login") or "").casefold()
        if loaded_login and login.casefold() != loaded_login:
            self.user_control_data = {}
            self.update_printer_color_permission()
            self.reset_user_ticket_preview("Usuário alterado; aguardando consulta.")
            self.user_result_card.hide()
            self.update_quick_ad_availability()
        cache = self.user_control_cache.get(login.casefold())
        force_refresh = bool(force_refresh or QApplication.keyboardModifiers() & Qt.ShiftModifier)
        if cache and not force_refresh and time.monotonic() - float(cache.get("time", 0)) <= 45:
            self.user_control_data = dict(cache.get("data") or {})
            self.render_user_control_data()
            full_name = str(self.user_control_data.get("display_name") or "").strip()
            self.set_user_query_state(False, "Informações do usuário disponíveis no AD.  •  %p%")
            self.finish_station_enrichment(True, "Estação e usuário carregados.")
            QTimer.singleShot(0, lambda u=login, n=full_name: self.start_user_ticket_preview(u, n))
            return
        self.user_query_progress_value = 4
        self.set_user_query_state(True, f"Consultando SENADO\\{login} no Active Directory…")
        self.append_log(f"\n[USUÁRIO] Consultando SENADO\\{login} no Active Directory…\n")
        if not self.run_user_bridge("user_control_lookup", login, timeout_ms=45000):
            self.set_user_query_state(False, "Consulta não iniciada.", completed=False)
            self.finish_station_enrichment(False, "Consulta parcial: não foi possível iniciar a consulta ao AD.")

    def _start_password_manager_user_lookup(self, login: str):
        """Pergunta sempre como o operador deseja tratar o PWM nesta solicitação."""
        self.set_user_query_state(False)
        self.password_manager_lookup_skipped = False
        self.password_manager_lookup_failed = False
        self.pwm_lookup_reauth_attempted = False
        if self.user_control_data:
            self.user_control_data.pop("password_manager", None)
            self.render_user_control_data()

        choice = ask_password_manager_session(self)
        if choice == "ad_only":
            self.password_manager_lookup_skipped = True
            self.pending_pwm_lookup_login = ""
            self.render_user_control_data()
            self.user_query_label.setText(
                "Consulta concluída no Active Directory; o PWM não foi consultado nesta solicitação."
            )
            return

        self.pending_pwm_lookup_login = login
        if choice == "open":
            self.pwm_lookup_reauth_attempted = True
            self.set_password_manager_connection_state(False, "Aguardando autenticação no PWM sob demanda")
            self._request_pwm_browser_session(login)
            return

        if not self.password_manager_connected:
            self.pwm_lookup_reauth_attempted = True
            self._request_pwm_browser_session(login)
            return

        self._run_password_manager_user_lookup(login)

    def _run_password_manager_user_lookup(self, login: str):
        """Executa a consulta somente após a decisão explícita do operador."""
        self.password_manager_lookup_skipped = False
        self.password_manager_lookup_failed = False
        if self.user_control_data:
            # Nunca apresenta dados PWM antigos enquanto uma nova leitura está em andamento.
            self.user_control_data.pop("password_manager", None)
            self.render_user_control_data()
        contact = dict(self.user_control_data.get("contact") or {})
        payload = {
            "login": login,
            "full_name": str(self.user_control_data.get("display_name") or "").strip(),
            "institutional_email": str(contact.get("E-mail institucional") or "").strip(),
        }
        self.user_query_progress_value = max(55, self.user_query_progress_value)
        self.set_user_query_state(True, "Active Directory concluído; consultando o Gestor de Senhas…")
        value = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        if not self.run_user_bridge(
            "password_manager_user_lookup", value, payload=payload, timeout_ms=85000,
        ):
            self.set_user_query_state(False)

    @staticmethod
    def _information_value(values: dict, *keys: str, fallback: str = "Não informado") -> str:
        for key in keys:
            value = str(values.get(key) or "").strip()
            if value and value.casefold() != "não informado":
                return value
        return fallback

    @staticmethod
    def format_company_name(value: object) -> str:
        """Suaviza nomes integralmente em caixa alta sem alterar o dado vindo do AD."""
        visible = str(value or "").strip() or "Não informado"
        if not visible.isupper():
            return visible
        formatted = visible.casefold().title()
        for connector in (" Da ", " Das ", " De ", " Do ", " Dos ", " E "):
            formatted = formatted.replace(connector, connector.lower())
        return formatted

    @staticmethod
    def parse_password_expiration(value: object) -> datetime | None:
        raw = str(value or "").strip()
        if not raw or raw.casefold() == "não informado":
            return None
        months = {
            "janeiro": 1, "fevereiro": 2, "marco": 3, "abril": 4, "maio": 5, "junho": 6,
            "julho": 7, "agosto": 8, "setembro": 9, "outubro": 10, "novembro": 11, "dezembro": 12,
        }
        normalized = unicodedata.normalize("NFKD", raw)
        normalized = "".join(char for char in normalized if not unicodedata.combining(char)).casefold()
        match = re.search(
            r"(\d{1,2})\s+de\s+([a-z]+)\s+de\s+(\d{4})(?:\s+as\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?",
            normalized,
        )
        if match and match.group(2) in months:
            try:
                return datetime(
                    int(match.group(3)), months[match.group(2)], int(match.group(1)),
                    int(match.group(4) or 0), int(match.group(5) or 0), int(match.group(6) or 0),
                )
            except ValueError:
                return None
        cleaned = re.sub(r"\s+(?:BRT|UTC(?:[+-]\d{1,2})?)$", "", raw, flags=re.IGNORECASE)
        for date_format in ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%d/%m/%Y"):
            try:
                return datetime.strptime(cleaned, date_format)
            except ValueError:
                continue
        return None

    def update_password_expiration_countdown(self):
        raw = self.password_expiration_source
        expiration = self.parse_password_expiration(raw)
        if expiration is None:
            self.password_expiration_card.set_value(raw or "PWM não conectado")
            return
        seconds = (expiration - datetime.now()).total_seconds()
        if seconds > 0:
            days = max(1, int((seconds + 86399) // 86400))
            countdown = "1 dia restante" if days == 1 else f"{days} dias restantes"
        elif seconds > -86400:
            countdown = "expira hoje"
        else:
            elapsed = max(1, int(abs(seconds) // 86400))
            countdown = "expirada há 1 dia" if elapsed == 1 else f"expirada há {elapsed} dias"
        self.password_expiration_card.set_value(f"{raw}  •  {countdown}")

    def missing_pwm_value(self, manager_data: dict) -> str:
        if manager_data:
            return "Não informado"
        if self.password_manager_lookup_skipped:
            return "Não consultado nesta solicitação"
        if not self.password_manager_connected:
            return "PWM não conectado"
        if self.password_manager_lookup_failed:
            return "Consulta PWM não concluída"
        return "Consultando PWM…"

    def render_user_control_data(self):
        data = self.user_control_data
        if not data:
            self.user_result_card.hide()
            self.update_printer_color_permission()
            return
        self.user_lookup_complete = True
        self.refresh_user_lookup_button()
        self.update_quick_ad_availability()
        self.user_information_refresh_button.setEnabled(not self.user_query_active)
        display_name = str(data.get("display_name") or data.get("user") or "Usuário consultado")
        login = str(data.get("login") or self.user_login_input.text()).strip()
        self.user_tickets_card.set_identity(display_name)
        if self.user_ticket_preview_login.casefold() != login.casefold():
            self.reset_user_ticket_preview("A consulta dos chamados começará após a leitura do AD.")
        self.user_identity_name.setText(f"NOME COMPLETO\n{display_name}")
        identity_login_value = f"SENADO\\{login}"
        self.user_identity_login.setText(f"LOGIN DE REDE\n{identity_login_value}")
        self.user_identity_name_host.set_copy_value(f"Nome completo: {display_name}")
        self.user_identity_login_host.set_copy_value(identity_login_value)
        self.user_result_heading.setText("INFORMAÇÕES DO USUÁRIO")
        contact = dict(data.get("contact") or {})
        organization = dict(data.get("organization") or {})
        account = dict(data.get("account") or {})
        password = dict(data.get("password") or {})
        profile = dict(data.get("profile") or {})
        values = {
            "status": self._information_value(account, "Status da conta"),
            "company": self.format_company_name(self._information_value(organization, "Empresa")),
            "department": self._information_value(organization, "Departamento"),
            "title": self._information_value(organization, "Cargo"),
            "unit_room": self._information_value(organization, "Unidade / sala", "Unidade-Sala"),
            "manager": self._information_value(organization, "Gestor"),
            "institutional_email": self._information_value(contact, "E-mail institucional"),
            "logon_script": self._information_value(profile, "Script de logon"),
        }
        for key, value in values.items():
            self.user_field_cards[key].set_value(value)
        normalized_status = PasswordExpiryStatusCard._normalized(values["status"])
        status_card = self.user_field_cards["status"]
        status_card.setProperty(
            "fieldState", "active"
            if normalized_status in {"ativa", "ativo", "active", "habilitada", "habilitado", "enabled"}
            else "neutral",
        )
        status_card.style().unpolish(status_card)
        status_card.style().polish(status_card)
        expired = self._information_value(password, "Senha expirada no AD")
        self.password_expiry_status.set_state(expired)
        self.password_expiration_source = self._information_value(password, "Vencimento calculado")
        self.update_password_expiration_countdown()
        phone_fields = (
            ("Comercial", "Telefone comercial"),
            ("Residência", "Residência"),
            ("Pager", "Pager"),
            ("Celular", "Celular"),
            ("Fax", "Fax"),
            ("Telefone IP", "Telefone IP"),
        )
        phone_values = []
        for label, key in phone_fields:
            value = self._information_value(contact, key)
            if value.casefold() != "não informado":
                phone_values.append(f"{label}: {value}")
        self.user_phones_card.set_value("  •  ".join(phone_values) or "Não informado")
        self.user_notes_card.set_value(data.get("notes") or "Não informado")
        self.update_printer_color_permission()
        self.update_information_cards_visibility()

    def reset_user_ticket_preview(self, message: str = "Aguardando consulta"):
        self.user_ticket_preview_generation += 1
        self.user_ticket_preview_items = []
        self.user_ticket_preview_login = ""
        self.user_ticket_preview_name = ""
        self.user_ticket_preview_status = "idle"
        self.user_ticket_preview_loading = False
        self.user_ticket_preview_percent = 2
        if hasattr(self, "user_tickets_card"):
            self.user_tickets_card.refresh_button.setEnabled(True)
            set_refresh_icon_busy(self.user_tickets_card.refresh_button, False)
            set_button_icon(self.user_tickets_card.refresh_button, "refresh", BLUE_2, 13)
            self.user_tickets_card.set_status(message)
        if self.user_ticket_dialog is not None:
            self.user_ticket_dialog.set_error(message)

    def open_user_ticket_preview(self):
        data = self.user_control_data
        login = str(data.get("login") or "").strip()
        full_name = str(data.get("display_name") or "").strip()
        if not login or not full_name:
            show_notice(self, "Consulte primeiro um usuário no Active Directory.")
            return
        dialog = UserTicketsDialog(
            full_name, self.open_ticket,
            lambda kind, ticket: self.toggle_ticket_bookmark(
                kind, ticket_number(ticket.get("number") or ticket.get("id")), ticket=ticket
            ),
            lambda kind, number: number in self.ticket_bookmarks[kind],
            self,
        )
        self.user_ticket_dialog = dialog
        dialog.refresh_requested.connect(self.refresh_user_ticket_preview)
        dialog.finished.connect(lambda _result, current=dialog: self._user_ticket_dialog_closed(current))
        if self.user_ticket_preview_status == "ready" and self.user_ticket_preview_login.casefold() == login.casefold():
            dialog.set_tickets(self.user_ticket_preview_items)
        elif self.user_ticket_preview_loading and self.user_ticket_preview_login.casefold() == login.casefold():
            dialog.set_progress(self.user_ticket_preview_percent, "Consultando os últimos 25 chamados no Capri…")
        else:
            dialog.set_progress(2, "Iniciando consulta dos chamados recentes no Capri…")
            self.start_user_ticket_preview(login, full_name)
        dialog.show()

    def refresh_user_ticket_preview(self):
        """Atualiza manualmente os chamados recentes sem alterar a Central de Chamados."""
        if self.user_ticket_preview_loading:
            return
        data = self.user_control_data
        login = str(data.get("login") or "").strip()
        full_name = str(data.get("display_name") or "").strip()
        if not login or not full_name:
            show_notice(self, "Consulte primeiro um usuário no Active Directory.")
            return
        if self.user_ticket_dialog is None:
            self.open_user_ticket_preview()
            if self.user_ticket_preview_loading:
                return
        if self.user_ticket_dialog is not None:
            self.user_ticket_dialog.set_progress(2, "Atualizando os chamados recentes no Capri…")
            self.user_ticket_dialog.show()
            self.user_ticket_dialog.raise_()
            self.user_ticket_dialog.activateWindow()
        self.start_user_ticket_preview(login, full_name)

    def _user_ticket_dialog_closed(self, dialog: UserTicketsDialog):
        if self.user_ticket_dialog is dialog:
            self.user_ticket_dialog = None

    def start_user_ticket_preview(self, login: str, full_name: str, from_station: bool = False):
        login = self.normalize_user_lookup_login(login)
        full_name = re.sub(r"\s+", " ", str(full_name or "")).strip()
        if not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", login) or not full_name:
            self.user_ticket_preview_status = "failed"
            self.user_ticket_preview_loading = False
            self.user_tickets_card.set_status("Login ou nome do AD indisponível para consultar o Capri.")
            return
        if self.user_ticket_preview_loading and self.user_ticket_preview_login.casefold() == login.casefold():
            return
        self.user_ticket_preview_generation += 1
        generation = self.user_ticket_preview_generation
        self.user_ticket_preview_login = login
        self.user_ticket_preview_name = full_name
        self.user_ticket_preview_items = []
        self.user_ticket_preview_status = "loading"
        self.user_ticket_preview_loading = True
        self.user_ticket_preview_percent = 2
        self.user_ticket_preview_wait_started = time.monotonic()
        self.user_tickets_card.set_identity(full_name)
        self.user_tickets_card.set_status("Consultando os últimos 25 chamados no Capri…")
        self.user_tickets_card.refresh_button.setEnabled(False)
        set_refresh_icon_busy(self.user_tickets_card.refresh_button, True)
        if self.user_ticket_dialog is not None:
            self.user_ticket_dialog.set_progress(2, "Atualizando os últimos 25 chamados no Capri…")
        self._try_start_user_ticket_preview(generation, login, full_name)

    def _try_start_user_ticket_preview(self, generation: int, login: str, full_name: str):
        if generation != self.user_ticket_preview_generation or not self.user_ticket_preview_loading:
            return
        if self.background_runner.state() != QProcess.NotRunning:
            if time.monotonic() - self.user_ticket_preview_wait_started > 120:
                self.finish_user_ticket_preview(False, "O Capri está ocupado há mais de 2 minutos. Tente novamente pelo card de chamados.", generation)
                return
            self.user_tickets_card.set_status("Aguardando a consulta atual do Capri terminar…")
            QTimer.singleShot(150, lambda g=generation, u=login, n=full_name: self._try_start_user_ticket_preview(g, u, n))
            return
        payload = build_user_ticket_preview_payload(login=login, display_name=full_name)
        self.background_pending_action = "user_ticket_preview"
        self.background_user_ticket_generation = generation
        self._background_output_chunks = []
        self._background_log_pending = ""
        self._background_log_skipping = False
        launcher = str(resource_path("scripts/bridge_launcher.ps1"))
        bridge = str(resource_path("scripts/bridge.ps1"))
        args = ["-Script", bridge, "-Action", TICKET_CATALOG, "-Computer", "", "-Value", payload]
        password = self._capri_session_password or credential_read(self.capri_username, "capri") or ""
        environment = capri_environment(self.capri_username, password) if password else {}
        if not self.background_runner.run_script(launcher, args, environment, timeout_ms=180000):
            self.finish_user_ticket_preview(False, "Não foi possível iniciar a consulta ao Capri.", generation)

    def update_user_ticket_preview_progress(self, value: int):
        percent = max(0, min(99, int(value)))
        self.user_ticket_preview_percent = percent
        self.user_tickets_card.set_status(f"Consultando chamados recentes no Capri em segundo plano… {percent}%")
        if self.user_ticket_dialog is not None:
            self.user_ticket_dialog.set_progress(percent, "Consultando os últimos 25 chamados no Capri…")

    def finish_user_ticket_preview(self, ok: bool, output: str, generation: int | None = None):
        if generation is not None and generation != self.user_ticket_preview_generation:
            return
        if not self.user_ticket_preview_loading:
            return
        data = self.extract_json_marker(output, "@@TICKETS@@") if ok else None
        valid = bool(
            data and data.get("preview_only") and data.get("complete")
            and isinstance(data.get("items"), list)
        )
        self.user_ticket_preview_loading = False
        if valid:
            self.user_ticket_preview_items = list(data["items"][:25])
            self.user_ticket_preview_status = "ready"
            count = len(self.user_ticket_preview_items)
            self.user_tickets_card.set_status(f"{count} chamado(s) recente(s) disponível(is) para consulta.")
            self.user_tickets_card.refresh_button.setEnabled(True)
            set_refresh_icon_busy(self.user_tickets_card.refresh_button, False)
            set_button_icon(self.user_tickets_card.refresh_button, "refresh", BLUE_2, 13)
            if self.user_ticket_dialog is not None:
                self.user_ticket_dialog.set_tickets(self.user_ticket_preview_items)
            self.append_log(f"[CHAMADOS DO USUÁRIO] {count} chamado(s) recebidos em memória; nenhum catálogo foi alterado.\n")
            return
        detail = self.clean_result_output(output)
        message = detail or "O Capri não confirmou a consulta temporária dos chamados."
        self.user_ticket_preview_items = []
        self.user_ticket_preview_status = "failed"
        self.user_tickets_card.set_status("Consulta não concluída. Clique para tentar novamente.")
        self.user_tickets_card.refresh_button.setEnabled(True)
        set_refresh_icon_busy(self.user_tickets_card.refresh_button, False)
        set_button_icon(self.user_tickets_card.refresh_button, "refresh", BLUE_2, 13)
        if self.user_ticket_dialog is not None:
            self.user_ticket_dialog.set_error(message)
        self.append_log(f"[CHAMADOS DO USUÁRIO] {message}\n")

    def finish_station_enrichment(self, success: bool, message: str = ""):
        if not self.station_enrichment_active and not self.station_load_cycle_active:
            return
        self.station_enrichment_active = False
        self.station_load_cycle_active = False
        self.station_load_partial = not success
        self.station_enrichment_login = ""
        self.connection_progress_timer.stop()
        # Os chamados do Capri são independentes e não atrasam a estação e o AD.
        # Uma falha nos dados principais mantém o último percentual abaixo de 100.
        final_percent = 100 if success else min(99, max(1, self.connection_progress_value))
        self.connection_progress_target = final_percent
        self.connection_progress_value = final_percent
        self.connection_progress.setValue(final_percent)
        self.connection_progress.setFormat(
            f"{message or ('Carregamento concluído.' if success else 'Carregamento concluído parcialmente.')}  •  %p%"
        )
        self.connection_progress.show()
        self.station_enrichment_finish_timer.start(1400 if success else 2600)

    def hide_station_enrichment_progress(self):
        if not self.connection_query_active and not self.station_enrichment_active and not self.station_load_cycle_active:
            self.connection_progress.hide()

    def preview_password_recovery(self):
        if self.user_query_active or not self.user_control_data:
            return
        remaining = int(self.password_recovery_cooldown_until - time.monotonic())
        if remaining > 0:
            show_notice(self, f"Aguarde {remaining} segundos antes de solicitar uma nova recuperação.")
            return
        login = str(self.user_control_data.get("login") or "").strip()
        full_name = str(self.user_control_data.get("display_name") or "").strip()
        if not login or not full_name or full_name == "Não informado":
            show_notice(self, "O login e o nome completo precisam estar disponíveis para a recuperação.")
            return
        payload = {"login": login, "full_name": full_name}
        value = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        self.user_query_progress_value = 4
        self.set_user_query_state(True, "Validando o destino protegido da recuperação…")
        if not self.run_user_bridge("password_recovery_preview", value, payload=payload, timeout_ms=65000):
            self.set_user_query_state(False)

    def open_password_manager_page(self):
        """Abre o PWM sem alterar a sessão usada pela recuperação de senha."""
        if self.open_external_link(PWM_URL):
            self.append_log("\n[PWM] Gestor de Senhas aberto para consulta no navegador configurado.\n")

    def _user_execution_done(self, ok: bool):
        action = self.user_pending_action
        output = self.user_output
        payload = dict(self.user_pending_payload)
        self.user_pending_action = ""
        self.user_pending_payload = {}

        if action == "user_control_lookup" and ok:
            data = self.extract_json_marker(output, "@@USERCONTROL@@")
            if data:
                login = str(data.get("login") or self.user_login_input.text()).strip()
                self.user_control_data = data
                self.user_control_cache[login.casefold()] = {"time": time.monotonic(), "data": dict(data)}
                self.render_user_control_data()
                self.set_user_query_state(False, "Informações do usuário disponíveis no AD.  •  %p%")
                self.finish_station_enrichment(True, "Estação e usuário carregados.")
                full_name = str(data.get("display_name") or data.get("user") or "").strip()
                QTimer.singleShot(0, lambda u=login, n=full_name: self.start_user_ticket_preview(u, n))
                return
        elif action == "password_manager_import_cookies" and ok and "@@PASSWORD_MANAGER_CHROME_SESSION@@" in output:
            browser_label = dict(BROWSER_OPTIONS).get(preferred_browser(), "navegador padrão do Windows")
            self.set_password_manager_connection_state(True, f"PWM conectado pelo {browser_label}")
            self.set_user_query_state(False)
            self.append_log("[PWM] Sessão ativa do Chrome validada; consultando os dados do usuário…\n")
            login = self.pending_pwm_lookup_login
            if login:
                QTimer.singleShot(0, lambda current=login: self._run_password_manager_user_lookup(current))
            return
        elif action == "password_manager_browser_session" and ok and "@@PASSWORD_MANAGER_SESSION@@" in output:
            self.set_password_manager_connection_state(True, "Gestor de Senhas conectado — sessão persistente")
            self.set_user_query_state(False)
            self.append_log("[PWM] Sessão persistente validada; a janela exclusiva foi fechada.\n")
            login = self.pending_pwm_lookup_login
            if login:
                QTimer.singleShot(0, lambda current=login: self._run_password_manager_user_lookup(current))
            return
        elif action == "password_manager_login" and ok and "@@PASSWORD_MANAGER_SESSION@@" in output:
            password = self._password_manager_pending_password
            self._password_manager_session_password = password
            if password:
                credential_write(self.password_manager_username, password, "gestor_senhas")
            self._password_manager_pending_password = ""
            self._password_manager_saved_attempt = False
            self.set_password_manager_connection_state(True)
            self.set_user_query_state(False)
            login = self.pending_pwm_lookup_login
            if login:
                QTimer.singleShot(0, lambda current=login: self._run_password_manager_user_lookup(current))
            return
        elif action == "password_manager_logout" and ok:
            self._password_manager_session_password = ""
            self._password_manager_pending_password = ""
            self.set_password_manager_connection_state(False)
            self.set_user_query_state(False)
            self.password_manager_lookup_failed = False
            self.password_manager_lookup_skipped = False
            self.pending_pwm_lookup_login = ""
            self.pwm_lookup_reauth_attempted = False
            self.user_control_data.pop("password_manager", None)
            if self.user_control_data:
                self.render_user_control_data()
            self._reset_password_manager_profile_async()
            return
        elif action == "password_manager_user_lookup" and ok:
            manager_data = self.extract_json_marker(output, "@@PASSWORD_MANAGER_USER@@")
            if manager_data:
                self.password_manager_lookup_failed = False
                self.pending_pwm_lookup_login = ""
                self.pwm_lookup_reauth_attempted = False
                self.user_control_data["password_manager"] = manager_data
                login = str(self.user_control_data.get("login") or "").casefold()
                if login:
                    self.user_control_cache[login] = {"time": time.monotonic(), "data": dict(self.user_control_data)}
                self.render_user_control_data()
                self.user_query_label.setText("Consulta concluída no Active Directory e no Gestor de Senhas.")
                self.set_user_query_state(False)
                return
        elif action == "password_recovery_preview" and ok:
            preview = self.extract_json_marker(output, "@@PASSWORD_RECOVERY_PREVIEW@@")
            self.set_user_query_state(False)
            if preview and preview.get("ready"):
                destination = self.masked_email(preview.get("masked_email") or "endereço protegido")
                if confirm_action(
                    self, "Confirmar recuperação de senha",
                    f"O Gestor encaminhará a recuperação para:\n\n{destination}\n\n"
                    "Deseja continuar? Esta ação não será repetida automaticamente.",
                ):
                    send_payload = dict(payload)
                    send_payload["masked_email"] = destination
                    value = json.dumps(send_payload, ensure_ascii=False, separators=(",", ":"))
                    self.set_user_query_state(True, "Enviando a recuperação de senha…")
                    if not self.run_user_bridge(
                        "password_recovery_send", value, payload=send_payload, timeout_ms=65000,
                    ):
                        self.set_user_query_state(False)
                return
        elif action == "password_recovery_send" and ok and "@@PASSWORD_RECOVERY_SENT@@" in output:
            result = self.extract_json_marker(output, "@@PASSWORD_RECOVERY_SENT@@") or {}
            self.password_recovery_cooldown_until = time.monotonic() + 60
            self.set_user_query_state(False)
            destination = self.masked_email(payload.get("masked_email") or "endereço protegido")
            if result.get("confirmed"):
                message = f"E-mail de redefinição encaminhado com sucesso para:\n\n{destination}"
            else:
                message = (
                    f"E-mail de redefinição encaminhado com sucesso para:\n\n{destination}\n\n"
                    "O servidor aceitou a solicitação, mas não exibiu uma confirmação textual."
                )
            show_notice(self, message)
            return

        if (action == "password_manager_browser_session" and
                "@@PASSWORD_MANAGER_BROWSER_REQUIRED@@" in output and not payload.get("interactive")):
            self.set_password_manager_connection_state(False, "Sessão do PWM expirada — autenticação necessária")
            self.user_query_progress.setFormat("Abrindo a janela exclusiva do PWM…")
            self.append_log("[PWM] Cookie ausente ou expirado; abrindo a janela exclusiva para login…\n")
            QTimer.singleShot(0, lambda: self._begin_password_manager_browser(True))
            return
        if (action == "password_manager_user_lookup" and
                "@@PASSWORD_MANAGER_EXPIRED@@" in output and
                self.pending_pwm_lookup_login and not self.pwm_lookup_reauth_attempted):
            self.pwm_lookup_reauth_attempted = True
            self.set_password_manager_connection_state(False, "Sessão do PWM expirada — atualizando pelo Chrome")
            self._request_pwm_browser_session(self.pending_pwm_lookup_login)
            return
        if "@@PASSWORD_MANAGER_EXPIRED@@" in output:
            self._password_manager_session_password = ""
            self.set_password_manager_connection_state(False, "Sessão do Gestor expirada — conecte novamente")
        if action == "password_manager_login":
            if self._password_manager_saved_attempt:
                credential_delete(self.password_manager_username, "gestor_senhas")
            self._password_manager_pending_password = ""
            self._password_manager_saved_attempt = False
            self.set_password_manager_connection_state(False, "Não foi possível validar o Gestor de Senhas")
        elif action == "password_manager_browser_session":
            self.pending_pwm_lookup_login = ""
            self.pwm_lookup_reauth_attempted = False
            self.set_password_manager_connection_state(False, "Não foi possível validar a sessão persistente do PWM")
        elif action == "password_manager_import_cookies":
            self.pending_pwm_cookie_sync_login = ""
            self.pending_pwm_lookup_login = ""
            self.pwm_lookup_reauth_attempted = False
            self.set_password_manager_connection_state(False, "PWM não autenticado no Chrome")
        if action == "user_control_lookup":
            self.user_query_label.setText("Não foi possível consultar o usuário no Active Directory.")
            self.set_user_query_state(False, "Consulta não concluída.", completed=False)
            self.user_tickets_card.set_status("AD não respondeu. Os chamados não foram consultados.")
            self.finish_station_enrichment(False, "Consulta parcial: falha ao carregar o usuário no AD.")
        else:
            self.set_user_query_state(False, "A operação não foi concluída.", completed=False)
        detail = self.clean_result_output(output)
        if action == "password_manager_user_lookup" and self.user_control_data:
            self.pending_pwm_lookup_login = ""
            self.pwm_lookup_reauth_attempted = False
            self.password_manager_lookup_failed = self.password_manager_connected
            self.render_user_control_data()
            if self.password_manager_connected:
                self.user_query_label.setText(
                    "Active Directory carregado; o PWM está conectado, mas a consulta do usuário não foi concluída. Tente consultar novamente."
                )
            else:
                self.user_query_label.setText(
                    "Active Directory carregado; a sessão do PWM expirou. Conecte novamente para completar os dados."
                )
            return
        show_notice(self, detail or "A operação de usuário não foi concluída. Consulte o Console de atividades.")

    def connect_target(self):
        if self.connection_query_active:
            return
        if self.connection_active:
            self.disconnect_target()
            return
        target = self.target_input.text().strip().replace("\\", "")
        if not target:
            show_notice(self, "Informe o nome ou IP do computador.")
            return
        self._station_query_before = dict(self.last_status_data)
        self.station_card_refresh_only = False
        self.target = target
        self.set_station_ping_result({"ping_result": "Testando"})
        self.append_log(f"\n[CONEXÃO] Consultando {target}...\n")
        if self.run_bridge("status", target):
            self.set_connection_query_state(True, target)

    def cancel_station_query(self):
        """Interrompe só a consulta em andamento e restaura o painel anterior."""
        if not self.connection_query_active or self.pending_action != "status":
            return
        self.pending_action = ""
        self.pending_popup_title = ""
        self.pending_popup_subtitle = ""
        self.runner.cancel()
        if self.station_enrichment_active and self.user_pending_action == "user_control_lookup":
            self.user_pending_action = ""
            self.user_runner.cancel()
            self.set_user_query_state(False, "Consulta ao AD cancelada.", completed=False)
            self.user_query_progress.hide()
        self.station_enrichment_finish_timer.stop()
        self.connection_progress_timer.stop()
        self.station_load_cycle_active = False
        self.station_enrichment_active = False
        self.station_enrichment_login = ""
        self.pending_station_user_login = ""
        self.station_card_refresh_only = True  # restauração sem nova consulta ao AD
        previous = self._station_query_before
        if previous:
            self.update_status_panel("@@STATUS@@" + json.dumps(previous, ensure_ascii=False))
        else:
            self.disconnect_target()
        self.station_card_refresh_only = False
        self.set_connection_query_state(False)
        self.connection_progress.hide()
        set_refresh_icon_busy(self.refresh_button, False)
        self.append_log("\n[CONEXÃO] Consulta da estação cancelada.\n")
        self.connection_label.setText("Consulta cancelada. Você pode tentar novamente.")

    def advance_connect_sync(self):
        """Gira o ícone de sincronização sem bloquear a interface."""
        self.connect_sync_angle = (self.connect_sync_angle + 24) % 360
        canvas = QPixmap(24, 24)
        canvas.fill(Qt.transparent)
        painter = QPainter(canvas)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.translate(12, 12)
        painter.rotate(self.connect_sync_angle)
        painter.translate(-9, -9)
        painter.drawPixmap(0, 0, self.connect_sync_icon)
        painter.end()
        self.connect_button.setIcon(QIcon(canvas))
        self.connect_button.setIconSize(QSize(18, 18))

    def advance_connection_progress(self):
        """Avança suavemente somente até o marco confirmado pela etapa atual."""
        value = self.connection_progress_value
        target = max(value, int(self.connection_progress_target))
        if value >= target:
            self.connection_progress_timer.stop()
            return
        distance = target - value
        step = 3 if distance > 18 else (2 if distance > 7 else 1)
        value = min(target, value + step)
        self.connection_progress_value = value
        self.connection_progress.setValue(value)

    def set_connection_progress_stage(self, percent: int, message: str):
        """Publica um marco real sem reiniciar nem ocultar a barra entre consultas."""
        # Apenas finish_station_enrichment confirma AD, estação e Capri.
        percent = max(0, min(99, int(percent)))
        self.connection_progress_target = max(self.connection_progress_target, percent)
        self.connection_progress.setFormat(f"{message}  •  %p%")
        self.connection_progress.show()
        if self.connection_progress_value < self.connection_progress_target:
            if not self.connection_progress_timer.isActive():
                self.connection_progress_timer.start()
        else:
            self.connection_progress.setValue(self.connection_progress_value)

    def set_connection_query_state(self, querying: bool, target: str = "", refreshing: bool = False):
        """Destaca a sincronização e impede consultas duplicadas."""
        self.connection_query_active = querying
        self.connection_card.setProperty("querying", querying)
        self.connection_label.setProperty("querying", querying)
        for widget in (self.connection_card, self.connection_label):
            widget.style().unpolish(widget)
            widget.style().polish(widget)

        if querying:
            action_text = "Sincronizando…" if refreshing else "Consultando…"
            detail_text = (
                f"Sincronizando novamente os dados de {target}. Aguarde a conclusão…"
                if refreshing else f"Consultando {target} e carregando os dados da estação. Aguarde…"
            )
            self.connect_button.setText(action_text)
            self.connect_button.setObjectName("syncButton")
            self.connect_button.setAccessibleName(action_text.rstrip("…"))
            self.connect_button.setEnabled(False)
            self.connection_tools.show()
            self.target_input.setEnabled(False)
            self.refresh_button.setEnabled(False)
            self.copy_target_button.setEnabled(False)
            self.connection_label.setText(detail_text)
            self.connection_label.hide()
            self.station_enrichment_finish_timer.stop()
            self.station_load_cycle_active = True
            self.station_load_partial = False
            self.connection_progress_target = 0
            self.connection_progress_value = 0
            self.connection_progress.setValue(0)
            self.set_connection_progress_stage(10, detail_text)
            self.connect_sync_angle = 0
            self.advance_connect_sync()
            self.connect_sync_timer.start()
        else:
            self.connection_tools.hide()
            if self.station_load_cycle_active or self.station_enrichment_active:
                self.connection_progress.show()
            elif not self.station_enrichment_finish_timer.isActive():
                self.connection_progress_timer.stop()
                self.connection_progress.hide()
            self.connection_label.show()
            self.connect_sync_timer.stop()
            self.connect_button.setIcon(QIcon())
            self.connect_button.setText("Desconectar" if self.connection_active else "Conectar")
            self.connect_button.setObjectName("disconnectButton" if self.connection_active else "primaryButton")
            self.connect_button.setAccessibleName(
                "Desconectar da estação" if self.connection_active else "Conectar à estação"
            )
            self.connect_button.setEnabled(True)
            self.target_input.setEnabled(not self.connection_active)
            self.refresh_button.setEnabled(self.connection_active)
            self.copy_target_button.setEnabled(bool(self.target))
        self.connect_button.style().unpolish(self.connect_button)
        self.connect_button.style().polish(self.connect_button)

    def set_connection_state(self, connected: bool):
        self.connection_active = connected
        self.update_action_card_availability()
        self.evaluation_button.setEnabled(connected and bool(self.last_status_data.get("user", "").strip())
                                          and self.last_status_data.get("user") != "Nenhum usuário logado")
        if not self.connection_query_active:
            self.connect_button.setText("Desconectar" if connected else "Conectar")
            self.connect_button.setObjectName("disconnectButton" if connected else "primaryButton")
            self.connect_button.setAccessibleName(
                "Desconectar da estação" if connected else "Conectar à estação"
            )
            self.connect_button.style().unpolish(self.connect_button)
            self.connect_button.style().polish(self.connect_button)
            self.target_input.setEnabled(not connected)
        self.refresh_button.setEnabled(connected and not self.connection_query_active)
        self.copy_target_button.setEnabled(bool(self.target) and not self.connection_query_active)
        self.station_ping_button.setEnabled(bool(self.target))
        self.station_remote_button.setEnabled(connected and self.profile == "ins")
        self.quick_sccm_button.setEnabled(connected and self.profile == "ins")
        self.update_quick_ad_availability()
        self.quick_internet_button.setEnabled(connected)
        self.quick_disk_button.setEnabled(connected)
        self.disk_d_button.setEnabled(connected)
        self.disk_temp_button.setEnabled(connected)
        self.windows_logoff_button.setEnabled(connected)
        self.windows_restart_button.setEnabled(connected)
        self.quick_local_users_button.setEnabled(connected)
        self.free_orientation_button.setEnabled(connected and bool(self.station_user_login(self.last_status_data.get("user"))))
        for section in ("Suporte remoto", "Impressoras"):
            self.nav_buttons[section].setEnabled(connected)
        software_access = connected and bool(self.last_status_data.get("software_access", False))
        if "Softwares autorizados" in self.nav_buttons:
            self.nav_buttons["Softwares autorizados"].setEnabled(software_access)
            self.nav_buttons["Softwares autorizados"].setToolTip(
                "Abrir catálogo autorizado do drive X:"
                if software_access else "Disponível quando o usuário conectado possuir acesso ao drive X:"
            )
        self.admin_status_widget.set_connected(connected)
        self.printer_ping_button.setEnabled(connected)
        self.printer_web_button.setEnabled(connected)
        self.printer_summary_refresh.setEnabled(connected)
        self.printer_summary_ping.setEnabled(connected)
        self.printer_summary_web.setEnabled(connected)
        self.printer_summary_test_page.setEnabled(connected)
        self.printer_summary_admin.setEnabled(connected and self.admin_status_widget.is_admin is not None)
        self.printer_summary_logoff.setEnabled(connected)
        self.sync_printer_admin_button()
        self.connection_status.setText("CONTROLE DA ESTAÇÃO")
        if connected:
            self.paint_station_icon(True)
            if not self.station_pulse_timer.isActive():
                self.station_pulse_timer.start()
        else:
            self.station_pulse_timer.stop()
            self.station_pulse_step = 0
            self.paint_station_icon(False)
            if not self.connection_query_active:
                set_refresh_icon_busy(self.refresh_button, False)
            set_refresh_icon_busy(self.printer_summary_refresh, False)

    def paint_station_icon(self, connected: bool, icon_size: int | None = None):
        """Desenha o computador com contraste próprio nos temas claro e escuro."""
        size = icon_size or (17 if self.status_pulse.width() <= 28 else 20)
        radius = max(12, self.status_pulse.width() // 2)
        if connected:
            bright = float(self.station_pulse_step == 0) if self.station_pulse_timer.isActive() else 1.0
            if self.dark_mode:
                color = "#73F2BE" if bright >= 0.5 else "#32C98E"
                background = "#0E4939" if bright >= 0.5 else "#0B332B"
                border = "#56E5AF" if bright >= 0.5 else "#278265"
            else:
                color = "#008F54" if bright >= 0.5 else "#00B866"
                background = "#D9F8E8" if bright >= 0.5 else "#ECFBF4"
                border = "#73D8A7"
        else:
            color, background, border = RED, "#FBE5E9", "#E9A9B3"
        signature = (connected, size, color, background, border, radius)
        if signature == self._station_icon_signature:
            return
        self._station_icon_signature = signature
        self.status_pulse.setPixmap(modern_icon("remote", color, size).pixmap(size, size))
        self.status_pulse.setStyleSheet(
            f"background: {background}; border: 2px solid {border}; border-radius: {radius}px;"
        )

    def advance_station_pulse(self):
        """Pulso suave sem efeito gráfico aninhado, que some no modo noturno."""
        self.station_pulse_step = (self.station_pulse_step + 1) % 2
        self.paint_station_icon(True)

    def set_station_ping_result(self, data: dict):
        state, text = station_ping_display(data)
        self.station_ping_state = state
        self.station_ping_result.setText(text)
        self.station_ping_result.setToolTip("Tempo de limite perdido" if state == "timeout" else text)
        self.station_ping_result.setVisible(bool(text))
        self.paint_station_ping_result()

    def paint_station_ping_result(self):
        colors = {
            "green": (98, 223, 173) if self.dark_mode else (0, 130, 74),
            "yellow": (255, 227, 109) if self.dark_mode else (153, 115, 0),
            "timeout": (255, 120, 135) if self.dark_mode else (199, 61, 77),
            "neutral": (163, 203, 222) if self.dark_mode else (55, 102, 130),
            "pending": (163, 203, 222) if self.dark_mode else (55, 102, 130),
        }
        red, green, blue = colors.get(self.station_ping_state, colors["neutral"])
        self.station_ping_result.setStyleSheet(
            f"color: rgb({red}, {green}, {blue}); "
            "background: transparent; border: none; font-size: 10px; font-weight: 850; padding: 0 2px;"
        )

    def toggle_station_icon(self):
        """Compatibilidade: a animação atual usa opacidade contínua, sem piscar."""
        if self.connection_active and not self.station_pulse_timer.isActive():
            self.station_pulse_timer.start()

    def disconnect_target(self):
        if self.target:
            self.append_log(f"\n[CONEXÃO] {self.target} desconectado do painel.\n")
        self.target = ""
        self.set_station_ping_result({})
        self.target_input.clear()
        self.connection_label.setText("Informe o nome ou IP da estação para iniciar.")
        self.last_status_data = {}
        self.update_printer_color_permission()
        self.last_auto_user_login = ""
        self.pending_station_user_login = ""
        self.software_catalog = {}
        self.software_loading = False
        self.software_expanded_categories.clear()
        self.software_search.clear()
        self.software_suggestion_model.setStringList([])
        self.status_card.hide()
        self.update_printer_summary()
        self.set_connection_state(False)

    def copy_target_address(self):
        address = self.target or self.target_input.text().strip()
        if not address:
            return
        QApplication.clipboard().setText(address)
        set_button_icon(self.copy_target_button, "check", GREEN, 14)
        self.copy_target_button.setToolTip(f"Copiado: {address}")
        self.append_log(f"\n[ESTAÇÃO] Endereço copiado: {address}\n")
        QTimer.singleShot(1200, self.restore_copy_target_button)

    def restore_copy_target_button(self):
        set_button_icon(self.copy_target_button, "copy", BLUE, 14)
        self.copy_target_button.setToolTip("Copiar nome ou IP da estação")

    def request_authorized_software(self):
        if not self.connection_active or not bool(self.last_status_data.get("software_access", False)):
            show_notice(self, "O usuário conectado não possui o drive X: disponível nesta sessão.")
            return
        self.software_loading = True
        self.current_columns = 0
        self.reflow()
        self.nav_buttons["Softwares autorizados"].setEnabled(False)
        self.append_log(f"\n[SOFTWARES] Consultando catálogo autorizado em {self.target}…\n")
        if not self.run_bridge("authorized_software_list", self.target):
            self.software_loading = False
            self.nav_buttons["Softwares autorizados"].setEnabled(True)

    def launch_authorized_software(self, path: str, name: str):
        if not path or not self.connection_active:
            return
        if not confirm_action(
            self,
            "Abrir software autorizado",
            f"Deseja iniciar “{name}” na sessão do usuário conectado em {self.target}?",
        ):
            return
        self.append_log(f"\n[SOFTWARE AUTORIZADO] {name} — {path}\n")
        self.run_bridge(
            "authorized_software_run",
            self.target,
            path,
            popup_title="Software autorizado",
            popup_subtitle=f"Solicitação enviada para {self.target}.",
        )

    def quick_open_sccm(self):
        action = next((item for item in ACTIONS if item.command == "cmrc"), None)
        if action:
            self.execute_action(action)

    def finish_quick_button_unless_running(self, button: QuickActionButton, actions: set):
        if self.runner.state() == QProcess.NotRunning or self.pending_action not in actions:
            button.end_loading()

    def quick_sidebar_sccm(self):
        self.quick_open_sccm()
        self.finish_quick_button_unless_running(self.quick_sccm_button, {"cmrc"})

    def quick_sidebar_ad_user_info(self):
        self.quick_ad_user_info()
        self.finish_quick_button_unless_running(self.quick_ad_user_button, {"ad_user_info", "ad_user_info_login"})

    def quick_sidebar_admin(self):
        self.handle_admin_lock()
        self.finish_quick_button_unless_running(self.quick_admin_button, {"admin_set", "status"})

    def toggle_useful_links(self):
        self.templates_popup.hide()
        popup = self.useful_links_popup
        if popup.isVisible():
            popup.hide()
            return
        anchor = self.useful_links_toggle.mapToGlobal(QPoint(self.useful_links_toggle.width() + 8, 0))
        screen = QApplication.screenAt(anchor) or self.screen() or QApplication.primaryScreen()
        bounds = screen.availableGeometry()
        width = min(320, max(240, bounds.width() - 24))
        height = min(390, max(180, bounds.height() - 24))
        popup.resize(width, height)
        popup.move(
            max(bounds.left() + 12, min(anchor.x(), bounds.right() - width - 11)),
            max(bounds.top() + 12, min(anchor.y(), bounds.bottom() - height - 11)),
        )
        popup.show()
        popup.raise_()

    def toggle_templates(self):
        self.useful_links_popup.hide()
        popup = self.templates_popup
        if popup.isVisible():
            popup.hide()
            return
        anchor = self.templates_toggle.mapToGlobal(
            QPoint(self.templates_toggle.width() + 8, 0)
        )
        screen = QApplication.screenAt(anchor) or self.screen() or QApplication.primaryScreen()
        bounds = screen.availableGeometry()
        # O painel fica à direita do Atlas. Reduzimos a largura ao espaço
        # disponível em vez de deslocá-lo para a esquerda, como na v20.12.
        right_room = bounds.right() - anchor.x() - 12
        width = min(620, max(280, right_room))
        x = anchor.x() if right_room >= 280 else bounds.right() - width - 11
        desired_height = {0: 510, 1: 790, 2: 700, 3: 790}.get(popup.stack.currentIndex(), 510)
        height = min(desired_height, bounds.height() - 24)
        popup.resize(width, height)
        popup.anchor_y = anchor.y()
        popup.move(
            max(bounds.left() + 12, min(x, bounds.right() - width - 11)),
            max(bounds.top() + 12, min(anchor.y(), bounds.bottom() - height - 11)),
        )
        popup.show()
        popup.raise_()

    def on_template_copied(self, label: str):
        self.append_log(f"\n[TEMPLATE] {label}: código-fonte HTML copiado.\n")
        QToolTip.showText(
            self.templates_toggle.mapToGlobal(QPoint(0, -20)),
            "Código-fonte HTML copiado",
            self.templates_toggle, self.templates_toggle.rect(), 1800,
        )

    def render_useful_links(self):
        layout = self.useful_links_list_layout
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
                widget.deleteLater()
        for index, entry in enumerate(self.useful_links):
            row = QFrame(objectName="usefulLinkRow")
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(3)
            name, url = entry["name"], entry["url"]
            # O título completo permanece na dica; limitar o texto impede que
            # um nome longo empurre a lixeira para fora da lateral estreita.
            open_button = HoverFadeButton()
            open_button.setText(open_button.fontMetrics().elidedText(name, Qt.ElideRight, 230))
            open_button.setObjectName("usefulLinkButton")
            open_button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            open_button.setMinimumWidth(0)
            open_button.setToolTip(f"{name}\n{url}")
            open_button.setAccessibleName(f"Abrir {name}")
            open_button.clicked.connect(lambda _checked=False, address=url: self.open_external_link(address))
            row_layout.addWidget(open_button, 1)
            delete_button = QPushButton()
            delete_button.setObjectName("usefulLinkDeleteButton")
            delete_button.setFixedSize(22, 24)
            delete_button.setToolTip(f"Excluir {name}")
            delete_button.setAccessibleName(f"Excluir {name}")
            set_button_icon(delete_button, "trash", "#D79BA8", 12)
            delete_button.clicked.connect(lambda _checked=False, selected=index: self.delete_useful_link(selected))
            row_layout.addWidget(delete_button)
            layout.addWidget(row)
        # A lista ocupa toda a área liberada e passa a rolar somente quando os
        # atalhos realmente excedem o espaço disponível.
        self.useful_links_scroll.setMaximumHeight(16777215)
        self.useful_links_scroll.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.useful_links_scroll.setVisible(bool(self.useful_links))

    def accept_useful_link_dialog(self, dialog: QDialog, name_input: QLineEdit, url_input: QLineEdit):
        name, url = name_input.text().strip(), url_input.text().strip()
        if not valid_useful_link(name, url):
            QMessageBox.warning(dialog, "Link inválido", "Informe um nome e um endereço http:// ou https:// válido.")
            return
        if any(item["url"].casefold() == url.casefold() for item in self.useful_links):
            QMessageBox.warning(dialog, "Link já adicionado", "Este endereço já está em Links úteis.")
            return
        dialog.accept()

    def add_useful_link(self):
        dialog = QDialog(self)
        dialog.setObjectName("usefulLinkDialog")
        dialog.setWindowTitle("Adicionar link útil")
        dialog.setMinimumWidth(360)
        form = QVBoxLayout(dialog)
        name_label = QLabel("Nome do atalho")
        name_input = QLineEdit()
        name_input.setPlaceholderText("Ex.: Portal de serviços")
        name_input.setMaxLength(80)
        url_label = QLabel("Endereço do link")
        url_input = QLineEdit()
        url_input.setPlaceholderText("https://...")
        url_input.setMaxLength(2048)
        for widget in (name_label, name_input, url_label, url_input):
            form.addWidget(widget)
        buttons = QHBoxLayout()
        buttons.addStretch()
        cancel = QPushButton("Cancelar")
        cancel.clicked.connect(dialog.reject)
        buttons.addWidget(cancel)
        save = QPushButton("Adicionar")
        save.setObjectName("primaryButton")
        save.clicked.connect(lambda: self.accept_useful_link_dialog(dialog, name_input, url_input))
        buttons.addWidget(save)
        form.addLayout(buttons)
        if dialog.exec() != QDialog.Accepted:
            return
        updated = [*self.useful_links, {"name": name_input.text().strip(), "url": url_input.text().strip()}]
        if not save_json_cache(useful_links_path(), {"links": updated}):
            QMessageBox.warning(self, "Links úteis", "Não foi possível salvar o novo link.")
            return
        self.useful_links = updated
        self.render_useful_links()

    def delete_useful_link(self, index: int):
        if index < 0 or index >= len(self.useful_links):
            return
        name = self.useful_links[index]["name"]
        if not confirm_action(self, "Excluir link útil", f"Excluir o atalho “{name}” de Links úteis?"):
            return
        updated = [item for position, item in enumerate(self.useful_links) if position != index]
        if not save_json_cache(useful_links_path(), {"links": updated}):
            QMessageBox.warning(self, "Links úteis", "Não foi possível salvar a exclusão.")
            return
        self.useful_links = updated
        self.render_useful_links()

    def quick_ping_station(self):
        action = next((item for item in ACTIONS if item.command == "ping"), None)
        if action:
            self.execute_action(action)

    def quick_open_cmd(self):
        if os.name != "nt":
            QMessageBox.warning(self, APP_NAME, "O Prompt de Comando está disponível somente no Windows.")
            self.quick_cmd_button.end_loading()
            return
        try:
            flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
            subprocess.Popen(["cmd.exe"], creationflags=flags)
        except OSError as exc:
            QMessageBox.critical(self, "Prompt de Comando", f"Não foi possível abrir o CMD.\n\n{exc}")
        self.quick_cmd_button.end_loading()

    def quick_ad_user_info(self):
        available_login = str(self.user_control_data.get("login") or "").strip()
        selected_login = available_login if self.control_tabs.currentIndex() == 1 or not self.target else ""
        if selected_login:
            self.append_log(f"\n[AD] Consultando informações complementares de SENADO\\{selected_login}...\n")
            started = self.run_bridge("ad_user_info_login", "", selected_login)
        elif self.target:
            self.append_log(f"\n[AD] Consultando informações do usuário conectado a {self.target}...\n")
            started = self.run_bridge("ad_user_info", self.target)
        else:
            show_notice(self, "Consulte um usuário ou conecte uma estação primeiro.")
            return
        if started:
            self.quick_ad_button.setEnabled(False)
            self.quick_ad_user_button.setEnabled(False)

    def quick_open_internet(self):
        action = next((item for item in ACTIONS if item.command == "inetcpl"), None)
        if action:
            self.execute_action(action)
        else:
            self.quick_internet_button.end_loading()

    def quick_disk_profiles(self):
        if not self.target:
            show_notice(self, "Conecte uma estação remota primeiro.")
            self.quick_disk_button.end_loading()
            return
        cache_key = self.target.lower()
        cached = self.disk_profiles_cache.get(cache_key)
        force_refresh = bool(QApplication.keyboardModifiers() & Qt.ShiftModifier)
        if cached and not force_refresh and time.monotonic() - cached["time"] <= 30:
            self.append_log(f"\n[DIAGNÓSTICO] Exibindo consulta confirmada há menos de 30 segundos. Use Shift+clique para atualizar.\n")
            DiskProfilesDialog(cached["data"], self).exec()
            self.quick_disk_button.end_loading()
            return
        self.append_log(f"\n[DIAGNÓSTICO] Consultando discos e perfis de {self.target}...\n")
        started = self.run_bridge("disk_profiles", self.target)
        if started:
            self.quick_disk_button.setEnabled(False)
            self.disk_d_button.setEnabled(False)
            set_refresh_icon_busy(self.disk_d_button, True)
        else:
            self.quick_disk_button.end_loading()

    def quick_local_users(self):
        action = next((item for item in ACTIONS if item.command == "local_users"), None)
        if action:
            self.execute_action(action)
        else:
            self.quick_local_users_button.end_loading()

    def quick_open_dsa(self):
        if os.name != "nt":
            show_notice(self, "O console do Active Directory está disponível somente no Windows.")
            self.quick_dsa_button.end_loading()
            return
        try:
            subprocess.Popen(
                ["mmc.exe", "dsa.msc"],
                creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
            )
            self.append_log("\n[ATALHO] Usuários e Computadores do Active Directory aberto.\n")
        except OSError as exc:
            QMessageBox.critical(self, "Active Directory", f"Não foi possível abrir o dsa.msc.\n\n{exc}")
        self.quick_dsa_button.end_loading()

    def quick_open_compmgmt(self):
        if os.name != "nt":
            show_notice(self, "O Gerenciamento do Computador está disponível somente no Windows.")
            self.quick_compmgmt_button.end_loading()
            return
        arguments = ["mmc.exe", "compmgmt.msc"]
        if self.connection_active and self.target:
            arguments.append(f"/computer=\\\\{self.target}")
        try:
            subprocess.Popen(arguments, creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
            scope = self.target if self.connection_active and self.target else "computador local"
            self.append_log(f"\n[ATALHO] Gerenciamento do Computador aberto para {scope}.\n")
        except OSError as exc:
            QMessageBox.critical(self, "Gerenciamento do Computador", f"Não foi possível abrir o compmgmt.msc.\n\n{exc}")
        self.quick_compmgmt_button.end_loading()

    def start_screen_capture(self):
        """Recorte de tela: oculta o Atlas, congela os monitores e abre a seleção."""
        if self.screen_capture_session is not None:
            return
        self.screen_capture_button.setEnabled(False)
        window = self.window()
        self.screen_capture_opacity = window.windowOpacity() or 1.0
        window.setWindowOpacity(0.0)
        # Aguarda o compositor redesenhar sem o Atlas antes de congelar a tela.
        QTimer.singleShot(220, self._open_screen_capture_overlay)

    def _open_screen_capture_overlay(self):
        session = ScreenCaptureSession(self)
        session.finished.connect(self._screen_capture_selected)
        session.cancelled.connect(self._end_screen_capture)
        self.screen_capture_session = session
        try:
            started = session.start()
        except Exception:
            started = False
        if not started:
            self._end_screen_capture()
            show_notice(self, "Não foi possível iniciar a captura de tela.", "Capturar Tela")

    def _end_screen_capture(self):
        if self.screen_capture_session is not None:
            self.screen_capture_session.deleteLater()
        self.screen_capture_session = None
        self.window().setWindowOpacity(self.screen_capture_opacity)
        self.screen_capture_button.setEnabled(True)

    def _screen_capture_selected(self, image: QImage):
        self._end_screen_capture()
        editor = CaptureEditorDialog(
            image, str(screen_capture_folder() / default_capture_filename()),
            dark=self.dark_mode, parent=self,
        )
        editor.saved.connect(self.screen_capture_saved.emit)
        editor.exec()

    def finish_screen_capture_save(self, ok: bool, path: str):
        if ok:
            self.append_log(f"\n[CAPTURA] Imagem salva em {path}\n")
            return
        show_notice(
            self,
            "Não foi possível salvar a captura. Verifique a pasta escolhida e tente novamente.",
            "Capturar Tela",
        )

    def open_free_orientation(self):
        if not self.connection_active or not self.target:
            show_notice(self, "Conecte uma estação remota antes de enviar uma orientação livre.")
            return
        remote_user = str(
            self.last_status_data.get("user_display")
            or self.last_status_data.get("user")
            or "usuário conectado"
        )
        dialog = FreeOrientationDialog(remote_user, self)
        if dialog.exec() != QDialog.Accepted:
            return
        payload = {
            "title": "Orientação livre",
            "guidance": dialog.text(),
            "path": "",
            "contact": "",
        }
        self.append_log(f"\n[ORIENTAÇÃO LIVRE] Enviando mensagem para {self.target}…\n")
        self.send_user_orientation(payload, previewed=True)

    def handle_admin_lock(self):
        if not self.connection_active:
            show_notice(self, "Conecte uma estação remota primeiro.")
            return
        if self.admin_status_widget.is_admin is None:
            self.refresh_panel()
        elif self.admin_status_widget.is_admin:
            self.change_admin_membership("remove")
        else:
            self.change_admin_membership("add")

    def change_admin_membership(self, operation: str):
        adding = operation == "add"
        verb = "adicionar aos" if adding else "remover dos"
        if not confirm_action(
            self, "Alterar administrador local",
            f"Deseja {verb} Administradores locais o usuário conectado em {self.target}?",
        ):
            return
        self.append_log(f"\n[ADMIN LOCAL] Alterando associação administrativa em {self.target}...\n")
        started = self.run_bridge(
            "admin_set", self.target, operation,
            popup_title="Administrador local",
            popup_subtitle=f"Resultado da alteração administrativa em {self.target}.",
        )
        if started:
            self.admin_status_widget.lock_button.setEnabled(False)
            self.printer_summary_admin.setEnabled(False)
            self.quick_admin_button.setEnabled(False)
            self.printer_admin_pulse.stop()
            self.printer_admin_opacity.setOpacity(1.0)

    @staticmethod
    def normalize_printer_name(value: str) -> str:
        name = value.replace(" (Padrão)", "").strip().rstrip("\\/")
        if "\\" in name:
            name = name.split("\\")[-1]
        return name.strip()

    def printer_choices(self) -> tuple[list[str], list[str]]:
        def split_values(key: str) -> list[str]:
            raw = str(self.last_status_data.get(key, ""))
            values = []
            for item in raw.split(","):
                name = self.normalize_printer_name(item)
                if name and name.lower() not in {"nenhum", "nenhuma", "não identificada"} and name not in values:
                    values.append(name)
            return values
        return split_values("printer_names"), split_values("printer_groups")

    def select_printer_for_quick_action(self, title: str) -> str:
        if not self.connection_active:
            show_notice(self, "Conecte uma estação remota primeiro.")
            return ""
        installed, allowed = self.printer_choices()
        default_name = self.normalize_printer_name(str(self.last_status_data.get("default_printer", "")))
        choices = installed or allowed
        if not choices:
            show_notice(self, "Nenhuma impressora foi listada para a estação conectada.")
            return ""
        dialog = PrinterSelectionDialog(title, choices, default_name, self)
        if dialog.exec() != QDialog.Accepted:
            return ""
        return dialog.value()

    def ping_printer(self):
        printer = self.select_printer_for_quick_action("Pingar impressora")
        if not printer:
            return
        self.append_log(f"\n[PING IMPRESSORA] Consultando {printer}...\n")
        self.run_bridge(
            "ping_printer", printer,
            popup_title=f"Ping da impressora {printer}",
            popup_subtitle="Resultado do teste de conectividade da impressora.",
        )

    def print_test_page(self):
        printer = self.select_printer_for_quick_action("Imprimir página de teste")
        if not printer:
            return
        self.append_log(f"\n[PÁGINA DE TESTE] Enviando para {printer} em {self.target}…\n")
        started = self.run_bridge("test_print", self.target, printer)
        if started:
            self.start_printer_operation_progress("test_print", "Imprimir página de teste", printer)

    def open_printer_web(self):
        printer = self.select_printer_for_quick_action("Interface web da impressora")
        if not printer:
            return
        url = f"http://{printer}/"
        if not self.open_external_link(url):
            return
        self.append_log(f"\n[IMPRESSORA] Interface web aberta: {url}\n")

    def refresh_panel(self):
        if not self.target:
            show_notice(self, "Conecte uma estação primeiro.")
            return
        self._station_query_before = dict(self.last_status_data)
        self.set_station_ping_result({"ping_result": "Testando"})
        self.append_log(f"\n[ATUALIZAÇÃO] Consultando novamente {self.target}...\n")
        started = self.run_bridge(
            "status", self.target,
            popup_title="Painel atualizado",
            popup_subtitle=f"As informações de {self.target} foram consultadas novamente.",
        )
        if started:
            self.station_card_refresh_only = True
            self.set_connection_query_state(True, self.target, refreshing=True)
            set_refresh_icon_busy(self.refresh_button, True)

    def request_temp_cleanup(self):
        action = next((item for item in ACTIONS if item.command == "temp"), None)
        if action and self.connection_active:
            self.execute_action(action)

    def request_station_restart(self):
        action = next((item for item in ACTIONS if item.command == "restart"), None)
        if action and self.connection_active:
            self.execute_action(action)

    def execute_action(self, action: Action):
        if action.command == "open_remote":
            self.apply_filter("Suporte remoto")
            self.scroll.verticalScrollBar().setValue(0)
            return
        if action.command == "open_main":
            self.apply_filter("Menu principal")
            self.scroll.verticalScrollBar().setValue(0)
            return
        if action.command == "close_app":
            self.window().close()
            return
        if action.command == "return_standard":
            self.logout.emit()
            return
        if action.command == "legacy_tool":
            self.open_legacy()
            return
        if action.command == "connect_toggle":
            if self.connection_active:
                self.disconnect_target()
            else:
                self.target_input.setFocus()
                show_notice(self, "Digite o nome ou IP no campo superior e clique em Conectar.")
            return
        if action.command == "refresh":
            self.refresh_panel()
            return
        if action.admin_only and self.profile != "ins":
            QMessageBox.warning(self, APP_NAME, "Esta função exige uma sessão INS.")
            return
        if action.needs_target and not self.target:
            show_notice(self, "Conecte uma estação remota primeiro.")
            return
        value = ""
        if action.command in {"install_printer", "remove_printer", "test_print", "set_default_printer"}:
            source_key = "printer_groups" if action.command == "install_printer" else "printer_names"
            raw = str(self.last_status_data.get(source_key, ""))
            if source_key == "printer_names" and not raw:
                raw = str(self.last_status_data.get("printers", "")).replace(" (Padrão)", "")
            choices = [item.strip() for item in raw.split(",") if item.strip() and item.strip().lower() not in {"nenhum", "nenhuma"}]
            if action.command == "install_printer":
                dialog = AuthorizedPrinterDialog(action.title, choices, self)
                if dialog.exec() != QDialog.Accepted:
                    return
                value = dialog.value()
            else:
                dialog = AuthorizedPrinterDialog(action.title, choices, self)
                if dialog.exec() != QDialog.Accepted:
                    return
                value = dialog.value()
            if not value.strip():
                return
        if action.destructive:
            confirmation_message = (
                f"O Atlas Repair executará em {self.target}:\n\n"
                "• Limpeza da pasta TEMP\n"
                "• Limpeza do cache DNS\n"
                "• Atualização das políticas\n"
                "• Configuração do Trellix\n\n"
                "Deseja iniciar a rotina completa?"
                if action.command == "atlas_repair" else
                f"Deseja realmente executar “{action.title.split('  ', 1)[-1]}” em {self.target}?"
            )
            if not confirm_action(
                self, "Confirmar ação",
                confirmation_message,
            ):
                return
        self.append_log(f"\n[AÇÃO] {action.title} — {self.target or 'computador local'}\n")
        display_title = action.title.split("  ", 1)[-1]
        silent_feedback = action.command in {"cmrc", "inetcpl", "cert_list", "remote_process_list", "user_software_list"}
        printer_progress = action.command in {"install_printer", "remove_printer", "set_default_printer", "test_print"}
        started = self.run_bridge(
            action.command, self.target, value,
            popup_title="" if silent_feedback or printer_progress else display_title,
            popup_subtitle="" if silent_feedback or printer_progress else f"Resultado da ação executada em {self.target or 'computador local'}.",
        )
        if started and printer_progress:
            self.start_printer_operation_progress(action.command, display_title, value)
        if started and not printer_progress and (action.category == "Suporte remoto" or action.command in {"logoff", "restart"}):
            card = next((item for current, item in getattr(self, "cards", ())
                         if current.command == action.command), None)
            if card is not None:
                self.remote_progress_card = card
                self.remote_progress_command = action.command
                card.start_remote_progress()
        if started and not printer_progress and (action.command in LOADING_ACTIONS or action.category == "Suporte remoto"
                        or action.command in {"logoff", "restart"}):
            self.set_action_loading(action.command, True)

    def start_printer_operation_progress(self, command: str, title: str, value: str):
        minimum_ms = 600 if command == "install_printer" else 400
        messages = {
            "install_printer": f"Instalando {value} em {self.target}. As impressoras serão atualizadas ao concluir.",
            "remove_printer": f"Excluindo {value} de {self.target}. As impressoras serão atualizadas ao concluir.",
            "set_default_printer": f"Definindo {value} como padrão em {self.target}. O painel será sincronizado ao concluir.",
            "test_print": f"Enviando uma página de teste para {value} em {self.target}.",
        }
        self.printer_operation_command = command
        self.printer_operation_refresh_pending = False
        self.printer_operation_result = ""
        self.printer_operation_progress = OperationProgressDialog(
            title, messages.get(command, "Executando operação de impressora…"), minimum_ms, self,
        )
        self.printer_operation_progress.completed.connect(self.finish_printer_operation_progress)
        self.printer_operation_progress.show()

    def finish_printer_operation_progress(self, ok: bool, output: str):
        self.printer_operation_progress = None
        self.printer_operation_command = ""
        self.printer_operation_refresh_pending = False
        self.printer_operation_result = ""

    def refresh_printer_operation_status(self):
        if not self.printer_operation_refresh_pending or not self.printer_operation_progress:
            return
        if not self.connection_active or not self.target:
            self.printer_operation_refresh_pending = False
            self.printer_operation_progress.finish_operation(
                True, "Solicitação processada, mas a estação foi desconectada antes da atualização dos painéis."
            )
            return
        self.printer_refresh_scope = "both"
        if not self.run_bridge("printer_status", self.target):
            self.printer_operation_refresh_pending = False
            self.printer_operation_progress.finish_operation(
                True, "Solicitação processada, mas não foi possível atualizar os resumos de impressoras."
            )

    def run_bridge(
        self, action: str, target: str = "", value: str = "",
        popup_title: str = "", popup_subtitle: str = "",
    ):
        if self.runner.state() != QProcess.NotRunning:
            show_notice(self, "Aguarde a operação atual terminar.")
            return False
        self.pending_action = action
        if action == "status":
            self._status_core_received = False
        self.pending_popup_title = popup_title
        self.pending_popup_subtitle = popup_subtitle
        self.command_output = ""
        launcher = str(resource_path("scripts/bridge_launcher.ps1"))
        bridge = str(resource_path("scripts/bridge.ps1"))
        args = ["-Script", bridge, "-Action", action, "-Computer", target, "-Value", value]
        environment = None
        if action in {"faq_catalog", "faq_export", "faq_single", "ticket_catalog"}:
            password = (
                self._capri_session_password
                if action == "ticket_catalog"
                else self._capri_session_password or credential_read(self.capri_username, "capri") or ""
            )
            if password:
                environment = capri_environment(self.capri_username, password)
        # Consultas remotas usam WMI, Registro e ADSI, que podem ficar aguardando
        # indefinidamente quando RPC/Firewall responde de forma incompleta.
        # O watchdog garante que a interface sempre recupere o estado utilizável.
        timeout_ms = 60_000 if action == "status" else 0
        if action == "printer_status":
            timeout_ms = 35_000
        elif action == "admin_status":
            timeout_ms = 25_000
        elif action == "ad_user_info_login":
            timeout_ms = 45_000
        elif action in {"remote_process_list", "user_software_list", "remote_process_end", "remote_process_end_group"}:
            timeout_ms = 70_000
        elif action == "support_escalation_show":
            timeout_ms = 45_000
        return self.runner.run_script(launcher, args, environment, timeout_ms=timeout_ms)

    def _append_background_output(self, text: str):
        self._background_output_chunks.append(text)
        progress_values = re.findall(r"@@FAQ_PROGRESS@@(\d{1,3})", text)
        if progress_values:
            value = max(0, min(99, int(progress_values[-1])))
            self.faq_mapping_progress_value = max(getattr(self, "faq_mapping_progress_value", 0), value)
            if hasattr(self, "faq_mapping_progress_bar"):
                self.faq_mapping_progress_bar.setValue(self.faq_mapping_progress_value)
            if hasattr(self, "faq_mapping_progress_percent"):
                self.faq_mapping_progress_percent.setText(f"{self.faq_mapping_progress_value}%")
        ticket_progress_values = re.findall(r"@@TICKET_PROGRESS@@(\d{1,3})", text)
        if ticket_progress_values:
            value = max(0, min(99, int(ticket_progress_values[-1])))
            if self.background_pending_action == "user_ticket_preview":
                self.update_user_ticket_preview_progress(value)
            else:
                self.ticket_sync_progress_value = max(self.ticket_sync_progress_value, value)
                if hasattr(self, "ticket_sync_progress_bar"):
                    self.ticket_sync_progress_bar.setValue(self.ticket_sync_progress_value)
                if hasattr(self, "ticket_sync_progress_percent"):
                    self.ticket_sync_progress_percent.setText(f"{self.ticket_sync_progress_value}%")
        visible_text, self._background_log_pending, self._background_log_skipping = filter_bridge_log_chunk(
            text, self._background_log_pending, self._background_log_skipping
        )
        if visible_text:
            self.log.moveCursor(QTextCursor.End)
            self.log.insertPlainText(visible_text)
            self.log.ensureCursorVisible()

    def run_background_bridge(self, action: str, target: str = "", value: str = ""):
        if self.background_runner.state() != QProcess.NotRunning:
            show_notice(self, "A atualização do Capri já está em andamento em segundo plano.")
            return False
        self.background_pending_action = action
        self._background_output_chunks = []
        self._background_log_pending = ""
        self._background_log_skipping = False
        launcher = str(resource_path("scripts/bridge_launcher.ps1"))
        bridge = str(resource_path("scripts/bridge.ps1"))
        args = ["-Script", bridge, "-Action", action, "-Computer", target, "-Value", value]
        password = self._capri_session_password or credential_read(self.capri_username, "capri") or ""
        environment = {}
        if password:
            environment = capri_environment(self.capri_username, password)
        return self.background_runner.run_script(launcher, args, environment)

    def _background_execution_done(self, ok: bool):
        if self._background_log_pending and not self._background_log_skipping:
            self.log.moveCursor(QTextCursor.End)
            self.log.insertPlainText(self._background_log_pending + "\n")
        self._background_log_pending = ""
        self._background_log_skipping = False
        action, output = self.background_pending_action, "".join(self._background_output_chunks)
        self._background_output_chunks = []
        generation = self.background_user_ticket_generation
        self.background_pending_action = ""
        if action == "user_ticket_preview":
            self.finish_user_ticket_preview(ok, output, generation)
            return
        previous_action, previous_output = self.pending_action, self.command_output
        previous_popup = self.pending_popup_title, self.pending_popup_subtitle
        try:
            self.pending_popup_title = ""
            self.pending_popup_subtitle = ""
            if action == TICKET_CATALOG and self.ticket_bookmark_refreshing:
                action = "ticket_status_only"
            self.execution_done(ok, action, output)
        finally:
            self.pending_action, self.command_output = previous_action, previous_output
            self.pending_popup_title, self.pending_popup_subtitle = previous_popup

    def remote_process_confirmed(self, action: str, ok: bool, output: str) -> bool:
        """Distingue uma operação verificada de uma tarefa apenas despachada."""
        if not ok:
            return False
        if action == "outlook":
            return bool(re.search(r"(?i)outlook[^\n]*(?:fechado|encerrado)", output))
        if action in {"browser_close_chrome", "browser_close_edge"}:
            return bool(re.search(r"(?i)(?:chrome|edge)[^\n]*fechado", output))
        if action == "cert_list":
            return bool(self.extract_json_marker(output, "@@CERTIFICATES@@"))
        if action in {"remote_process_list", "user_software_list"}:
            marker = "@@REMOTE_PROCESSES@@" if action == "remote_process_list" else "@@USER_SOFTWARE@@"
            result = self.extract_json_marker(output, marker)
            return isinstance(result, dict) and isinstance(result.get("items"), list)
        # Tarefas agendadas, WMI e reinício confirmam o envio, não o término.
        return False

    def execution_done(self, ok: bool, action_override: str = "", output_override: str = ""):
        completed_action = action_override or self.pending_action
        is_background = bool(action_override)
        saved_output = self.command_output
        if output_override:
            self.command_output = output_override
        if not is_background:
            for quick_button in getattr(self, "quick_buttons", []):
                if quick_button.loading:
                    quick_button.end_loading()
            if self.loading_command:
                self.set_action_loading(self.loading_command, False)
            if self.remote_progress_card and self.remote_progress_command == completed_action:
                confirmed = self.remote_process_confirmed(completed_action, ok, self.command_output)
                self.remote_progress_card.finish_remote_progress(ok, confirmed)
                self.remote_progress_card = None
                self.remote_progress_command = ""
        if completed_action in {"ad_user_info", "ad_user_info_login"}:
            self.update_quick_ad_availability()
        if completed_action == "disk_profiles":
            set_refresh_icon_busy(self.disk_d_button, False)
            self.quick_disk_button.setEnabled(self.connection_active)
            self.disk_d_button.setEnabled(self.connection_active)
        if completed_action == "authorized_software_list":
            self.software_loading = False
            software_access = self.connection_active and bool(self.last_status_data.get("software_access", False))
            self.nav_buttons["Softwares autorizados"].setEnabled(software_access)
        if completed_action == "faq_catalog":
            if ok:
                self.faq_mapping_progress_value = 100
                if hasattr(self, "faq_mapping_progress_bar"):
                    self.faq_mapping_progress_bar.setValue(100)
                if hasattr(self, "faq_mapping_progress_percent"):
                    self.faq_mapping_progress_percent.setText("100%")
            self.faq_loading = False
            feedback_button = getattr(self, "faq_refresh_feedback_button", None)
            if feedback_button is not None:
                set_refresh_icon_busy(feedback_button, False)
            self.faq_refresh_feedback_button = None
            self.faq_refresh_button.setEnabled(True)
            self.faq_incremental_button.setEnabled(True)
        if completed_action == "faq_single":
            set_refresh_icon_busy(self.faq_specific_button, False)
            set_refresh_icon_busy(self.specific_faq_button, False)
            self.faq_specific_button.setEnabled(True)
            self.specific_faq_button.setEnabled(True)
        if completed_action == "ticket_catalog":
            self.ticket_sync_progress_timer.stop()
            set_refresh_icon_busy(self.ticket_refresh_cache_button, False)
            if ok:
                self.ticket_sync_progress_value = 100
                if hasattr(self, "ticket_sync_progress_bar"):
                    self.ticket_sync_progress_bar.setValue(100)
                if hasattr(self, "ticket_sync_progress_percent"):
                    self.ticket_sync_progress_percent.setText("100%")
            self.ticket_loading = False
            self.ticket_map_button.setEnabled(True)
            self.ticket_query_button.setEnabled(True)
            self.ticket_refresh_cache_button.setEnabled(True)
        if completed_action in {"install_printer", "remove_printer", "set_default_printer", "test_print"} and self.printer_operation_progress:
            result = self.clean_result_output(self.command_output)
            if ok:
                self.printer_operation_result = result
                self.printer_operation_refresh_pending = True
                self.printer_operation_progress.phase_label.setText("Atualizando as impressoras nos dois painéis…")
                QTimer.singleShot(0, self.refresh_printer_operation_status)
            else:
                self.printer_operation_progress.finish_operation(False, result)
        if completed_action == "printer_status":
            refreshed = ok and self.apply_printer_status(self.command_output)
            set_refresh_icon_busy(self.printer_summary_refresh, False)
            self.printer_summary_refresh.setEnabled(self.connection_active)
            if not refreshed:
                self.append_log("[IMPRESSORAS] Não foi possível atualizar o contêiner de impressoras.\n")
            if self.printer_operation_refresh_pending and self.printer_operation_progress:
                self.printer_operation_refresh_pending = False
                result = self.printer_operation_result
                if refreshed:
                    result = "Solicitação processada; os resumos de impressoras foram atualizados."
                    if self.printer_operation_command == "test_print":
                        result += " A impressão física da página não pode ser confirmada remotamente."
                else:
                    result = (result + "\n\nA atualização dos resumos de impressoras não foi confirmada.").strip()
                self.printer_operation_progress.finish_operation(True, result, completion_confirmed=refreshed)
        if completed_action == "admin_status":
            refreshed = ok and self.apply_admin_status(self.command_output)
            if not refreshed:
                self.admin_status_widget.set_connected(self.connection_active)
                self.sync_printer_admin_button()
        if ok and completed_action == "status":
            self.update_status_panel(self.command_output)
        if completed_action == "status":
            if not ok and self.connection_active and self.last_status_data:
                settled = dict(self.last_status_data)
                for key in ("admin", "rdp", "disk_d", "sccm", "printers", "printer_names", "default_printer", "printer_groups"):
                    if str(settled.get(key, "")).startswith("Concluindo"):
                        settled[key] = "Não foi possível consultar no prazo"
                self.update_status_panel("@@STATUS@@" + json.dumps(settled, ensure_ascii=False))
            if self.station_load_cycle_active and not self.station_enrichment_active:
                self.finish_station_enrichment(
                    False,
                    "Carregamento concluído parcialmente; consulte o Console de atividades.",
                )
            self.set_connection_query_state(False)
            self.station_card_refresh_only = False
        self.append_log("[CONCLUÍDO]\n" if ok else "[ERRO] A operação não foi concluída.\n")
        if self.target:
            if completed_action == "status" and not ok and "não foi encontrado" in self.command_output.casefold():
                self.connection_label.setText("Micro não encontrado. Confira o endereço lógico e tente novamente.")
            elif completed_action == "status" and not ok and self.connection_active:
                self.connection_label.setText("Conectado com dados principais; detalhes remotos não responderam no prazo.")
            else:
                self.connection_label.setText(
                    "Painel sincronizado e pronto para atendimento."
                    if self.connection_active else "Não foi possível estabelecer a conexão."
                )
        if completed_action == "status":
            set_refresh_icon_busy(self.refresh_button, False)
            self.refresh_button.setEnabled(self.connection_active)
        if completed_action in {"ad_user_info", "ad_user_info_login"}:
            data = self.extract_json_marker(self.command_output, "@@ADUSER@@") if ok else None
            if data:
                ADUserDialog(data, self).exec()
            else:
                content = self.clean_result_output(self.command_output)
                self.show_information_result(
                    "Informações do usuário no AD",
                    "Não foi possível organizar os dados da conta conectada.",
                    content or "A consulta não retornou informações. Consulte o Console de atividades.",
                    False,
                )
        if completed_action == "disk_profiles":
            data = self.extract_json_marker(self.command_output, "@@DISKPROFILE@@") if ok else None
            if data:
                network_count = int(data.get("network_drive_count", 0) or 0)
                cache_key = self.target.lower()
                if network_count > 0:
                    self.disk_profiles_cache[cache_key] = {"time": time.monotonic(), "data": data}
                else:
                    # Um retorno apenas com discos locais pode ser legítimo,
                    # mas não deve mascarar uma sessão interativa incompleta.
                    self.disk_profiles_cache.pop(cache_key, None)
                DiskProfilesDialog(data, self).exec()
            else:
                content = self.clean_result_output(self.command_output)
                self.show_information_result(
                    "Discos e perfis",
                    "Não foi possível organizar o diagnóstico da estação.",
                    content or "A consulta não retornou informações. Consulte o Console de atividades.",
                    False,
                )
        if completed_action in {"remote_process_list", "user_software_list"}:
            marker = "@@REMOTE_PROCESSES@@" if completed_action == "remote_process_list" else "@@USER_SOFTWARE@@"
            data = self.extract_json_marker(self.command_output, marker) if ok else None
            if isinstance(data, dict) and isinstance(data.get("items"), list):
                self.show_remote_inventory(data, completed_action == "remote_process_list")
            else:
                self.show_information_result(
                    "Processos remotos" if completed_action == "remote_process_list" else "Programas instalados",
                    "A consulta remota não foi concluída.",
                    self.clean_result_output(self.command_output) or "Verifique o Console de atividades.", False,
                )
        if completed_action == "cert_list":
            data = self.extract_json_marker(self.command_output, "@@CERTIFICATES@@") if ok else None
            if data:
                dialog = CertificatesDialog(data, self)
                if dialog.exec() == QDialog.Accepted:
                    certificate = dialog.selected_certificate()
                    if certificate:
                        display_name = str(certificate.get("display_name", "certificado selecionado"))
                        scope = str(certificate.get("scope", "estação remota"))
                        if confirm_action(
                            self, "Excluir certificado remoto",
                            f"Deseja excluir “{display_name}” de {scope} em {self.target}?\n\n"
                            "Esta ação remove somente o certificado selecionado da estação remota.",
                        ):
                            payload = json.dumps({
                                "store_type": certificate.get("store_type", ""),
                                "user_sid": certificate.get("user_sid", ""),
                                "user_account": certificate.get("user_account", ""),
                                "thumbprint": certificate.get("thumbprint", ""),
                                "display_name": display_name,
                            }, ensure_ascii=False, separators=(",", ":"))
                            self.append_log(f"\n[CERTIFICADOS] Excluindo {display_name} somente de {self.target}...\n")
                            self.run_bridge(
                                "cert_delete", self.target, payload,
                                popup_title="Certificado excluído",
                                popup_subtitle=f"Resultado da exclusão executada somente em {self.target}.",
                            )
            else:
                content = self.clean_result_output(self.command_output)
                self.show_information_result(
                    "Certificados digitais remotos",
                    "Não foi possível listar os certificados pessoais da estação.",
                    content or "A consulta não retornou certificados. Consulte o Console de atividades.",
                    False,
                )
        if completed_action == "authorized_software_list":
            data = self.extract_json_marker(self.command_output, "@@SOFTWARES@@") if ok else None
            if data:
                self.software_catalog = data
                self.software_expanded_categories.clear()
                self.update_software_suggestions()
                raw_items = data.get("items") or []
                item_count = 1 if isinstance(raw_items, dict) else len(raw_items)
                count = int(data.get("count", item_count))
                self.section_description.setText(
                    f"{count} executáveis disponíveis no drive X:, classificados por finalidade para o usuário conectado."
                )
            else:
                self.software_catalog = {}
                content = self.clean_result_output(self.command_output)
                self.show_information_result(
                    "Softwares autorizados",
                    "Não foi possível montar o catálogo do drive X:.",
                    content or "A consulta não retornou executáveis. Consulte o Console de atividades.",
                    False,
                )
            if self.current_section == "Softwares autorizados":
                self.current_columns = 0
                self.reflow()
        if completed_action == "faq_catalog":
            data = self.extract_json_marker(self.command_output, "@@FAQS@@") if ok else None
            if data:
                previous_catalog = self.faq_catalog
                mapping_complete = bool(data.get("complete", False))
                if mapping_complete or not previous_catalog:
                    merged = {}
                    for item in previous_catalog.get("items") or []:
                        key = normalize_faq_number(item.get("id"))
                        if key: merged[key] = item
                    for item in data.get("items") or []:
                        key = normalize_faq_number(item.get("id"))
                        if key: merged[key] = item
                    data["items"] = list(merged.values())
                    data["count"] = len(data["items"])
                    data["new_count"] = int(data.get("new_count", len(data.get("items") or [])) or 0)
                    self.faq_catalog = data
                self.faq_expanded_categories.clear()
                self.rebuild_local_search_indexes()
                self.update_faq_suggestions()
                cache_saved = save_faq_cache(data) if mapping_complete else False
                count = int(data.get("count", 0) or 0)
                expected = int(data.get("expected_count", 0) or 0)
                categories = int(data.get("categories_scanned", 0) or 0)
                if expected and count < expected:
                    preservation = "o catálogo completo anterior foi preservado" if previous_catalog else "a leitura parcial não será salva"
                    self.section_description.setText(
                        f"Coleta parcial: {count} de {expected} FAQs; {preservation}."
                    )
                else:
                    total_text = f"{count} de {expected}" if expected else str(count)
                    self.section_description.setText(
                        f"{total_text} FAQs oficiais preservadas na árvore do Capri; {categories} páginas analisadas."
                    )
                if mapping_complete and not cache_saved:
                    self.append_log("\n[FAQ] Aviso: o catálogo foi carregado, mas não pôde ser salvo no perfil local.\n")
                elif not mapping_complete:
                    self.append_log("\n[FAQ] Coleta parcial descartada; o catálogo salvo não foi substituído.\n")
                if mapping_complete:
                    self.map_all_orientations()
            else:
                content = self.clean_result_output(self.command_output)
                self.show_information_result(
                    "FAQs — Capri",
                    "Não foi possível montar a central de conhecimento.",
                    content or "Entre no Capri pelo navegador corporativo e tente atualizar novamente.",
                    False,
                )
        if completed_action == "faq_single":
            record = self.extract_json_marker(self.command_output, "@@FAQ_SINGLE@@") if ok else None
            if record and self.apply_single_faq_update(record):
                show_notice(self, f"A FAQ {self.pending_specific_faq} e sua orientação foram atualizadas localmente.")
        if completed_action == "ticket_status_only":
            self.ticket_bookmark_refreshing = False
            set_refresh_icon_busy(self.ticket_bookmark_refresh, False)
            result = self.extract_json_marker(self.command_output, "@@TICKET_STATUS@@") if ok else None
            if result and result.get("complete") and isinstance(result.get("updates"), list):
                catalog_tickets = {ticket_number(item.get("number") or item.get("id")): item
                                   for item in self.ticket_catalog.get("items", []) if isinstance(item, dict)}
                snapshots = self.ticket_bookmarks.get("snapshots", {})
                tickets = {**snapshots, **catalog_tickets}
                confirmed, changes = apply_state_updates(
                    tickets, result["updates"], classify_ticket_state,
                    datetime.now().isoformat(timespec="seconds"),
                )
                for number, snapshot in snapshots.items():
                    mapped = catalog_tickets.get(number)
                    if mapped and mapped is not snapshot:
                        snapshot.update({key: mapped[key] for key in
                                         ("state", "state_kind", "closed", "successful", "state_verified_at")
                                         if key in mapped})
                if confirmed and catalog_tickets and not save_json_cache(ticket_cache_path(), self.ticket_catalog):
                    show_notice(self, "Situações conferidas, mas não foi possível salvar o catálogo local.")
                if confirmed and snapshots and not save_bookmarks(ticket_bookmarks_path(), self.ticket_bookmarks):
                    show_notice(self, "Situações conferidas, mas não foi possível salvar as listas pessoais.")
                failed = result.get("failed") or []
                self.append_log(f"\n[CHAMADOS] Listas pessoais: {confirmed} situação(ões) conferida(s), "
                                f"{len(changes)} alteração(ões), {len(failed)} sem confirmação.\n")
                self.ticket_bookmark_update_result.setText(
                    f"{confirmed} situação(ões) conferida(s); {len(changes)} alterada(s); "
                    f"{len(failed)} sem confirmação."
                )
                self.ticket_search_cache.clear()
                if self.current_section == "Chamados":
                    self.current_columns = 0
                    self.reflow()
                if self.ticket_bookmark_popup.isVisible():
                    self.render_ticket_bookmarks_popup()
            else:
                show_notice(self, "O Capri não confirmou a atualização das situações. O catálogo foi preservado.")
                self.ticket_bookmark_update_result.setText("Consulta não confirmada; dados locais preservados.")
                self.render_ticket_bookmarks_popup()
        if completed_action == "ticket_catalog":
            data = self.extract_json_marker(self.command_output, "@@TICKETS@@") if ok else None
            received_tickets = []
            recheck_summary = ""
            if data and data.get("complete") and isinstance(data.get("items"), list):
                previous = self.ticket_catalog if isinstance(self.ticket_catalog, dict) else {}
                deduplicated = {}
                reconcile_existing = self.ticket_feedback_mode == "reconcile_mapped"
                replace_interval = self.ticket_feedback_mode in {"recent", "reconcile_mapped"}
                reconcile_from = ticket_created_date(data.get("date_from")) if replace_interval else None
                reconcile_to = ticket_created_date(data.get("date_to")) if replace_interval else None
                for item in previous.get("items") or []:
                    number = re.sub(r"\D", "", str(item.get("number") or item.get("id") or ""))
                    created_date = ticket_created_date(item.get("created"))
                    if (
                        replace_interval and created_date and reconcile_from and reconcile_to
                        and reconcile_from <= created_date <= reconcile_to
                    ):
                        continue
                    if number:
                        item["number"] = number
                        deduplicated[number] = item
                previous_count = len(deduplicated)
                for item in data["items"]:
                    number = re.sub(r"\D", "", str(item.get("number") or item.get("id") or ""))
                    if number:
                        item["number"] = number
                        deduplicated[number] = item
                        title = re.sub(r"\s+", " ", str(item.get("title") or "Sem título")).strip()
                        received_tickets.append((number, title))
                rechecked, state_changes = apply_state_updates(
                    deduplicated, data.pop("state_updates", []) or [], classify_ticket_state,
                    datetime.now().isoformat(timespec="seconds"),
                )
                failed_rechecks = data.pop("recheck_failed", []) or []
                data["state_recheck_total"] = int(data.get("state_recheck_total", 0) or 0)
                data["state_rechecked"] = rechecked
                data["state_changed"] = len(state_changes)
                data["state_recheck_failed"] = len(failed_rechecks)
                if self.ticket_feedback_mode == "recent":
                    recheck_summary = (
                        f" {rechecked} estado(s) antigo(s) conferido(s); "
                        f"{len(state_changes)} corrigido(s); {len(failed_rechecks)} sem confirmação."
                    )
                    for number, old, new in state_changes:
                        self.append_log(f"[CHAMADOS] {number}: {old} → {new}.\n")
                    if failed_rechecks:
                        self.append_log(
                            "[CHAMADOS] Sem confirmação no Capri (cache preservado): "
                            + ", ".join(map(str, failed_rechecks)) + ".\n"
                        )
                data["items"] = list(deduplicated.values())
                data["count"] = len(deduplicated)
                data["new_count"] = len(deduplicated) - previous_count
                data["complete"] = True
                mapped_months = {
                    str(value) for value in (previous.get("mapped_months") or [])
                    if re.fullmatch(r"\d{4}-\d{2}", str(value))
                }
                if self.ticket_mapping_month_key:
                    mapped_year, mapped_month = map(int, self.ticket_mapping_month_key.split("-"))
                    mapped_end = QDate(mapped_year, mapped_month, 1)
                    mapped_end = QDate(mapped_year, mapped_month, mapped_end.daysInMonth())
                    if mapped_end <= QDate.currentDate():
                        mapped_months.add(self.ticket_mapping_month_key)
                if reconcile_existing and reconcile_from and reconcile_to:
                    verified_months = set()
                    for month_key in mapped_months:
                        year_value, month_value = map(int, month_key.split("-"))
                        month_start = QDate(year_value, month_value, 1)
                        month_end = QDate(year_value, month_value, month_start.daysInMonth())
                        if (
                            month_start.isValid()
                            and reconcile_from <= datetime(year_value, month_value, 1).date()
                            and datetime(year_value, month_value, month_end.day()).date() <= reconcile_to
                        ):
                            verified_months.add(month_key)
                    mapped_months = verified_months
                    data["mapped_months_verified_at"] = datetime.now().isoformat(timespec="seconds")
                data["mapped_months"] = sorted(mapped_months)
                self.ticket_catalog = data
                self.ticket_search_cache.clear()
                self.ticket_status_combo.blockSignals(True)
                self.ticket_status_combo.setCurrentIndex(3)
                self.ticket_status_combo.blockSignals(False)
                self.ticket_status_index = 3
                self.ticket_period = "all"
                self.ticket_local_period_active = False
                self.update_local_ticket_period_button()
                self.ticket_search.blockSignals(True)
                self.ticket_search.clear()
                self.ticket_search.blockSignals(False)
                self.ticket_search_text = ""
                if not save_json_cache(ticket_cache_path(), data):
                    self.append_log("\n[CHAMADOS] Aviso: não foi possível persistir o catálogo no perfil local.\n")
                count = int(data.get("count", 0) or 0)
                scanned = int(data.get("scanned_count", 0) or 0)
                new_count = int(data.get("new_count", 0) or 0)
                total_text = f"{count} chamados no cache; {new_count} novo(s) incorporado(s)"
                self.section_description.setText(
                    f"{total_text} chamados salvos localmente. Novas pesquisas na tela usam apenas este cache."
                )
            elif ok:
                self.append_log("\n[CHAMADOS] A coleta não foi confirmada como integral; o catálogo anterior foi preservado.\n")
            self.ticket_mapping_month_key = ""
            if self.ticket_feedback_mode in {"recent", "reconcile_mapped"}:
                if data and data.get("complete") and isinstance(data.get("items"), list):
                    unique_received = dict(received_tickets)
                    if unique_received:
                        content = "\n\n".join(
                            f"{number}\n{title}" for number, title in unique_received.items()
                        )
                        subtitle = (
                            f"{len(unique_received)} chamado(s) conferido(s) e atualizado(s). "
                            "O cache e os meses mapeados foram reconciliados." + recheck_summary
                        )
                    else:
                        content = "Nenhum chamado foi encontrado no período revalidado."
                        subtitle = "Consulta concluída para o período selecionado." + recheck_summary
                    self.show_information_result("Atualização de chamados", subtitle, content, True)
                else:
                    self.show_information_result(
                        "Atualização de chamados",
                        "Não foi possível confirmar a atualização do catálogo.",
                        "O catálogo anterior foi preservado. Consulte o Console de atividades para mais detalhes.",
                        False,
                    )
            self.ticket_feedback_mode = ""
            if self.current_section == "Chamados":
                self.ticket_period = "all"
                self.ticket_local_period_active = False
                self.update_local_ticket_period_button()
                self.current_columns = 0
                self.reflow()
                self.faq_specific_input.clear()
                self.specific_faq_input.clear()
            elif ok:
                show_notice(self, "O Capri respondeu, mas não foi possível identificar o conteúdo escrito da FAQ.")
            self.pending_specific_section = ""
            self.pending_specific_faq = ""
            if self.current_section == "FAQs":
                self.current_columns = 0
                self.reflow()
        if self.pending_popup_title and not is_background:
            content = self.clean_result_output(self.command_output)
            if ok and completed_action == "status":
                content = "Consulta concluída. O resumo da estação foi atualizado em Informações."
            elif ok and completed_action in {"remote_process_end", "remote_process_end_group"}:
                ended = self.extract_json_marker(self.command_output, "@@REMOTE_PROCESS_END@@")
                if completed_action == "remote_process_end_group" and ended:
                    content = (
                        f"{ended.get('name')}: {ended.get('ended', 0)} de "
                        f"{ended.get('count', 0)} processos encerrados."
                    )
                    if ended.get("failed"):
                        content += f" PID(s) não confirmados: {', '.join(map(str, ended['failed']))}."
                else:
                    content = (f"{ended.get('name')} (PID {ended.get('pid')}) foi encerrado na estação."
                               if ended and ended.get("confirmed") else "A estação não confirmou o encerramento.")
                ok = bool(ended and ended.get("confirmed"))
            elif ok and not content:
                content = "A solicitação foi enviada e concluída sem mensagens adicionais."
            elif not ok and not content:
                content = "A operação não pôde ser concluída. Consulte o Console de atividades para mais detalhes."
            self.show_information_result(
                self.pending_popup_title,
                self.pending_popup_subtitle,
                content,
                ok,
            )
            self.pending_popup_title = ""
            self.pending_popup_subtitle = ""
        if completed_action in {"remote_process_end", "remote_process_end_group"} and self.connection_active:
            QTimer.singleShot(0, lambda: self.run_bridge("remote_process_list", self.target))
        if completed_action in {"admin", "admin_set"}:
            if ok and self.target:
                self.append_log("\n[ATUALIZAÇÃO] Confirmando o novo estado de Admin local...\n")
                if not self.run_bridge("admin_status", self.target):
                    self.admin_status_widget.set_connected(self.connection_active)
            else:
                self.admin_status_widget.set_connected(self.connection_active)
                self.sync_printer_admin_button()

    def show_remote_inventory(self, data: dict, process_mode: bool):
        if not self.connection_active or not self.target:
            return
        dialog = RemoteInventoryDialog(
            "Processos do usuário" if process_mode else "Programas instalados",
            data["items"], self.target, process_mode, self,
        )
        if dialog.exec() != QDialog.Accepted:
            return
        if dialog.choice == "refresh":
            action = "remote_process_list" if process_mode else "user_software_list"
            QTimer.singleShot(0, lambda: self.run_bridge(action, self.target))
        elif dialog.choice == "end":
            selected = dialog.selected()
            group = bool(selected and selected.get("pids"))
            if not selected or not confirm_action(
                self, "Encerrar processo remoto",
                f"Encerrar {selected.get('name', 'processo')} "
                + (f"({len(selected['pids'])} processos selecionados) " if group
                   else f"(PID {selected.get('pid', '—')}) ")
                + f"do usuário conectado em {self.target}? Dados não salvos nesse programa podem ser perdidos.",
            ):
                return
            payload = json.dumps(
                {"pids": selected["pids"], "name": selected.get("name"), "user": data.get("user")}
                if group else
                {"pid": selected.get("pid"), "name": selected.get("name"), "user": data.get("user")},
                ensure_ascii=False,
            )
            QTimer.singleShot(0, lambda: self.run_bridge(
                "remote_process_end_group" if group else "remote_process_end", self.target, payload,
                popup_title="Processos remotos" if group else "Processo remoto",
                popup_subtitle="Resultado informado pela estação.",
            ))

    def set_action_loading(self, command: str, loading: bool):
        for action, card in self.cards:
            if action.command == command:
                card.set_loading(loading)
                break
        self.loading_command = command if loading else ""
        if not loading:
            self.update_action_card_availability()

    def update_action_card_availability(self):
        if not hasattr(self, "cards"):
            return
        has_user = bool(self.station_user_login(self.last_status_data.get("user")))
        user_actions = {"admin", "ad_groups", "outlook", "remote_process_list", "user_software_list"}
        for action, card in self.cards:
            available = (not action.needs_target or self.connection_active)
            if action.command in user_actions:
                available = available and has_user
            if self.loading_command != action.command:
                card.setEnabled(available)

    @staticmethod
    def clean_result_output(content: str) -> str:
        lines = []
        for line in content.splitlines():
            if ("@@STATUS@@" in line or "@@ADUSER@@" in line or "@@DISKPROFILE@@" in line
                    or "@@SOFTWARES@@" in line or "@@FAQS@@" in line or "@@CERTIFICATES@@" in line
                    or "@@TICKETS@@" in line or "@@PRINTER_STATUS@@" in line
                    or "@@ADMIN_STATUS@@" in line or "@@TICKET_PROGRESS@@" in line
                    or "@@REMOTE_PROCESSES@@" in line or "@@USER_SOFTWARE@@" in line
                    or "@@REMOTE_PROCESS_END@@" in line):
                continue
            stripped = line.strip()
            if "bridge_launcher.ps1 :" in line:
                message = line.split("bridge_launcher.ps1 :", 1)[1].strip()
                if message:
                    lines.append(message)
                continue
            if (stripped.startswith("No ") and "bridge_launcher.ps1:" in stripped) \
                    or stripped.startswith("+") or stripped.startswith("~") \
                    or "CategoryInfo" in stripped or "FullyQualifiedErrorId" in stripped:
                continue
            lines.append(line)
        return "\n".join(lines).strip()

    @staticmethod
    def extract_json_marker(content: str, marker: str) -> dict | None:
        for line in content.splitlines():
            if marker not in line:
                continue
            try:
                return json.loads(line.split(marker, 1)[1].strip())
            except (json.JSONDecodeError, IndexError):
                return None
        return None

    def show_information_result(self, title: str, subtitle: str, content: str, success: bool = True):
        dialog = ResultDialog(title, subtitle, content, success, self)
        dialog.exec()

    @staticmethod
    def station_user_login(value: object) -> str:
        account = str(value or "").strip()
        if not account or account.casefold() in {"nenhum usuário logado", "nao informado", "não informado", "—"}:
            return ""
        if "\\" in account:
            account = account.rsplit("\\", 1)[1]
        elif "@" in account:
            account = account.split("@", 1)[0]
        account = account.strip()
        return account if re.fullmatch(r"[A-Za-z0-9._-]{1,128}", account) else ""

    def sync_station_user_control(self, data: dict):
        """Consulta o usuário da estação ao fim do enriquecimento, sem trocar a aba ativa."""
        if str(data.get("status") or "").casefold() != "conectado":
            return
        if any(
            "concluindo consulta" in str(data.get(key) or "").casefold()
            for key in ("admin", "sccm", "printers", "printer_groups")
        ):
            return
        login = self.station_user_login(data.get("user"))
        if not login:
            return
        self.station_enrichment_active = True
        self.station_enrichment_login = login.casefold()
        self.set_connection_progress_stage(
            60, "Detalhes da estação carregados; consultando usuário no Active Directory…"
        )
        current_login = str(self.user_control_data.get("login") or "").casefold()
        if login.casefold() == current_login:
            self.last_auto_user_login = login.casefold()
            self.user_login_input.setText(login)
            full_name = str(self.user_control_data.get("display_name") or "").strip()
            if full_name:
                self.finish_station_enrichment(True, "Estação e usuário carregados.")
                self.start_user_ticket_preview(login, full_name, from_station=True)
            else:
                self.pending_station_user_login = login
                self.flush_pending_station_user()
            return
        if login.casefold() == self.last_auto_user_login and not self.pending_station_user_login:
            self.pending_station_user_login = login
            self.flush_pending_station_user()
            return
        self.pending_station_user_login = login
        self.flush_pending_station_user()

    def flush_pending_station_user(self):
        login = self.pending_station_user_login
        if not login:
            return
        if self.user_runner.state() != QProcess.NotRunning or self.user_query_active:
            QTimer.singleShot(150, self.flush_pending_station_user)
            return
        self.pending_station_user_login = ""
        self.last_auto_user_login = login.casefold()
        self.user_login_input.setText(login)
        self.lookup_user_control()

    def update_status_panel(self, output: str):
        marker = "@@STATUS@@"
        # O bridge publica primeiro o núcleo e depois o resultado enriquecido.
        # A leitura reversa garante que a atualização final prevaleça.
        for line in reversed(output.splitlines()):
            if marker not in line:
                continue
            try:
                data = json.loads(line.split(marker, 1)[1].strip())
            except (json.JSONDecodeError, IndexError):
                continue
            previous_software_root = str(self.last_status_data.get("software_root", ""))
            current_software_root = str(data.get("software_root", ""))
            if previous_software_root and previous_software_root != current_software_root:
                self.software_catalog = {}
            self.last_status_data = data
            self.update_printer_color_permission()
            for key, (caption, label, display_widget) in self.status_labels.items():
                value = str(data.get(key, "—"))
                if key == "admin":
                    self.admin_status_widget.set_status(caption, value)
                elif key == "printers":
                    label.setText(self.format_printer_status("", value))
                elif isinstance(display_widget, StationDataFieldCard):
                    display_widget.set_value(value)
                else:
                    label.setText(value)
            self.update_printer_summary()
            status_value = str(data.get("status", ""))
            connected = status_value.lower() == "conectado"
            self.status_card.setProperty("connected", connected)
            station = str(data.get("station", ""))
            remote_user = str(data.get("user") or "Nenhum usuário logado").strip()
            ad_name = str(data.get("user_ad_name") or "").strip()
            self.station_identity_machine.setText(station or "—")
            self.set_station_ping_result(data)
            user_connected = remote_user.casefold() != "nenhum usuário logado"
            if user_connected:
                user_name = ad_name or "Consultando nome no AD…"
                name_resolved = bool(ad_name)
            else:
                user_name = "Nenhum usuário logado"
                name_resolved = False
            self.station_identity_user_name.setText(f"USUÁRIO\n{user_name}")
            self.station_identity_user_name.setToolTip(user_name if name_resolved else "")
            if self.station_identity_user_name.property("nameResolved") != name_resolved:
                self.station_identity_user_name.setProperty("nameResolved", name_resolved)
                self.station_identity_user_name.style().unpolish(self.station_identity_user_name)
                self.station_identity_user_name.style().polish(self.station_identity_user_name)
            if connected:
                self.status_pulse.setObjectName("connectedComputerPulse")
                self.status_pulse.setPixmap(modern_icon("remote", GREEN, 20).pixmap(20, 20))
                self.status_pulse.setToolTip("Estação conectada")
                self.status_title.setText("ESTAÇÃO CONECTADA")
            else:
                self.status_pulse.setObjectName("alertComputerPulse")
                self.status_pulse.setPixmap(modern_icon("remote", RED, 20).pixmap(20, 20))
                self.status_pulse.setToolTip("Estação sem resposta")
                self.status_title.setText(f"ESTAÇÃO SEM RESPOSTA  •  {station}")
            self.status_pulse.style().unpolish(self.status_pulse)
            self.status_pulse.style().polish(self.status_pulse)
            self.set_connection_state(connected)
            details_pending = any(
                "concluindo consulta" in str(data.get(key) or "").casefold()
                for key in ("admin", "sccm", "printers", "printer_groups")
            )
            if self.station_load_cycle_active:
                if not connected:
                    self.finish_station_enrichment(False, "Carregamento concluído: a estação não respondeu.")
                elif details_pending:
                    self.set_connection_progress_stage(
                        35, "Dados principais do micro carregados; concluindo detalhes da estação…"
                    )
                else:
                    self.set_connection_progress_stage(
                        60, "Detalhes da estação carregados; consultando usuário no Active Directory…"
                    )
            if not self.station_card_refresh_only:
                self.sync_station_user_control(data)
            elif self.station_load_cycle_active and not details_pending:
                self.finish_station_enrichment(connected, "Estação conectada atualizada." if connected else "A estação não respondeu.")
            if (
                self.station_load_cycle_active and connected and not details_pending
                and not self.station_card_refresh_only
                and not self.station_user_login(data.get("user"))
            ):
                self.finish_station_enrichment(True, "Estação carregada; nenhum usuário conectado.")
            self.status_card.style().unpolish(self.status_card)
            self.status_card.style().polish(self.status_card)
            self.update_information_cards_visibility()
            if self.status_card.isVisible():
                self.status_animation.stop()
                self.status_opacity.setOpacity(0.0)
                self.status_animation.setStartValue(0.0)
                self.status_animation.setEndValue(1.0)
                self.status_animation.start()
            break

    def update_printer_color_permission(self):
        """Exibe a regra somente para o usuário da estação, usando o AD já consultado."""
        if not hasattr(self, "printer_color_status"):
            return
        station_data = self.last_status_data
        station_login = self.station_user_login(station_data.get("user"))
        loaded_login = str(self.user_control_data.get("login") or "").strip().casefold()
        if str(station_data.get("status") or "").casefold() != "conectado":
            message, state = "Impressão colorida: conecte uma estação", "pending"
        elif not station_login:
            message, state = "Impressão colorida: sem usuário conectado", "pending"
        elif station_login.casefold() != loaded_login:
            message, state = "Impressão colorida: consultando usuário no AD…", "pending"
        else:
            organization = dict(self.user_control_data.get("organization") or {})
            department = organization.get("Departamento") or ""
            groups = self.user_control_data.get("groups") or []
            allowed = color_printing_allowed(department, groups)
            message = "Impressão colorida permitida" if allowed else "Impressão colorida não permitida"
            state = "allowed" if allowed else "denied"
        self.printer_color_status.setText(message)
        if self.printer_color_status.property("permissionState") != state:
            self.printer_color_status.setProperty("permissionState", state)
            self.printer_color_status.style().unpolish(self.printer_color_status)
            self.printer_color_status.style().polish(self.printer_color_status)

    def update_printer_summary(self):
        """Mostra no menu Impressoras os mesmos dados do resumo da estação."""
        data = self.last_status_data
        station = str(data.get("station") or self.target or "").strip()
        self.printer_summary_station.setText(
            f"Estação: {station}" if data and station
            else "Conecte uma estação para consultar suas impressoras."
        )
        self.printer_summary_names.setText(self.format_printer_status(
            "Impressoras de rede", str(data.get("printers") or "—")
        ))
        self.printer_summary_groups.setText(
            f"Grupos de impressoras no AD\n{data.get('printer_groups') or '—'}"
        )
        self.printer_summary_ping.setEnabled(self.connection_active)
        self.printer_summary_web.setEnabled(self.connection_active)
        self.printer_summary_test_page.setEnabled(self.connection_active)
        self.printer_summary_refresh.setEnabled(self.connection_active)
        self.printer_summary_logoff.setEnabled(self.connection_active)
        self.sync_printer_admin_button()

    def sync_printer_admin_button(self):
        """Espelha o estado de Admin no painel de impressoras sem recarregar a estação."""
        if not hasattr(self, "printer_summary_admin"):
            return
        is_admin = self.admin_status_widget.is_admin
        connected = self.connection_active and bool(self.station_user_login(self.last_status_data.get("user")))
        if is_admin is True:
            state, icon, color = "active", "lock", "#11A866"
            tooltip = "Admin local ativo — clique para remover"
        elif is_admin is False:
            state, icon, color = "inactive", "unlock", "#D74757"
            tooltip = "Admin local inativo — clique para adicionar"
        else:
            state, icon, color = "unknown", "lock", "#778B99"
            tooltip = "Estado de Admin ainda não disponível"
        self.printer_summary_admin.setProperty("adminState", state)
        self.printer_summary_admin.setToolTip(tooltip)
        set_button_icon(self.printer_summary_admin, icon, color, 15)
        self.printer_summary_admin.setEnabled(connected and is_admin is not None)
        if hasattr(self, "quick_admin_button"):
            self.quick_admin_button.set_icon_state(icon, color if is_admin is not None else "#778B99")
            self.quick_admin_button.setToolTip(tooltip)
            self.quick_admin_button.setAccessibleName(tooltip)
            self.quick_admin_button.setEnabled(connected and is_admin is not None)
            if connected and is_admin is not None:
                if not self.quick_admin_pulse_timer.isActive():
                    self.quick_admin_pulse_timer.start()
            else:
                self.quick_admin_pulse_timer.stop()
                self.quick_admin_pulse_on = False
        self.printer_summary_admin.style().unpolish(self.printer_summary_admin)
        self.printer_summary_admin.style().polish(self.printer_summary_admin)
        if connected and is_admin is not None:
            if self.printer_admin_pulse.state() != QAbstractAnimation.State.Running:
                self.printer_admin_pulse.start()
        else:
            self.printer_admin_pulse.stop()
            self.printer_admin_opacity.setOpacity(1.0)

    def pulse_quick_admin(self):
        state = self.admin_status_widget.is_admin
        if not self.connection_active or state is None:
            self.quick_admin_pulse_timer.stop()
            return
        self.quick_admin_pulse_on = not self.quick_admin_pulse_on
        color = ("#11A866" if self.quick_admin_pulse_on else "#75DDB0") if state else ("#D74757" if self.quick_admin_pulse_on else "#F2919B")
        self.quick_admin_button.set_icon_state("lock" if state else "unlock", color)

    def request_printer_logoff(self):
        """Reutiliza a confirmação destrutiva já aplicada ao logoff do Atlas."""
        action = next((item for item, _card in self.cards if item.command == "logoff"), None)
        if action:
            self.execute_action(action)

    def refresh_printer_status(self, scope: str = "summary"):
        if not self.connection_active or not self.target:
            show_notice(self, "Conecte uma estação antes de atualizar as impressoras.")
            return False
        self.printer_refresh_scope = "both" if scope == "both" else "summary"
        self.printer_summary_refresh.setEnabled(False)
        set_refresh_icon_busy(self.printer_summary_refresh, True)
        self.append_log(f"\n[IMPRESSORAS] Atualizando somente as impressoras de {self.target}…\n")
        started = self.run_bridge("printer_status", self.target)
        if not started:
            set_refresh_icon_busy(self.printer_summary_refresh, False)
            self.printer_summary_refresh.setEnabled(True)
        return started

    def apply_printer_status(self, output: str) -> bool:
        data = self.extract_json_marker(output, "@@PRINTER_STATUS@@")
        if not data:
            return False
        self.last_status_data.update({
            "printers": data.get("printers", "Nenhuma"),
            "printer_names": data.get("printer_names", ""),
            "default_printer": data.get("default_printer", ""),
        })
        if self.printer_refresh_scope == "both":
            caption, label, _widget = self.status_labels["printers"]
            label.setText(self.format_printer_status("", str(self.last_status_data["printers"])))
        self.update_printer_summary()
        return True

    def apply_admin_status(self, output: str) -> bool:
        data = self.extract_json_marker(output, "@@ADMIN_STATUS@@")
        if not data:
            return False
        value = str(data.get("admin") or "Não foi possível consultar")
        self.last_status_data["admin"] = value
        caption = self.status_labels["admin"][0]
        self.admin_status_widget.set_status(caption, value)
        self.admin_status_widget.set_connected(self.connection_active)
        self.sync_printer_admin_button()
        return True

    def format_printer_status(self, caption: str, value: str) -> str:
        """Destaca apenas o estado, preservando nomes recebidos como texto seguro."""
        online_color = "#55E0AD" if self.dark_mode else "#00824A"
        offline_color = "#FF8A98" if self.dark_mode else "#C73D4D"
        safe_value = html.escape(str(value))
        safe_value = re.sub(
            r"\bOnline\b",
            f'<span style="color:{online_color}; font-weight:700;">Online</span>',
            safe_value,
            flags=re.IGNORECASE,
        )
        safe_value = re.sub(
            r"\bOffline\b",
            f'<span style="color:{offline_color}; font-weight:700;">Offline</span>',
            safe_value,
            flags=re.IGNORECASE,
        )
        return f"{html.escape(caption)}<br>{safe_value}" if caption else safe_value

    def open_settings(self):
        label = open_browser_settings_dialog(self)
        if not label:
            return
        self.append_log(f"\n[CONFIGURAÇÕES] Navegador para links: {label}.\n")

    def open_legacy(self):
        legacy = resource_path("scripts/legacy_tool.bat")
        if not legacy.exists():
            QMessageBox.warning(self, APP_NAME, "A ferramenta legada não foi localizada.")
            return
        subprocess.Popen(["cmd.exe", "/c", "start", "", str(legacy)], shell=False)


class MainWindow(QMainWindow):
    structural_validation_completed = Signal(dict)

    def __init__(self):
        super().__init__()
        saved_mode = load_json_cache(window_mode_settings_path()).get("mode")
        if "--window-mode-full" in sys.argv:
            saved_mode = "full"
        elif "--window-mode-lateral" in sys.argv:
            saved_mode = "lateral"
        self._display_mode = "full" if saved_mode == "full" else "lateral"
        self._entering_lateral = False
        self._software_exit_confirmed = False
        self._structural_validation_running = False
        # No Windows, o Qt acrescenta o applicationDisplayName ao título de
        # toda janela. Mantendo o título principal vazio, a moldura exibe uma
        # única vez apenas “Atlas — Suporte Avançado”.
        self.setWindowTitle("")
        self.setMinimumSize(480, 680)
        monitor_x = next((arg.split("=", 1)[1] for arg in sys.argv if arg.startswith("--monitor-x=")), None)
        monitor_y = next((arg.split("=", 1)[1] for arg in sys.argv if arg.startswith("--monitor-y=")), None)
        target_screen = None
        try:
            if monitor_x is not None and monitor_y is not None:
                target_screen = QApplication.screenAt(QPoint(int(monitor_x), int(monitor_y)))
        except (TypeError, ValueError):
            target_screen = None
        target_screen = target_screen or QApplication.primaryScreen()
        screen = target_screen.availableGeometry()
        width = min(LATERAL_WIDTH, screen.width())
        height = min(920, screen.height())
        self.resize(width, height)
        self.move(screen.right() - width + 1, screen.top())
        icon_file = resource_path("assets/app_icon.ico")
        if not icon_file.exists():
            icon_file = resource_path("assets/app_icon.png")
        self.setWindowIcon(QIcon(str(icon_file)) if icon_file.exists() else QIcon())
        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)
        self.show_login()
        self.structural_validation_timer = QTimer(self)
        self.structural_validation_timer.setInterval(6 * 60 * 60 * 1000)
        self.structural_validation_timer.timeout.connect(self.run_due_structural_validation)
        self.structural_validation_timer.start()
        self.structural_validation_completed.connect(self.finish_structural_validation)
        QTimer.singleShot(60_000, self.run_due_structural_validation)
        QTimer.singleShot(0, self.refresh_taskbar_icon)

    def refresh_taskbar_icon(self):
        apply_native_window_icon(self)

    def run_due_structural_validation(self):
        """Agenda a verificação fora da UI e nunca concorre com ações PowerShell."""
        if self._structural_validation_running:
            return
        settings = structural_validation_settings()
        if not validation_is_due(settings):
            return
        active_page = self.stack.currentWidget()
        runners = (
            getattr(active_page, "runner", None),
            getattr(active_page, "background_runner", None),
        )
        if any(runner is not None and runner.state() != QProcess.NotRunning for runner in runners):
            QTimer.singleShot(60_000, self.run_due_structural_validation)
            return
        self._structural_validation_running = True

        def validate_in_background():
            try:
                result = run_structural_validation()
            except Exception as exc:  # nunca deixa uma manutenção impedir o uso do Atlas
                result = {
                    "last_status": "attention",
                    "last_summary": "A validação estrutural não pôde ser concluída.",
                    "issues": [str(exc)],
                }
            self.structural_validation_completed.emit(result)

        threading.Thread(
            target=validate_in_background,
            name="atlas-structural-validation",
            daemon=True,
        ).start()

    def finish_structural_validation(self, result: dict):
        self._structural_validation_running = False
        active_page = self.stack.currentWidget()
        compacted = 0
        if hasattr(active_page, "compact_transient_caches"):
            compacted = active_page.compact_transient_caches()
        if hasattr(active_page, "append_log"):
            cache_note = f" Caches transitórios compactados: {compacted}." if compacted else ""
            active_page.append_log(f"\n[MANUTENÇÃO] {result['last_summary']}{cache_note}\n")
        if result.get("last_status") == "attention":
            details = "\n".join(f"• {item}" for item in result.get("issues", [])[:5])
            show_notice(
                self,
                f"A validação estrutural encontrou itens que precisam de atenção.\n\n{details}",
                "Integridade do Atlas",
            )

    def replace_page(self, page: QWidget):
        """Troca a visão sem manter telas antigas e seus timers em memória."""
        previous = self.stack.currentWidget()
        self.stack.addWidget(page)
        self.stack.setCurrentWidget(page)
        if previous is not None and previous is not page:
            self.stack.removeWidget(previous)
            previous.deleteLater()

    def fit_current_monitor_height(self):
        """Ocupa toda a altura útil sem alterar o monitor atual."""
        if self._display_mode == "full":
            return
        current_screen = (
            QApplication.screenAt(self.frameGeometry().center())
            or self.screen()
            or QApplication.primaryScreen()
        )
        if not current_screen:
            return
        available = current_screen.availableGeometry()
        width = min(LATERAL_WIDTH, available.width())
        frame = self.frameGeometry()
        client = self.geometry()
        top_frame = max(0, client.top() - frame.top())
        right_frame = max(0, frame.right() - client.right())
        bottom_frame = max(0, frame.bottom() - client.bottom())
        client_height = max(self.minimumHeight(), available.height() - top_frame - bottom_frame)
        client_x = available.right() - width - right_frame + 1
        client_y = available.top() + top_frame
        self.setGeometry(client_x, client_y, width, client_height)

    def show_login(self):
        QApplication.instance().setApplicationDisplayName(LOGIN_WINDOW_TITLE)
        login = LoginPage()
        login.selected.connect(self.select_profile)
        login.reset_requested.connect(self.reset_saved_credentials)
        login.lateral_requested.connect(self.toggle_login_side)
        login.exit_requested.connect(self.close)
        self.login_page = login
        self.replace_page(login)
        QTimer.singleShot(0, self.update_login_arrow_direction)

    def closeEvent(self, event):
        """Preserva o perfil PWM; somente o logout explícito remove seus cookies."""
        if self._software_exit_confirmed:
            self.save_display_mode()
            event.accept()
            return
        ok, details = terminate_capri_session()
        if ok:
            self._software_exit_confirmed = True
            self.save_display_mode()
            event.accept()
            return
        answer = QMessageBox.question(
            self,
            "Sessão web ainda ativa",
            "Não foi possível confirmar o encerramento da sessão do Capri.\n\n"
            + f"Capri: {details or 'sem retorno do servidor'}\n\n"
            "Para evitar conflito de logins, escolha Não e tente sair novamente quando a conexão estiver disponível.\n\n"
            "Deseja fechar o Atlas mesmo assim?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer == QMessageBox.Yes:
            self._software_exit_confirmed = True
            self.save_display_mode()
            event.accept()
        else:
            event.ignore()

    def update_login_arrow_direction(self):
        if not hasattr(self, "login_page"):
            return
        target_screen, target_side = next_lateral_slot(self)
        self.login_page.set_side_direction(lateral_slot_direction(self, target_screen, target_side))

    def toggle_login_side(self):
        """Percorre as bordas esquerda e direita de todos os monitores."""
        target_screen, target_side = next_lateral_slot(self)
        self.enter_lateral_mode(target_screen, target_side)
        QTimer.singleShot(0, self.update_login_arrow_direction)

    def save_display_mode(self):
        save_json_cache(window_mode_settings_path(), {"mode": self._display_mode})

    def is_full_display_mode(self):
        return self._display_mode == "full"

    def enter_lateral_mode(self, screen, side):
        self._entering_lateral = True
        self._display_mode = "lateral"
        if self.isMaximized() or self.isFullScreen():
            self.showNormal()
        apply_lateral_slot(self, screen, side)
        self.save_display_mode()
        self._entering_lateral = False
        page = self.stack.currentWidget()
        if isinstance(page, Dashboard):
            page.update_information_cards_visibility()

    def changeEvent(self, event):
        super().changeEvent(event)
        if event.type() == QEvent.WindowStateChange and self.isMaximized() and not self._entering_lateral:
            self._display_mode = "full"
            self.save_display_mode()
            page = self.stack.currentWidget() if hasattr(self, "stack") else None
            if isinstance(page, Dashboard):
                page.update_information_cards_visibility()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if not self.isVisible() or self._entering_lateral or self._display_mode == "full":
            return
        screen = self.screen() or QApplication.primaryScreen()
        if screen and self.width() >= screen.availableGeometry().width() * 0.85:
            self._display_mode = "full"
            self.save_display_mode()
            page = self.stack.currentWidget() if hasattr(self, "stack") else None
            if isinstance(page, Dashboard):
                page.update_information_cards_visibility()

    def authenticate_capri_startup(self) -> tuple[str, str] | None:
        """Exige e valida o Capri uma vez, logo após a entrada na sessão INS."""
        default_user = normalize_capri_login(getpass.getuser())
        saved_password = credential_read(default_user, "capri") or ""
        username = default_user
        password = saved_password
        if not password:
            username, accepted = QInputDialog.getText(
                self, "Acesso ao Capri", "Login de rede do Capri:", QLineEdit.Normal, default_user,
            )
            username = normalize_capri_login(username)
            if not accepted or not username:
                return None
            password, accepted = QInputDialog.getText(
                self, "Acesso ao Capri", "Senha do Capri:", QLineEdit.Password,
            )
            if not accepted or not password:
                return None
        ok, message = validate_capri_session(username, password)
        if not ok and saved_password:
            credential_delete(default_user, "capri")
            password = ""
            username, accepted = QInputDialog.getText(
                self, "Atualizar acesso ao Capri", "Login de rede do Capri:", QLineEdit.Normal, default_user,
            )
            username = normalize_capri_login(username)
            if not accepted or not username:
                return None
            password, accepted = QInputDialog.getText(
                self, "Atualizar acesso ao Capri", "Senha atual do Capri:", QLineEdit.Password,
            )
            if not accepted or not password:
                return None
            ok, message = validate_capri_session(username, password)
        if not ok:
            show_notice(self, "Não foi possível validar a sessão do Capri. Confira o login e tente novamente.")
            return None
        credential_write(username, password, "capri")
        return username, password

    def select_profile(self, profile: str, username: str = "", password: str = ""):
        current = windows_identity().lower()
        requested = username.strip().lower()
        expected_ins = getpass.getuser().lower().endswith("_ins") or is_admin()
        already_correct = requested == current and (profile == "standard" or expected_ins)
        if not already_correct:
            saved_password = credential_read(username) if not password else None
            password = password or saved_password or ""
            if not password:
                password, accepted = QInputDialog.getText(
                    self, "Primeiro acesso",
                    f"Digite uma vez a senha de {username}.\nEla será protegida pelo Windows:",
                    QLineEdit.Password,
                )
                if not accepted or not password:
                    return
            current_screen = (
                QApplication.screenAt(self.frameGeometry().center())
                or self.screen()
                or QApplication.primaryScreen()
            )
            monitor_center = None
            if current_screen:
                center = current_screen.geometry().center()
                monitor_center = (center.x(), center.y())
            active_page = self.stack.currentWidget()
            active_dark_mode = bool(getattr(active_page, "dark_mode", load_json_cache(theme_settings_path()).get("dark", False)))
            ok, message = start_with_credentials(
                username, password, profile, monitor_center, active_dark_mode, self._display_mode,
            )
            if not ok and saved_password and "erro 1326" in message.lower():
                credential_delete(username)
                password, accepted = QInputDialog.getText(
                    self, "Credencial atualizada",
                    f"A senha salva de {username} não é mais válida.\nDigite a senha atual:",
                    QLineEdit.Password,
                )
                if not accepted or not password:
                    return
                ok, message = start_with_credentials(
                    username, password, profile, monitor_center, active_dark_mode, self._display_mode,
                )
            if ok:
                saved = credential_write(username, password)
                password = ""
                if not saved:
                    QMessageBox.warning(
                        self, APP_NAME,
                        "A sessão foi iniciada, mas o Windows não permitiu salvar o acesso. A senha poderá ser solicitada novamente.",
                    )
                QApplication.quit()
            else:
                password = ""
                QMessageBox.critical(self, "Falha no login", message)
            return
        if profile == "ins" and not expected_ins:
            if os.name != "nt":
                QMessageBox.warning(self, APP_NAME, "A sessão INS está disponível somente no Windows.")
                return
            return
        capri_credentials = self.authenticate_capri_startup() if profile == "ins" else ("", "")
        if profile == "ins" and capri_credentials is None:
            return
        capri_user, capri_password = capri_credentials or ("", "")
        dashboard = Dashboard(profile, capri_user, capri_password)
        capri_password = ""
        dashboard.logout.connect(self.return_to_standard)
        QApplication.instance().setApplicationDisplayName(APP_NAME)
        self.replace_page(dashboard)
        dashboard.update_information_cards_visibility()
        QTimer.singleShot(0, self.fit_current_monitor_height)
        QTimer.singleShot(0, self.refresh_taskbar_icon)
        QTimer.singleShot(250, self.refresh_taskbar_icon)

    def return_to_standard(self):
        dashboard = self.stack.currentWidget()
        if isinstance(dashboard, Dashboard):
            ok, details = dashboard.run_capri_logout()
        else:
            ok, details = terminate_capri_session()
        if not ok:
            QMessageBox.warning(
                self,
                "Sessão web não confirmou o logout",
                "O Atlas sairá do perfil INS, mas uma sessão web pode continuar ativa.\n\n"
                + f"Capri: {details or 'sem retorno do servidor'}",
            )
        standard_user, _ins_user = profile_usernames()
        self.select_profile("standard", standard_user, "")

    def reset_saved_credentials(self):
        standard_user, ins_user = profile_usernames()
        credential_delete(standard_user)
        credential_delete(ins_user)
        credential_delete(normalize_capri_login(getpass.getuser()), "capri")
        credential_delete(normalize_capri_login(getpass.getuser()), "gestor_senhas")
        try:
            capri_session_path().unlink(missing_ok=True)
            password_manager_session_path().unlink(missing_ok=True)
        except OSError:
            pass
        show_notice(self, "Os acessos locais salvos para usuário padrão, INS, Capri e PWM foram removidos. O Chrome continua sem alterações.")
        self.show_login()


STYLE = f"""
* {{ font-family: 'Segoe UI Variable', 'Segoe UI'; font-size: 14px; color: {TEXT}; }}
QMainWindow, #content {{ background: {BG}; }}
#loginPanel {{ background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #F2F8FC, stop:.55 #ECF5FB, stop:1 #EAF2F8); }}
#hero {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #0D3A72, stop:.6 #082A54, stop:1 #061C37); }}
#heroEyebrow, #loginEyebrow {{ color: {YELLOW}; font-size: 11px; font-weight: 800; letter-spacing: 2px; margin-top: 18px; }}
#loginEyebrow {{ color: #086E82; margin-top: 8px; }}
#heroTitle {{ color: white; font-family: 'Georgia'; font-size: 48px; font-weight: 900; letter-spacing: .5px; }}
#heroSubtitle {{ color: #DBEDF8; font-size: 17px; font-weight: 800; letter-spacing: 2.3px; }}
#heroDescription {{ color: #DCE8F2; font-size: 17px; max-width: 430px; }}
#stripe {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {GREEN}, stop:.55 {GREEN}, stop:.55 {YELLOW}, stop:1 {YELLOW}); border-radius: 4px; }}
#pageTitle {{ font-size: 29px; font-weight: 750; color: {BLUE}; letter-spacing: -.3px; }}
#pageTitle[compact="true"] {{ font-size: 23px; }}
#sectionTitle {{ font-size: 21px; font-weight: 750; color: {BLUE}; margin-top: 5px; }}
#sectionDescription {{ color: {MUTED}; font-size: 12px; padding-bottom: 3px; }}
#sectionSeparator {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 transparent, stop:.08 #175D8A, stop:.50 #0A6EAA, stop:.92 #175D8A, stop:1 transparent); border: none; }}
#muted {{ color: {MUTED}; font-size: 13px; font-weight: 500; }}
#smallMuted {{ color: {MUTED}; font-size: 12px; }}
#loginFooter {{ color: #708696; font-size: 10px; font-weight: 650; line-height: 1.4; }}
#pageDeveloperFooter {{ color: #708696; font-size: 10px; font-weight: 600; padding: 7px 2px 1px 2px; }}
#pageDeveloperFooter a {{ color: {GREEN}; text-decoration: none; }}
#identityCard {{ background: {SURFACE}; border: 1px solid #CFDDE6; border-left: 4px solid {GREEN}; border-radius: 15px; color: {BLUE}; }}
#loginProfileCard {{ background: #FBFDFF; border: 1px solid #BCD7E9; border-radius: 15px; }}
#identityCard:hover, #loginProfileCard:hover {{ background: #F9FCFD; border-color: #9EC4D7; }}
#loginCardIcon {{ background: #E7F5EF; border: 1px solid #C8E8D8; border-radius: 12px; }}
#loginCardStatusIcon {{ background: #E8F6EF; border: 1px solid #C3E5D3; border-radius: 14px; }}
#loginCardCaption {{ color: #547084; font-size: 9px; font-weight: 850; letter-spacing: 1.1px; }}
#loginCardValue {{ color: {BLUE}; font-size: 14px; font-weight: 800; }}
#profileName {{ color: {BLUE}; font-size: 11px; font-weight: 800; letter-spacing: .8px; }}
#profileAccount {{ color: {TEXT}; font-size: 14px; font-weight: 700; }}
#profileStatus {{ color: {GREEN}; font-size: 11px; font-weight: 600; }}
#loginPanel #primaryButton {{ border-radius: 12px; min-height: 46px; font-size: 13px; }}
#loginPanel #dangerButton {{ border-radius: 12px; min-height: 42px; }}
#loginPanel #linkButton {{ border-radius: 10px; }}
#loginTopActionButton {{ min-width: 28px; max-width: 28px; min-height: 28px; max-height: 28px; padding: 0; border-radius: 14px; background: transparent; border: 1px solid transparent; }}
#loginTopActionButton:hover {{ background: #E3EEF5; border-color: #9EC4D7; }}
#loginExitSoftwareButton {{ min-width: 44px; max-width: 44px; min-height: 44px; max-height: 44px; padding: 0; border-radius: 22px; background: #FFF4F5; border: 1px solid #D99AA2; }}
#loginExitSoftwareButton:hover {{ background: #FCE2E5; border-color: #C73D4D; }}
QPushButton {{ min-height: 42px; border-radius: 9px; padding: 0 18px; font-weight: 650; }}
#primaryButton {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {GREEN}, stop:1 #00965A); color: white; border: none; }}
#primaryButton:hover {{ background: {GREEN_2}; }}
#primaryButton:pressed {{ background: #006E40; }}
#syncButton, #syncButton:disabled {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #006F42, stop:1 {GREEN_2}); color: white; border: 1px solid #45C18B; }}
#disconnectButton {{ background: #A83240; color: white; border: none; }}
#disconnectButton:hover {{ background: {RED}; }}
#dangerButton {{ background: #A83240; color: white; border: 1px solid #D36571; }}
#dangerButton:hover {{ background: {RED}; border-color: #E58A93; }}
#dangerButton:pressed {{ background: #8D2632; }}
#secondaryButton {{ background: {SURFACE}; color: {BLUE}; border: 1px solid #9EB5C8; }}
#secondaryButton:hover {{ background: #E6EFF5; border-color: {BLUE}; }}
#sidebar {{ background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #0B3A75, stop:.72 #082E61, stop:1 #061F43); color: white; border-right: 1px solid #2573A6; }}
#sidebar QLabel {{ color: white; font-weight: 700; }}
#sidebar #brandTitle {{ color: #F4FBFF; font-family: 'Georgia'; font-size: 29px; font-weight: 900; letter-spacing: .2px; }}
#brandSubtitle {{ color: #8FB1C9; font-size: 9px; font-weight: 700; letter-spacing: 1.4px; padding-left: 2px; }}
#quickTitle {{ color: #86A9C1; font-size: 9px; font-weight: 800; letter-spacing: 1.2px; padding: 3px 2px; }}
#quickSeparator {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 transparent, stop:.18 #2387BC, stop:.72 #43C8B7, stop:1 transparent); border: none; }}
#usefulLinksToggle {{ text-align: left; background: rgba(255,255,255,0.06); color: #E7F6F2; border: 1px solid rgba(91,178,218,0.30); border-radius: 8px; padding: 5px 9px; min-height: 23px; font-size: 11px; font-weight: 800; }}
#usefulLinksToggle:hover, #usefulLinksToggle:checked {{ background: rgba(0,165,103,0.22); border-color: {GREEN_2}; }}
#usefulLinksPopup {{ background: #0A2438; border: 1px solid #3887A0; border-radius: 12px; }}
#usefulLinksPopupTitle {{ color: #EAF7FC; font-size: 12px; font-weight: 800; letter-spacing: 1px; }}
#usefulLinksPopupClose {{ background: #153D53; color: #EAF7FC; border: 1px solid #376987; border-radius: 7px; padding: 0; min-width: 28px; max-width: 28px; min-height: 28px; max-height: 28px; }}
#usefulLinksPopupClose:hover {{ background: #245E70; }}
#usefulLinksPanel {{ background: rgba(8,43,73,0.65); border: none; border-radius: 8px; }}
#usefulLinksScroll, #usefulLinksScroll > QWidget, #usefulLinksScroll QWidget#qt_scrollarea_viewport {{ background: transparent; border: none; }}
#usefulLinkRow {{ background: transparent; border: none; }}
#usefulLinkButton {{ text-align: left; background: transparent; color: #C7DDE8; border: none; border-radius: 6px; padding: 3px 7px; min-height: 19px; max-height: 24px; font-size: 10px; }}
#usefulLinkButton:hover {{ background: rgba(0,165,103,0.27); color: white; }}
#usefulLinkDeleteButton {{ background: transparent; border: none; border-radius: 6px; padding: 0; min-width: 22px; max-width: 22px; min-height: 24px; max-height: 24px; }}
#usefulLinkDeleteButton:hover {{ background: rgba(199,61,77,0.25); }}
#usefulLinksAddButton {{ text-align: left; background: rgba(0,165,103,0.10); color: #AEEBCF; border: 1px dashed rgba(91,200,152,0.45); border-radius: 7px; padding: 2px 7px; min-height: 24px; max-height: 26px; font-size: 10px; font-weight: 750; }}
#usefulLinksAddButton:hover {{ background: rgba(0,165,103,0.28); color: white; }}
#usefulLinkDialog {{ background: #F3F8FB; color: {BLUE}; }}
#usefulLinkDialog QLabel {{ color: {BLUE}; font-weight: 750; }}
#usefulLinkDialog QLineEdit {{ background: white; color: {TEXT}; border: 1px solid #B7CFDC; border-radius: 7px; padding: 6px; min-height: 27px; }}
#templatesToggle {{ text-align: left; background: rgba(255,255,255,0.06); color: #E7F6F2; border: 1px solid rgba(91,178,218,0.30); border-radius: 8px; padding: 5px 9px; min-height: 23px; font-size: 11px; font-weight: 800; }}
#templatesToggle:hover {{ background: rgba(0,165,103,0.22); border-color: {GREEN_2}; }}
#templatesPopup {{ background: transparent; border: none; }}
#templatesSurface {{ background: #F3F8FB; color: {TEXT}; border: 1px solid #78AABD; border-radius: 16px; }}
#templatesDivider {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {GREEN}, stop:.5 #50B7D2, stop:1 transparent); border: none; }}
#templatesFooterDivider {{ background: #BBD1DD; border: none; }}
#templatesTitle {{ color: {BLUE}; font-size: 15px; font-weight: 850; letter-spacing: .7px; }}
#templatesHistoryDialog {{ background: #F3F8FB; color: {TEXT}; border: 1px solid #78AABD; border-radius: 14px; }}
#templatesHistoryConfirm {{ background: #F3F8FB; color: {TEXT}; border: 1px solid #78AABD; border-radius: 12px; }}
#templatesHistoryTitle {{ color: {BLUE}; font-size: 14px; font-weight: 850; }}
#templatesHistoryHint {{ color: {MUTED}; font-size: 11px; }}
#templatesHistoryButton {{ background: #E4EEF4; border: 1px solid #BDD5E0; border-radius: 7px; padding: 0; min-width: 30px; max-width: 30px; min-height: 30px; max-height: 30px; }}
#templatesHistoryButton:hover {{ background: #D0E8EE; border-color: {GREEN}; }}
#templatesHistoryRow {{ text-align: left; color: {BLUE}; background: #FFFFFF; border: 1px solid #BBD1DD; border-radius: 9px; padding: 10px; min-height: 34px; font-size: 12px; }}
#templatesHistoryRow:hover {{ background: #E7F6EF; border-color: {GREEN}; }}
#templatesHistoryClear {{ color: {BLUE}; background: #E4EEF4; border: 1px solid #BDD5E0; border-radius: 8px; padding: 8px 12px; }}
#templatesHistoryClear:hover {{ background: #D0E8EE; }}
#templatesHistoryClear:disabled {{ color: {MUTED}; }}
#templatesHistoryPreview {{ background: #FFFFFF; color: #111827; border: 1px solid #BBD1DD; border-radius: 9px; padding: 12px; font-family: 'Segoe UI'; font-size: 12px; selection-background-color: {GREEN}; }}
#templatesHistoryCopy, #templatesHistoryCloseAction, #templatesHistoryDelete {{ border-radius: 8px; padding: 0 12px; min-height: 34px; font-size: 12px; font-weight: 750; }}
#templatesHistoryCopy {{ color: white; background: {GREEN}; border: 1px solid {GREEN}; }}
#templatesHistoryCopy:hover {{ background: {GREEN_2}; }}
#templatesHistoryCloseAction {{ color: {BLUE}; background: #E4EEF4; border: 1px solid #BDD5E0; }}
#templatesHistoryCloseAction:hover {{ background: #D0E8EE; }}
#templatesHistoryDelete {{ color: white; background: {RED}; border: 1px solid {RED}; }}
#templatesHistoryDelete:hover {{ background: #AC3040; }}
#templatesHint {{ color: {MUTED}; font-size: 12px; padding: 2px 1px 7px; }}
#templatesItem {{ background: white; border: 1px solid #BBD1DD; border-left: 4px solid {GREEN}; border-radius: 10px; padding: 0; }}
#templatesItem:hover {{ background: #E7F6EF; border-color: {GREEN}; }}
#templatesItemTitle {{ color: {BLUE}; font-size: 13px; font-weight: 800; }}
#templatesItemDetail {{ color: {MUTED}; font-size: 11px; }}
#templatesItemChevron {{ color: {GREEN}; font-size: 25px; font-weight: 600; }}
#templatesSavedOpen {{ text-align: left; background: #E4F4EF; color: {BLUE}; border: 1px solid #9CCDBA; border-radius: 9px; padding: 8px 12px; min-height: 36px; font-size: 12px; font-weight: 800; }}
#templatesSavedOpen:hover {{ background: #CEF0E2; }}
#templatesSavedRow {{ background: white; border: 1px solid #BBD1DD; border-radius: 8px; }}
#templatesSavedSearch {{ background: #FFFFFF; color: {TEXT}; border: 1px solid #9BBBCB; border-radius: 9px; padding: 5px 8px; min-height: 28px; }}
#templatesSavedSearch:focus {{ border: 2px solid {GREEN}; }}
#templatesSavedItem {{ text-align: left; background: transparent; color: {BLUE}; border: none; padding: 5px 8px; min-height: 30px; font-size: 12px; font-weight: 750; }}
#templatesSavedItem:hover {{ color: {GREEN}; }}
#templatesSavedDelete {{ background: transparent; color: {RED}; border: none; border-radius: 6px; padding: 0; min-width: 28px; max-width: 28px; min-height: 28px; max-height: 28px; }}
#templatesSavedDelete:hover {{ background: #FBE6E8; }}
#templatesSavedEdit {{ background: transparent; color: {BLUE}; border: none; border-radius: 6px; padding: 0; min-width: 28px; max-width: 28px; min-height: 28px; max-height: 28px; font-size: 16px; }}
#templatesSavedEdit:hover {{ background: #D9F3E9; color: {GREEN}; }}
#templatesBack, #templatesClose {{ background: #E4EEF4; color: {BLUE}; border: 1px solid #BDD5E0; border-radius: 7px; padding: 0; min-width: 30px; max-width: 30px; min-height: 30px; max-height: 30px; }}
#templatesBack:hover, #templatesClose:hover {{ background: #D0E8EE; }}
#templatesScroll, #templatesScroll > QWidget, #templatesScroll QWidget#qt_scrollarea_viewport, #templatesBody {{ background: transparent; border: none; }}
#templatesScroll QScrollBar:vertical {{ background: transparent; border: none; width: 11px; margin: 1px 0; }}
#templatesScroll QScrollBar::handle:vertical {{ background: #86B6BD; border-radius: 4px; min-height: 34px; margin: 0 2px; }}
#templatesScroll QScrollBar::handle:vertical:hover {{ background: {GREEN}; }}
#templatesScroll QScrollBar::add-line:vertical, #templatesScroll QScrollBar::sub-line:vertical {{ height: 0; background: transparent; border: none; }}
#templatesScroll QScrollBar::add-page:vertical, #templatesScroll QScrollBar::sub-page:vertical {{ background: transparent; }}
#templatesScrollStatus {{ color: {MUTED}; font-size: 11px; padding: 0 5px; }}
#templatesFieldLabel, #templatesSection {{ color: {BLUE}; font-size: 12px; font-weight: 750; }}
#templatesSection {{ padding-top: 8px; font-size: 14px; }}
#templatesPopup QTextEdit, #templatesPopup QLineEdit, #templatesPopup QComboBox {{ background: white; color: {TEXT}; border: 1px solid #B7CFDC; border-radius: 7px; padding: 5px 8px; selection-background-color: {GREEN}; }}
#templatesPopup QComboBox {{ min-height: 29px; }}
#templatesPopup QCheckBox {{ color: {TEXT}; font-size: 12px; padding: 4px 0; }}
#templatesSaveIcon {{ background: #E4F4EF; color: {BLUE}; border: 1px solid #9CCDBA; border-radius: 8px; padding: 0 8px; min-height: 40px; max-height: 40px; font-size: 12px; font-weight: 800; }}
#templatesSaveIcon:hover {{ background: #D0F0E1; }}
#templatesPrimary {{ background: {GREEN}; color: white; border: none; border-radius: 9px; min-height: 38px; font-size: 12px; font-weight: 800; }}
#templatesPrimary:hover {{ background: {GREEN_2}; }}
#navItem, #navActive {{ text-align: left; color: #C7D8E5; border: none; background: transparent; padding-left: 14px; font-size: 13px; }}
#navItem:hover {{ background: rgba(255,255,255,0.08); color: white; }}
#navItem:disabled {{ color: #55758D; background: transparent; }}
#faqFavoritesToggle {{ background: rgba(217,181,52,0.08); border: 1px solid rgba(217,181,52,0.31); border-radius: 7px; padding: 0; min-height: 26px; max-height: 27px; }}
#faqFavoritesToggle:hover {{ background: rgba(217,181,52,0.18); border-color: {GOLD}; }}
#faqFavoritesPopup {{ background: #F3F8FB; border: 1px solid #95B6C7; border-radius: 13px; }}
#ticketBookmarksPopup {{ background: #F3F8FB; border: 1px solid #95B6C7; border-radius: 13px; }}
#faqFavoritesTitle {{ color: {BLUE}; font-size: 14px; font-weight: 850; }}
#faqFavoritesHint {{ color: {MUTED}; font-size: 11px; }}
#faqFavoritesSearch {{ background: #FFFFFF; color: {TEXT}; border: 1px solid #B4CDD9; border-radius: 9px; padding: 6px 8px; min-height: 30px; selection-background-color: {GREEN}; }}
#faqFavoritesSearch:focus {{ border: 2px solid {GREEN}; }}
#faqFavoritesScroll, #faqFavoritesBody, #faqFavoritesScroll QWidget#qt_scrollarea_viewport {{ background: transparent; border: none; }}
#faqFavoriteRow {{ background: #FFFFFF; border: 1px solid #C6DAE4; border-radius: 9px; }}
#faqFavoriteOpen {{ background: transparent; border: none; color: {BLUE}; text-align: left; padding: 4px 7px; min-height: 36px; font-size: 11px; }}
#faqFavoriteOpen:hover {{ color: {GREEN}; }}
#ticketBookmarkQueue {{ color: {MUTED}; font-size: 10px; }}
#faqFavoriteRemove, #faqFavoriteAction, #faqFavoritesClose {{ background: #EAF2F6; border: 1px solid #C6DAE4; border-radius: 7px; padding: 0; min-height: 27px; }}
#faqFavoriteRemove:hover, #faqFavoriteAction:hover, #faqFavoritesClose:hover {{ background: #FFF5D7; border-color: {GOLD}; }}
#navActive {{ background: #12639C; color: white; border-left: 4px solid #42D4D9; }}
#exitInsButton {{ text-align: left; background: rgba(199,61,77,0.22); color: #FFDDE1; border: 1px solid rgba(255,190,198,0.22); padding-left: 14px; }}
#exitInsButton:hover {{ background: {RED}; color: white; }}
#footerIconButton {{ background: rgba(255,255,255,0.06); border: 1px solid rgba(150,192,218,0.20); border-radius: 9px; padding: 0; min-width: 44px; max-width: 44px; min-height: 34px; max-height: 34px; }}
#footerIconButton:hover {{ background: rgba(255,255,255,0.14); border-color: #6BAECC; }}
#capriSidebarLogoutButton, #passwordManagerButton {{ text-align: left; background: rgba(18,112,153,0.20); color: #CBEAF7; border: 1px solid rgba(91,178,218,0.28); padding-left: 14px; }}
#capriSidebarLogoutButton:hover, #passwordManagerButton:hover {{ background: #176C99; color: white; border-color: #3B8DB8; }}
#capriSidebarLogoutButton:disabled, #passwordManagerButton:disabled {{ background: rgba(85,117,141,0.12); color: #7895AA; border-color: rgba(85,117,141,0.20); }}
#exitInsButton, #capriSidebarLogoutButton, #passwordManagerButton {{ padding: 0 4px; text-align: center; font-size: 12px; }}
#passwordManagerButton {{ background: #125D86; color: #F0FAFF; border-color: #2C7DA6; }}
#passwordManagerButton:hover {{ background: #176C99; color: white; border-color: #3B8DB8; }}
#sideActionButton {{ text-align: left; color: white; background: rgba(0,165,103,0.20); border: 1px solid rgba(119,226,174,0.28); padding-left: 14px; }}
#sideActionButton:hover {{ background: {GREEN}; border-color: {GREEN_2}; }}
#quickActionButton {{ background: rgba(255,255,255,0.08); color: white; border: 1px solid rgba(255,255,255,0.13); border-radius: 10px; padding: 0; font-size: 16px; font-weight: 800; }}
#quickActionButton:hover {{ background: rgba(0,165,103,0.35); border-color: {GREEN_2}; }}
#quickActionButton:disabled {{ color: #54748C; background: rgba(255,255,255,0.035); border-color: rgba(255,255,255,0.06); }}
#quickActionButton[emphasis="true"] {{ background: rgba(23,135,125,0.19); border: 1px solid rgba(99,224,194,0.54); }}
#quickActionButton[emphasis="true"]:hover {{ background: rgba(22,161,131,0.34); border-color: #78F1CF; }}
#quickActionButton[emphasis="true"]:disabled {{ background: rgba(255,255,255,0.035); border-color: rgba(255,255,255,0.06); }}
#connectionTools {{ background: #F3F8FB; border: 1px solid #D3E1E9; border-radius: 17px; }}
#refreshIconButton {{ background: transparent; color: {GREEN}; border: none; border-radius: 14px; padding: 0; min-height: 28px; font-size: 15px; font-weight: 800; }}
#refreshIconButton:hover {{ background: #DDF5E9; color: {GREEN}; border: none; }}
#refreshIconButton:disabled {{ background: #E9EEF2; color: #A0AFBA; border-color: #D5DEE5; }}
#copyTargetButton {{ background: transparent; color: {BLUE}; border: none; border-radius: 14px; padding: 0; min-height: 28px; font-size: 13px; font-weight: 800; }}
#copyTargetButton:hover {{ background: #DCECF6; color: {BLUE}; border: none; }}
#copyTargetButton:disabled {{ background: #EDF1F4; color: #A5B1B9; border-color: #DDE4E9; }}
#standardBadge, #insBadge {{ border-radius: 12px; padding: 7px 13px; font-size: 11px; font-weight: 700; }}
#standardBadge {{ background: #DFF3E8; color: {GREEN}; }}
#insBadge {{ background: #FFF2C2; color: #725800; }}
#escalationButton {{ background: #FFE4E8; color: #B42032; border: 1px solid #E88594; border-radius: 9px; padding: 0; min-height: 30px; max-height: 30px; }}
#escalationButton:hover {{ background: #FFC9D0; border-color: #CE3448; }}
#escalationPopup {{ background: transparent; border: none; }}
#escalationSurface {{ background: #F5F9FB; border: 1px solid #BF6976; border-radius: 14px; }}
#escalationTitle {{ color: #A62033; font-size: 14px; font-weight: 850; }}
#escalationHint {{ color: #526B7A; font-size: 11px; }}
#escalationRefresh, #escalationClose {{ background: #E8EEF2; color: #29475B; border: 1px solid #B6CED8; border-radius: 7px; padding: 0; min-height: 28px; max-height: 28px; }}
#escalationRow {{ text-align: left; background: #FFFFFF; border: 1px solid #BBD1DD; border-radius: 9px; padding: 0; min-height: 68px; max-height: 82px; }}
#escalationRow:hover {{ background: #FFF0F2; border-color: #CB4859; }}
#escalationRow:disabled {{ background: #EBF0F3; border-color: #CCD8DF; }}
#escalationName {{ color: #183C54; font-size: 12px; font-weight: 800; }}
#escalationDetail, #escalationState {{ color: #587486; font-size: 11px; }}
#escalationDot {{ color: #9CADB7; font-size: 15px; }}
#escalationDot[available="true"] {{ color: #0DA866; }}
#escalationContacted {{ color: #29475B; font-size: 11px; }}
#escalationReason {{ background: #FFFFFF; color: #183C54; border: 1px solid #B6CED8; border-radius: 7px; padding: 4px 8px; min-height: 30px; }}
#escalationScheduleLink {{ background: transparent; color: #087A57; border: none; padding: 3px 0; font-size: 11px; font-weight: 850; text-decoration: underline; }}
#escalationScheduleLink:hover {{ color: #005C40; }}
#escalationOverridePopup {{ background: transparent; border: none; }}
#escalationOverrideSurface {{ background: #F5F9FB; border: 1px solid #BF6976; border-radius: 14px; }}
#escalationOverrideRow {{ text-align: left; background: #FFFFFF; color: #183C54; border: 1px solid #BBD1DD; border-radius: 9px; padding: 9px 12px; min-height: 48px; font-size: 12px; font-weight: 750; }}
#escalationOverrideRow:hover {{ background: #FFF0F2; border-color: #CB4859; }}
#connectionCard, #actionCard, #statusCard {{ background: {SURFACE}; border: 1px solid #D5E0E8; border-radius: 13px; }}
#connectionCard {{ border-top: 3px solid {BLUE}; }}
#connectionCard[querying="true"] {{ background: #F3FBF7; border: 1px solid #9BD7B8; border-top: 3px solid {GREEN_2}; }}
#controlTabs::pane {{ background: transparent; border: none; }}
#controlTabs QTabBar {{ background: transparent; border: none; }}
#controlTabs QTabBar::tab {{ background: #E5EDF3; color: {BLUE}; border: none; border-bottom: 2px solid #BFCFD9; padding: 10px 8px; font-size: 11px; font-weight: 800; }}
#controlTabs QTabBar::tab:first {{ border-top-left-radius: 10px; }}
#controlTabs QTabBar::tab:last {{ border-top-right-radius: 10px; }}
#controlTabs QTabBar::tab:selected {{ background: {SURFACE}; color: {GREEN}; border-bottom: 3px solid {GREEN_2}; }}
#stationControlPage, #userControlPage {{ background: transparent; }}
#passwordManagerStatus {{ color: #647B8B; background: #EDF2F5; border: 1px solid #D3E0E7; border-radius: 8px; padding: 6px 9px; font-size: 10px; font-weight: 750; }}
#passwordManagerStatus[connected="true"] {{ color: #006D40; background: #E1F5EA; border-color: #A7D9BD; }}
#userResultCard[connected="true"] {{ background: #F3FAF7; border: 1px solid #B7D9C7; border-left: 4px solid #18A86F; border-radius: 14px; }}
#connectedUserPulse {{ background: #DDF7E9; border: 1px solid #98DDB9; border-radius: 17px; }}
#userResultTitle {{ background: transparent; color: {BLUE}; border: none; font-size: 15px; font-weight: 900; letter-spacing: .35px; }}
#userHeaderRefreshButton {{ background: #E6F3F8; border: 1px solid #B7D4E2; border-radius: 7px; padding: 0; }}
#userHeaderRefreshButton:hover {{ background: #D8EDF6; border-color: {BLUE_2}; }}
#userHeaderRefreshButton:disabled {{ background: #EDF3F6; border-color: #D5E1E8; }}
#userIdentityBar {{ background: #E8F7F0; border: 1px solid #B6DFC9; border-radius: 10px; }}
#userIdentityItem {{ background: {SURFACE}; color: {BLUE}; border: 1px solid #CDE5D8; border-radius: 8px; padding: 5px 8px; font-size: 11px; font-weight: 750; }}
#userIdentityText {{ background: transparent; color: {BLUE}; border: none; padding: 0; font-size: 11px; font-weight: 750; }}
#userLoginCopyButton {{ background: #E6F3F8; border: 1px solid #B7D4E2; border-radius: 6px; padding: 0; min-height: 22px; }}
#userLoginCopyButton:hover {{ background: {BLUE}; border-color: {BLUE}; }}
#userFieldCard, #userPasswordExpiryCard {{ background: {SURFACE}; border: 1px solid #C7DEE4; border-radius: 11px; }}
#userTicketPreviewCard {{ background: {SURFACE}; border: 1px solid #C7DEE4; border-radius: 11px; }}
#userTicketPreviewCard:hover {{ background: #EAF7F0; border-color: #8BCDAA; }}
#userTicketPreviewButton {{ background: #E6F3F8; border: 1px solid #B7D4E2; border-radius: 6px; padding: 0; }}
#userTicketPreviewButton:hover {{ background: {GREEN}; border-color: {GREEN}; }}
#userTicketRefreshButton {{ background: #E6F3F8; border: 1px solid #B7D4E2; border-radius: 6px; padding: 0; }}
#userTicketRefreshButton:hover {{ background: #DDF3E8; border-color: #8BCDAA; }}
#userTicketRefreshButton:disabled {{ background: #EFF3F6; border-color: #D2DCE3; }}
#userTicketsDialog {{ background: {SURFACE}; color: {TEXT}; }}
#userTicketResultsScroll, #userTicketResultsHost, #userTicketResultsScroll QWidget#qt_scrollarea_viewport {{ background: transparent; border: none; }}
#userTicketStatusFilter {{ background: #F8FAFC; color: {TEXT}; border: 1px solid #C6D4DE; border-radius: 9px; padding: 7px 10px; min-height: 24px; }}
#userTicketStatusFilter:hover {{ background: #FFFFFF; border-color: #75A9C7; }}
#userTicketStatusFilter QAbstractItemView {{ background: #FFFFFF; color: {TEXT}; border: 1px solid #C6D4DE; selection-background-color: #E1F3EA; selection-color: {BLUE}; outline: none; padding: 4px; }}
#userTicketProgressBar {{ background: #D3E6F1; border: none; border-radius: 3px; }}
#userTicketProgressBar::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #258DC2, stop:1 {GREEN_2}); border-radius: 3px; }}
#userTicketProgressPercent {{ color: {GREEN}; font-size: 10px; font-weight: 900; }}
#userFieldCaption {{ background: transparent; color: #24668F; border: none; font-size: 10px; font-weight: 850; letter-spacing: .25px; }}
#userFieldValue {{ background: transparent; color: {BLUE}; border: none; font-size: 11px; font-weight: 720; }}
#userFieldCard[fieldState="active"] #userFieldValue {{ color: {GREEN}; font-weight: 850; }}
#passwordExpiryAction {{ background: transparent; border: none; border-radius: 6px; padding: 0 4px; min-height: 18px; font-size: 11px; font-weight: 900; text-align: left; }}
#passwordExpiryAction[expiryState="valid"] {{ color: {GREEN}; }}
#passwordExpiryAction[expiryState="expired"] {{ color: {RED}; }}
#passwordExpiryAction[expiryState="unknown"] {{ color: #7B8E9B; }}
#passwordRecoveryButton {{ background: #E1F5EA; border: 1px solid #A7D9BD; border-radius: 7px; padding: 1px; min-height: 26px; }}
#passwordRecoveryButton:hover {{ background: {GREEN}; border-color: {GREEN}; }}
#passwordRecoveryButton:disabled {{ background: #EDF2F5; border-color: #D3E0E7; }}
#passwordManagerOpenButton {{ background: #E6F3F8; color: {BLUE}; border: 1px solid #B7D4E2; border-radius: 7px; padding: 0; min-height: 26px; max-height: 26px; font-size: 9px; font-weight: 900; }}
#passwordManagerOpenButton:hover {{ background: {BLUE}; color: white; border-color: {BLUE}; }}
#userInformationTabs::pane {{ background: {SURFACE}; border: 1px solid #CFDDE6; border-radius: 9px; top: -1px; }}
#userInformationTabs QTabBar::tab {{ background: #DFE9F0; color: {BLUE}; border: 1px solid #CFDDE6; padding: 8px 11px; min-width: 60px; font-size: 10px; font-weight: 750; }}
#userInformationTabs QTabBar::tab:selected {{ background: {GREEN}; color: white; border-color: {GREEN}; }}
#connectionTitle {{ color: {BLUE}; font-size: 11px; font-weight: 850; letter-spacing: 1.1px; }}
#smallMuted[querying="true"] {{ color: {BLUE}; background: #E4F5EC; border-left: 4px solid {GREEN_2}; border-radius: 7px; padding: 8px 10px; font-size: 12px; font-weight: 750; }}
#connectionProgress {{ background: #DDEFE6; color: {NAVY}; border: 1px solid #9BCFB5; border-radius: 9px; min-height: 24px; text-align: center; font-size: 10px; font-weight: 800; }}
#connectionProgress::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #42D68E, stop:.65 {GREEN_2}, stop:1 {GREEN}); border-radius: 8px; }}
#statusCard[connected="true"] {{ background: #F1FBF6; border: 1px solid #A8D9BF; border-left: 6px solid {GREEN_2}; }}
#statusTitle {{ color: {GREEN}; font-size: 15px; font-weight: 800; padding: 5px; }}
#connectedComputerPulse {{ background: #DDF7E9; border: 1px solid #98DDB9; border-radius: 17px; }}
#alertComputerPulse {{ background: #FBE5E9; border: 1px solid #E9A9B3; border-radius: 17px; }}
#stationIdentityBar {{ background: #E8F7F0; border: 1px solid #B6DFC9; border-radius: 10px; }}
#stationIdentityItem {{ background: {SURFACE}; color: {BLUE}; border: 1px solid #CDE5D8; border-radius: 8px; padding: 5px 8px; font-size: 11px; font-weight: 750; }}
#stationIdentityText {{ background: transparent; color: {BLUE}; border: none; font-size: 11px; font-weight: 750; }}
#freeOrientationButton {{ background: #E6F3F8; border: 1px solid #B7D4E2; border-radius: 7px; padding: 0; min-height: 24px; }}
#freeOrientationButton:hover {{ background: {BLUE}; border-color: {BLUE}; }}
#freeOrientationButton:disabled {{ background: #EFF3F5; border-color: #DCE5EA; }}
#connectedPulse {{ color: {GREEN_2}; font-size: 18px; font-weight: 800; }}
#alertPulse {{ color: {RED}; font-size: 18px; font-weight: 800; }}
#statusValue {{ background: #F3F7FA; color: {BLUE}; border: 1px solid #E4EBF0; border-radius: 9px; padding: 10px; font-size: 12px; }}
#statusValueText {{ background: transparent; color: {BLUE}; border: none; padding: 0; font-size: 12px; }}
#stationDataFieldCard {{ background: #F3F7FA; color: {BLUE}; border: 1px solid #E4EBF0; border-radius: 9px; padding: 0; }}
#statusFieldCaption {{ background: transparent; color: {BLUE_2}; border: none; padding: 0; font-size: 9px; font-weight: 850; letter-spacing: .25px; }}
#statusFieldValue {{ background: transparent; color: {BLUE}; border: none; padding: 0; font-size: 11px; font-weight: 700; }}
#statusCard[connected="true"] #statusValue {{ background: {SURFACE}; border: 1px solid #D4EADF; }}
#statusCard[connected="true"] #stationDataFieldCard {{ background: {SURFACE}; border: 1px solid #D4EADF; }}
#statusCard[compact="true"] {{ border-left-width: 4px; border-radius: 11px; }}
#statusCard[compact="true"] #statusTitle {{ font-size: 13px; padding: 3px; line-height: 1.15; }}
#statusCard[compact="true"] #connectedComputerPulse, #statusCard[compact="true"] #alertComputerPulse {{ border-radius: 14px; }}
#statusCard[compact="true"] #stationIdentityBar {{ border-radius: 8px; }}
#statusCard[compact="true"] #stationIdentityItem {{ padding: 4px 7px; font-size: 11px; border-radius: 7px; }}
#statusCard[compact="true"] #statusValue {{ border-radius: 8px; padding: 6px 7px; font-size: 11px; }}
#statusCard[compact="true"] #stationDataFieldCard {{ border-radius: 8px; padding: 0; }}
#statusCard[compact="true"] #statusValueText {{ font-size: 11px; }}
#statusCard[compact="true"] #statusFieldCaption {{ font-size: 9px; }}
#statusCard[compact="true"] #statusFieldValue {{ font-size: 11px; }}
#statusCard[compact="true"] #adminLockButton {{ min-height: 22px; border-radius: 6px; }}
#statusCard[compact="true"] #printerQuickButton {{ min-height: 25px; border-radius: 7px; }}
#adminGreenDot {{ color: {GREEN_2}; font-size: 15px; font-weight: 800; }}
#adminRedDot {{ color: {RED}; font-size: 15px; font-weight: 800; }}
#adminNeutralDot {{ color: #94A5B1; font-size: 15px; font-weight: 800; }}
#adminLockButton {{ background: #E8F2F7; color: {BLUE}; border: 1px solid #C9D9E3; border-radius: 7px; padding: 0; min-height: 24px; font-family: 'Segoe UI Emoji', 'Segoe UI'; font-size: 14px; }}
#adminLockButton:hover {{ background: {BLUE}; color: white; border-color: {BLUE}; }}
#adminLockButton:disabled {{ background: #EDF1F4; color: #A4B0B8; border-color: #DDE4E9; }}
#printerQuickButton {{ background: #E1F3EA; color: {GREEN}; border: 1px solid #B9DECA; border-radius: 8px; padding: 0; min-height: 28px; font-size: 13px; font-weight: 800; }}
#printerColorStatus {{ color: #55768A; font-size: 10px; font-weight: 750; }}
#printerColorStatus[permissionState="allowed"] {{ color: #00824A; }}
#printerColorStatus[permissionState="denied"] {{ color: #B63040; }}
#printerQuickButton:hover {{ background: {GREEN}; color: white; }}
#printerQuickButton:disabled {{ background: #E9EEF2; color: #9DABB5; border-color: #D6E0E6; }}
#printerAdminButton {{ border-radius: 8px; padding: 0; min-height: 28px; }}
#printerAdminButton[adminState="active"] {{ background: #E0F7EB; border: 1px solid #87D9AF; }}
#printerAdminButton[adminState="inactive"] {{ background: #FCE8EB; border: 1px solid #E8A1AB; }}
#printerAdminButton[adminState="unknown"] {{ background: #E9EEF2; border: 1px solid #D6E0E6; }}
#groupHeader {{ color: {BLUE_2}; font-size: 11px; font-weight: 800; letter-spacing: 1px; padding: 15px 4px 6px 4px; border-bottom: 2px solid #C9D8E3; }}
QLineEdit {{ background: #F8FAFC; border: 1px solid #C6D4DE; border-radius: 9px; padding: 10px 12px; min-height: 23px; selection-background-color: {GREEN}; }}
#settingsBrowserCombo, #settingsBrowserCombo QAbstractItemView, #settingsValidationCombo, #settingsValidationCombo QAbstractItemView {{ background: #F8FAFC; color: {TEXT}; border: 1px solid #AFC7D6; selection-background-color: #DCECF6; selection-color: {BLUE}; }}
#settingsValidationStatus {{ background: #F0F6F4; color: #315747; border: 1px solid #C4DDD2; border-radius: 8px; padding: 8px 10px; }}
#settingsValidationStatus[status="attention"] {{ background: #FFF4F1; color: #8E3F49; border-color: #E6BDC2; }}
QLineEdit:hover {{ border-color: #8DA8BA; }}
QLineEdit:focus {{ border: 2px solid {GREEN}; background: white; }}
#actionCard:hover {{ background: #FBFDFC; border: 1px solid {GREEN_2}; }}
#actionCard[compact="true"] {{ background: #FFFFFF; border: 1px solid #C8D9E3; border-radius: 12px; }}
#actionCard[compact="true"]:hover {{ background: #F6FCF9; border: 1px solid {GREEN_2}; }}
#actionCard[featuredRepair="true"] {{ background: #EAF1F5; border-color: #AFC8D6; }}
#actionCard[featuredRepair="true"]:hover {{ background: #E1EDF3; border-color: {GREEN_2}; }}
#softwareCard, #authorizedSoftwareCard, #faqCard, #orientationCard {{ background: {SURFACE}; border: 1px solid #CFDDE6; border-radius: 13px; }}
#softwareCard:hover, #authorizedSoftwareCard:hover, #faqCard:hover, #orientationCard:hover {{ background: #F8FCFA; border: 1px solid {GREEN_2}; }}
#authorizedSoftwareCard, #faqCard {{ border-left: 4px solid #9EDABB; }}
#orientationCard {{ border-left: 4px solid {BLUE_2}; }}
#cardActions {{ background: #F2F7FA; border: 1px solid #D9E5EC; border-radius: 11px; }}
#faqNumber {{ color: {GREEN}; background: #E5F6ED; border: 1px solid #BFE3CF; border-radius: 7px; padding: 3px 8px; font-size: 11px; font-weight: 850; letter-spacing: .4px; }}
#faqFavoriteButton {{ background: #EAF2F6; border: 1px solid #C6DAE4; border-radius: 8px; padding: 0; min-height: 31px; }}
#faqFavoriteButton[favorite="true"] {{ background: #FFF4D3; border-color: #D9B534; }}
#faqFavoriteButton:hover {{ border-color: #D9B534; background: #FFF7E2; }}
#orientationTreeLine {{ background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 {BLUE_2}, stop:.55 {GREEN_2}, stop:1 {YELLOW}); border-radius: 2px; }}
#orientationGlyph {{ background: #E7F1F7; border: 1px solid #C5DBE8; border-radius: 12px; }}
#orientationBadge {{ color: {BLUE_2}; background: #E7F1F7; border: 1px solid #C5DBE8; border-radius: 7px; padding: 3px 8px; font-size: 10px; font-weight: 850; letter-spacing: .5px; }}
#orientationTitle {{ color: {BLUE}; font-size: 14px; font-weight: 800; }}
#orientationSummary {{ color: {TEXT}; font-size: 11px; }}
#orientationPath {{ color: {GREEN}; background: #ECF8F1; border: 1px solid #C5E6D3; border-radius: 7px; padding: 7px 9px; font-size: 10px; font-weight: 700; }}
#orientationContact {{ color: #17324A; background: #F4F8FB; border: 1px solid #C8D9E5; border-radius: 7px; padding: 7px 9px; font-size: 10px; font-weight: 700; }}
#orientationTopicHeader {{ color: {BLUE_2}; background: #F3F8FB; border-left: 3px solid {YELLOW}; border-radius: 7px; padding: 8px 11px; font-size: 10px; font-weight: 850; letter-spacing: .7px; }}
#orientationSendButton {{ background: {BLUE}; border: 1px solid {BLUE_2}; border-radius: 10px; padding: 0; }}
#orientationSendButton:hover {{ background: {GREEN}; border-color: {GREEN_2}; }}
#faqOrientationButton {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {BLUE_2}, stop:1 {GREEN}); border: 1px solid #1C6C76; border-radius: 10px; padding: 0; min-height: 34px; }}
#faqOrientationButton:hover {{ background: {GREEN_2}; border-color: {GREEN}; }}
#faqOrientationAddButton {{ background: #EDF8F2; border: 1px dashed {GREEN_2}; border-radius: 10px; padding: 0; min-height: 34px; }}
#faqOrientationAddButton:hover {{ background: #DDF3E7; border: 1px solid {GREEN}; }}
#orientationPreviewDialog {{ background: #F3F7FA; }}
#orientationPreviewLabel {{ color: {BLUE_2}; font-size: 10px; font-weight: 900; letter-spacing: .9px; padding-top: 3px; }}
#orientationPreviewEditor {{ background: white; color: {TEXT}; border: 1px solid #BDD0DC; border-radius: 9px; padding: 8px 10px; selection-background-color: {GREEN}; }}
#orientationPreviewEditor:focus {{ border: 2px solid {GREEN_2}; }}
#orientationDeleteButton {{ background: #FFF2F3; color: {RED}; border: 1px solid #E5B6BD; border-radius: 9px; padding: 8px 12px; font-weight: 750; }}
#orientationDeleteButton:hover {{ background: {RED}; color: white; border-color: {RED}; }}
#orientationChoiceList {{ background: white; color: {TEXT}; border: 1px solid #C4D6E1; border-radius: 10px; padding: 6px; outline: none; }}
#orientationChoiceList::item {{ min-height: 42px; padding: 5px 9px; border-bottom: 1px solid #E7EEF3; border-radius: 6px; }}
#orientationChoiceList::item:selected {{ background: #E3F4EB; color: {BLUE}; border-left: 4px solid {GREEN}; }}
#faqSearchPanel {{ background: #F7FBFE; border: 2px solid #8DB5CE; border-left: 6px solid {BLUE}; border-radius: 13px; }}
#faqSearchTitle {{ color: {BLUE}; font-size: 12px; font-weight: 900; letter-spacing: 1px; }}
#faqSearchBadge {{ color: white; background: {BLUE}; border-radius: 8px; padding: 4px 8px; font-size: 9px; font-weight: 850; letter-spacing: .7px; }}
#faqSearchHint {{ color: #526B7E; font-size: 10px; font-weight: 600; }}
#faqSearchModeLabel {{ color: #526B7E; font-size: 9px; font-weight: 850; letter-spacing: .7px; }}
#faqSearchModeSelector {{ background: #E5EEF4; border: 1px solid #BED0DC; border-radius: 9px; }}
#faqSearchModeButton {{ background: transparent; color: #526B7E; border: none; border-radius: 7px; padding: 5px 10px; min-height: 18px; font-size: 10px; font-weight: 800; }}
#faqSearchModeButton:hover {{ color: {BLUE}; background: #F4F9FC; }}
#faqSearchModeButton:checked {{ color: white; background: {BLUE}; }}
#faqSearchInputFrame {{ background: white; border: 1px solid #A9C6D8; border-radius: 10px; }}
#faqSearchInput {{ background: transparent; color: {BLUE}; border: none; padding: 7px 5px; min-height: 25px; font-size: 12px; }}
#faqSearchInput:focus {{ background: transparent; border: none; }}
#faqResultCount {{ color: {GREEN}; background: #E7F6EE; border: 1px solid #C4E6D3; border-radius: 7px; padding: 4px 7px; font-size: 10px; font-weight: 850; }}
#faqMaintenanceFrame {{ background: #FFFDF5; border: 1px solid #DDD3A5; border-left: 5px solid {GOLD}; border-radius: 12px; }}
#faqMaintenanceTitle {{ color: #665719; font-size: 11px; font-weight: 900; letter-spacing: .9px; }}
#faqMaintenanceHint {{ color: #716A4C; font-size: 10px; font-weight: 600; }}
#faqMaintenanceFieldLabel {{ color: #665719; font-size: 10px; font-weight: 800; }}
#faqCapriAccessButton, #faqRemapAllButton {{ background: #F4F0DD; color: {BLUE}; border: 1px solid #D7C98D; border-radius: 8px; padding: 0 11px; min-height: 31px; font-size: 10px; font-weight: 750; }}
#faqCapriAccessButton:hover, #faqRemapAllButton:hover {{ background: {BLUE}; color: white; border-color: {BLUE}; }}
#orientationSearchPanel {{ background: #F7FBFE; border: 2px solid #8DB5CE; border-left: 6px solid {BLUE}; border-radius: 13px; }}
#orientationSearchTitle {{ color: {BLUE}; font-size: 12px; font-weight: 900; letter-spacing: 1px; }}
#orientationSearchBadge {{ color: white; background: {BLUE}; border-radius: 8px; padding: 4px 8px; font-size: 9px; font-weight: 850; letter-spacing: .7px; }}
#orientationSearchHint {{ color: #526B7E; font-size: 10px; font-weight: 600; }}
#orientationSearchInputFrame {{ background: white; border: 1px solid #A9C6D8; border-radius: 10px; }}
#orientationSearchInput {{ background: transparent; color: {BLUE}; border: none; padding: 7px 5px; min-height: 25px; font-size: 12px; }}
#orientationSearchInput:focus {{ background: transparent; border: none; }}
#orientationResultCount {{ color: {GREEN}; background: #E7F6EE; border: 1px solid #C4E6D3; border-radius: 7px; padding: 4px 7px; font-size: 10px; font-weight: 850; }}
#orientationMaintenanceFrame {{ background: #FFFDF5; border: 1px solid #DDD3A5; border-left: 5px solid {GOLD}; border-radius: 12px; }}
#orientationMaintenanceTitle {{ color: #665719; font-size: 11px; font-weight: 900; letter-spacing: .9px; }}
#orientationMaintenanceHint {{ color: #716A4C; font-size: 10px; font-weight: 600; }}
#orientationMaintenanceFieldLabel {{ color: #665719; font-size: 10px; font-weight: 800; }}
#orientationRemapAllButton {{ background: #F4F0DD; color: {BLUE}; border: 1px solid #D7C98D; border-radius: 8px; padding: 0 11px; min-height: 31px; font-size: 10px; font-weight: 750; }}
#orientationRemapAllButton:hover {{ background: {BLUE}; color: white; border-color: {BLUE}; }}
#specificOrientationFrame {{ background: #F8FBFD; border: 1px solid #C8DAE5; border-radius: 12px; }}
#specificOrientationLabel {{ color: {BLUE}; font-size: 11px; font-weight: 850; }}
#specificFaqInput {{ background: white; border: 1px solid #C4D6E1; border-radius: 8px; padding: 8px 10px; color: {TEXT}; }}
#specificFaqInput:focus {{ border: 1px solid {GREEN_2}; }}
#specificFaqButton {{ background: #EAF7F0; color: {GREEN}; border: 1px solid #B8DFC9; border-radius: 9px; padding: 8px 12px; font-weight: 750; }}
#specificFaqButton:hover {{ background: {GREEN}; color: white; }}
#softwareSearchFrame {{ background: {SURFACE}; border: 1px solid #C9D9E3; border-radius: 12px; }}
#softwareSearchInput {{ background: transparent; border: none; padding: 7px 5px; min-height: 25px; color: {BLUE}; }}
#softwareSearchInput:focus {{ background: transparent; border: none; }}
#softwareResultCount {{ color: {GREEN}; font-size: 10px; font-weight: 800; padding: 0 5px; }}
#softwareSuggestionPopup {{ background: #FFFFFF; border: 1px solid #9FBACB; border-radius: 9px; padding: 4px; outline: none; selection-background-color: {BLUE}; selection-color: #FFFFFF; }}
#softwareSuggestionPopup::item {{ min-height: 34px; padding: 0 8px; border-bottom: 1px solid #E7EEF3; }}
#softwareSuggestionPopup::item:hover {{ background: #EAF6F0; }}
#softwareSuggestionPopup::item:selected {{ background: {BLUE}; }}
#softwareCategoryCollapsed, #softwareCategoryExpanded {{ text-align: left; color: {BLUE}; background: #EAF2F7; border: 1px solid #C9D9E3; border-radius: 11px; padding: 0 14px; font-size: 12px; font-weight: 800; }}
#softwareCategoryCollapsed:hover {{ background: #DFEDF5; border-color: #91B3C9; }}
#softwareCategoryExpanded {{ color: {GREEN}; background: #E5F5EC; border-color: #A9D8BE; }}
#softwareCategoryExpanded:hover {{ background: #D8F0E3; border-color: {GREEN_2}; }}
#faqRootCollapsed, #faqRootExpanded {{ text-align: left; background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {BLUE}, stop:1 #075483); color: white; border: none; border-left: 5px solid {YELLOW}; border-radius: 11px; padding: 0 16px; min-height: 48px; font-size: 13px; font-weight: 850; letter-spacing: .6px; }}
#faqRootCollapsed:hover, #faqRootExpanded:hover {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #074777, stop:1 #0B6698); }}
#faqRootExpanded {{ border-left-color: #FFF27A; }}
#faqProcedureHeader {{ color: {BLUE_2}; background: #F5F9FB; border-left: 3px solid {GREEN_2}; border-radius: 7px; padding: 8px 11px; font-size: 10px; font-weight: 850; letter-spacing: .7px; }}
#softwareTreeLine {{ background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #BFE3CF, stop:.5 {GREEN_2}, stop:1 #BFE3CF); border-radius: 1px; }}
#softwareGlyph {{ background: #E2F4EA; border: 1px solid #BFE3CF; border-radius: 20px; padding: 0; }}
#softwareTitle {{ color: {BLUE}; font-size: 13px; font-weight: 750; }}
#softwarePath {{ color: {MUTED}; font-size: 10px; }}
#softwareLaunchButton {{ background: #E8F1F6; border: 1px solid #C8D9E3; border-radius: 9px; padding: 0; min-height: 32px; }}
#softwareLaunchButton:hover {{ background: {GREEN}; border-color: {GREEN_2}; }}
#softwareNotice {{ background: #E8F2F7; color: {BLUE}; border: 1px solid #C7DBE7; border-radius: 12px; padding: 18px; font-size: 12px; font-weight: 650; }}
#glyph {{ background: #E1F3EA; color: {GREEN}; border: 1px solid #CBE8D9; border-radius: 23px; font-size: 18px; font-weight: 800; }}
#cardTitle {{ font-weight: 750; color: {BLUE}; }}
#cardSubtitle {{ color: {MUTED}; font-size: 12px; }}
#actionCard[compact="true"] #glyph {{ border-radius: 17px; }}
#actionCard[compact="true"] #cardTitle {{ color: {BLUE}; font-size: 13px; font-weight: 800; }}
#actionCard[compact="true"] #cardSubtitle {{ color: #5D7384; font-size: 10px; font-weight: 550; }}
#actionCard[compact="true"][available="true"] #cardTitle, #actionCard[compact="false"][available="true"] #cardTitle {{ color: #07365B; font-weight: 850; }}
#actionCard[compact="true"][available="true"] #cardSubtitle, #actionCard[compact="false"][available="true"] #cardSubtitle {{ color: #354F62; font-weight: 620; }}
#actionCard:disabled, #actionCard[compact="true"]:disabled {{ background: #EDF2F5; border-color: #CFD9DF; }}
#actionCard[available="false"] #cardTitle, #actionCard[compact="true"][available="false"] #cardTitle,
#actionCard[available="false"] #cardSubtitle, #actionCard[compact="true"][available="false"] #cardSubtitle {{ color: #8C9CA7; }}
#cardArrow {{ background: #EAF1F6; color: {BLUE}; border: none; border-radius: 15px; padding: 0; min-height: 30px; font-size: 20px; }}
#actionCard[compact="true"] #cardArrow {{ border-radius: 13px; min-height: 26px; }}
#cardArrow:hover {{ background: {BLUE}; color: white; }}
#linkButton {{ background: transparent; color: {GREEN}; border: none; }}
#terminal {{ background: #051A2B; color: #C8F0DC; border: 1px solid #123B57; border-radius: 11px; padding: 14px; font-family: 'Cascadia Mono', Consolas; font-size: 12px; selection-background-color: {GREEN}; }}
#resultDialog, #remoteInventoryDialog {{ background: #F2F6F9; }}
#inventoryTree {{ background: #FFFFFF; alternate-background-color: #F0F6F8; color: #12354C; border: 1px solid #BDD2DD; border-radius: 9px; outline: none; }}
#inventoryTree::item {{ min-height: 29px; padding: 3px 5px; }}
#inventoryTree::item:selected {{ background: #D7F1E6; color: #063E2E; }}
#inventoryTree QHeaderView::section {{ background: #E3EFF4; color: #0E4A6C; border: none; border-bottom: 1px solid #B9D6E3; padding: 7px; font-weight: 750; }}
#compactConfirmDialog {{ background: #F7FAFC; }}
#compactNoticeDialog, #operationProgressDialog {{ background: #F7FAFC; }}
#noticeIcon {{ background: #E5F1F7; border: 1px solid #C6DDE9; border-radius: 17px; }}
#noticeMessage {{ color: {TEXT}; font-size: 12px; font-weight: 600; }}
#confirmIcon {{ background: #E6F1F7; border: 1px solid #C9DEE9; border-radius: 19px; }}
#confirmTitle {{ color: {BLUE}; font-size: 15px; font-weight: 750; }}
#confirmMessage {{ color: {TEXT}; font-size: 12px; }}
#popupHeader {{ background: {SURFACE}; border: 1px solid #D7E3EA; border-radius: 14px; }}
#popupStatusIconOk {{ background: #E1F5EA; border: 1px solid #BFE5D0; border-radius: 20px; }}
#popupStatusIconError {{ background: #FBE8EB; border: 1px solid #F1C9D0; border-radius: 20px; }}
#dialogSuccess {{ color: {GREEN}; font-size: 10px; font-weight: 800; letter-spacing: 1.5px; }}
#dialogError {{ color: {RED}; font-size: 10px; font-weight: 800; letter-spacing: 1.5px; }}
#dialogTitle {{ color: {BLUE}; font-size: 20px; font-weight: 750; }}
#popupResultScroll {{ background: transparent; border: none; }}
#popupResultScroll > QWidget > QWidget {{ background: transparent; }}
#popupInfoCard {{ background: {SURFACE}; border: 1px solid #D8E4EB; border-radius: 11px; }}
#popupInfoCard:hover {{ border-color: #A9CFBC; background: #FBFEFC; }}
#popupCardIcon {{ background: #E6F5ED; border: 1px solid #CBE8D8; border-radius: 18px; }}
#popupFieldCaption {{ color: {MUTED}; font-size: 10px; font-weight: 750; letter-spacing: 0.6px; }}
#popupFieldValue {{ color: {TEXT}; font-size: 12px; font-weight: 600; }}
#resultText {{ background: {SURFACE}; color: {TEXT}; border: 1px solid #CFDDE6; border-radius: 11px; padding: 14px; font-family: 'Cascadia Mono', Consolas; font-size: 12px; selection-background-color: {GREEN}; }}
#adTabs::pane {{ background: {SURFACE}; border: 1px solid #CFDDE6; border-radius: 9px; top: -1px; }}
#adTabs QTabBar::tab {{ background: #DFE9F0; color: {BLUE}; border: 1px solid #CFDDE6; padding: 9px 13px; min-width: 70px; font-weight: 700; }}
#adTabs QTabBar::tab:selected {{ background: {GREEN}; color: white; border-color: {GREEN}; }}
#adTabContent {{ background: {SURFACE}; color: {TEXT}; border: none; padding: 14px; font-family: 'Segoe UI Variable', 'Segoe UI'; font-size: 12px; }}
#diskCard {{ background: #F5F9FB; border: 1px solid #D7E3EA; border-radius: 9px; }}
#diskTitle {{ color: {BLUE}; font-size: 12px; font-weight: 750; }}
#profileDetails {{ color: {MUTED}; font-size: 11px; }}
#dialogScroll {{ background: {SURFACE}; border: none; }}
QProgressBar {{ background: #DDE8EE; color: {BLUE}; border: none; border-radius: 6px; min-height: 18px; text-align: center; font-size: 10px; font-weight: 700; }}
QProgressBar::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {GREEN}, stop:1 {GREEN_2}); border-radius: 6px; }}
QScrollArea {{ background: {BG}; border: none; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: #A9BBC8; min-height: 35px; border-radius: 5px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QMessageBox {{ background: #F2F6F9; }}
QMessageBox QLabel {{ color: {TEXT}; font-size: 12px; min-width: 300px; padding: 8px; }}
QMessageBox QPushButton {{ background: {BLUE}; color: white; min-width: 92px; min-height: 34px; border-radius: 8px; }}
QMessageBox QPushButton:hover {{ background: {GREEN}; }}
"""

STYLE += f"""
#content {{ background: #F3F7FA; }}
#themeButton {{ background: #FFFFFF; border: 1px solid #D4E0E8; border-radius: 18px; }}
#themeButton:hover {{ background: #EAF5F0; border-color: {GREEN_2}; }}
#themeLabel {{ color: #425F73; font-size: 10px; font-weight: 750; }}
#connectionCard, #actionCard, #statusCard, #softwareCard, #authorizedSoftwareCard, #faqCard, #orientationCard {{ border-radius: 16px; }}
#ticketFilterPanel {{ background: #FFFFFF; border: 1px solid #D5E1E9; border-radius: 18px; }}
#ticketHeaderIcon {{ background: #EAF2F8; border: 1px solid #D2E2EC; border-radius: 12px; }}
#ticketPanelTitle {{ color: {BLUE}; font-size: 16px; font-weight: 850; }}
#ticketPanelHint {{ color: {MUTED}; font-size: 10px; }}
#ticketResultCount {{ color: {GREEN}; background: #E9F7F0; border: 1px solid #C6E7D5; border-radius: 10px; padding: 5px 9px; font-size: 10px; font-weight: 850; }}
#capriSessionStatus {{ color: #6B7F8D; background: #F1F5F7; border: 1px solid #D4E0E7; border-radius: 9px; padding: 5px 8px; font-size: 9px; font-weight: 800; }}
#capriSessionStatus[connected="true"] {{ color: #087A54; background: #E5F6ED; border-color: #BCE2CC; }}
#ticketSearchFrame {{ background: #F8FAFC; border: 1px solid #CAD8E2; border-radius: 12px; }}
#ticketSearchInput {{ background: transparent; border: none; padding: 7px 4px; min-height: 26px; }}
#ticketSearchInput:focus {{ background: transparent; border: none; }}
#ticketSearchButton {{ background: {BLUE}; color: #FFFFFF; border: 1px solid {BLUE}; border-radius: 9px; padding: 0 14px; min-height: 34px; font-size: 10px; font-weight: 800; }}
#ticketSearchButton:hover {{ background: {GREEN}; border-color: {GREEN}; }}
#ticketSearchButton:disabled {{ background: #CBD7DF; color: #718593; border-color: #B9C8D2; }}
#ticketFilterButton {{ background: {GREEN}; color: #FFFFFF; border: 1px solid {GREEN}; border-radius: 9px; padding: 0 14px; min-height: 34px; font-size: 10px; font-weight: 800; }}
#ticketFilterButton:hover {{ background: {BLUE}; border-color: {BLUE}; }}
#ticketFilterButton:disabled {{ background: #CBD7DF; color: #718593; border-color: #B9C8D2; }}
#ticketLocalPeriodButton {{ background: #EAF2F7; border: 1px solid #B8CBD8; border-radius: 9px; padding: 0; }}
#ticketLocalPeriodButton:hover {{ background: #DDF0E9; border-color: {GREEN}; }}
#ticketLocalPeriodButton[active="true"] {{ background: #DDF4E9; border-color: {GREEN}; }}
#ticketLocalPeriodButton:disabled {{ background: #EDF2F5; border-color: #C9D6DE; }}
#ticketSectionLabel, #ticketFieldLabel {{ color: #5B7183; font-size: 9px; font-weight: 900; letter-spacing: 1px; }}
#ticketAdvancedToggle {{ text-align: left; background: #F2F6F9; color: {BLUE_2}; border: 1px solid #D7E2E9; border-radius: 10px; min-height: 36px; padding: 0 12px; }}
#ticketAdvancedToggle:hover, #ticketAdvancedToggle:checked {{ background: #E7F0F6; border-color: #AFC8D8; }}
#ticketAdvancedFrame {{ background: #F4F8FB; border: 1px solid #C8DBE7; border-left: 4px solid #258DC2; border-radius: 16px; }}
#ticketDateSeparator {{ color: {MUTED}; font-size: 10px; }}
#ticketGhostButton {{ background: #FFFFFF; color: {BLUE}; border: 1px solid #B8CBD8; border-radius: 10px; }}
#ticketGhostButton:hover {{ background: #EAF2F7; border-color: {BLUE_2}; }}
#ticketCard {{ background: #FFFFFF; border: 1px solid #D5E1E9; border-radius: 16px; }}
#ticketBookmarkButton {{ background: #E8F1F6; border: 1px solid #C8D9E3; border-radius: 9px; padding: 0; min-height: 32px; }}
#ticketBookmarkButton[active="true"] {{ background: #FFF5D7; border-color: {GOLD}; }}
#ticketBookmarkButton:hover {{ border-color: {GREEN}; }}
#licenseCard {{ background: #F7FBFD; border: 1px solid #BFD6E2; border-left: 3px solid {GREEN_2}; border-radius: 10px; }}
#licenseCode {{ color: {BLUE}; font-size: 12px; font-weight: 850; }}
#licenseSummary {{ color: {TEXT}; font-size: 11px; font-weight: 750; }}
#licenseResource {{ color: {MUTED}; font-size: 11px; padding-left: 8px; }}
#licensePolicyTitle {{ color: {BLUE}; font-size: 11px; font-weight: 850; margin-top: 12px; }}
#ticketCard:hover {{ border-color: {GREEN_2}; background: #FBFEFC; }}
#ticketNumber {{ color: {BLUE}; font-size: 10px; font-weight: 900; letter-spacing: .7px; }}
#ticketTitle {{ color: {BLUE}; font-size: 14px; font-weight: 800; }}
#ticketDetails {{ color: {MUTED}; font-size: 10px; }}
#ticketStatePending {{ color: #8A5B00; background: #FFF5D8; border: 1px solid #E9CF84; border-radius: 8px; padding: 4px 8px; font-size: 9px; font-weight: 850; }}
#ticketStateDone {{ color: {GREEN}; background: #E5F6ED; border: 1px solid #BCE2CC; border-radius: 8px; padding: 4px 8px; font-size: 9px; font-weight: 850; }}
#ticketStateOpen {{ color: #075D8A; background: #E2F3FC; border: 1px solid #ACD5E9; border-radius: 8px; padding: 4px 8px; font-size: 9px; font-weight: 850; }}
#ticketStateClosed {{ color: #536978; background: #EAF0F4; border: 1px solid #CAD8E1; border-radius: 8px; padding: 4px 8px; font-size: 9px; font-weight: 850; }}
#ticketQuickFilter {{ background: #F1F6F9; color: {BLUE}; border: 1px solid #CDDCE5; border-radius: 10px; padding: 5px 8px; min-height: 34px; font-size: 10px; font-weight: 750; }}
#ticketQuickFilter:hover {{ background: #E2EEF5; border-color: #A8C1D1; }}
#ticketQuickFilter:checked {{ background: {BLUE}; color: white; border-color: {BLUE}; }}
#ticketStatusPanel {{ background: #F5F8FA; border: 1px solid #D5E1E9; border-radius: 11px; }}
#ticketRenderProgress {{ background: #EAF5FB; border: 1px solid #BBD9E9; border-left: 4px solid #258DC2; border-radius: 10px; }}
#ticketRenderProgressLabel {{ color: {BLUE_2}; font-size: 10px; font-weight: 750; }}
#ticketRenderProgressBar {{ background: #D3E6F1; border: none; border-radius: 3px; }}
#ticketRenderProgressBar::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #258DC2, stop:1 {GREEN_2}); border-radius: 3px; }}
#faqMappingProgress {{ background: #EAF5FB; border: 1px solid #BBD9E9; border-left: 4px solid #258DC2; border-radius: 12px; }}
#faqMappingProgressText {{ color: {BLUE}; font-size: 12px; font-weight: 650; }}
#faqMappingProgressLabel {{ color: #526F82; font-size: 10px; font-weight: 750; }}
#faqMappingProgressPercent {{ color: {GREEN}; font-size: 11px; font-weight: 900; }}
#faqMappingProgressBar {{ background: #D3E6F1; border: none; border-radius: 4px; }}
#faqMappingProgressBar::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #258DC2, stop:1 {GREEN_2}); border-radius: 4px; }}
#ticketSyncProgress {{ background: #EAF5FB; border: 1px solid #BBD9E9; border-left: 4px solid #258DC2; border-radius: 12px; }}
#ticketSyncProgressText {{ color: {BLUE}; font-size: 12px; font-weight: 650; }}
#ticketSyncProgressLabel, #operationProgressLabel {{ color: #526F82; font-size: 10px; font-weight: 750; }}
#ticketSyncProgressPercent, #operationProgressPercent {{ color: {GREEN}; font-size: 11px; font-weight: 900; }}
#ticketSyncProgressBar, #operationProgressBar {{ background: #D3E6F1; border: none; border-radius: 4px; }}
#ticketSyncProgressBar::chunk, #operationProgressBar::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #258DC2, stop:1 {GREEN_2}); border-radius: 4px; }}
#ticketPeriodDialog {{ background: #F7FAFC; }}
#ticketPeriodTabs {{ background: transparent; border: none; }}
#ticketPeriodTabs::pane {{ background: #FFFFFF; border: 1px solid #C9DCE7; border-radius: 12px; top: -1px; }}
#ticketPeriodTabs QTabBar::tab {{ background: #EAF2F7; color: {BLUE_2}; border: 1px solid #C9DCE7; padding: 9px 16px; min-width: 130px; font-weight: 800; }}
#ticketPeriodTabs QTabBar::tab:first {{ border-top-left-radius: 9px; }}
#ticketPeriodTabs QTabBar::tab:last {{ border-top-right-radius: 9px; }}
#ticketPeriodTabs QTabBar::tab:selected {{ background: #FFFFFF; color: {GREEN}; border-bottom-color: #FFFFFF; }}
#ticketMonthSelect, #ticketYearSelect {{ min-height: 28px; }}
#dialogHint {{ color: {MUTED}; font-size: 12px; }}
#cacheClearButton {{ background: transparent; color: #6B7F8D; border: 1px solid #D4E0E7; border-radius: 8px; padding: 5px 9px; min-height: 22px; font-size: 9px; font-weight: 700; }}
#cacheClearButton:hover {{ background: #F4F8FA; color: {RED}; border-color: #E4BBC2; }}
#cacheRefreshButton {{ background: transparent; color: {BLUE}; border: 1px solid #C7D8E2; border-radius: 8px; padding: 5px 9px; min-height: 22px; font-size: 9px; font-weight: 750; }}
#cacheRefreshButton:hover {{ background: #EAF4F9; color: {GREEN}; border-color: #8FC8A9; }}
#cacheClearIconButton {{ background: transparent; border: 1px solid #D4E0E7; border-radius: 7px; }}
#cacheClearIconButton:hover {{ background: #FBEFF1; border-color: #E2ADB6; }}
QToolTip {{ color: #FFFFFF; background: #123B57; border: 1px solid #3A789D; border-radius: 6px; padding: 7px 9px; }}
QComboBox, QDateEdit {{ background: #F8FAFC; color: {TEXT}; border: 1px solid #C6D4DE; border-radius: 9px; padding: 8px 10px; min-height: 24px; }}
QComboBox::drop-down {{ border: none; width: 28px; background: transparent; }}
QDateEdit::drop-down {{ border: none; width: 38px; background: #E7F2F8; border-left: 1px solid #C6DCE8; border-top-right-radius: 8px; border-bottom-right-radius: 8px; }}
QDateEdit::down-arrow {{ image: url(assets/calendar_field.svg); width: 18px; height: 18px; }}
QComboBox:hover, QDateEdit:hover {{ background: #FFFFFF; border-color: #75A9C7; }}
#ticketCalendar {{ background: #FFFFFF; border: 1px solid #B9CFDC; border-radius: 14px; }}
#ticketCalendar QWidget#qt_calendar_navigationbar {{ background: #E8F3F9; border-bottom: 1px solid #C9DEE9; }}
#ticketCalendar QToolButton {{ background: transparent; color: {BLUE}; border: none; border-radius: 8px; margin: 4px 2px; min-height: 31px; padding: 0 8px; font-weight: 800; }}
#ticketCalendar QToolButton#qt_calendar_monthbutton {{ min-width: 128px; }}
#ticketCalendar QToolButton#qt_calendar_yearbutton {{ min-width: 64px; }}
#ticketCalendar QToolButton:hover {{ background: #D3E8F3; color: {GREEN}; }}
#ticketCalendar QToolButton#qt_calendar_prevmonth,
#ticketCalendar QToolButton#qt_calendar_nextmonth {{ background: #FFFFFF; border: 1px solid #C4DAE6; min-width: 30px; max-width: 30px; padding: 0; }}
#ticketCalendar QSpinBox {{ background: #FFFFFF; color: {BLUE}; border: 1px solid #C3D6E1; border-radius: 6px; selection-background-color: {GREEN}; }}
#ticketCalendar QAbstractItemView {{ background: #FFFFFF; color: {TEXT}; border: none; outline: none; selection-background-color: {GREEN}; selection-color: #FFFFFF; alternate-background-color: #F4F8FB; font-size: 11px; }}
#ticketCalendar QMenu {{ background: #FFFFFF; color: {TEXT}; border: 1px solid #C5D8E3; }}
"""

DARK_STYLE = f"""
* {{ color: #DCE8F2; }}
QMainWindow, #content, QScrollArea {{ background: #07131F; }}
#loginPanel {{ background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #071A34, stop:.55 #0A203C, stop:1 #07172C); }}
#loginPanel #pageTitle {{ color: #F7FBFE; }}
#loginEyebrow {{ color: #66D8EF; }}
#loginPanel #muted {{ color: #A9C0D0; }}
#loginPanel #identityCard {{ background: #0D2A48; color: #F1F8FC; border: 1px solid #326585; border-left: 5px solid #35D29A; }}
#loginPanel #loginProfileCard {{ background: #0B2742; border: 1px solid #315D7E; }}
#profileName {{ color: #8FCBEA; }}
#profileAccount {{ color: #F1F7FB; }}
#profileStatus {{ color: #55DDAA; }}
#loginFooter {{ color: #91ABBD; }}
#pageDeveloperFooter {{ color: #91ABBD; }}
#loginCardIcon {{ background: #10334A; border-color: #2A607D; }}
#loginCardStatusIcon {{ background: #10382F; border-color: #2C705A; }}
#loginCardCaption {{ color: #8CB7D0; }}
#loginCardValue {{ color: #F4F9FC; }}
#loginPanel #smallMuted {{ color: #A6BDCD; }}
#loginPanel #linkButton {{ color: #50DCAA; }}
#loginPanel #primaryButton {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #087E59, stop:1 #0AA06D); color: #FFFFFF; border: 1px solid #22B781; }}
#loginPanel #primaryButton:hover {{ background: #0DB37A; border-color: #62E4B6; }}
#loginPanel #dangerButton {{ background: #A93647; color: #FFFFFF; border-color: #D06776; }}
#loginPanel #dangerButton:hover {{ background: #C54658; border-color: #EA8793; }}
#loginPanel #loginTopActionButton {{ background: transparent; border-color: transparent; }}
#loginPanel #loginTopActionButton:hover {{ background: #12344B; border-color: #356783; }}
#loginPanel #loginExitSoftwareButton {{ background: #321A24; border-color: #70404B; }}
#loginPanel #loginExitSoftwareButton:hover {{ background: #4A2230; border-color: #B65A69; }}
#loginFooter a {{ color: #55DDB0; text-decoration: none; }}
#pageDeveloperFooter a {{ color: #55DDB0; text-decoration: none; }}
#loginPanel #themeLabel {{ color: #C1D5E2; }}
#sidebar {{ background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #092B5B, stop:.68 #071F42, stop:1 #05172D); border-right: 1px solid #246899; }}
#navItem {{ color: #AFC8DA; }}
#navItem:hover {{ color: white; background: rgba(73,154,210,.14); }}
#faqFavoritesPopup {{ background: #0B2031; border-color: #315F77; }}
#ticketBookmarksPopup {{ background: #0B2031; border-color: #315F77; }}
#ticketBookmarkButton {{ background: #112E43; border-color: #2C526A; }}
#ticketBookmarkButton[active="true"] {{ background: #3C3525; border-color: #D9B534; }}
#licenseCard {{ background: #102B40; border-color: #315F77; border-left-color: #41D1A5; }}
#licenseCode {{ color: #E5F4FC; }}
#licenseSummary {{ color: #EAF6FB; }}
#licenseResource {{ color: #B7D0DF; }}
#licensePolicyTitle {{ color: #8AD9F7; }}
#faqFavoritesTitle {{ color: #D8F3FF; }}
#faqFavoritesHint {{ color: #AFC9D9; }}
#faqFavoritesSearch {{ background: #102B40; color: #F2F8FC; border-color: #3F7791; }}
#faqFavoritesSearch:focus {{ border-color: #41D1A5; }}
#faqFavoriteRow {{ background: #102B40; border-color: #315C73; }}
#faqFavoriteOpen {{ color: #E5F4FC; }}
#faqFavoriteOpen:hover {{ color: #7BE8BC; }}
#ticketBookmarkQueue {{ color: #AFC9D9; }}
#faqFavoriteRemove, #faqFavoriteAction, #faqFavoritesClose {{ background: #17364A; border-color: #3D6780; color: #EAF5FB; }}
#faqFavoriteRemove:hover, #faqFavoriteAction:hover, #faqFavoritesClose:hover {{ background: #374033; border-color: #D9B534; }}
#faqFavoriteButton {{ background: #143044; border-color: #315C73; }}
#faqFavoriteButton[favorite="true"] {{ background: #3C3525; border-color: #D9B534; }}
#faqFavoriteButton:hover {{ background: #41402A; border-color: #D9B534; }}
#navActive {{ color: white; background: #176A9E; border-left-color: #58D9E9; }}
#quickActionButton {{ background: rgba(119,181,221,.10); border-color: rgba(142,197,231,.20); }}
#quickActionButton:hover {{ background: rgba(33,132,191,.30); border-color: #3E9DD2; }}
#quickActionButton[emphasis="true"] {{ background: rgba(31,124,149,.20); border: 1px solid rgba(113,203,206,.58); }}
#quickActionButton[emphasis="true"]:hover {{ background: rgba(37,151,168,.34); border-color: #81DDE3; }}
#quickActionButton[emphasis="true"]:disabled {{ background: rgba(119,181,221,.05); border-color: rgba(142,197,231,.10); }}
#usefulLinksPanel {{ background: rgba(8,33,53,0.85); }}
#usefulLinkButton {{ color: #DCECF6; }}
#usefulLinkDialog {{ background: #0B1D2B; color: #E7F1F7; }}
#usefulLinkDialog QLabel {{ color: #E7F1F7; }}
#usefulLinkDialog QLineEdit {{ background: #0A1B29; color: #F2F8FC; border-color: #315A73; }}
#templatesPopup {{ background: transparent; border: none; }}
#templatesSurface {{ background: #0A2438; color: #F1F8FC; border-color: #3887A0; }}
#templatesFooterDivider {{ background: #315A73; }}
#templatesTitle, #templatesFieldLabel, #templatesSection {{ color: #EAF7FC; }}
#templatesHistoryDialog {{ background: #0A2438; color: #F1F8FC; border-color: #3887A0; }}
#templatesHistoryConfirm {{ background: #0A2438; color: #F1F8FC; border-color: #3887A0; }}
#templatesHistoryTitle {{ color: #EAF7FC; }}
#templatesHistoryHint {{ color: #A8C2D1; }}
#templatesHistoryButton {{ background: #153D53; border-color: #376987; }}
#templatesHistoryButton:hover {{ background: #245E70; }}
#templatesHistoryRow {{ background: #102D43; color: #F1F8FC; border-color: #376987; }}
#templatesHistoryRow:hover {{ background: #194158; border-color: #5DBFA9; }}
#templatesHistoryClear {{ background: #153D53; color: #EAF7FC; border-color: #376987; }}
#templatesHistoryClear:hover {{ background: #245E70; }}
#templatesHistoryClear:disabled {{ color: #668094; }}
#templatesHistoryPreview {{ background: #102B40; color: #EAF7FC; border-color: #376987; }}
#templatesHistoryCloseAction {{ background: #153D53; color: #EAF7FC; border-color: #376987; }}
#templatesHistoryCloseAction:hover {{ background: #245E70; }}
#templatesHint {{ color: #A8C2D1; }}
#templatesItem {{ background: #102D43; border-color: #376987; border-left-color: #41D1A5; }}
#templatesItem:hover {{ background: #194158; border-color: #5DBFA9; }}
#templatesItemTitle {{ color: #F1F8FC; }}
#templatesItemDetail, #templatesScrollStatus {{ color: #A8C2D1; }}
#templatesItemChevron {{ color: #67E2B8; }}
#templatesSavedOpen {{ background: #103D3B; color: #C7FFE9; border-color: #3E887C; }}
#templatesSavedOpen:hover {{ background: #1B5951; }}
#templatesSavedRow {{ background: #102D43; border-color: #376987; }}
#templatesSavedItem {{ color: #EAF7FC; }}
#templatesSavedItem:hover {{ color: #67E2B8; }}
#templatesSavedDelete {{ color: #F0A7AE; }}
#templatesSavedDelete:hover {{ background: #583344; }}
#templatesSavedEdit {{ color: #BCEAF4; }}
#templatesSavedEdit:hover {{ background: #1B5951; color: #9EF4CD; }}
#templatesBack, #templatesClose {{ background: #153D53; color: #EAF7FC; border-color: #376987; }}
#templatesBack:hover, #templatesClose:hover {{ background: #245E70; }}
#templatesScroll, #templatesScroll > QWidget, #templatesScroll QWidget#qt_scrollarea_viewport, #templatesBody {{ background: #0A2438; border: none; }}
#templatesScroll QScrollBar::handle:vertical {{ background: #3E7690; }}
#templatesScroll QScrollBar::handle:vertical:hover {{ background: #41D1A5; }}
#templatesPopup QTextEdit, #templatesPopup QLineEdit, #templatesPopup QComboBox {{ background: #0B2031; color: #F2F8FC; border-color: #315A73; }}
#templatesSavedSearch {{ background: #102B40; color: #F2F8FC; border-color: #3F7791; }}
#templatesPopup QCheckBox {{ color: #EAF7FC; }}
#templatesSaveIcon {{ background: #103D3B; color: #D2FFEC; border-color: #3E887C; }}
#templatesSaveIcon:hover {{ background: #1B5951; }}
#pageTitle, #sectionTitle, #cardTitle, #softwareTitle, #faqTitle, #orientationTitle, #ticketTitle,
#ticketPanelTitle, #statusTitle, #connectionTitle, #diskTitle, #confirmTitle, #dialogTitle {{ color: #F4F9FC; }}
#sectionDescription, #muted, #smallMuted, #cardSubtitle, #softwarePath, #ticketDetails,
#profileDetails, #faqSearchHint, #ticketPanelHint, #ticketDateSeparator {{ color: #90AABD; }}
#sectionSeparator {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 transparent, stop:.08 #0C6B4D, stop:.50 #39F0A6, stop:.92 #0C6B4D, stop:1 transparent); border: none; }}
#connectionCard, #actionCard, #statusCard, #softwareCard, #authorizedSoftwareCard, #faqCard,
#orientationCard, #ticketCard, #popupHeader, #popupInfoCard, #diskCard, #loginProfileCard,
#identityCard {{ background: #0D2132; border-color: #234760; }}
#softwareCard, #softwareCard:focus, #authorizedSoftwareCard, #authorizedSoftwareCard:focus {{
    background: #0D2132; color: #EDF6FB; border: 1px solid #2A536B; border-left: 4px solid #37D49B;
}}
#softwareCard:hover, #authorizedSoftwareCard:hover {{
    background: #102B40; color: #FFFFFF; border: 1px solid #36C992; border-left: 4px solid #52E0AD;
}}
#softwareCard QLabel, #authorizedSoftwareCard QLabel {{ background: transparent; color: #DCEAF3; }}
#softwareCard #softwareTitle, #authorizedSoftwareCard #softwareTitle {{ color: #F4F9FC; }}
#softwareCard #softwarePath, #authorizedSoftwareCard #softwarePath {{ color: #8FB1C6; }}
#softwareCard:hover #softwareTitle, #authorizedSoftwareCard:hover #softwareTitle {{ color: #FFFFFF; }}
#softwareCard:hover #softwarePath, #authorizedSoftwareCard:hover #softwarePath {{ color: #B7D0DF; }}
#softwareCard #softwareGlyph, #authorizedSoftwareCard #softwareGlyph {{ background: #10334A; border-color: #2B6380; }}
#softwareCard #cardActions, #authorizedSoftwareCard #cardActions {{ background: #091B29; border-color: #285069; }}
#identityCard:hover, #loginProfileCard:hover {{ background: #102B40; border-color: #347291; }}
#connectionCard {{ border-top-color: #2B8FC5; }}
#connectionCard[querying="true"] {{ background: #0C2930; border-color: #24765E; border-top-color: #31C88B; }}
#controlTabs QTabBar::tab {{ background: #0A1C2A; color: #AFC8D8; border-bottom-color: #284B61; }}
#controlTabs QTabBar::tab:selected {{ background: #0D2132; color: #65DFB0; border-bottom-color: #39D49A; }}
#passwordManagerStatus {{ color: #9BB4C4; background: #10293B; border-color: #315268; }}
#passwordManagerStatus[connected="true"] {{ color: #66E2B1; background: #123C35; border-color: #2E7B63; }}
#passwordManagerButton {{ background: #123A52; color: #DDF3FD; border-color: #315F78; }}
#passwordManagerButton:hover {{ background: #176C99; color: white; border-color: #4A9BC5; }}
#userResultCard[connected="true"] {{ background: #081F28; border-color: #24515D; border-left-color: #27B986; }}
#connectedUserPulse {{ background: #123C35; border-color: #2E7B63; }}
#userResultTitle {{ color: #F2F8FC; }}
#userHeaderRefreshButton {{ background: #123A52; border-color: #315F78; }}
#userHeaderRefreshButton:hover {{ background: #176C99; border-color: #4A9BC5; }}
#userHeaderRefreshButton:disabled {{ background: #0B2232; border-color: #203C50; }}
#userIdentityBar {{ background: #0B2630; border-color: #24536A; }}
#userIdentityItem {{ background: #10293B; color: #E9F4FA; border-color: #274B62; }}
#userIdentityText {{ color: #E9F4FA; }}
#userLoginCopyButton {{ background: #123A52; border-color: #315F78; }}
#userLoginCopyButton:hover {{ background: #176C99; border-color: #4A9BC5; }}
#userFieldCard, #userPasswordExpiryCard {{ background: #0F293B; border-color: #286078; }}
#userTicketPreviewCard {{ background: #0F293B; border-color: #286078; }}
#userTicketPreviewCard:hover {{ background: #10372F; border-color: #39A87D; }}
#userTicketPreviewButton {{ background: #123A52; border-color: #315F78; }}
#userTicketPreviewButton:hover {{ background: #087A54; border-color: #39D49A; }}
#userTicketRefreshButton {{ background: #123A52; border-color: #315F78; }}
#userTicketRefreshButton:hover {{ background: #123C35; border-color: #39D49A; }}
#userTicketRefreshButton:disabled {{ background: #102536; border-color: #27465B; }}
#userTicketsDialog {{ background: #081824; color: #E7F1F7; }}
#userTicketResultsScroll, #userTicketResultsHost, #userTicketResultsScroll QWidget#qt_scrollarea_viewport {{ background: transparent; border: none; }}
#userTicketStatusFilter {{ background: #0A2030; color: #F0F7FB; border: 1px solid #315B74; border-radius: 10px; padding: 7px 10px; min-height: 24px; selection-background-color: #176C99; selection-color: #FFFFFF; }}
#userTicketStatusFilter:hover {{ background: #0D2A3E; color: #FFFFFF; border-color: #4484A8; }}
#userTicketStatusFilter:focus {{ background: #102E43; color: #FFFFFF; border: 2px solid #37A7D9; }}
#userTicketStatusFilter QAbstractItemView {{ background: #10293B; color: #E9F4FA; border: 1px solid #315B74; selection-background-color: #176C99; selection-color: #FFFFFF; outline: none; padding: 4px; }}
#userTicketStatusFilter QAbstractItemView::item {{ color: #E9F4FA; padding: 6px 8px; min-height: 24px; }}
#userTicketStatusFilter QAbstractItemView::item:hover {{ background: #1A5273; color: #FFFFFF; }}
#userTicketProgressBar {{ background: #17384D; border: none; border-radius: 3px; }}
#userTicketProgressBar::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #42B8E8, stop:1 #39D49A); border-radius: 3px; }}
#userTicketProgressPercent {{ color: #72E3B4; font-size: 10px; font-weight: 900; }}
#userTicketsDialog #ticketCard {{ background: #10293B; border: 1px solid #2B5B6B; }}
#userTicketsDialog #ticketCard:hover {{ background: #102B40; border-color: #36C992; }}
#userFieldCaption {{ color: #8FCBEA; }}
#userFieldValue {{ color: #E9F4FA; }}
#userFieldCard[fieldState="active"] #userFieldValue {{ color: #66E2B1; }}
#passwordExpiryAction[expiryState="valid"] {{ color: #66E2B1; }}
#passwordExpiryAction[expiryState="expired"] {{ color: #FF7887; }}
#passwordExpiryAction[expiryState="unknown"] {{ color: #91A8B8; }}
#passwordRecoveryButton {{ background: #123C35; border-color: #2E7B63; }}
#passwordRecoveryButton:hover {{ background: #087A54; border-color: #39D49A; }}
#passwordRecoveryButton:disabled {{ background: #172F40; border-color: #315268; }}
#passwordManagerOpenButton {{ background: #123A52; color: #DDF3FD; border-color: #315F78; }}
#passwordManagerOpenButton:hover {{ background: #176C99; color: white; border-color: #4A9BC5; }}
#userInformationTabs::pane {{ background: #0D2132; border-color: #284B61; }}
#userInformationTabs QTabBar::tab {{ background: #112C41; color: #BCD4E3; border-color: #2D5269; }}
#userInformationTabs QTabBar::tab:selected {{ background: #087A54; color: white; border-color: #28B880; }}
#statusCard[connected="true"] {{ background: #0B2A29; border-color: #226451; border-left-color: #2FD394; }}
#stationIdentityBar {{ background: #0B2630; border-color: #24536A; }}
#stationIdentityItem, #statusValue, #stationDataFieldCard {{ background: #10293B; color: #E9F4FA; border-color: #274B62; }}
#stationIdentityText, #statusValueText {{ color: #E9F4FA; }}
#statusFieldCaption {{ color: #8FC7E5; }}
#statusFieldValue {{ color: #E9F4FA; }}
#statusCard[connected="true"] #statusValue,
#statusCard[connected="true"] #stationDataFieldCard,
#statusCard[connected="true"] #stationIdentityItem {{ background: #10293B; color: #E9F4FA; border-color: #2B5B6B; }}
#statusCard[connected="true"] #statusValueText,
#statusCard[connected="true"] #stationIdentityText {{ background: transparent; color: #E9F4FA; border-color: transparent; }}
#softwareCategoryCollapsed, #faqProcedureHeader, #orientationTopicHeader {{ background: #102B40; color: #DCECF6; border-color: #2A526A; }}
#softwareCategoryExpanded {{ background: #113B3A; color: #63E0AF; border-color: #28725C; }}
#softwareCategoryCollapsed:hover {{ background: #15364C; color: #F2F8FC; border-color: #3B7898; }}
#softwareCategoryExpanded:hover {{ background: #154843; color: #7BE8BC; border-color: #3A9A78; }}
#faqRootCollapsed, #faqRootExpanded {{ background: #0D4168; border-left-color: #40D59C; }}
#faqSearchPanel, #orientationSearchPanel, #softwareSearchFrame, #faqSearchInputFrame,
#orientationSearchInputFrame, #ticketFilterPanel {{ background: #0B2031; border-color: #245574; }}
#faqSearchTitle {{ color: #8EDBFF; }}
#faqSearchBadge {{ color: #FFFFFF; background: #176C99; border: 1px solid #3A91BD; }}
#faqSearchHint {{ color: #B4CDDC; }}
#faqSearchModeSelector {{ background: #102B40; border-color: #315D77; }}
#faqSearchModeButton {{ color: #C4D8E5; }}
#faqSearchModeButton:checked {{ color: #FFFFFF; background: #176C99; }}
#ticketHeaderIcon, #orientationGlyph, #softwareGlyph, #noticeIcon, #confirmIcon {{ background: #102F48; border-color: #285A78; }}
#glyph, #actionCard[compact="true"] #glyph, #actionCard[compact="false"] #glyph {{ background: #102F48; color: #65DFB0; border-color: #285A78; }}
#ticketResultCount, #faqResultCount, #orientationResultCount {{ color: #62E0AF; background: #0E342D; border-color: #27634F; }}
#capriSessionStatus {{ color: #AFC8D8; background: #102B40; border: 1px solid #315B73; border-radius: 9px; padding: 5px 8px; font-size: 9px; font-weight: 800; }}
#capriSessionStatus[connected="true"] {{ color: #72E3B4; background: #10372D; border-color: #2B6B56; }}
#ticketSearchFrame, #ticketAdvancedFrame {{ background: #091A28; border-color: #24475D; }}
#ticketSearchButton {{ background: #176C99; color: #FFFFFF; border-color: #3B8DB8; }}
#ticketSearchButton:hover {{ background: #087A54; border-color: #28B880; }}
#ticketSearchButton:disabled {{ background: #0A1824; color: #688296; border-color: #203C50; }}
#ticketFilterButton {{ background: #087A54; color: #FFFFFF; border-color: #28B880; }}
#ticketFilterButton:hover {{ background: #176C99; border-color: #3B8DB8; }}
#ticketFilterButton:disabled {{ background: #0A1824; color: #688296; border-color: #203C50; }}
#ticketLocalPeriodButton {{ background: #15344A; border-color: #3A6A82; }}
#ticketLocalPeriodButton:hover {{ background: #1A5062; border-color: #45BE9C; }}
#ticketLocalPeriodButton[active="true"] {{ background: #17463E; border-color: #41D1A5; }}
#ticketLocalPeriodButton:disabled {{ background: #0A1824; border-color: #203C50; }}
#ticketStatusPanel {{ background: #0A1C2A; border-color: #24475D; }}
#ticketRenderProgress {{ background: #0D2A3D; border-color: #2C5D78; border-left-color: #52C7F0; }}
#ticketRenderProgressLabel {{ color: #C9E8F7; }}
#ticketRenderProgressBar {{ background: #17384D; }}
#ticketRenderProgressBar::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #42B8E8, stop:1 #39D49A); }}
#faqMappingProgress {{ background: #0D2A3D; border-color: #2C5D78; border-left-color: #52C7F0; }}
#faqMappingProgressText {{ color: #D7EAF5; }}
#faqMappingProgressLabel {{ color: #9FC5D9; }}
#faqMappingProgressPercent {{ color: #72E3B4; }}
#faqMappingProgressBar {{ background: #17384D; }}
#faqMappingProgressBar::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #42B8E8, stop:1 #39D49A); }}
#ticketSyncProgress {{ background: #0D2A3D; border-color: #2C5D78; border-left-color: #52C7F0; }}
#ticketSyncProgressText {{ color: #D7EAF5; }}
#ticketSyncProgressLabel, #operationProgressLabel {{ color: #9FC5D9; }}
#ticketSyncProgressPercent, #operationProgressPercent {{ color: #72E3B4; }}
#ticketSyncProgressBar, #operationProgressBar {{ background: #17384D; }}
#ticketSyncProgressBar::chunk, #operationProgressBar::chunk {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #42B8E8, stop:1 #39D49A); }}
#ticketPeriodDialog {{ background: #081824; color: #E7F1F7; }}
#ticketPeriodTabs {{ background: transparent; border: none; }}
#ticketPeriodTabs::pane {{ background: #0A1D2B; border: 1px solid #315B74; border-radius: 12px; top: -1px; }}
#ticketPeriodTabs QTabBar::tab {{ background: #0D2B40; color: #AFC8D8; border: 1px solid #315B74; padding: 9px 16px; min-width: 130px; font-weight: 800; }}
#ticketPeriodTabs QTabBar::tab:first {{ border-top-left-radius: 9px; }}
#ticketPeriodTabs QTabBar::tab:last {{ border-top-right-radius: 9px; }}
#ticketPeriodTabs QTabBar::tab:selected {{ background: #12364D; color: #65DFB0; border-bottom-color: #12364D; }}
#ticketMonthSelect, #ticketYearSelect {{ background: #12364D; color: #F4FAFE; border-color: #4386A8; }}
#ticketPeriodDialog #ticketMonthSelect QAbstractItemView,
#ticketPeriodDialog #ticketYearSelect QAbstractItemView {{ background: #12364D; color: #EAF4FA; border: 1px solid #4386A8; selection-background-color: #1D6E9F; selection-color: #FFFFFF; outline: none; padding: 4px; }}
#ticketPeriodDialog #ticketMonthSelect QAbstractItemView::item,
#ticketPeriodDialog #ticketYearSelect QAbstractItemView::item {{ color: #EAF4FA; padding: 7px 9px; min-height: 24px; }}
#ticketPeriodDialog #ticketMonthSelect QAbstractItemView::item:hover,
#ticketPeriodDialog #ticketYearSelect QAbstractItemView::item:hover {{ background: #1A5273; color: #FFFFFF; }}
#ticketPeriodDialog #ticketMonthSelect QAbstractItemView::item:disabled {{ color: #7890A0; background: #102B3E; }}
#ticketPeriodDialog #dialogTitle {{ color: #F4F9FC; }}
#ticketPeriodDialog #dialogHint {{ color: #9DB5C5; }}
#ticketPeriodDialog #ticketPeriodDate,
#ticketStatusPanel QComboBox {{ background: #0A2030; color: #F0F7FB; border: 1px solid #315B74; border-radius: 10px; padding: 8px 10px; }}
#ticketPeriodDialog #ticketPeriodDate::drop-down {{ background: #102F45; border-left: 1px solid #315B74; border-top-right-radius: 9px; border-bottom-right-radius: 9px; width: 38px; }}
#ticketPeriodDialog #ticketPeriodDate::down-arrow {{ image: url(assets/calendar_field.svg); width: 18px; height: 18px; }}
#ticketPeriodDialog #ticketPeriodDate:hover,
#ticketStatusPanel QComboBox:hover {{ background: #0D2A3E; color: #FFFFFF; border-color: #4484A8; }}
#ticketPeriodDialog #ticketPeriodDate:focus,
#ticketStatusPanel QComboBox:focus {{ background: #102E43; color: #FFFFFF; border: 2px solid #37A7D9; }}
#ticketPeriodDialog #ticketPeriodDate:disabled,
#ticketStatusPanel QComboBox:disabled {{ background: #081722; color: #748FA1; border-color: #1D3A4D; }}
#ticketCalendar {{ background: #081A28; color: #EAF4FA; border: 1px solid #315B74; border-radius: 14px; }}
#ticketCalendar QWidget#qt_calendar_navigationbar {{ background: #0D2B40; border-bottom: 1px solid #315B74; }}
#ticketCalendar QToolButton {{ background: transparent; color: #F2F8FC; border: none; border-radius: 8px; margin: 4px 2px; min-height: 31px; padding: 0 8px; font-weight: 800; }}
#ticketCalendar QToolButton#qt_calendar_monthbutton {{ min-width: 128px; }}
#ticketCalendar QToolButton#qt_calendar_yearbutton {{ min-width: 64px; }}
#ticketCalendar QToolButton:hover {{ background: #17618D; color: #FFFFFF; }}
#ticketCalendar QToolButton:pressed {{ background: #087A54; }}
#ticketCalendar QToolButton#qt_calendar_prevmonth,
#ticketCalendar QToolButton#qt_calendar_nextmonth {{ background: #102F45; border: 1px solid #315B74; min-width: 30px; max-width: 30px; padding: 0; }}
#ticketCalendar QToolButton#qt_calendar_prevmonth:hover,
#ticketCalendar QToolButton#qt_calendar_nextmonth:hover {{ background: #17618D; border-color: #4A9BC6; }}
#ticketCalendar QSpinBox {{ background: #0D2B40; color: #FFFFFF; border: 1px solid #32617D; border-radius: 6px; selection-background-color: #1878AD; }}
#ticketCalendar QAbstractItemView {{ background: #0A1D2B; color: #DCEAF3; border: none; outline: none; selection-background-color: #07865D; selection-color: #FFFFFF; alternate-background-color: #0C2232; font-size: 11px; }}
#ticketCalendar QAbstractItemView:disabled {{ color: #526E80; }}
#ticketCalendar QMenu {{ background: #0C2435; color: #EDF6FB; border: 1px solid #315A73; }}
#ticketAdvancedFrame {{ border-left: 4px solid #39A9D5; }}
#ticketSearchInput, #faqSearchInput, #orientationSearchInput, #softwareSearchInput {{ background: transparent; color: #EDF6FB; border: none; placeholder-text-color: #8EACBF; }}
#ticketSectionLabel, #ticketFieldLabel, #faqSearchModeLabel {{ color: #87B3D0; }}
QLineEdit, QComboBox, QDateEdit, QTextEdit, QListWidget {{ background: #0A1B29; color: #EDF6FB; border: 1px solid #294A60; selection-background-color: #1878AD; }}
#settingsBrowserCombo, #settingsBrowserCombo QAbstractItemView, #settingsValidationCombo, #settingsValidationCombo QAbstractItemView {{ background: #0A1B29; color: #EDF6FB; border: 1px solid #315A73; selection-background-color: #15598B; selection-color: #FFFFFF; }}
#settingsValidationStatus {{ background: #0E2B28; color: #8DE0BC; border: 1px solid #285C4B; border-radius: 8px; padding: 8px 10px; }}
#settingsValidationStatus[status="attention"] {{ background: #341D25; color: #FF9EAA; border-color: #72404C; }}
QLineEdit:hover, QComboBox:hover, QDateEdit:hover {{ border-color: #3B7191; }}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus {{ background: #0C2233; border: 2px solid #2A9BD1; }}
QComboBox QAbstractItemView {{ background: #0D2132; color: #EDF6FB; border: 1px solid #315A73; selection-background-color: #15598B; }}
#ticketAdvancedToggle, #ticketQuickFilter {{ background: #102A3E; color: #CDE3F1; border-color: #294E66; }}
#ticketAdvancedToggle:hover, #ticketAdvancedToggle:checked, #ticketQuickFilter:hover {{ background: #153B56; border-color: #36789E; }}
#ticketQuickFilter:checked {{ background: #1673A8; color: white; border-color: #3FA9DD; }}
#ticketGhostButton, #secondaryButton {{ background: #102B40; color: #DCECF6; border-color: #315B73; }}
#ticketGhostButton:hover, #secondaryButton:hover {{ background: #164462; color: white; border-color: #3B8DB8; }}
#ticketGhostButton:pressed, #secondaryButton:pressed {{ background: #0D3148; color: #FFFFFF; }}
#ticketGhostButton:disabled, #secondaryButton:disabled {{ background: #0A1A27; color: #688397; border-color: #203C50; }}
#primaryButton {{ background: #087A54; color: white; }}
#primaryButton:hover {{ background: #0A9868; }}
#disconnectButton {{ background: #9C3444; color: white; }}
#cardActions {{ background: #0A1C2A; border-color: #25475D; }}
#cardArrow, #softwareLaunchButton {{ background: #112E43; border-color: #2C526A; }}
#connectionTools {{ background: #0B2232; border: 1px solid #294E66; border-radius: 17px; }}
#refreshIconButton, #copyTargetButton {{ background: transparent; color: #9FD3EC; border: none; border-radius: 14px; }}
#refreshIconButton:hover, #copyTargetButton:hover {{ background: #164866; color: #FFFFFF; border: none; }}
#refreshIconButton:disabled, #copyTargetButton:disabled {{ background: transparent; color: #557386; border: none; }}
#cardArrow:hover, #softwareLaunchButton:hover {{ background: #176B94; border-color: #3EA0CF; }}
#faqNumber {{ color: #65DFB0; background: #0D352E; border-color: #286650; }}
#ticketStatePending {{ color: #FFD879; background: #392E16; border-color: #735C23; }}
#ticketStateDone {{ color: #6FE2B1; background: #10342A; border-color: #2B6B56; }}
#ticketStateOpen {{ color: #80D4FF; background: #102F49; border-color: #2D6689; }}
#ticketStateClosed {{ color: #B5C7D3; background: #192B38; border-color: #3A5364; }}
#ticketCard:hover {{ background: #102B40; border-color: #36C992; }}
#ticketCard:hover #ticketNumber {{ color: #8AD9F7; }}
#ticketCard:hover #ticketTitle {{ color: #FFFFFF; }}
#ticketCard:hover #ticketDetails {{ color: #B7CCDA; }}
#ticketNumber {{ color: #76C8EC; }}
#groupHeader {{ color: #76BDE6; border-color: #25485F; }}
#terminal, #resultText, #adTabContent {{ background: #04111C; color: #BEEBD8; border-color: #21445A; }}
#themeButton {{ background: #102E44; border: 1px solid #32617E; border-radius: 18px; }}
#themeButton:hover {{ background: #174866; border-color: #4A9BC6; }}
#themeLabel {{ color: #BBD0DE; }}
#insBadge {{ background: #3B3216; color: #FFE28A; }}
#escalationButton {{ background: #49242E; color: #FF9CA6; border-color: #A74255; }}
#escalationButton:hover {{ background: #65313E; border-color: #F27284; }}
#escalationSurface {{ background: #0D2739; border-color: #A74255; }}
#escalationTitle {{ color: #FF98A4; }}
#escalationHint {{ color: #B2C6D1; }}
#escalationRefresh, #escalationClose {{ background: #1A3D52; color: #E9F5F9; border-color: #416E82; }}
#escalationRow {{ background: #153247; border-color: #3E667D; }}
#escalationRow:hover {{ background: #3D2C3D; border-color: #D35A6B; }}
#escalationRow:disabled {{ background: #10293B; border-color: #34556A; }}
#escalationName {{ color: #EFF8FC; }}
#escalationDetail, #escalationState {{ color: #A5C0CD; }}
#escalationDot {{ color: #7591A0; }}
#escalationDot[available="true"] {{ color: #45D59B; }}
#escalationContacted {{ color: #E3F2F6; }}
#escalationReason {{ background: #10293B; color: #EFF8FC; border-color: #416E82; }}
#escalationScheduleLink {{ color: #64E1B7; }}
#escalationScheduleLink:hover {{ color: #B0F6D9; }}
#escalationOverrideSurface {{ background: #0D2739; border-color: #A74255; }}
#escalationOverrideRow {{ background: #153247; color: #EFF8FC; border-color: #3E667D; }}
#escalationOverrideRow:hover {{ background: #3D2C3D; border-color: #D35A6B; }}
#standardBadge {{ background: #10372D; color: #78E3B7; }}
#actionCard[compact="true"], #actionCard[compact="false"] {{ background: #0D2132; border: 1px solid #234760; }}
#actionCard[compact="true"]:enabled, #actionCard[compact="false"]:enabled {{ background: #122E43; border-color: #397391; }}
#actionCard[compact="true"]:hover, #actionCard[compact="false"]:hover {{ background: #102B40; border-color: #3182AA; }}
#actionCard[featuredRepair="true"][compact="true"], #actionCard[featuredRepair="true"][compact="false"] {{ background: #091A29; border-color: #31526B; }}
#actionCard[featuredRepair="true"][compact="true"]:hover, #actionCard[featuredRepair="true"][compact="false"]:hover {{ background: #0D2638; border-color: #4393B7; }}
#actionCard[compact="true"][available="true"] #cardTitle, #actionCard[compact="false"][available="true"] #cardTitle {{ color: #FFFFFF; font-weight: 850; }}
#actionCard[compact="true"][available="true"] #cardSubtitle, #actionCard[compact="false"][available="true"] #cardSubtitle {{ color: #E0EEF5; font-weight: 630; }}
#actionCard[compact="true"]:disabled, #actionCard[compact="false"]:disabled {{ background: #0B1925; border-color: #1B3444; }}
#actionCard[compact="true"][available="false"] #cardTitle, #actionCard[compact="false"][available="false"] #cardTitle,
#actionCard[compact="true"][available="false"] #cardSubtitle, #actionCard[compact="false"][available="false"] #cardSubtitle {{ color: #617889; }}
#softwareNotice {{ background: #0E2A3E; color: #D7EAF5; border-color: #2A5670; }}
#faqMaintenanceFrame, #orientationMaintenanceFrame, #specificOrientationFrame {{ background: #102536; border-color: #355269; }}
#faqMaintenanceTitle, #orientationMaintenanceTitle, #faqMaintenanceFieldLabel, #orientationMaintenanceFieldLabel {{ color: #BFD8E8; }}
#faqMaintenanceHint, #orientationMaintenanceHint {{ color: #91AABC; }}
#faqCapriAccessButton, #faqRemapAllButton, #orientationRemapAllButton, #specificFaqButton {{ background: #15364C; color: #DCECF6; border-color: #37647E; }}
#cacheClearButton {{ background: transparent; color: #8FA8B8; border-color: #29495D; }}
#cacheClearButton:hover {{ background: #301B25; color: #FF9BA8; border-color: #70404B; }}
#cacheRefreshButton {{ background: transparent; color: #9ED4EC; border: 1px solid #315A73; border-radius: 8px; padding: 5px 9px; min-height: 22px; font-size: 9px; font-weight: 750; }}
#cacheRefreshButton:hover {{ background: #123B52; color: #71E1B0; border-color: #3B8DB8; }}
#cacheRefreshButton:disabled {{ background: transparent; color: #557386; border-color: #203C50; }}
#cacheClearIconButton {{ background: transparent; border-color: #29495D; }}
#cacheClearIconButton:hover {{ background: #301B25; border-color: #70404B; }}
#faqCard, #faqCard:focus {{ background: #0D2132; color: #EDF6FB; border-color: #2A536B; }}
#faqCard:hover {{ background: #102B40; color: #EDF6FB; border-color: #36C992; }}
#faqCard QLabel {{ color: #DCEAF3; background: transparent; }}
#faqCard #faqNumber {{ color: #65DFB0; background: #0D352E; border-color: #286650; }}
#faqCard #cardActions {{ background: #081B29; border-color: #2A536B; }}
#faqCard #faqOrientationAddButton {{ background: #123047; color: #65DFB0; border: 1px solid #315B74; }}
#faqCard #faqOrientationAddButton:hover {{ background: #164A46; border-color: #42C99A; }}
#orientationPath {{ color: #70DFB3; background: #0E342D; border-color: #286650; }}
QToolTip {{ color: #F5FAFD; background: #0E2B40; border: 1px solid #3B7799; border-radius: 7px; padding: 7px 9px; }}
#orientationContact {{ color: #CBE2EF; background: #102A3D; border-color: #2B536A; }}
#orientationPreviewLabel {{ color: #78CFF2; font-size: 10px; font-weight: 900; letter-spacing: .9px; padding-top: 3px; }}
#orientationTitleInput {{ background: #0A1F2E; color: #F3F8FC; border: 1px solid #376982; border-radius: 9px; padding: 9px 11px; selection-background-color: #1878AD; selection-color: #FFFFFF; }}
#orientationTitleInput:hover {{ background: #0D2638; border-color: #4A87A7; }}
#orientationTitleInput:focus {{ background: #0D2638; border: 2px solid #31A9DE; color: #FFFFFF; }}
#orientationPreviewEditor, #orientationChoiceList {{ background: #081925; color: #EDF6FB; border-color: #31536A; }}
#orientationPreviewEditor:hover {{ background: #0A1D2A; border-color: #3B6B86; }}
#orientationPreviewEditor:focus {{ background: #0A1D2A; border: 2px solid #2A9BD1; color: #F5FAFD; }}
#specificFaqInput, #faqSearchInputFrame, #orientationSearchInputFrame {{ background: #091C2A; color: #EDF6FB; border-color: #2D5870; }}
#softwareSuggestionPopup {{ background: #0D2132; color: #EDF6FB; border-color: #315A73; selection-background-color: #176C99; selection-color: #FFFFFF; }}
#faqSearchModeButton:hover {{ background: #123249; color: #F1F8FC; border-color: #367494; }}
#adTabs::pane, #dialogScroll {{ background: #0D2132; border-color: #284B61; }}
#adTabs QTabBar::tab {{ background: #112C41; color: #BCD4E3; border-color: #2D5269; }}
#adTabs QTabBar::tab:selected {{ background: #176C99; color: white; border-color: #2E8CBB; }}
#popupFieldCaption, #dialogSuccess {{ color: #64DDAF; }}
#popupInfoCard:hover {{ background: #102B3D; border-color: #377596; }}
#noticeIcon, #popupCardIcon {{ background: #113249; border-color: #2C6381; }}
#connectedComputerPulse {{ background: #103A32; border-color: #2A775F; }}
#alertComputerPulse {{ background: #3A1D26; border-color: #743746; }}
#freeOrientationButton, #adminLockButton, #printerQuickButton {{ background: #123047; border-color: #315B74; }}
#printerQuickButton {{ background: #123047; color: #72DEB2; border: 1px solid #315B74; }}
#printerColorStatus {{ color: #A8C3D2; }}
#printerColorStatus[permissionState="allowed"] {{ color: #58DEAA; }}
#printerColorStatus[permissionState="denied"] {{ color: #FF9BA7; }}
#printerQuickButton:hover {{ background: #087A54; color: #FFFFFF; border-color: #35C98E; }}
#printerQuickButton:disabled {{ background: #0B2232; color: #58788B; border-color: #234357; }}
#printerAdminButton[adminState="active"] {{ background: #0B3A2B; border: 1px solid #2F9F72; }}
#printerAdminButton[adminState="inactive"] {{ background: #3C202B; border: 1px solid #A94B5A; }}
#printerAdminButton[adminState="unknown"] {{ background: #0B2232; border: 1px solid #234357; }}
QPushButton:disabled, QLineEdit:disabled, QComboBox:disabled {{ color: #688296; background: #0A1824; border-color: #203C50; }}
QLabel {{ background: transparent; }}
QScrollBar::handle:vertical {{ background: #31556C; }}
QInputDialog, QMessageBox, #resultDialog, #remoteInventoryDialog, #compactConfirmDialog, #compactNoticeDialog, #operationProgressDialog, #orientationPreviewDialog {{ background: #0B1D2B; color: #E7F1F7; }}
#inventoryTree {{ background: #0D2638; alternate-background-color: #113047; color: #EDF8FD; border: 1px solid #315F79; border-radius: 9px; outline: none; }}
#inventoryTree::item {{ min-height: 29px; padding: 3px 5px; }}
#inventoryTree::item:selected {{ background: #176A68; color: #FFFFFF; }}
#inventoryTree QHeaderView::section {{ background: #173A53; color: #E4F6FD; border: none; border-bottom: 1px solid #3A7592; padding: 7px; font-weight: 750; }}
QInputDialog QLabel, QMessageBox QLabel, #noticeMessage, #confirmMessage, #popupFieldValue {{ color: #E7F1F7; background: transparent; }}
QInputDialog QLineEdit {{ background: #0A1B29; color: #F2F8FC; border: 2px solid #2A9BD1; selection-background-color: #1673A8; selection-color: #FFFFFF; }}
QInputDialog QPushButton, QMessageBox QPushButton {{ background: #12344B; color: #EAF4FA; border: 1px solid #356783; border-radius: 8px; min-width: 82px; min-height: 32px; padding: 2px 10px; }}
QInputDialog QPushButton:hover, QMessageBox QPushButton:hover {{ background: #195072; color: #FFFFFF; border-color: #50A8D4; }}
QInputDialog QPushButton:default, QMessageBox QPushButton:default {{ background: #087A54; color: #FFFFFF; border-color: #28B880; }}
QInputDialog QPushButton:disabled, QMessageBox QPushButton:disabled {{ background: #0A1824; color: #688296; border-color: #203C50; }}
"""



def main():
    if "--browser-session-helper" in sys.argv:
        raise SystemExit(run_browser_session_helper())
    configure_windows_app_identity()
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationDisplayName(APP_NAME)
    app.setApplicationVersion(VERSION)
    icon_file = resource_path("assets/app_icon.ico")
    if not icon_file.exists():
        icon_file = resource_path("assets/app_icon.png")
    if icon_file.exists():
        app.setWindowIcon(QIcon(str(icon_file)))
    saved_dark = bool(load_json_cache(theme_settings_path()).get("dark", False))
    start_dark = True if "--theme-dark" in sys.argv else (False if "--theme-light" in sys.argv else saved_dark)
    if start_dark != saved_dark:
        save_json_cache(theme_settings_path(), {"dark": start_dark})
    app.theme_window_filter = ThemeWindowFilter(app)
    app.installEventFilter(app.theme_window_filter)
    apply_application_theme(start_dark)
    window = MainWindow()
    if window.is_full_display_mode():
        window.showMaximized()
    else:
        window.show()
    apply_native_window_icon(window)
    # A segunda passagem ocorre após o Windows calcular a moldura real.
    QTimer.singleShot(0, window.fit_current_monitor_height)
    QTimer.singleShot(120, window.fit_current_monitor_height)
    if "--ins" in sys.argv:
        window.select_profile("ins", windows_identity(), "")
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
