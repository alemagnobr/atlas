# Política de segurança

## Controle de usuários e Gestor de Senhas

- O Gestor utiliza um escopo próprio no Gerenciador de Credenciais do Windows (`gestor_senhas`), separado do Capri.
- Cookies de cada serviço são protegidos pelo DPAPI do usuário Windows e nunca compartilhados entre integrações.
- Senhas são enviadas ao processo PowerShell por variável de ambiente codificada, não por argumentos ou arquivos.
- Consultas do Active Directory aceitam somente login normalizado e aplicam filtro exato.
- O e-mail de recuperação é mascarado na interface e não é escrito no Console de atividades.
- Uma consulta de usuário nunca envia recuperação automaticamente.
- O envio exige uma etapa de pré-visualização, confirmação humana e intervalo contra repetição.
- O ATLAS não armazena tokens, códigos de recuperação ou conteúdo completo das páginas do portal.

## Versões atendidas

A versão mais recente da branch `main` recebe correções. Versões antigas são mantidas somente como histórico e não devem ser consideradas seguras para uso operacional.

## Como relatar uma vulnerabilidade

Não publique credenciais, nomes reais de usuários ou estações, IPs, logs corporativos ou detalhes exploráveis em uma issue.

Relate o problema diretamente aos mantenedores **@joaocerq-me** e **@alemagnobr** pelos canais internos autorizados. Inclua apenas o necessário para reproduzir a falha em ambiente de homologação e remova dados sensíveis de capturas e logs.

## Princípios do projeto

- menor privilégio e uso da sessão INS somente quando necessário;
- confirmação antes de ações com impacto;
- credenciais protegidas pelo Gerenciador de Credenciais do Windows;
- revisão conjunta das rotinas administrativas;
- testes em homologação antes do uso operacional.
