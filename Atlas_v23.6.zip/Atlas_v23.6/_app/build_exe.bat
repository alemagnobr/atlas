@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_CMD="
where py >nul 2>&1 && set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD where python >nul 2>&1 && set "PYTHON_CMD=python"
if not defined PYTHON_CMD (
  echo [ERRO] Python 3.11 ou superior nao foi localizado.
  exit /b 1
)

%PYTHON_CMD% -m pip install --disable-pip-version-check -r requirements-build.txt
if errorlevel 1 exit /b 1

%PYTHON_CMD% -m PyInstaller --noconfirm --clean --windowed --onefile ^
  --name "AtlasSuporteAvancado" ^
  --icon "assets\app_icon.ico" ^
  --add-data "assets;assets" ^
  --add-data "data;data" ^
  --add-data "scripts;scripts" ^
  --version-file "installer\version_info.txt" ^
  main.py
if errorlevel 1 exit /b 1
if not exist "dist\AtlasSuporteAvancado.exe" (
  echo [ERRO] O executavel nao foi criado.
  exit /b 1
)
echo.
echo [OK] Executavel criado em dist\AtlasSuporteAvancado.exe
exit /b 0
