@echo off
setlocal
chcp 65001 >nul
title Publicar Atlas - Suporte Avancado no GitHub

cd /d "%~dp0"

where git >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERRO] Git nao foi encontrado neste computador.
    echo Instale o Git for Windows e execute este arquivo novamente.
    echo https://git-scm.com/download/win
    echo.
    pause
    exit /b 1
)

if not exist ".git" (
    git init -b main
    if errorlevel 1 goto :erro
)

git config user.name "Joao Cerqueira"
git config user.email "247242926+joaocerq-me@users.noreply.github.com"
git branch -M main

git add .
git diff --cached --quiet
if errorlevel 1 (
    git commit -m "feat: sessão Capri e acabamento visual no Atlas v10.19"
    if errorlevel 1 goto :erro
)

git remote get-url origin >nul 2>&1
if errorlevel 1 (
    git remote add origin "https://github.com/joaocerq-me/gerenciador-suporte-senado.git"
)

echo.
echo Publicando no repositorio privado...
echo O Git Credential Manager podera abrir o navegador para confirmar seu login.
echo.
git push -u origin main
if errorlevel 1 goto :erro

echo.
echo ============================================================
echo  PUBLICACAO CONCLUIDA
echo  https://github.com/joaocerq-me/gerenciador-suporte-senado
echo ============================================================
echo.
pause
exit /b 0

:erro
echo.
echo [ERRO] Nao foi possivel concluir a publicacao.
echo Copie a mensagem exibida acima e envie ao Clark para diagnostico.
echo.
pause
exit /b 1
