"""Interface compatível sem dependências externas (Tkinter)."""
from __future__ import annotations

import ctypes
import getpass
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, scrolledtext

ROOT = Path(__file__).resolve().parent
BLUE = "#00305C"
BLUE2 = "#0A426F"
GREEN = "#00824A"
YELLOW = "#FAE042"
BG = "#EEF3F7"
WHITE = "#FFFFFF"
TEXT = "#102638"
MUTED = "#637789"
RED = "#C73D4D"

ACTIONS = [
    ("Controle remoto SCCM", "Abrir acesso remoto da estação", "cmrc", True, False),
    ("Ping contínuo", "Monitorar a conectividade", "ping", False, False),
    ("Encerrar Outlook", "Finalizar o Outlook remotamente", "outlook", True, False),
    ("Limpar cache DNS", "Executar FlushDNS", "dns", True, False),
    ("Atualizar políticas", "Executar GPUpdate /force", "gpupdate", True, False),
    ("Limpar TEMP", "Remover arquivos temporários", "temp", True, True),
    ("Logoff remoto", "Encerrar a sessão conectada", "logoff", True, True),
    ("Reiniciar estação", "Reiniciar em 15 segundos", "restart", True, True),
    ("Admin local", "Adicionar ou remover usuário", "admin", True, True),
    ("Active Directory", "Abrir usuários e computadores", "ad", True, False),
    ("Opções da Internet", "Certificados e configurações", "inetcpl", False, False),
    ("Limpar spooler", "Limpar a fila de impressão", "spooler", True, True),
]


def identity():
    return f"{os.environ.get('USERDOMAIN', 'SENADO')}\\{getpass.getuser()}"


def admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Atlas — Suporte Avançado — Senado Federal")
        self.geometry("1360x820")
        self.minsize(1100, 700)
        self.configure(bg=BG)
        self.target = ""
        self.profile = "ins" if "--ins" in sys.argv else "standard"
        self.events = queue.Queue()
        self.after(100, self.poll_events)
        if "--ins" in sys.argv:
            self.dashboard()
        else:
            self.login()

    def clear(self):
        for child in self.winfo_children():
            child.destroy()

    def button(self, parent, text, command, primary=True, **kwargs):
        return tk.Button(parent, text=text, command=command, cursor="hand2",
                         bg=GREEN if primary else WHITE,
                         fg=WHITE if primary else BLUE,
                         activebackground="#126F40" if primary else "#E8EEF4",
                         activeforeground=WHITE if primary else BLUE,
                         relief="flat", bd=0, padx=20, pady=12,
                         font=("Segoe UI", 10, "bold"), **kwargs)

    def login(self):
        self.clear()
        left = tk.Frame(self, bg=BLUE, width=520)
        left.pack(side="left", fill="both")
        left.pack_propagate(False)
        logo = tk.Canvas(left, width=118, height=130, bg=BLUE, highlightthickness=0)
        logo.pack(anchor="w", padx=65, pady=(100, 20))
        logo.create_polygon(59, 4, 110, 24, 105, 87, 59, 123, 13, 87, 8, 24,
                            fill=BLUE2, outline=YELLOW, width=4)
        logo.create_line(11, 33, 107, 33, fill=GREEN, width=7)
        logo.create_rectangle(31, 51, 87, 85, fill=WHITE, outline="")
        logo.create_line(39, 68, 50, 68, 56, 58, 65, 79, 72, 67, 81, 67,
                         fill=GREEN, width=4)
        tk.Label(left, text="ATLAS\nSUPORTE AVANÇADO", bg=BLUE, fg=WHITE,
                 font=("Segoe UI", 34, "bold"), justify="left").pack(anchor="w", padx=65)
        tk.Label(left, text="Operações técnicas organizadas, seguras e rápidas\npara o atendimento de TI.",
                 bg=BLUE, fg="#DCE8F2", font=("Segoe UI", 12), justify="left").pack(anchor="w", padx=65, pady=22)
        stripe = tk.Frame(left, bg=GREEN, height=7)
        stripe.pack(side="bottom", fill="x")
        tk.Frame(stripe, bg=YELLOW, width=260).pack(side="right", fill="y")

        right = tk.Frame(self, bg=BG)
        right.pack(side="left", expand=True, fill="both")
        box = tk.Frame(right, bg=BG)
        box.place(relx=.5, rely=.5, anchor="center", width=520)
        tk.Label(box, text="Bem-vindo", bg=BG, fg=BLUE,
                 font=("Segoe UI", 27, "bold")).pack(anchor="w")
        tk.Label(box, text="Autentique-se com a sessão administrativa para iniciar o atendimento.", bg=BG,
                 fg=MUTED, font=("Segoe UI", 11)).pack(anchor="w", pady=(4, 25))
        ident = tk.Frame(box, bg=WHITE, highlightbackground="#DCE4EB", highlightthickness=1)
        ident.pack(fill="x", pady=(0, 24))
        tk.Frame(ident, bg=GREEN, width=6).pack(side="left", fill="y")
        tk.Label(ident, text=f"IDENTIDADE WINDOWS\n{identity()}", bg=WHITE, fg=BLUE,
                 font=("Segoe UI", 11, "bold"), justify="left", padx=20, pady=18).pack(anchor="w")
        self.button(box, "Autenticar como INS", self.authenticate_ins).pack(fill="x", pady=5)
        tk.Label(box, text="A senha administrativa é solicitada pelo Windows e não é armazenada.",
                 bg=BG, fg=MUTED, font=("Segoe UI", 9), wraplength=480).pack(anchor="w", pady=15)

    def authenticate_ins(self):
        if admin() or getpass.getuser().lower().endswith("_ins"):
            self.profile = "ins"
            self.dashboard()
            return
        user = getpass.getuser()
        if user.lower().endswith("_ins"):
            user = user[:-4]
        account = f"{os.environ.get('USERDOMAIN', 'SENADO')}\\{user}_ins"
        if not messagebox.askyesno("Autenticação INS", f"O Windows solicitará a senha de {account}. Continuar?"):
            return
        command = f'cmd.exe /c "\"{sys.executable}\" \"{Path(__file__).resolve()}\" --ins"'
        try:
            subprocess.Popen(["runas", f"/user:{account}", command])
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Falha na autenticação", str(exc))

    def dashboard(self):
        self.clear()
        side = tk.Frame(self, bg=BLUE, width=235)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        tk.Label(side, text="◆  SUPORTE SENADO", bg=BLUE, fg=WHITE,
                 font=("Segoe UI", 14, "bold"), padx=22, pady=30).pack(anchor="w")
        for index, label in enumerate(("Informações", "Suporte remoto", "Impressoras")):
            tk.Label(side, text=label, bg=BLUE2 if index == 0 else BLUE,
                     fg=WHITE if index == 0 else "#D5E2ED", anchor="w",
                     font=("Segoe UI", 10, "bold" if index == 0 else "normal"),
                     padx=25, pady=14).pack(fill="x")
        tk.Frame(side, bg=GREEN, height=2).pack(fill="x", padx=22, pady=(14, 10))
        shortcuts = tk.Frame(side, bg=BLUE)
        shortcuts.pack(fill="x", padx=22)
        shortcut_items = (
            ("↗", "SCCM", lambda: self.quick_action("cmrc")),
            (">_", "CMD", lambda: subprocess.Popen(["cmd.exe"])),
            ("♙", "Usuário no AD", lambda: self.quick_action("ad_user_info")),
            ("⌁", "Internet e certificados", lambda: self.quick_action("inetcpl")),
            ("◫", "Discos e perfis", lambda: self.quick_action("disk_profiles")),
            ("♟", "Usuários e grupos locais", lambda: self.quick_action("local_users")),
        )
        for index, (glyph, tooltip, command) in enumerate(shortcut_items):
            button = tk.Button(shortcuts, text=glyph, command=command, bg=BLUE2, fg=WHITE,
                               activebackground=GREEN, activeforeground=WHITE, relief="flat",
                               cursor="hand2", font=("Segoe UI", 11, "bold"), width=4, height=1)
            button.grid(row=index // 3, column=index % 3, padx=3, pady=3, sticky="nsew")
            shortcuts.grid_columnconfigure(index % 3, weight=1)
        tk.Button(side, text="⌘  Legada", command=self.legacy, bg=BLUE, fg=WHITE,
                  activebackground=BLUE2, relief="flat", anchor="w", padx=25, pady=13).pack(side="bottom", fill="x")
        tk.Button(side, text="Sair do INS", command=self.return_standard, bg=BLUE, fg=WHITE,
                  activebackground=BLUE2, relief="flat", anchor="w", padx=25, pady=13).pack(side="bottom", fill="x")

        body = tk.Frame(self, bg=BG)
        body.pack(side="left", expand=True, fill="both")
        header = tk.Frame(body, bg=BG)
        header.pack(fill="x", padx=32, pady=(25, 8))
        tk.Label(header, text=f"Olá, {getpass.getuser()}", bg=BG, fg=BLUE,
                 font=("Segoe UI", 24, "bold")).pack(side="left")
        badge = tk.Label(header, text="SESSÃO INS" if self.profile == "ins" else "SESSÃO PADRÃO",
                         bg="#FFF2C2" if self.profile == "ins" else "#DFF3E8",
                         fg="#725800" if self.profile == "ins" else GREEN,
                         font=("Segoe UI", 9, "bold"), padx=14, pady=7)
        badge.pack(side="right")
        tk.Label(body, text="Central de operações técnicas  •  Senado Federal", bg=BG,
                 fg=MUTED, font=("Segoe UI", 10)).pack(anchor="w", padx=33)

        connect = tk.Frame(body, bg=WHITE, highlightbackground="#DDE5EC", highlightthickness=1)
        connect.pack(fill="x", padx=32, pady=18)
        tk.Label(connect, text="●  ESTAÇÃO REMOTA", bg=WHITE, fg=GREEN,
                 font=("Segoe UI", 10, "bold"), padx=18).pack(side="left")
        self.target_entry = tk.Entry(connect, font=("Segoe UI", 11), relief="solid", bd=1)
        self.target_entry.pack(side="left", expand=True, fill="x", padx=12, pady=16, ipady=8)
        self.target_entry.bind("<Return>", lambda _e: self.connect())
        self.button(connect, "Conectar", self.connect).pack(side="left", padx=(0, 16))

        tk.Label(body, text="Ações rápidas", bg=BG, fg=BLUE,
                 font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=33, pady=(0, 8))
        cards = tk.Frame(body, bg=BG)
        cards.pack(fill="x", padx=27)
        visible = ACTIONS if self.profile == "ins" else [a for a in ACTIONS if not a[3]]
        for i, action in enumerate(visible):
            card = tk.Frame(cards, bg=WHITE, highlightbackground="#DDE5EC", highlightthickness=1)
            card.grid(row=i // 3, column=i % 3, sticky="nsew", padx=6, pady=6)
            cards.grid_columnconfigure(i % 3, weight=1, uniform="cards")
            tk.Label(card, text=action[0], bg=WHITE, fg=BLUE,
                     font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=16, pady=(14, 3))
            tk.Label(card, text=action[1], bg=WHITE, fg=MUTED,
                     font=("Segoe UI", 8), wraplength=230).pack(anchor="w", padx=16)
            tk.Button(card, text="Executar  ›", command=lambda a=action: self.action(a),
                      bg=WHITE, fg=GREEN, activebackground=WHITE, relief="flat",
                      font=("Segoe UI", 9, "bold"), cursor="hand2").pack(anchor="e", padx=12, pady=10)

        tk.Label(body, text="Console de atividades", bg=BG, fg=BLUE,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=33, pady=(13, 5))
        self.log = scrolledtext.ScrolledText(body, height=8, bg="#071B2D", fg="#CDE6D8",
                                             insertbackground=WHITE, relief="flat",
                                             font=("Consolas", 9), padx=12, pady=10)
        self.log.pack(expand=True, fill="both", padx=32, pady=(0, 25))
        self.write("Sistema pronto. Conecte uma estação para iniciar.\n")

    def write(self, text):
        self.log.insert("end", text)
        self.log.see("end")

    def connect(self):
        target = self.target_entry.get().strip().replace("\\", "")
        if not target:
            messagebox.showinfo("Estação remota", "Informe o nome ou IP do computador.")
            return
        self.target = target
        self.execute("status", target, f"Consultando {target}")

    def action(self, action):
        title, _subtitle, command, needs_admin, destructive = action
        if needs_admin and self.profile != "ins":
            messagebox.showwarning("Sessão INS", "Esta função exige uma sessão INS.")
            return
        if command not in ("ad", "inetcpl") and not self.target:
            messagebox.showinfo("Estação remota", "Conecte uma estação primeiro.")
            return
        if destructive and not messagebox.askyesno("Confirmar ação", f"Executar “{title}” em {self.target}?"):
            return
        self.execute(command, self.target, title)

    def quick_action(self, command):
        if not self.target:
            messagebox.showinfo("Estação remota", "Conecte uma estação primeiro.")
            return
        self.execute(command, self.target, command.replace("_", " ").title())

    def execute(self, command, target, title):
        self.write(f"\n[AÇÃO] {title}\n")
        script = ROOT / "scripts" / "bridge.ps1"
        launcher = ROOT / "scripts" / "bridge_launcher.ps1"
        def worker():
            try:
                result = subprocess.run(
                    ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
                     "-File", str(launcher), "-Script", str(script),
                     "-Action", command, "-Computer", target],
                    text=True, capture_output=True, encoding="utf-8", errors="replace"
                )
                self.events.put((result.stdout + result.stderr, result.returncode))
            except Exception as exc:
                self.events.put((str(exc), 1))
        threading.Thread(target=worker, daemon=True).start()

    def poll_events(self):
        try:
            while True:
                text, code = self.events.get_nowait()
                if hasattr(self, "log") and self.log.winfo_exists():
                    self.write(text + ("\n[CONCLUÍDO]\n" if code == 0 else "\n[ERRO]\n"))
        except queue.Empty:
            pass
        self.after(100, self.poll_events)

    def legacy(self):
        subprocess.Popen(["cmd.exe", "/c", "start", "", str(ROOT / "scripts" / "legacy_tool.bat")])

    def return_standard(self):
        user = getpass.getuser().removesuffix("_ins")
        account = f"{os.environ.get('USERDOMAIN', 'SENADO')}\\{user}"
        command = f'cmd.exe /c "\"{sys.executable}\" \"{Path(__file__).resolve()}\" --standard"'
        try:
            subprocess.Popen(["runas", f"/user:{account}", command])
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Retorno ao usuário padrão", str(exc))


if __name__ == "__main__":
    App().mainloop()
