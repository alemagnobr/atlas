@echo off
setlocal
cd /d "%~dp0"
title Atlas - Criacao do instalador

echo ============================================================
echo ATLAS - GERACAO DO EXECUTAVEL E INSTALADOR v23.6
echo ============================================================
echo.

call build_exe.bat
if errorlevel 1 goto BUILD_ERROR

set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
where ISCC.exe >nul 2>&1 && set "ISCC=ISCC.exe"

if not defined ISCC (
  echo.
  echo [ERRO] Inno Setup 6 nao foi localizado.
  echo Instale-o pelo comando abaixo e execute este arquivo novamente:
  echo winget install --id JRSoftware.InnoSetup -e
  pause
  exit /b 2
)

"%ISCC%" "installer\Atlas_Setup.iss"
if errorlevel 1 goto INSTALLER_ERROR

if not exist "release\Atlas_Setup_v23.6.exe" goto INSTALLER_ERROR
echo.
echo ============================================================
echo [OK] INSTALADOR CRIADO COM SUCESSO
echo %CD%\release\Atlas_Setup_v23.6.exe
echo ============================================================
start "" explorer.exe "%CD%\release"
pause
exit /b 0

:BUILD_ERROR
echo.
echo [ERRO] Nao foi possivel gerar o executavel principal.
pause
exit /b 1

:INSTALLER_ERROR
echo.
echo [ERRO] O Inno Setup nao conseguiu gerar o instalador.
pause
exit /b 1
