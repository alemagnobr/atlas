@echo off
setlocal
cd /d "%~dp0"
title Diagnostico - Atlas Suporte Avancado 5.0
echo ============================================================
echo DIAGNOSTICO DO GERENCIADOR DE SUPORTE
echo ============================================================
echo.
echo Pasta: %CD%
echo Pasta local segura: %LOCALAPPDATA%\AtlasSuporteAvancado\v10.19
echo Windows: %OS%
echo Usuario: %USERDOMAIN%\%USERNAME%
echo.
echo Procurando Python...
where py 2>&1
where python 2>&1
echo.
py -3 --version 2>&1
python --version 2>&1
echo.
echo Testando permissao de leitura do codigo...
python -c "from pathlib import Path; p=Path(r'%CD%')/'main.py'; print('Leitura OK:', p, '-', len(p.read_bytes()), 'bytes')" 2>&1
echo.
echo Testando interface nativa...
py -3 -c "import tkinter; print('Tkinter OK - versao', tkinter.TkVersion)" 2>&1
echo.
echo Testando interface principal...
py -3 -c "import PySide6; print('PySide6 OK - versao', PySide6.__version__)" 2>&1
echo.
echo Se houver erro, envie uma foto desta tela.
pause
