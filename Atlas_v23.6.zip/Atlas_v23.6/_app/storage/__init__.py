"""Persistência local de cache e preferências."""

