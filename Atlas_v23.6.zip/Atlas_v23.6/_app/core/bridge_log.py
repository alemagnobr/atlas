"""Separa mensagens operacionais dos dados estruturados do PowerShell."""

from __future__ import annotations


def filter_bridge_log_chunk(chunk: str, pending: str = "", skipping: bool = False) -> tuple[str, str, bool]:
    """Retorna texto visível e estado para a próxima leitura de QProcess.

    Marcadores @@ carregam JSON e progresso em linhas que podem chegar em
    diversos blocos. Seu conteúdo permanece no buffer bruto do processo.
    """
    source = pending + chunk
    visible: list[str] = []
    while source:
        if skipping:
            boundary = source.find("\n")
            if boundary < 0:
                return "".join(visible), "", True
            source = source[boundary + 1:]
            skipping = False
            continue
        boundary = source.find("\n")
        if boundary >= 0:
            line, source = source[:boundary], source[boundary + 1:]
            if not line.lstrip().startswith("@@"):
                visible.append(line + "\n")
        elif source.lstrip().startswith("@@"):
            return "".join(visible), "", True
        else:
            return "".join(visible), source, False
    return "".join(visible), "", False
