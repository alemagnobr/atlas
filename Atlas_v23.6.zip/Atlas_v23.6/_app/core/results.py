from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class OperationResult:
    ok: bool
    message: str = ""
    data: object | None = None
