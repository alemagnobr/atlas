"""Estado e contratos centrais da aplicação."""

