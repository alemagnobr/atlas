# Aviso de uso

Este software foi desenvolvido para apoiar rotinas autorizadas de suporte técnico em ambiente corporativo Windows.

- Não há concessão automática de licença pública para uso, cópia ou redistribuição.
- Não publique credenciais, nomes de estações, endereços, logs, dados pessoais ou detalhes internos da infraestrutura.
- Utilize somente contas e permissões fornecidas oficialmente para o atendimento.
- Antes de tornar o repositório público, obtenha autorização formal e realize revisão de segurança.
- A identidade visual do software não substitui marcas, brasões ou elementos oficiais do Senado Federal.

Autores: Alexandre Linhares e João Cerqueira.
