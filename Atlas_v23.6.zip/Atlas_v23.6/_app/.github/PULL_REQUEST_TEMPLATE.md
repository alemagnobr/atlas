## Objetivo

Descreva o problema resolvido ou a melhoria adicionada.

## Alterações

-

## Validação

- [ ] `python -m py_compile main.py fallback.py`
- [ ] abertura pelo `run.bat`
- [ ] teste em estação de homologação
- [ ] interface normal e modo lateral
- [ ] ferramenta Legada preservada
- [ ] nenhuma credencial, log ou informação sensível incluída

## Risco e reversão

Explique os riscos da alteração e como retornar à versão anterior.
