---
name: Relato de problema
about: Registrar comportamento inesperado sem dados sensíveis
title: "[BUG] "
labels: bug
---

## Descrição

Explique o problema sem informar senha, IP, nome real de estação ou dados pessoais.

## Passos para reproduzir

1.
2.
3.

## Resultado esperado


## Resultado observado


## Ambiente

- Versão do Windows:
- Versão do Python:
- Versão do software:
- Perfil padrão ou INS:

## Logs sanitizados

Remova nomes, contas, estações, endereços e outros dados internos antes de anexar.
