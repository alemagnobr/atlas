# Atlas — Suporte Avançado

![Python](https://img.shields.io/badge/Python-3.11%2B-3776AB?logo=python&logoColor=white)
![PySide6](https://img.shields.io/badge/PySide6-6.7%2B-41CD52?logo=qt&logoColor=white)
![Windows](https://img.shields.io/badge/Windows-10%20%7C%2011-0078D4?logo=windows&logoColor=white)
![Versão](https://img.shields.io/badge/versão-23.6-00824A)

Na v23.6, o cadeado do cartão Admin local volta a aparecer com um pulso de cor verde ou vermelho. Na v23.5, a consulta da estação pode ser cancelada pelo X; o resumo da estação tem atualização própria, o ping segue disponível sem resposta e os cards Windows e Espaço Dados (D:) mostram ações remotas. Na v23.4, a janela de chamados recentes do usuário permite favoritar e monitorar diretamente os chamados exibidos, salvando somente os selecionados nas listas pessoais. O relógio em **Meus templates** abre o histórico local de HTMLs copiados hoje, e o grupo `WEB_Libera_Chat` no AD informa acesso ao WhatsApp Web. **Chamados** permite favoritar ou monitorar os registros já mapeados. As duas listas têm pesquisa local e conferência pontual de situação no Capri; a aba **Membro de** apresenta as licenças do AD em cartões com os respectivos recursos, incluindo `Lic-ADP1`. A base v22.4 preserva a pesquisa nas FAQs favoritas e o filtro de período local dos chamados.

Na captura de tela, o preview permite definir o nome do arquivo e mover o texto inserido com a ferramenta Selecionar antes de salvar. Na prévia das orientações das FAQs, o aviso sobre abertura do chamado pelo chefe do setor pode ser incluído ou retirado pelo operador.

Na barra lateral, **Meus templates** abre à direita os modelos de Fechamento, Escalonamento, Verificação Wi-Fi e Instalação padrão. O painel flutuante permanece aberto ao clicar fora dele; fechar ou pressionar Esc apenas oculta a janela, e ao reabrir o preenchimento continua no formulário. Os campos longos têm rolagem própria com aviso de continuação, enquanto os botões de ação ficam fixos. Preencha os campos, selecione as opções necessárias e clique em **Finalizar e copiar HTML**; depois cole o código-fonte no editor HTML do Capri. O ícone de salvar permite nomear e guardar o modelo já preenchido; em **Templates salvos**, a busca com lupa filtra os modelos pelo nome, o lápis edita o registro existente e um clique no nome utiliza o HTML novamente. Nos campos de texto, conteúdo colado de outros programas entra sem formatação rica. A lista de FAQs favoritas também permite copiar o número da FAQ e abrir suas orientações. Os modelos pessoais ficam no perfil Windows em `%LOCALAPPDATA%\AtlasSuporteAvancado\templates\saved_templates.json`, preservados entre versões. As FAQs favoritas ficam em `%LOCALAPPDATA%\AtlasSuporteAvancado\cache\faq_favorites.json`, separadas do catálogo atualizado do Capri. A assinatura é preenchida com nome completo e cargo encontrados no AD para o operador atual; se algum dado não estiver disponível, o modelo indica isso no texto antes da colagem. Os três recursos de imagem mantêm os links informados no modelo e exigem uma sessão Capri com acesso aos anexos.

Na sessão INS, o alerta ao lado do indicador de perfil consulta MD2020 (Marcos Ryan, líder), MD1608 (Márcia Yoshie, supervisão) e MD1824 (Alessandro Thadeu, supervisão). A bolinha verde exige que a conta logada no micro corresponda à pessoa indicada no AD e que ela esteja no horário informado. Para pular o líder disponível, marque que já conversou com ele e descreva o motivo específico. Se ele estiver indisponível, escolha uma pessoa disponível da supervisão. A mensagem remota informa “Analista [nome e sobrenome do AD] solicita apoio técnico.” A confirmação do ATLAS cobre apenas o despacho da tarefa; não comprova abertura nem leitura na estação.

Interface gráfica para centralizar rotinas de suporte técnico remoto em estações Windows. O aplicativo organiza consultas, ações administrativas, gerenciamento de impressoras, Active Directory, diagnóstico de discos e perfis em uma interface moderna inspirada na identidade visual do Senado Federal.

Na v14.55, os créditos de desenvolvimento aparecem logo abaixo da seta da barra lateral, com Alexandre Linhares e João Cerqueira em linhas separadas e seus respectivos links do LinkedIn.

![Demonstração visual do Atlas — Suporte Avançado](docs/demo-interface.svg)

> A demonstração acima usa informações fictícias e serve somente para apresentar a organização visual. Ela não representa uma estação, usuário ou infraestrutura real.

> Uso institucional: publique este projeto em um repositório **privado** e utilize-o somente em ambientes nos quais você possua autorização administrativa.

## Visão geral

O operador informa o nome ou IP de uma estação ou consulta diretamente um login de rede. A interface chama processos PowerShell isolados, que executam as ações selecionadas e devolvem os resultados para a aplicação. Operações destrutivas exigem confirmação. INS e Capri mantêm seus escopos independentes. A recuperação de senha é acionada somente pelo operador e utiliza o formulário público protegido do Gestor de Senhas.

### Navegadores e certificados — v3.39

Em **Suporte remoto**, a terceira categoria é **Navegadores e certificados**. Além de abrir a limpeza, o Atlas pode fechar completamente o Chrome ou o Edge na estação conectada, sempre após confirmação:

- **Abrir limpeza do Chrome:** abre `chrome://settings/clearBrowserData` no Chrome da sessão remota.
- **Abrir limpeza do Edge:** abre `edge://settings/clearBrowserData` no Edge da sessão remota.
- **Certificados digitais:** listagem e exclusão remotas existentes, apenas realocadas para esta categoria. A confirmação de exclusão de certificado continua obrigatória.

As opções executam uma tarefa interativa curta para localizar o navegador instalado e abrir sua página interna. Não utilizam `D$`, `ADMIN$`, pasta TEMP nem arquivos no computador remoto. Também não fecham o navegador nem apagam dados automaticamente. O operador ou usuário precisa selecionar o intervalo e os itens, conferir as escolhas e clicar em **Limpar agora**. A mensagem do aplicativo confirma o envio da solicitação, não a limpeza.

Requer WMI e Agendador de Tarefas remoto acessíveis às permissões INS já utilizadas. O navegador precisa estar instalado e a sessão do usuário precisa estar ativa. Políticas da organização podem restringir itens da página. A ferramenta não automatiza cliques na interface e não contorna essas políticas.

Principais recursos:

- **Controle de usuários** independente da estação, com consulta direta pelo login de rede ou sincronização automática a partir do micro conectado;
- painel operacional compacto com nova consulta, cópia do login, dados pessoais, telefones, observações, situação e vencimento da senha fornecidos diretamente pelo Active Directory;
- indicador pulsante de senha vigente ou expirada e contagem regressiva calculada a partir de `msDS-UserPasswordExpiryTimeComputed`;
- recuperação de senha por um ícone discreto ao lado do status, com destino mascarado, confirmação obrigatória, bloqueio de repetição e ausência de dados sensíveis nos logs;
- botão **PWM** no mesmo card para abrir o Gestor de Senhas no navegador configurado pelo Atlas;
- card de chamados recentes do usuário, com até 25 resultados temporários do Capri, popup com pesquisa e filtros locais e carregamento automático em segundo plano após consulta no AD ou pela estação;
- descrições dos grupos `Lic-` conhecidos na aba **Membro de** da consulta ao AD;
- solicitação de avaliação por mensagem na sessão remota, com links para Outlook Web e Desktop e fechamento após três minutos;
- assinatura visual do Atlas com raio vetorial temático, revelação descendente e pausas irregulares de baixo consumo;
- cards de ação compactos e responsivos, com ícone, título, descrição e acesso alinhados sem espaços vazios excessivos;
- identidade visual simplificada, com título único “Atlas — Suporte Avançado” e marca lateral “ATLAS” alinhada à logo;
- autenticação administrativa INS com retorno seguro ao perfil padrão;
- consulta consolidada da estação, usuário, Windows, BIOS, SCCM e impressoras, com **Online** em verde ou **Offline** em vermelho para cada impressora de rede;
- Controle Remoto SCCM e Prompt de Comando por atalhos;
- ping, encerramento do Outlook, limpeza de DNS, GPUpdate, logoff e reinicialização;
- administração local, Active Directory, usuários e grupos locais;
- instalação, remoção, teste, definição padrão e limpeza de fila de impressoras;
- popup de progresso para instalar, definir padrão ou solicitar página de teste, com atualização dos dois resumos de impressoras antes de fechar; o envio da página não confirma a impressão física;
- painel de impressoras com atalhos compactos para atualizar, pingar, abrir a interface web, imprimir página de teste, alternar Admin local e efetuar logoff com confirmação;
- retorno visual no próprio ícone de atualização, que gira somente enquanto a consulta correspondente estiver ativa;
- troca de tema autenticada em crossfade, com movimento imediato do seletor e recoloração incremental dos ícones;
- catálogo dos executáveis autorizados do drive `X:`, organizado automaticamente por categoria;
- pesquisa de FAQs com alternância visível entre resultados relacionados e frase contínua somente no título;
- modo escuro com hover coerente, ícones de alto contraste e autenticação do Capri totalmente tematizada;
- geometria original da v9.3 preservada na renderização de todos os chamados;
- redesenho automático do filtro **Todos** após a montagem do catálogo completo, sem exigir alternância manual de tema;
- aviso compacto e padronizado quando outra operação é solicitada durante um processamento;
- pesquisa de FAQs com contraste reforçado no modo escuro e seletor com animação durante a troca de tema;
- entrada em Chamados com barra de andamento, filtro **Pendentes** como padrão e redesenho seguro também para **Todos** e **Fechados com êxito**;
- atualização de Chamados com percentual baseado nas fases reais entregues pelo Capri, sem indicar 100% antes da conclusão;
- faixa de carregamento posicionada fora do painel de filtros, sem comprimir campos e botões;
- pesquisa textual em todos os chamados do cache local somente ao clicar em **Pesquisar** ou pressionar Enter, com barra de andamento;
- comandos independentes em Chamados: **Pesquisar** para o texto e **Filtrar** para a situação selecionada;
- botão **Atualizar** de Chamados restrito a ontem e hoje, preservando os demais períodos já mapeados;
- validação visual ao vivo do código da impressora: verde pulsante quando autorizado no AD e vermelho pulsante quando não localizado nos grupos do usuário;
- discos locais e drives de rede por `Win32_LogicalDisk`, `Win32_MappedLogicalDisk`, `HKU\SID\Network` e consulta na sessão interativa com `WScript.Network`/`Get-PSDrive`;
- cálculo individual do espaço ocupado por cada perfil de usuário;
- modo lateral, popups modernos e terminal integrado;
- modo lateral em duas colunas, encaixado do topo ao rodapé e com alternância automática entre monitores disponíveis;
- largura lateral padronizada em 740 px tanto na tela de login quanto na sessão INS;
- resumo compacto da estação no modo lateral, com dados curtos em duas colunas e listas extensas em largura total;
- saudação personalizada com primeiro e último nome consultados no AD e cabeçalho organizado para micro e usuário remoto;
- comunicação UTF-8 protegida para nomes acentuados, usuário remoto exibido apenas pelo nome e transições suaves entre páginas e painéis;
- ícone animado de computador para a estação conectada, conta de rede no cartão Usuário e compactação automática em janelas estreitas;
- pulsação independente do ícone do computador em verde forte, sem conflito com a transição do painel;
- terminal de inicialização forçado para minimizado e resumo compacto automático ao encaixar a janela com Windows + seta;
- resumo compacto definido somente pela largura, incluindo encaixe em meia tela ou dois terços, com tipografia ampliada para leitura confortável;
- controle lateral animado também na tela inicial, encaixe vertical completo, nova identidade visual do escudo e avisos informativos compactos;
- controle lateral menor abaixo de Sair, alternando sempre para o canto direito de cada monitor disponível;
- menu **Configurações** para escolher entre o navegador padrão do Windows, Google Chrome ou Microsoft Edge ao abrir links;
- manutenção estrutural periódica com limpeza restrita a resíduos regeneráveis e proteção explícita dos dados funcionais;
- abertura de links comuns encaminhada à sessão padrão que iniciou o INS; a consulta de usuários não inicia navegador nem sessão do PWM;
- seleção explícita da impressora antes de executar o ping ou abrir sua interface web, com a impressora padrão pré-selecionada;
- retorno da atualização rápida de Chamados organizado em uma lista contendo somente número e título;
- acesso preservado à ferramenta original pelo botão **Legada**.

## Como surgiu o projeto

O projeto nasceu da rotina prática de suporte técnico: várias tarefas eram executadas em ferramentas, consoles e comandos separados, o que aumentava o tempo de atendimento e dificultava a leitura rápida do estado de uma estação.

Alexandre Linhares (**[@alemagnobr](https://github.com/alemagnobr)**) e João Cerqueira (**[@joaocerq-me](https://github.com/joaocerq-me)**) reuniram essa experiência em uma ferramenta única. A primeira versão funcionava em prompt e priorizava a execução confiável dos procedimentos. A interface em Python foi criada depois para preservar essas rotinas e torná-las mais claras, seguras e organizadas.

Hoje, o Atlas — Suporte Avançado funciona como um painel operacional: o técnico seleciona a estação, consulta as informações essenciais e executa procedimentos autorizados sem precisar decorar comandos ou alternar continuamente entre diversas janelas.

## Demonstração

A demonstração incluída neste repositório é deliberadamente visual e utiliza dados fictícios. Para testar as funções reais, é necessário executar o projeto em Windows, possuir acesso autorizado ao ambiente e atender aos requisitos descritos em [Instalação e ambiente](docs/INSTALACAO.md).

O fluxo normal é simples:

1. o técnico autentica o perfil INS;
2. informa o nome ou IP da estação;
3. o painel consulta e organiza as informações disponíveis;
4. o técnico escolhe uma ação ou atalho;
5. a ferramenta executa o procedimento e apresenta o resultado.

## Início rápido

### Pré-requisitos

- Windows 10 ou Windows 11;
- Python 3.11 ou superior instalado com **Add Python to PATH**;
- acesso autorizado à rede e às estações atendidas;
- permissões compatíveis com WMI, compartilhamentos administrativos e tarefas agendadas;
- Console do MECM ou `CmRcViewer.exe` para controle remoto.

### Execução

1. Extraia completamente o projeto.
2. Abra a pasta `Atlas_v23.6`.
3. Execute **Atlas.exe**, identificado pelo escudo do aplicativo.
4. Na tela inicial, selecione **Autenticar como INS**.
5. Informe o nome ou IP da estação e clique em **Conectar**.

O lançador portátil possui a logo incorporada e encaminha a execução para `_app\run.bat`. Não execute `main.py` diretamente no ambiente institucional. O inicializador interno copia a aplicação para `%LOCALAPPDATA%\AtlasSuporteAvancado\v23.6`, instala a dependência gráfica quando necessário e evita bloqueios comuns de Downloads e OneDrive.

### Criar o instalador do Windows

Em um computador Windows com Python 3.11 ou superior, execute `CRIAR_INSTALADOR.bat`. O processo gera o aplicativo independente com PyInstaller e depois cria `release\Atlas_Setup_v23.6.exe` com Inno Setup 6. O computador que receber o instalador não precisa ter Python nem PySide6.

O instalador é feito por usuário, cria um atalho no Menu Iniciar, oferece atalho opcional na Área de Trabalho e inclui desinstalação pelo painel de Aplicativos do Windows.

### Aviso do SmartScreen no lançador portátil

O aviso **"Fornecedor desconhecido"** é emitido pelo Windows antes de o Atlas.exe iniciar. Nenhuma opção do aplicativo pode escolher automaticamente **"Executar assim mesmo"**. Para distribuir com um editor identificado, assine digitalmente o `Atlas.exe`, o `dist\AtlasSuporteAvancado.exe` e o instalador após gerá-los, usando um certificado de assinatura de código válido e o SignTool do Windows SDK. A assinatura precisa ser aplicada **depois** da criação de cada executável. Um arquivo recém-assinado ainda pode receber o aviso até estabelecer reputação no SmartScreen. Não desative o SmartScreen das estações para instalar o Atlas. Referência: https://learn.microsoft.com/pt-br/windows/apps/package-and-deploy/smartscreen-reputation

## Como o software funciona

1. `run.bat` prepara uma cópia local confiável e inicia a interface.
2. `main.py` apresenta login, painel, ações, animações e resultados.
3. A interface chama `scripts/bridge_launcher.ps1` sem abrir uma janela adicional.
4. O launcher carrega `scripts/bridge.ps1` em UTF-8.
5. O bridge executa a rotina remota e envia texto ou JSON estruturado à interface.
6. A interface registra a execução no console e apresenta o resultado em popup quando aplicável.

Para discos e perfis, a fonte principal executa temporariamente como `SYSTEM`, enumera as sessões WTS existentes e assume o token real do logon antes de consultar `WNetGetConnection`. O coletor é enviado por uma chave temporária do registro e pode ser iniciado por serviço temporário ou pelo Agendador, sem depender de arquivo XML. A coleta devolve letra, UNC, nome, total, espaço livre e sistema de arquivos. `Explorer\MountPoints2`, `Shell.Application`, `WScript.Network`, `net use`, `Get-PSDrive`, WinRM, registro e WMI permanecem como fontes complementares. Compartilhamentos corporativos reconhecidos podem ser reconciliados com as letras R:, U:, V:, W: e X: quando a sessão administrativa não devolve a letra. Todo dado e lançador temporário são removidos ao final.

## Referência completa dos botões e funções

### Tela inicial

| Botão/campo | Para que serve | Como funciona |
| --- | --- | --- |
| **Autenticar como INS** | Entrar no perfil administrativo | Usa a identidade INS configurada. Se necessário, solicita a senha e a guarda no Gerenciador de Credenciais do Windows. Abre a interface administrativa sem gravar a senha no projeto. |
| **Redefinir acessos salvos** | Apagar credenciais armazenadas | Remove do cofre do Windows os acessos salvos pela ferramenta. Use depois de trocar a senha ou quando a autenticação falhar. |
| **Sair do software** | Encerrar o aplicativo | Fecha a tela inicial sem iniciar uma sessão. |
| **Seta animada no canto inferior esquerdo** | Levar a tela inicial ao próximo monitor | A seta usa o mesmo azul institucional principal da logo (`#00305C`), aparece acima dos créditos, indica a direção do próximo monitor, desloca-se e desaparece suavemente. Cada clique encaixa a janela, em altura total, no lado direito da próxima tela disponível. |

### Conexão e painel da estação

| Botão/campo | Para que serve | Como funciona |
| --- | --- | --- |
| **Nome ou IP do computador** | Definir a estação atendida | Aceita hostname ou endereço IP. O valor é utilizado pelas consultas WMI, PowerShell e ferramentas remotas. |
| **Conectar** | Consultar e selecionar a estação | Executa a ação `status`, testa a estação e preenche o painel com Windows, usuário, administração local, RDP, tempo ligado, BIOS, SCCM e impressoras. |
| **Desconectar** | Encerrar o atendimento atual no painel | Limpa a estação selecionada e desabilita os comandos que dependem de conexão. Não desliga nem desconecta o usuário do Windows. |
| **Atualizar** — ícone circular | Reconsultar o painel | Repete a consulta de status. O ícone anima enquanto a atualização está sendo executada. |
| **Copiar estação** — ícone de cópia | Copiar hostname/IP | Coloca o endereço da estação na área de transferência para uso em outras ferramentas. |
| **Cadeado de Admin local** | Adicionar ou remover o usuário conectado dos Administradores locais | Cadeado aberto/vermelho adiciona; fechado/verde remove. Se o estado for desconhecido, o clique atualiza a informação. Toda alteração pede confirmação e depois reconsulta o painel. |
| **Pingar impressora** | Testar conectividade da impressora | Usa a impressora padrão/instalada ou solicita uma escolha. Executa quatro respostas de ping e mostra a média. |
| **Abrir interface web da impressora** | Consultar o painel HTTP da impressora | Abre `http://NOME-DA-IMPRESSORA/` no navegador padrão. |

### Atalhos rápidos da barra lateral

| Ícone/atalho | Para que serve | Comportamento |
| --- | --- | --- |
| **Controle Remoto SCCM** | Iniciar atendimento visual remoto | Localiza `CmRcViewer.exe` e abre o visualizador apontando para a estação conectada. Não exibe popup de sucesso. |
| **Prompt de Comando** | Abrir um CMD livre para comandos manuais | Abre `cmd.exe` localmente em uma janela separada. Não executa comandos automaticamente e não exibe popup de sucesso. |
| **Informações do usuário no AD** | Consultar a conta conectada | Busca Organização, Conta, Perfil e Membro de. O botão inferior copia somente a aba selecionada e o pequeno ícone de cada cartão copia apenas aquele valor. |
| **Internet e certificados** | Abrir opções de Internet/certificados | Tenta abrir `inetcpl.cpl` na sessão remota; se não for possível, abre o console de certificados remoto como alternativa. Não exibe popup de sucesso. |
| **Discos e perfis** | Diagnosticar armazenamento | Lista discos locais, virtuais e drives mapeados, além do consumo dos perfis. O software confere o usuário informado pelo Windows e os proprietários reais do `explorer.exe`. Somente resultados com drives de rede confirmados ficam em cache, por 30 segundos; **Shift+clique** força nova consulta. |
| **Usuários e grupos locais** | Administrar contas locais | Abre `lusrmgr.msc` conectado ao computador remoto. |

Ao clicar em qualquer atalho, o ícone é substituído temporariamente por um indicador circular animado. Ele permanece visível até a conclusão da solicitação e respeita um tempo mínimo nos comandos rápidos, oferecendo o mesmo retorno visual nas operações curtas e nas consultas mais demoradas, como **Discos e perfis**.

### Navegação lateral

Na aba **Suporte remoto**, cada card de ação apresenta uma porcentagem enquanto aguarda a estação. O avanço durante a espera é visual e fica abaixo de 100%. Fechar Outlook e os navegadores chega a 100% somente quando a consulta remota confirma o encerramento; tarefas agendadas ou disparadas via WMI mostram que o comando foi enviado, sem afirmar que o processo terminou. No controle de usuários, **Nome completo** e **Empresa** copiam “Título: valor” ao clicar; o botão de login continua copiando somente o login.

| Botão | Para que serve |
| --- | --- |
| **Informações** | Volta ao painel principal, resumo da estação e ações mais usadas no perfil atual. |
| **Suporte remoto** | Exibe **Ping**, **Logoff** e **Reiniciar** juntos em Conexão e controle, além das rotinas de manutenção do computador remoto. |
| **Impressoras** | Exibe instalação, drivers, teste, padrão e spooler. |
| **Softwares autorizados** | É habilitado somente quando o usuário da estação conectada possui acesso ao drive `X:`. Exibe os executáveis permitidos em cartões organizados por finalidade. |
| **FAQs** | Exibe o catálogo salvo do Capri, organizado por categoria, ferramenta e procedimento, e abre o artigo selecionado no navegador corporativo. |
| **Orientações ao usuário** | Pesquisa procedimentos resumidos extraídos das FAQs e exibe uma orientação personalizada na sessão da estação conectada. |
| **Chamados** | Indexa sob comando os chamados do operador ou do usuário atendido, pesquisa o cache local quando solicitado e atualiza rapidamente somente ontem e hoje. |
| **Seta animada acima de Legada** | Usa o mesmo controle minimalista da tela inicial. Cada clique leva a aplicação ao lado direito do próximo monitor, em altura total, e reorganiza os cartões de forma compacta. |
| **Legada** | Abre a ferramenta original em prompt, preservada para compatibilidade e comparação. |
| **Sair do INS** | Encerra o contexto administrativo e retorna à tela inicial/perfil padrão. |
| **Voltar ao perfil padrão** | Ação equivalente de sessão que encerra a interface INS com segurança. |
| **Voltar ao menu principal** | Retorna da categoria atual para a página Informações sem desconectar a estação. |
| **Fechar o gerenciador** | Encerra completamente a aplicação. |

Ao alternar entre **Informações**, **Suporte remoto**, **Impressoras**, **Softwares autorizados**, **FAQs** e **Orientações ao usuário**, o destaque anterior desvanece enquanto o novo campo surge suavemente, tornando a mudança de página mais natural sem atrasar os comandos.

No modo lateral, os cartões de ações continuam em duas colunas, mas adotam um desenho interno compacto: ícone, título e seta ficam no cabeçalho, enquanto a descrição ocupa toda a largura inferior. Ao retornar para uma janela ampla, o arranjo horizontal original é restaurado automaticamente.

### Ações de suporte e diretório

| Ação | Para que serve | Execução e resultado |
| --- | --- | --- |
| **Controle remoto SCCM** | Visualizar/controlar a estação | Abre o CmRcViewer com o hostname selecionado. Requer o console MECM ou o executável na pasta do projeto. |
| **Ping contínuo** | Monitorar estabilidade da conexão | Abre uma janela separada executando ping contínuo até o operador interromper. |
| **Administrador local** | Alternar privilégio do usuário remoto | Adiciona ou remove a conta conectada do grupo Administradores locais. O cadeado do painel oferece a mesma função com indicação visual. |
| **Usuários e grupos locais** | Gerenciar contas locais | Abre o snap-in do Windows para a estação remota. |
| **Active Directory** | Abrir Usuários e Computadores do AD | Inicia `dsa.msc` no computador do operador. Não depende de uma estação conectada. |
| **Grupos do usuário no AD** | Conferir permissões por grupos | Identifica a conta conectada e lista suas associações no Active Directory em popup copiável. |
| **Disco e perfis** | Conferir discos, mapeamentos e perfis | Combina WMI e registro para listar unidades. Mede cada perfil por FSO, Robocopy ou varredura; quando necessário, calcula diretamente na estação via WMI. |
| **Internet e certificados** | Abrir configurações relacionadas | Executa a abertura na sessão remota e usa o console de certificados como alternativa. |
| **Logoff remoto** | Encerrar a sessão do usuário | Fica no grupo **Conexão e controle**, executa logoff da sessão ativa e pede confirmação porque pode fechar aplicativos sem salvamento. |
| **Reiniciar computador** | Reiniciar a estação | Fica no grupo **Conexão e controle**, agenda a reinicialização em aproximadamente 15 segundos e sempre pede confirmação. |

### Ações de suporte remoto

A ação **Configuração Trellix** confirma o disparo da tarefa remota e libera a interface em poucos segundos. As etapas `/p`, `/c` e `/e` continuam na estação em segundo plano, cada uma protegida por limite de execução para evitar processos presos.

Em **Suporte ao computador**, a opção **Certificados digitais** lista somente os certificados existentes na estação remota, separando `CurrentUser\My` e `LocalMachine\My`. A coleta prioriza a sessão interativa do usuário e usa WMI, Registro Remoto e WinRM como alternativas. A exclusão exige seleção e confirmação antes de executar a rotina remota validada.

| Ação | Para que serve | Cuidados e retorno |
| --- | --- | --- |
| **Fechar Outlook** | Finalizar Outlook travado | Encerra `outlook.exe` e `olk.exe` na estação. Pede confirmação porque pode interromper trabalho não salvo. |
| **Limpar cache DNS** | Corrigir resolução de nomes | Executa `ipconfig /flushdns` na estação. O cartão exibe animação durante o processo e o popup informa o resultado. |
| **Atualizar políticas** | Aplicar políticas de domínio | Executa `gpupdate /force`. Pode abrir uma janela temporária na sessão remota e mostra resultado ao concluir. |
| **Configuração Trellix** | Sincronizar o agente de segurança | Localiza o agente e executa `cmdagent.exe /p`, `/c` e `/e` dentro da sessão interativa do usuário conectado à estação remota. Cada etapa tem limite de 60 segundos. O resultado é devolvido por um arquivo temporário no próprio perfil remoto, evitando dependência do Registro Remoto; o sucesso só é informado quando os três códigos de saída forem zero. |
| **Limpar pasta TEMP** | Remover temporários do usuário | Cria uma tarefa na sessão interativa, remove arquivos não utilizados e preserva itens bloqueados/em uso. Pede confirmação. |

### Ações de impressoras

| Ação | Para que serve | Como funciona |
| --- | --- | --- |
| **Instalar impressora** | Instalar uma fila autorizada | Carrega os grupos de impressão do AD, permite selecionar/digitar a impressora e executa a instalação na sessão do usuário. |
| **Excluir impressora** | Remover uma fila instalada | Seleciona uma impressora detectada, pede confirmação, remove a conexão do usuário e trata a conexão global quando existir; ao concluir, atualiza os dois resumos. |
| **Remover driver HP** | Remover pacote HP problemático | Inicia o assistente Prodasen de remoção de driver na estação. |
| **Instalar driver HP** | Instalar pacote HP homologado | Inicia o assistente Prodasen de instalação na estação. |
| **Imprimir página de teste** | Validar fila e comunicação | Permite selecionar uma impressora instalada e envia uma página de teste. |
| **Definir impressora padrão** | Alterar a impressora padrão do usuário | Apresenta as impressoras instaladas e aplica a escolhida na sessão interativa. |
| **Limpar fila de impressão** | Resolver documentos presos | Para o Spooler, remove itens da fila e inicia o serviço novamente. Pede confirmação. |

### Diagnóstico remoto do usuário

Em **Suporte remoto**, **Processos do usuário** lista nome, PID e memória dos processos pertencentes à sessão interativa conectada. O encerramento exige seleção e confirmação e confere novamente PID, nome e proprietário antes de executar. **Programas do usuário** consulta as entradas de desinstalação do perfil carregado e das instalações da estação, identificadas separadamente. Aplicativos portáteis ou sem registro de instalação não podem ser enumerados por esse método. Essas consultas são transitórias e exigem WMI e Registro Remoto acessíveis na estação.

As orientações e avaliações abrem uma janela gráfica na sessão do usuário. A tarefa visual permanece em execução enquanto a janela estiver aberta; orientações têm limite de dez minutos e avaliações de três minutos, além do botão Fechar.

### Softwares autorizados

A área **Softwares autorizados** consulta o mapeamento `X:` pertencente ao usuário conectado na estação. Quando o acesso é confirmado, os arquivos `.exe` encontrados são organizados em categorias como Navegadores e Internet, Comunicação, Produtividade, Segurança, Suporte remoto, Desenvolvimento, Utilitários, Drivers e Sistemas corporativos. As categorias aparecem recolhidas e podem ser clicadas para abrir ou fechar sua árvore de executáveis.

No resumo da estação, o quadro **Usuário** apresenta o nome completo confirmado pelo AD em destaque e mantém a conta de rede logo abaixo no padrão `SENADO\\login`. Os ícones dos executáveis usam uma área segura própria para permanecerem íntegros em diferentes escalas do Windows.

O campo de pesquisa filtra o catálogo enquanto o técnico digita. As sugestões aparecem em uma lista compacta abaixo do campo, sem substituir ou cobrir o texto digitado, e destacam em verde as letras correspondentes. A busca também considera nome do executável, pasta, caminho e categoria, sem diferenciar maiúsculas, minúsculas ou acentos. Durante a pesquisa, somente as categorias e os programas correspondentes são expandidos.

Cada cartão e cada sugestão apresentam exatamente o nome do arquivo existente no drive `X:`, incluindo extensão `.exe`, versão, hífens, espaços e sublinhados. A descrição interna do executável nunca substitui esse nome; ela é usada somente como apoio invisível para definir a categoria. A pasta de origem diferencia arquivos com nomes semelhantes. Antes da execução, a ferramenta solicita confirmação e valida que o caminho pertence ao drive `X:`.

Os arquivos `Driver Impressoras HP (Prodasen).exe` e `Remove Driver Impressoras HP (Prodasen).exe` não aparecem nesse catálogo, pois permanecem nos comandos específicos da área **Impressoras**. A coleta tenta primeiro o compartilhamento associado ao drive e, se necessário, executa a descoberta dentro da própria sessão remota.

### FAQs do Capri

A área **FAQs** mantém todos os títulos e links oficiais do Capri, mas apresenta o catálogo em uma árvore temática mais útil ao suporte: **Microsoft 365**, **Windows**, **Impressoras**, **Equipamentos**, **Sistemas corporativos**, **Navegadores e internet**, **Segurança e acesso remoto** e categorias adicionais identificadas. Os títulos principais também são recolhíveis: um clique em **Microsoft 365**, por exemplo, abre ou fecha todo o bloco. Dentro deles, as FAQs são separadas por ferramenta e procedimento, como `Microsoft 365 › Outlook › Correção de problemas`.

A interface separa os dois fluxos: o cartão azul **Pesquisar FAQs** filtra somente o catálogo local, enquanto a área amarela **Atualizar a base** reúne autenticação do Capri, remapeamento completo e atualização de uma FAQ específica. Pesquisar nunca acessa o Capri nem altera o catálogo.

A coleta percorre todas as páginas e remove duplicidades pelo identificador oficial da FAQ. URLs de ordenação e navegação são consolidadas para não criar ciclos. O total informado na página inicial do Capri é usado como conferência: a interface mostra quantas FAQs foram coletadas em relação ao total anunciado, evitando que uma leitura parcial pareça completa.

O campo de pesquisa acompanha a digitação e procura em título, categoria temática, ferramenta, procedimento, caminho original e número da FAQ. Um pequeno intervalo de 170 ms evita reconstruir centenas de cartões a cada tecla, deixando a digitação mais fluida. As sugestões preservam o texto digitado e destacam o trecho encontrado.

O coletor prioriza o título visível da linha do artigo no Capri. Quando a listagem retorna somente um identificador, como `10002281`, ele abre especificamente aquela página e extrai o cabeçalho oficial. O cartão combina os dois dados no padrão **FAQ 10002281 — Google Chrome – Limpeza de Cache e Cookies do Navegador**, preservando simultaneamente o número e o título original do Capri.

O mapeamento completo é iniciado somente por **Remapear todas as FAQs**. Depois de concluído, o catálogo é salvo no perfil local do Windows e passa a abrir instantaneamente nas próximas execuções, sem consultar novamente centenas de páginas. Um novo mapeamento substitui o catálogo somente após terminar com sucesso; falhas não apagam a cópia anterior. **Acesso ao Capri** permite atualizar a conta protegida pelo Gerenciador de Credenciais do Windows. Ao clicar em uma FAQ, o artigo oficial é aberto no navegador padrão.

Cada artigo possui ações compactas para copiar seu número completo e abrir o conteúdo oficial no Capri.

### Orientações ao usuário

A área **Orientações ao usuário** utiliza um catálogo local produzido a partir das 697 FAQs fornecidas. Artigos com caminho iniciado por `Intranet > Central de Serviços` ou indicação objetiva de telefone, ramal e setor responsável são transformados em orientações acionáveis. Foram estruturadas 126 orientações; 32 apresentam contatos e 23 existem exclusivamente para encaminhamento ao setor responsável.

A interface separa os dois fluxos: o cartão azul **Pesquisar orientações** filtra somente o conteúdo já salvo, enquanto a área amarela **Atualizar a base** concentra o remapeamento completo e a atualização individual por número de FAQ. Pesquisar nunca consulta o Capri nem altera o catálogo.

A pesquisa aceita título, assunto, categoria, caminho e número completo da FAQ. Ao selecionar **Enviar orientação**, o Atlas identifica o primeiro e o último nome do usuário conectado no Active Directory e abre, na sessão remota, um popup moderno com saudação, resumo do procedimento, possível regra importante, caminho destacado e referência da FAQ. O sucesso somente é apresentado ao operador depois que a renderização do popup é confirmada.

O conteúdo obtido é salvo em um cache separado no perfil local. Na primeira extração, os artigos ainda não armazenados são consultados individualmente; nas próximas, o TXT é reconstruído diretamente a partir do cache e fica consideravelmente mais rápido. O extrator lê exclusivamente o conteúdo escrito na própria FAQ — campos de texto, orientações, listas e subtítulos — sem extrair anexos PDF. O cache antigo, que podia conter somente cabeçalhos ou falhas de anexos, é descartado automaticamente. Artigos que falharem ou retornarem texto insuficiente não são gravados como válidos e serão tentados novamente na extração seguinte. Como o material pode conter informações internas, o arquivo deve permanecer em local corporativo autorizado e não deve ser publicado em repositórios externos.

### Popups e controles de resultado

| Controle | Função |
| --- | --- |
| **Copiar resultado / Copiar tudo** | Copia o conteúdo apresentado para a área de transferência. |
| **Confirmar** | Autoriza uma ação destrutiva ou administrativa previamente descrita. |
| **Cancelar** | Fecha a confirmação sem executar a ação. |
| **Fechar** | Fecha apenas o popup; não desfaz uma ação já concluída. |
| **Abas Organização, Conta, Perfil e Membro de** | Separam as informações do usuário obtidas no Active Directory. |
| **Abas Discos e rede / Perfis** | Alternam entre unidades físicas/mapeadas e consumo das pastas de usuários. |
| **Limpar histórico** | Apaga somente o texto do Console de atividades da interface; não apaga logs do Windows nem desfaz comandos. |

### Indicadores e regras visuais

- ponto verde piscando: estação conectada ou estado administrativo confirmado;
- ponto vermelho: estação sem resposta ou usuário fora dos Administradores locais;
- spinner no cartão: ação ainda em execução;
- botão desabilitado: falta conexão, perfil INS ou existe outra operação em andamento;
- popup verde: ação concluída; popup vermelho: falha; confirmação compacta: ação com impacto;
- o Console de atividades registra início, saída e conclusão para facilitar diagnóstico.

## Estrutura do projeto

```text
Atlas_v23.6/
├── Atlas.exe                  # Lançador portátil com a logo incorporada
└── _app/                      # Código, recursos e documentação internos
    ├── main.py                # Interface principal PySide6
    ├── fallback.py            # Interface compatível sem PySide6
    ├── run.bat                # Inicializador técnico interno
    ├── requirements.txt       # Dependências Python
    ├── assets/                # Logo e ícones
    ├── scripts/               # Comandos e consultas remotas
    ├── services/              # Serviços da aplicação
    ├── storage/               # Camada de persistência
    ├── ui/                    # Componentes visuais
    ├── tests/                 # Testes automatizados
    ├── tools/                 # Ferramentas de construção, incluindo o lançador
    └── docs/                  # Documentação técnica e operacional
```

## Documentação

- [Instalação e ambiente](docs/INSTALACAO.md)
- [Manual de uso](docs/MANUAL_DE_USO.md)
- [Arquitetura e fluxo técnico](docs/ARQUITETURA.md)
- [Segurança e privacidade](docs/SEGURANCA.md)
- [Solução de problemas](docs/SOLUCAO_DE_PROBLEMAS.md)
- [Publicação no GitHub pelo VS Code](docs/PUBLICACAO_GITHUB.md)
- [Como contribuir](CONTRIBUTING.md)
- [Governança e mantenedores](GOVERNANCE.md)
- [Política de segurança](SECURITY.md)
- [Histórico de versões](CHANGELOG.md)

Para preparar o repositório Git local automaticamente, execute `INICIAR_REPOSITORIO_GIT.bat`. Ele não publica nada e não envia arquivos para a internet.

Para publicar na conta configurada para o projeto, depois de criar o repositório privado vazio, execute `PUBLICAR_NO_GITHUB.bat`. O navegador poderá solicitar a confirmação do login pelo Git Credential Manager.

## Gerar executável

Execute `build_exe.bat`. O PyInstaller criará `dist\AtlasSuporteAvancado.exe`. A pasta `dist` não deve ser versionada; publique o executável somente como artefato de uma Release privada depois de validá-lo.

## Diagnóstico

Se o aplicativo não abrir, execute `diagnostico.bat`. Verifique também:

- `%LOCALAPPDATA%\AtlasSuporteAvancado\v23.6\erro_inicializacao.txt`;
- `%TEMP%\AtlasSuporteAvancado_copia.log`;
- o Console de atividades dentro da interface.

## Autores

Criado e mantido por:

- **Alexandre Linhares** — [@alemagnobr](https://github.com/alemagnobr)
- **João Cerqueira** — [@joaocerq-me](https://github.com/joaocerq-me)

As alterações relevantes devem ser revisadas por pelo menos um dos mantenedores, principalmente quando envolverem autenticação, PowerShell, Active Directory, impressoras ou ações administrativas.

## Uso e distribuição

O projeto contém rotinas administrativas voltadas a um ambiente corporativo específico. Nenhuma licença pública de redistribuição foi concedida neste repositório. Consulte [NOTICE.md](NOTICE.md) antes de compartilhar ou publicar.

## Captura e edição de tela

Após escolher a área, o Atlas abre o preview e permite marcações. Salvar grava a imagem final em PNG, JPG ou BMP no local exibido; Alterar modifica o destino. Cancelar descarta com confirmação quando há edições.
