# ATLAS v23.6 — cadeado Admin local e controles da estação

Extraia o ZIP inteiro e execute `Atlas.exe`. A versão 23.6 parte da v23 e mantém o mesmo perfil local de cache e configurações.

## Estação

O cadeado no campo Admin local aparece com pulso verde ou vermelho quando a estação responde.

O X ao lado de Consultando cancela a consulta. No cabeçalho de Estação conectada, Atualizar recarrega somente esse cartão. Copie o nome junto ao micro; o ping contínuo também pode ser aberto quando não há resposta. Em Windows, use os botões de logoff e reinício; em Espaço Dados (D:), Discos e Perfis ou Limpar temporários. Ações destrutivas mantêm a confirmação.

## Meus templates

O relógio ao lado do X abre os HTMLs de templates copiados hoje. Você pode consultar o conteúdo, copiar novamente e limpar o histórico diário. O grupo `WEB_Libera_Chat` aparece em **Membro de** com a descrição “Acesso ao WhatsApp Web”.

## Chamados

Na janela de chamados recentes do usuário, clique na estrela para favoritar ou no olho para monitorar. Apenas o chamado selecionado é salvo na lista pessoal; a consulta de até 25 resultados continua temporária. Use Atualizar na lista pessoal para conferir o estado salvo no Capri.

- Use a estrela ou o olho nos cartões já mapeados para incluir/remover chamados em **Favoritos** ou **Monitorados**.
- Os dois atalhos ao lado de **Chamados** abrem as listas com pesquisa local por número, título, fila, usuário e situação.
- **Atualizar situações no Capri** verifica pontualmente os chamados da lista aberta. Somente respostas confirmadas alteram os estados salvos; falhas preservam o último estado local. A consulta depende de sessão ativa no Capri e pode levar algum tempo se a lista for grande.
- As escolhas ficam no perfil Windows, separadas do catálogo; um número removido do catálogo deixa de aparecer até ser mapeado novamente.

## Licenças do AD

A aba **Membro de** exibe os grupos `Lic-` em cartões com recursos separados por linha, incluindo `Lic-ADP1`. A política de uso apresentada foi fornecida pelo operador; o ATLAS não calcula elegibilidade a partir dela.

## Validação

`python -m unittest discover -s _app/tests -p "test_*.py" -q`

A interface e a consulta real ao Capri exigem verificação em uma estação Windows autorizada da rede institucional.
