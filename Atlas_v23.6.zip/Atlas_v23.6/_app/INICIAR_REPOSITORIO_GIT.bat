@echo off
setlocal
cd /d "%~dp0"

where git >nul 2>&1
if errorlevel 1 (
  echo Git nao foi encontrado.
  echo Instale o Git for Windows em https://git-scm.com/download/win
  pause
  exit /b 1
)

if not exist ".git" git init
git branch -M main

echo.
echo Repositorio local preparado na branch main.
echo Revise os arquivos abaixo antes do primeiro commit:
echo.
git status --short
echo.
echo No terminal do VS Code, execute:
echo   git add .
echo   git status
echo   git commit -m "feat: publica versao inicial do gerenciador de suporte"
echo.
echo Depois crie um repositorio PRIVADO no GitHub e siga docs\PUBLICACAO_GITHUB.md.
pause
