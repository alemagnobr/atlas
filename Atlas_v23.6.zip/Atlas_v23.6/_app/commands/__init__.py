"""Execução de comandos locais e remotos."""

