"""Nomes públicos das operações executadas pelo bridge PowerShell."""

TICKET_CATALOG = "ticket_catalog"
FAQ_CATALOG = "faq_catalog"

