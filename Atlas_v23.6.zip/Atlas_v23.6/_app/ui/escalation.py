"""Painel de escalonamento pela escala e escolha para horários alterados."""

from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QPoint, QPropertyAnimation, Qt, Signal
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QDialog, QFrame, QGraphicsDropShadowEffect,
    QHBoxLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout,
)
from PySide6.QtGui import QColor

from services.escalation import may_escalate, on_duty


class EscalationOverrideDialog(QDialog):
    """Escolha explícita quando a escala cadastrada deixou de refletir o plantão."""

    selected = Signal(str)

    def __init__(self, targets: list[dict], parent=None):
        super().__init__(parent)
        self.setObjectName("escalationOverridePopup")
        self.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setModal(True)
        self.setFixedWidth(392)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 18)
        surface = QFrame(objectName="escalationOverrideSurface")
        shadow = QGraphicsDropShadowEffect(surface)
        shadow.setBlurRadius(25)
        shadow.setOffset(0, 5)
        shadow.setColor(QColor(0, 10, 22, 130))
        surface.setGraphicsEffect(shadow)
        outer.addWidget(surface)
        body = QVBoxLayout(surface)
        body.setContentsMargins(15, 13, 15, 15)
        body.setSpacing(8)
        heading = QHBoxLayout()
        heading.addWidget(QLabel("ESCOLHER ESCALONAMENTO", objectName="escalationTitle"), 1)
        close = QPushButton("×", objectName="escalationClose")
        close.setFixedSize(30, 30)
        close.clicked.connect(self.reject)
        heading.addWidget(close)
        body.addLayout(heading)
        hint = QLabel("Horários alterados: selecione a liderança ou supervisão responsável.",
                      objectName="escalationHint")
        hint.setWordWrap(True)
        body.addWidget(hint)
        self.buttons = {}
        for target in targets:
            button = QPushButton(f'{target["name"]}\n{target["role"]} · {target["computer"]}',
                                 objectName="escalationOverrideRow")
            button.setAccessibleName(f'Escolher {target["name"]} para escalonamento excepcional')
            button.clicked.connect(lambda _checked=False, key=target["key"]: self.choose(key))
            body.addWidget(button)
            self.buttons[target["key"]] = button
        note = QLabel("A escolha por horário alterado não confirma uma sessão ativa no micro.",
                      objectName="escalationHint")
        note.setWordWrap(True)
        body.addWidget(note)

    def choose(self, key: str):
        if key not in self.buttons:
            return
        self.accept()
        self.selected.emit(key)

    def open_near(self, anchor: QPoint):
        self.adjustSize()
        screen = QApplication.screenAt(anchor) or QApplication.primaryScreen()
        bounds = screen.availableGeometry()
        x = max(bounds.left() + 8, min(anchor.x(), bounds.right() - self.width() - 8))
        y = max(bounds.top() + 8, min(anchor.y(), bounds.bottom() - self.height() - 8))
        self.move(x, y)
        self.show()
        self.raise_()
        self.activateWindow()


class EscalationPopup(QDialog):
    selected = Signal(str, bool)

    def __init__(self, targets: list[dict], parent=None):
        super().__init__(parent)
        self.targets = targets
        self.setObjectName("escalationPopup")
        # Qt.Popup closes itself on focus changes. Keep this window explicit-close
        # while the analyst chooses between the regular and exceptional flows.
        self.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedWidth(412)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 18)
        surface = QFrame(objectName="escalationSurface")
        shadow = QGraphicsDropShadowEffect(surface)
        shadow.setBlurRadius(27)
        shadow.setOffset(0, 6)
        shadow.setColor(QColor(0, 10, 22, 130))
        surface.setGraphicsEffect(shadow)
        outer.addWidget(surface)
        body = QVBoxLayout(surface)
        body.setContentsMargins(15, 13, 15, 15)
        body.setSpacing(8)
        top = QHBoxLayout()
        title = QLabel("APOIO TÉCNICO", objectName="escalationTitle")
        top.addWidget(title, 1)
        close = QPushButton("×", objectName="escalationClose")
        close.setFixedSize(30, 30)
        close.clicked.connect(self.hide)
        top.addWidget(close)
        body.addLayout(top)
        self.status = QLabel("Disponibilidade conforme o horário de Brasília.", objectName="escalationHint")
        self.status.setWordWrap(True)
        body.addWidget(self.status)
        self.rows = {}
        for target in self.targets:
            button = QPushButton(objectName="escalationRow")
            button.setAccessibleName(f'Escalonar para {target["name"]}')
            button.setEnabled(False)
            row_layout = QHBoxLayout(button)
            row_layout.setContentsMargins(10, 7, 10, 7)
            row_layout.setSpacing(9)
            dot = QLabel("●", objectName="escalationDot")
            dot.setFixedWidth(13)
            row_layout.addWidget(dot)
            detail = QVBoxLayout()
            detail.setSpacing(2)
            name = QLabel(target["name"], objectName="escalationName")
            name.setWordWrap(True)
            info = QLabel(f'{target["role"]} · {target["computer"]}', objectName="escalationDetail")
            state = QLabel("Conforme escala", objectName="escalationState")
            detail.addWidget(name)
            detail.addWidget(info)
            detail.addWidget(state)
            row_layout.addLayout(detail, 1)
            for widget in (dot, name, info, state):
                widget.setAttribute(Qt.WA_TransparentForMouseEvents)
            button.clicked.connect(lambda _checked=False, key=target["key"]: self.choose(key))
            body.addWidget(button)
            self.rows[target["key"]] = (button, dot, state)
        self.contacted = QCheckBox("Já conversei com Marcos e preciso da supervisão")
        self.contacted.setObjectName("escalationContacted")
        self.contacted.toggled.connect(self.refresh_rows)
        body.addWidget(self.contacted)
        self.reason = QLineEdit(objectName="escalationReason")
        self.reason.setPlaceholderText("Motivo específico para acionar a supervisão")
        self.reason.setMaxLength(300)
        self.reason.textChanged.connect(self.refresh_rows)
        body.addWidget(self.reason)
        schedule_question = QLabel("Os horários da liderança ou Supervisão foram alterados? Se sim,",
                                   objectName="escalationHint")
        schedule_question.setWordWrap(True)
        body.addWidget(schedule_question)
        schedule_action = QHBoxLayout()
        schedule_action.setSpacing(4)
        self.schedule_link = QPushButton("Clique aqui", objectName="escalationScheduleLink")
        self.schedule_link.clicked.connect(self.open_override)
        schedule_action.addWidget(self.schedule_link)
        schedule_action.addWidget(QLabel("para escolher o seu escalonamento.",
                                         objectName="escalationHint"), 1)
        body.addLayout(schedule_action)
        note = QLabel(
            "A disponibilidade considera o horário, não a sessão do micro. "
            "O envio requer uma sessão ativa; o Atlas não confirma a leitura.",
            objectName="escalationHint",
        )
        note.setWordWrap(True)
        body.addWidget(note)
        self.override_dialog = EscalationOverrideDialog(targets, self)
        self.override_dialog.selected.connect(lambda key: self.selected.emit(key, True))
        self._animation = None

    def open_override(self):
        self.override_dialog.open_near(self.mapToGlobal(QPoint(24, 65)))

    def refresh_rows(self, *_args):
        leader = next((item for item in self.targets if item["key"] == "leader"), None)
        leader_on_duty = bool(leader and on_duty(leader))
        self.contacted.setVisible(leader_on_duty)
        self.reason.setVisible(leader_on_duty)
        self.reason.setEnabled(self.contacted.isChecked())
        for target in self.targets:
            button, dot, label = self.rows[target["key"]]
            duty = on_duty(target)
            ready = may_escalate(
                target, self.targets,
                leader_contacted=self.contacted.isChecked(), reason=self.reason.text(),
            )
            button.setEnabled(ready)
            dot.setProperty("available", duty)
            dot.style().unpolish(dot)
            dot.style().polish(dot)
            if not duty:
                label.setText("Fora do horário ou em almoço")
            else:
                label.setText("Dentro do horário" if ready else "Fale com o líder e informe o motivo")

    def choose(self, key: str):
        target = next((item for item in self.targets if item["key"] == key), None)
        if not target or not may_escalate(
            target, self.targets,
            leader_contacted=self.contacted.isChecked(), reason=self.reason.text(),
        ):
            return
        self.selected.emit(key, False)

    def open_at(self, anchor: QPoint):
        self.refresh_rows()
        screen = QApplication.screenAt(anchor) or QApplication.primaryScreen()
        bounds = screen.availableGeometry()
        self.adjustSize()
        x = max(bounds.left() + 8, min(anchor.x(), bounds.right() - self.width() - 8))
        y = max(bounds.top() + 8, min(anchor.y(), bounds.bottom() - self.height() - 8))
        # Animate the native window rather than applying a painter effect to
        # the dialog; the old effect caused painting glitches on some machines.
        self.move(x, y)
        if self.isVisible():
            self.raise_()
            self.activateWindow()
            return
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        fade = QPropertyAnimation(self, b"windowOpacity", self)
        fade.setDuration(220)
        fade.setStartValue(0.0)
        fade.setEndValue(1.0)
        fade.setEasingCurve(QEasingCurve.OutCubic)
        self._animation = fade
        fade.start()
