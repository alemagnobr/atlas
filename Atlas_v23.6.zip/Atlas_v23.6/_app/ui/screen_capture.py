"""Recorte de área da tela no estilo da Ferramenta de Captura do Windows.

Cada monitor é congelado antes de exibir a sobreposição; o recorte final sai
da imagem congelada em pixels físicos, então não inclui bordas da seleção e
respeita escalas de DPI diferentes entre monitores.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QObject, QPoint, QRect, QRectF, QSize, QStandardPaths, Qt, Signal
from PySide6.QtGui import QColor, QCursor, QGuiApplication, QImage, QPainter, QPainterPath, QPen, QPixmap, QScreen
from PySide6.QtWidgets import QWidget


CAPTURE_FORMATS = (
    ("PNG", (".png",), "Imagem PNG (*.png)"),
    ("JPG", (".jpg", ".jpeg"), "Imagem JPEG (*.jpg *.jpeg)"),
    ("BMP", (".bmp",), "Imagem BMP (*.bmp)"),
)
DEFAULT_CAPTURE_FILTER = CAPTURE_FORMATS[0][2]
MIN_SELECTION_PIXELS = 2


def default_capture_filename(moment: datetime | None = None) -> str:
    return f"Captura_{(moment or datetime.now()):%Y-%m-%d_%H-%M-%S}.png"


def default_capture_folder() -> Path:
    for location in (QStandardPaths.PicturesLocation, QStandardPaths.DesktopLocation):
        folder = QStandardPaths.writableLocation(location)
        if folder and Path(folder).is_dir():
            return Path(folder)
    return Path.home()


def capture_save_filter() -> str:
    return ";;".join(item[2] for item in CAPTURE_FORMATS)


def resolve_capture_path(path: str, selected_filter: str = "") -> tuple[str, str]:
    """Garante extensão coerente com o formato escolhido no 'Salvar como'."""
    target = Path(path)
    suffix = target.suffix.casefold()
    for image_format, suffixes, _label in CAPTURE_FORMATS:
        if suffix in suffixes:
            return str(target), image_format
    image_format, suffixes, _label = next(
        (item for item in CAPTURE_FORMATS if item[2] == selected_filter), CAPTURE_FORMATS[0]
    )
    return str(target.with_name(target.name + suffixes[0])), image_format


def normalized_selection(start: QPoint, end: QPoint, bounds: QRect) -> QRect:
    left, right = sorted((start.x(), end.x()))
    top, bottom = sorted((start.y(), end.y()))
    return QRect(QPoint(left, top), QPoint(right, bottom)).intersected(bounds)


def logical_to_physical(selection: QRect, logical: QSize, physical: QSize) -> QRect:
    """Converte a seleção da sobreposição para pixels reais da imagem congelada."""
    if logical.width() <= 0 or logical.height() <= 0:
        return QRect()
    scale_x = physical.width() / logical.width()
    scale_y = physical.height() / logical.height()
    left = round(selection.left() * scale_x)
    top = round(selection.top() * scale_y)
    right = round((selection.left() + selection.width()) * scale_x)
    bottom = round((selection.top() + selection.height()) * scale_y)
    return QRect(left, top, right - left, bottom - top).intersected(QRect(QPoint(0, 0), physical))


@dataclass
class ScreenSnapshot:
    screen: QScreen
    geometry: QRect
    pixmap: QPixmap


def grab_screens() -> list[ScreenSnapshot]:
    snapshots = []
    for screen in QGuiApplication.screens():
        pixmap = screen.grabWindow(0)
        if not pixmap.isNull():
            snapshots.append(ScreenSnapshot(screen, screen.geometry(), pixmap))
    return snapshots


class ScreenCaptureOverlay(QWidget):
    """Sobreposição de um monitor com a tela congelada e escurecida."""

    selected = Signal(QImage)
    cancelled = Signal()

    def __init__(self, snapshot: ScreenSnapshot):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.snapshot = snapshot
        self.origin: QPoint | None = None
        self.selection = QRect()
        self.setAttribute(Qt.WA_DeleteOnClose)
        self.setCursor(Qt.CrossCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setWindowTitle("Capturar Tela")
        self.create()
        if self.windowHandle() is not None:
            self.windowHandle().setScreen(snapshot.screen)
        self.setGeometry(snapshot.geometry)

    def physical_selection(self) -> QRect:
        return logical_to_physical(self.selection, self.size(), self.snapshot.pixmap.size())

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.drawPixmap(QRectF(self.rect()), self.snapshot.pixmap, QRectF(self.snapshot.pixmap.rect()))
        shade = QPainterPath()
        shade.addRect(QRectF(self.rect()))
        if not self.selection.isEmpty():
            hole = QPainterPath()
            hole.addRect(QRectF(self.selection))
            shade = shade.subtracted(hole)
        painter.fillPath(shade, QColor(0, 0, 0, 115))
        painter.setRenderHint(QPainter.Antialiasing)
        if self.selection.isEmpty():
            self._draw_label(painter, "Arraste para selecionar a área  •  ESC para cancelar",
                             QPoint(self.width() // 2, 34), centered=True)
            return
        painter.setPen(QPen(QColor("#38BDF8"), 1.5))
        painter.setBrush(Qt.NoBrush)
        painter.drawRect(QRectF(self.selection).adjusted(-0.75, -0.75, 0.75, 0.75))
        size = self.physical_selection().size()
        anchor = self.selection.bottomLeft() + QPoint(0, 10)
        if anchor.y() + 30 > self.height():
            anchor = self.selection.topLeft() - QPoint(0, 38)
        self._draw_label(painter, f"{size.width()} × {size.height()} px", anchor)

    def _draw_label(self, painter: QPainter, text: str, anchor: QPoint, centered: bool = False):
        metrics = painter.fontMetrics()
        box = QRect(0, 0, metrics.horizontalAdvance(text) + 22, metrics.height() + 12)
        if centered:
            box.moveCenter(anchor)
        else:
            box.moveTopLeft(QPoint(max(4, min(anchor.x(), self.width() - box.width() - 4)), max(4, anchor.y())))
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(7, 21, 34, 225))
        painter.drawRoundedRect(QRectF(box), 8, 8)
        painter.setPen(QColor("#E7F1F7"))
        painter.drawText(box, Qt.AlignCenter, text)

    def mousePressEvent(self, event):
        if event.button() == Qt.RightButton:
            self.cancelled.emit()
        elif event.button() == Qt.LeftButton:
            self.origin = event.position().toPoint()
            self.selection = QRect()
            self.update()

    def mouseMoveEvent(self, event):
        if self.origin is not None:
            self.selection = normalized_selection(self.origin, event.position().toPoint(), self.rect())
            self.update()

    def mouseReleaseEvent(self, event):
        if event.button() != Qt.LeftButton or self.origin is None:
            return
        self.selection = normalized_selection(self.origin, event.position().toPoint(), self.rect())
        self.origin = None
        area = self.physical_selection()
        if area.width() < MIN_SELECTION_PIXELS or area.height() < MIN_SELECTION_PIXELS:
            self.selection = QRect()
            self.update()
            return
        self.selected.emit(self.snapshot.pixmap.copy(area).toImage())

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.cancelled.emit()
        else:
            super().keyPressEvent(event)


class ScreenCaptureSession(QObject):
    """Abre uma sobreposição por monitor e devolve somente a área recortada."""

    finished = Signal(QImage)
    cancelled = Signal()

    def __init__(self, parent: QObject | None = None):
        super().__init__(parent)
        self.overlays: list[ScreenCaptureOverlay] = []
        self.done = False

    def start(self) -> bool:
        snapshots = grab_screens()
        if not snapshots:
            return False
        for snapshot in snapshots:
            overlay = ScreenCaptureOverlay(snapshot)
            overlay.selected.connect(self._finish)
            overlay.cancelled.connect(self._cancel)
            overlay.show()
            self.overlays.append(overlay)
        cursor_screen = QGuiApplication.screenAt(QCursor.pos())
        active = next((item for item in self.overlays if item.snapshot.screen is cursor_screen), self.overlays[0])
        active.raise_()
        active.activateWindow()
        active.setFocus(Qt.ActiveWindowFocusReason)
        return True

    def _close_overlays(self):
        overlays, self.overlays = self.overlays, []
        for overlay in overlays:
            overlay.close()

    def _finish(self, image: QImage):
        if self.done:
            return
        self.done = True
        self._close_overlays()
        self.finished.emit(image)

    def _cancel(self):
        if self.done:
            return
        self.done = True
        self._close_overlays()
        self.cancelled.emit()
