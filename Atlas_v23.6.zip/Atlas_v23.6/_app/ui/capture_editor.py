"""Editor não destrutivo para o QImage já produzido pela captura do Atlas."""

from __future__ import annotations

import math
import threading
from dataclasses import dataclass, replace
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QImage, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (
    QButtonGroup, QCheckBox, QColorDialog, QComboBox, QDialog, QFileDialog,
    QHBoxLayout, QInputDialog, QLabel, QLineEdit, QMessageBox, QPushButton, QScrollArea,
    QSpinBox, QVBoxLayout, QWidget,
)

from ui.screen_capture import DEFAULT_CAPTURE_FILTER, capture_save_filter, resolve_capture_path


@dataclass
class Annotation:
    kind: str
    points: list[QPointF]
    color: QColor
    width: int
    text: str = ""
    font_size: int = 22
    bold: bool = False


@dataclass
class MoveAnnotation:
    before: Annotation
    after: Annotation


def text_bounds(item: Annotation) -> QRectF:
    font = QFont("Segoe UI")
    font.setPixelSize(max(8, item.font_size))
    font.setBold(item.bold)
    metrics = QFontMetricsF(font)
    bounds = metrics.boundingRect(item.text)
    bounds.moveBottomLeft(item.points[0])
    return bounds.adjusted(-6, -6, 6, 6)


def active_annotations(history: list[Annotation | MoveAnnotation | None], position: int) -> list[Annotation]:
    """None representa Limpar; desfazer e refazer percorrem o mesmo histórico."""
    visible: list[Annotation] = []
    for item in history[:position]:
        if item is None:
            visible.clear()
        elif isinstance(item, MoveAnnotation):
            for index, visible_item in enumerate(visible):
                if visible_item is item.before:
                    visible[index] = item.after
                    break
        else:
            visible.append(item)
    return visible


def draw_annotation(painter: QPainter, item: Annotation):
    color = QColor(item.color)
    width = max(1, item.width)
    if item.kind == "highlight":
        color.setAlpha(85)
        painter.setPen(Qt.NoPen)
        painter.setBrush(color)
        painter.drawRect(QRectF(item.points[0], item.points[-1]).normalized())
        return
    painter.setBrush(Qt.NoBrush)
    painter.setPen(QPen(color, width, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
    if item.kind == "pen":
        path = QPainterPath(item.points[0])
        for point in item.points[1:]:
            path.lineTo(point)
        if len(item.points) == 1:
            path.lineTo(item.points[0] + QPointF(0.01, 0.01))
        painter.drawPath(path)
    elif item.kind == "rectangle":
        painter.drawRect(QRectF(item.points[0], item.points[-1]).normalized())
    elif item.kind == "ellipse":
        painter.drawEllipse(QRectF(item.points[0], item.points[-1]).normalized())
    elif item.kind == "arrow":
        start, end = item.points[0], item.points[-1]
        painter.drawLine(start, end)
        dx, dy = end.x() - start.x(), end.y() - start.y()
        length = math.hypot(dx, dy)
        if length > 0:
            size = min(35.0, max(10.0, width * 4.0))
            size = min(size, length * 0.7)
            ux, uy = dx / length, dy / length
            wing = size * 0.48
            painter.drawLine(end, QPointF(end.x() - ux * size - uy * wing,
                                         end.y() - uy * size + ux * wing))
            painter.drawLine(end, QPointF(end.x() - ux * size + uy * wing,
                                         end.y() - uy * size - ux * wing))
    elif item.kind == "text":
        font = QFont("Segoe UI")
        font.setPixelSize(max(8, item.font_size))
        font.setBold(item.bold)
        painter.setFont(font)
        painter.drawText(item.points[0], item.text)


class CaptureCanvas(QWidget):
    """Ajusta a visualização à janela, mas guarda e desenha em pixels da origem."""

    changed = Signal()
    text_requested = Signal(QPointF)

    def __init__(self, image: QImage, parent=None):
        super().__init__(parent)
        self.original = image.copy()
        # O recorte já está em pixels físicos. DPR só influencia o pintor:
        # normalizá-lo aqui preserva os pixels e evita deslocar marcações.
        self.original.setDevicePixelRatio(1.0)
        self.history: list[Annotation | MoveAnnotation | None] = []
        self.position = 0
        self.tool = "select"
        self.color = QColor("#F04452")
        self.pen_width = 4
        self.font_size = 22
        self.bold = False
        self.draft: Annotation | None = None
        self.selected_text: Annotation | None = None
        self._drag_origin: QPointF | None = None
        self._drag_anchor: QPointF | None = None
        self.setMinimumSize(320, 240)
        self.setMouseTracking(True)
        self.setCursor(Qt.ArrowCursor)

    def image_rect(self) -> QRectF:
        if self.original.isNull() or self.width() < 1 or self.height() < 1:
            return QRectF()
        scale = min(self.width() / self.original.width(), self.height() / self.original.height())
        size = QPointF(self.original.width() * scale, self.original.height() * scale)
        return QRectF((self.width() - size.x()) / 2, (self.height() - size.y()) / 2, size.x(), size.y())

    def image_point(self, position: QPointF) -> QPointF | None:
        bounds = self.image_rect()
        if bounds.isEmpty() or not bounds.contains(position):
            return None
        return QPointF((position.x() - bounds.left()) * self.original.width() / bounds.width(),
                       (position.y() - bounds.top()) * self.original.height() / bounds.height())

    def annotations(self) -> list[Annotation]:
        return active_annotations(self.history, self.position)

    def commit(self, item: Annotation | MoveAnnotation | None):
        self.history = self.history[:self.position]
        self.history.append(item)
        self.position = len(self.history)
        self.draft = None
        if isinstance(item, MoveAnnotation):
            self.selected_text = item.after
        elif isinstance(item, Annotation) and item.kind == "text":
            self.selected_text = item
        else:
            self.selected_text = None
        self.changed.emit()
        self.update()

    def undo(self):
        if self.position:
            self.position -= 1
            self.selected_text = None
            self.changed.emit()
            self.update()

    def redo(self):
        if self.position < len(self.history):
            self.position += 1
            self.selected_text = None
            self.changed.emit()
            self.update()

    def clear_annotations(self):
        if self.annotations():
            self.commit(None)

    def set_tool(self, tool: str):
        self.tool = tool
        self.draft = None
        self._drag_origin = self._drag_anchor = None
        if tool != "select":
            self.selected_text = None
        self.setCursor(Qt.ArrowCursor if tool == "select" else Qt.CrossCursor)
        self.update()

    def mousePressEvent(self, event):
        if event.button() != Qt.LeftButton:
            return super().mousePressEvent(event)
        point = self.image_point(event.position())
        if point is None:
            return
        if self.tool == "select":
            self.selected_text = next((item for item in reversed(self.annotations())
                                       if item.kind == "text" and text_bounds(item).contains(point)), None)
            self._drag_origin = point if self.selected_text is not None else None
            self._drag_anchor = self.selected_text.points[0] if self.selected_text is not None else None
            self.setCursor(Qt.ClosedHandCursor if self.selected_text is not None else Qt.ArrowCursor)
            self.update()
            return
        if self.tool == "text":
            self.text_requested.emit(point)
            return
        self.draft = Annotation(self.tool, [point, point], QColor(self.color), self.pen_width)
        self.update()

    def mouseMoveEvent(self, event):
        if self.tool == "select" and self.selected_text is not None and self._drag_origin is not None:
            bounds = self.image_rect()
            clamped = QPointF(max(bounds.left(), min(event.position().x(), bounds.right())),
                              max(bounds.top(), min(event.position().y(), bounds.bottom())))
            point = self.image_point(clamped)
            if point is not None:
                next_anchor = self._drag_anchor + point - self._drag_origin
                next_anchor = QPointF(max(0, min(next_anchor.x(), self.original.width())),
                                      max(0, min(next_anchor.y(), self.original.height())))
                self.draft = replace(self.selected_text, points=[next_anchor])
                self.update()
            return
        if self.draft is None:
            return super().mouseMoveEvent(event)
        bounds = self.image_rect()
        clamped = QPointF(max(bounds.left(), min(event.position().x(), bounds.right())),
                          max(bounds.top(), min(event.position().y(), bounds.bottom())))
        point = self.image_point(clamped)
        if point is not None:
            if self.tool == "pen":
                self.draft.points.append(point)
            else:
                self.draft.points[-1] = point
            self.update()

    def mouseReleaseEvent(self, event):
        if self.tool == "select" and event.button() == Qt.LeftButton:
            if self._drag_origin is not None:
                self.mouseMoveEvent(event)
                if self.draft is not None and (self.draft.points[0] - self.selected_text.points[0]).manhattanLength() >= 1:
                    self.commit(MoveAnnotation(self.selected_text, self.draft))
                self.draft = None
                self._drag_origin = self._drag_anchor = None
                self.setCursor(Qt.OpenHandCursor if self.selected_text is not None else Qt.ArrowCursor)
                self.update()
            return
        if event.button() != Qt.LeftButton or self.draft is None:
            return super().mouseReleaseEvent(event)
        self.mouseMoveEvent(event)
        item, self.draft = self.draft, None
        if item.kind == "pen" or (item.points[-1] - item.points[0]).manhattanLength() >= 2:
            self.commit(item)
        self.update()

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor("#071A28"))
        bounds = self.image_rect()
        if bounds.isEmpty():
            return
        painter.setRenderHint(QPainter.SmoothPixmapTransform)
        painter.drawImage(bounds, self.original)
        painter.save()
        painter.translate(bounds.topLeft())
        painter.scale(bounds.width() / self.original.width(), bounds.height() / self.original.height())
        painter.setRenderHint(QPainter.Antialiasing)
        for item in self.annotations():
            if item is not self.selected_text or self.draft is None:
                draw_annotation(painter, item)
        if self.draft is not None:
            draw_annotation(painter, self.draft)
        selected = self.draft if self.draft is not None and self.tool == "select" else self.selected_text
        if selected is not None and selected.kind == "text" and (
            selected in self.annotations() or (self.tool == "select" and self.draft is not None)
        ):
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor("#38BDF8"), 1, Qt.DashLine))
            painter.drawRect(text_bounds(selected))
        painter.restore()

    def rendered_image(self) -> QImage:
        output = self.original.copy()
        annotations = self.annotations()
        if annotations:
            painter = QPainter(output)
            painter.setRenderHint(QPainter.Antialiasing)
            for item in annotations:
                draw_annotation(painter, item)
            painter.end()
        return output


class CaptureEditorDialog(QDialog):
    """Preview e edição sobre a captura existente; grava apenas após Salvar."""

    saved = Signal(bool, str)
    save_result = Signal(bool, str)

    def __init__(self, image: QImage, proposed_path: str, dark: bool = True, parent=None):
        super().__init__(parent)
        self.setObjectName("captureEditorDialog")
        self.setWindowTitle("ATLAS — Preview e edição da captura")
        self.resize(1100, 760)
        self.setMinimumSize(750, 540)
        self._saving = False
        self._selected_filter = DEFAULT_CAPTURE_FILTER
        self.canvas = CaptureCanvas(image, self)
        self.canvas.text_requested.connect(self.insert_text)
        self.canvas.changed.connect(self.update_actions)
        self.save_result.connect(self._save_complete)
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 15, 16, 15)
        root.setSpacing(10)
        heading = QLabel("Preview da captura")
        heading.setObjectName("editorHeading")
        root.addWidget(heading)
        tools_scroll = QScrollArea()
        tools_scroll.setObjectName("editorToolsScroll")
        tools_scroll.setFrameShape(QScrollArea.NoFrame)
        tools_scroll.setWidgetResizable(True)
        tools_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        tools_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        tools_scroll.setFixedHeight(64)
        tools = QWidget()
        tools.setObjectName("editorTools")
        toolbar_background = "#091B2A" if dark else "#F2F7FA"
        tools_scroll.viewport().setObjectName("editorToolsViewport")
        tools_scroll.viewport().setStyleSheet(
            f"#editorToolsViewport {{ background: {toolbar_background}; border: none; }}"
        )
        tools.setStyleSheet(f"#editorTools {{ background: {toolbar_background}; border: none; }}")
        row = QHBoxLayout(tools)
        row.setContentsMargins(2, 2, 2, 4)
        row.setSpacing(5)
        group = QButtonGroup(self)
        group.setExclusive(True)
        self.tool_buttons = {}
        for key, caption in (
            ("select", "🖱 Selecionar"), ("pen", "✏ Caneta"), ("arrow", "➜ Seta"),
            ("rectangle", "▭ Retângulo"), ("ellipse", "◯ Elipse"),
            ("text", "T Texto"), ("highlight", "🖌 Destaque"),
        ):
            button = QPushButton(caption)
            button.setObjectName("editorTool")
            button.setCheckable(True)
            button.setChecked(key == "select")
            group.addButton(button)
            self.tool_buttons[key] = button
            button.clicked.connect(lambda _checked=False, tool=key: self.canvas.set_tool(tool))
            row.addWidget(button)
        self.undo_button = QPushButton("↶ Desfazer")
        self.undo_button.clicked.connect(self.canvas.undo)
        row.addWidget(self.undo_button)
        self.redo_button = QPushButton("↷ Refazer")
        self.redo_button.clicked.connect(self.canvas.redo)
        row.addWidget(self.redo_button)
        self.clear_button = QPushButton("🗑 Limpar")
        self.clear_button.clicked.connect(self.canvas.clear_annotations)
        row.addWidget(self.clear_button)
        tools_scroll.setWidget(tools)
        root.addWidget(tools_scroll)
        config = QHBoxLayout()
        config.addWidget(QLabel("Cor"))
        self.color_picker = QComboBox()
        for label, color in (
            ("Vermelho", "#F04452"), ("Amarelo", "#F8D447"), ("Verde", "#34D399"),
            ("Azul", "#39B9F2"), ("Branco", "#FFFFFF"), ("Preto", "#101820"),
        ):
            self.color_picker.addItem(label, color)
        self.color_picker.currentIndexChanged.connect(self.change_color)
        config.addWidget(self.color_picker)
        custom_color = QPushButton("●")
        custom_color.setToolTip("Escolher outra cor")
        custom_color.clicked.connect(self.choose_color)
        config.addWidget(custom_color)
        config.addWidget(QLabel("Espessura"))
        self.thickness = QSpinBox()
        self.thickness.setRange(1, 24)
        self.thickness.setValue(4)
        self.thickness.valueChanged.connect(lambda value: setattr(self.canvas, "pen_width", value))
        config.addWidget(self.thickness)
        config.addWidget(QLabel("Fonte"))
        self.font_size = QSpinBox()
        self.font_size.setRange(8, 96)
        self.font_size.setValue(22)
        self.font_size.valueChanged.connect(lambda value: setattr(self.canvas, "font_size", value))
        config.addWidget(self.font_size)
        self.bold = QCheckBox("Negrito")
        self.bold.toggled.connect(lambda checked: setattr(self.canvas, "bold", checked))
        config.addWidget(self.bold)
        config.addStretch(1)
        root.addLayout(config)
        root.addWidget(self.canvas, 1)
        name_row = QHBoxLayout()
        name_row.addWidget(QLabel("Nome do arquivo"))
        self.name_edit = QLineEdit(Path(proposed_path).name)
        self.name_edit.setAccessibleName("Nome da captura")
        self.name_edit.setPlaceholderText("Digite o nome da imagem, por exemplo: evidência.png")
        self.name_edit.textEdited.connect(self._name_changed)
        name_row.addWidget(self.name_edit, 1)
        root.addLayout(name_row)
        destination = QHBoxLayout()
        destination.addWidget(QLabel("Arquivo final"))
        self.path_edit = QLineEdit(proposed_path)
        self.path_edit.setAccessibleName("Local e nome da imagem final")
        self.path_edit.textEdited.connect(self._path_changed)
        destination.addWidget(self.path_edit, 1)
        browse = QPushButton("Alterar…")
        browse.clicked.connect(self.choose_path)
        destination.addWidget(browse)
        root.addLayout(destination)
        actions = QHBoxLayout()
        self.status = QLabel(f"Imagem original: {image.width()} × {image.height()} px")
        actions.addWidget(self.status, 1)
        self.cancel_button = QPushButton("Cancelar")
        self.cancel_button.clicked.connect(self.reject)
        actions.addWidget(self.cancel_button)
        self.save_button = QPushButton("💾 Salvar")
        self.save_button.setObjectName("editorSave")
        self.save_button.clicked.connect(self.save_image)
        actions.addWidget(self.save_button)
        root.addLayout(actions)
        self.setStyleSheet(self._theme(dark))
        self.update_actions()

    @staticmethod
    def _theme(dark: bool) -> str:
        bg, panel, fg, border, selected = (
            ("#091B2A", "#102B3F", "#F3F9FC", "#356078", "#12684E") if dark else
            ("#F2F7FA", "#FFFFFF", "#12344B", "#B6CBD8", "#D9F3E8")
        )
        return f"""
        #captureEditorDialog {{ background: {bg}; color: {fg}; }}
        #captureEditorDialog QLabel, #captureEditorDialog QCheckBox {{ color: {fg}; }}
        #editorHeading {{ font-size: 17px; font-weight: 800; }}
        #editorToolsScroll {{ background: transparent; border: none; }}
        #editorToolsScroll QWidget#qt_scrollarea_viewport {{ background: {bg}; border: none; }}
        #captureEditorDialog QPushButton, #captureEditorDialog QComboBox,
        #captureEditorDialog QSpinBox, #captureEditorDialog QLineEdit {{
            background: {panel}; color: {fg}; border: 1px solid {border};
            border-radius: 7px; padding: 5px 8px; min-height: 25px;
        }}
        #editorTool:checked {{ background: {selected}; border-color: #45D6A1; }}
        #editorSave {{ background: #087C58; color: white; border-color: #39BE8D; }}
        """

    def change_color(self):
        color = self.color_picker.currentData()
        if color:
            self.canvas.color = QColor(color)

    def choose_color(self):
        color = QColorDialog.getColor(self.canvas.color, self, "Cor da marcação")
        if color.isValid():
            self.canvas.color = color
            index = self.color_picker.findData(color.name())
            self.color_picker.setCurrentIndex(index)

    def insert_text(self, point: QPointF):
        text, accepted = QInputDialog.getText(
            self, "Inserir texto", "Texto para inserir na imagem:"
        )
        if accepted and text.strip():
            self.canvas.commit(Annotation(
                "text", [point], QColor(self.canvas.color), self.canvas.pen_width,
                text.strip(), self.canvas.font_size, self.canvas.bold,
            ))
            self.tool_buttons["select"].setChecked(True)
            self.canvas.set_tool("select")
            self.canvas.setCursor(Qt.OpenHandCursor)

    def _name_changed(self, name: str):
        if name and not any(char in name for char in '/\\'):
            self.path_edit.setText(str(Path(self.path_edit.text()).parent / name))

    def _path_changed(self, path: str):
        self.name_edit.setText(Path(path).name)

    def update_actions(self):
        self.undo_button.setEnabled(self.canvas.position > 0)
        self.redo_button.setEnabled(self.canvas.position < len(self.canvas.history))
        self.clear_button.setEnabled(bool(self.canvas.annotations()))

    def choose_path(self):
        path, selected_filter = QFileDialog.getSaveFileName(
            self, "Salvar captura em", self.path_edit.text(),
            capture_save_filter(), self._selected_filter,
        )
        if path:
            self._selected_filter = selected_filter
            self.path_edit.setText(path)
            self.name_edit.setText(Path(path).name)

    def save_image(self):
        name = self.name_edit.text().strip()
        if not name or name in {".", ".."} or any(char in name for char in '/\\<>:"|?*'):
            self.status.setText("Informe um nome de arquivo válido.")
            return
        raw_path = self.path_edit.text().strip()
        if not raw_path:
            self.status.setText("Informe o nome e a pasta do arquivo.")
            return
        path, image_format = resolve_capture_path(raw_path, self._selected_filter)
        if not Path(path).parent.is_dir():
            self.status.setText("A pasta de destino não existe.")
            return
        if Path(path).exists() and QMessageBox.question(
            self, "Substituir imagem",
            "Já existe uma imagem com esse nome. Deseja substituí-la?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
        ) != QMessageBox.Yes:
            return
        self.path_edit.setText(path)
        self.name_edit.setText(Path(path).name)
        output = self.canvas.rendered_image()
        self._saving = True
        self.save_button.setEnabled(False)
        self.cancel_button.setEnabled(False)
        self.status.setText("Salvando imagem editada…")
        quality = 95 if image_format == "JPG" else -1

        def write_file():
            try:
                ok = output.save(path, image_format, quality)
            except Exception:
                ok = False
            self.save_result.emit(bool(ok), path)

        threading.Thread(target=write_file, name="atlas-screen-capture-save", daemon=True).start()

    def _save_complete(self, ok: bool, path: str):
        self._saving = False
        if ok:
            self.saved.emit(True, path)
            super().accept()
            return
        self.save_button.setEnabled(True)
        self.cancel_button.setEnabled(True)
        self.status.setText("Não foi possível salvar. Confira o local e tente novamente.")

    def reject(self):
        if self._saving:
            return
        if self.canvas.annotations():
            prompt = QMessageBox(self)
            prompt.setWindowTitle("Descartar edição")
            prompt.setText("Deseja descartar as alterações?")
            discard = prompt.addButton("Descartar", QMessageBox.DestructiveRole)
            prompt.addButton("Continuar editando", QMessageBox.RejectRole)
            prompt.exec()
            if prompt.clickedButton() is not discard:
                return
        super().reject()

    def closeEvent(self, event):
        event.ignore()
        self.reject()
