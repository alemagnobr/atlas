"""Painel de modelos do Capri, aberto ao lado da barra lateral."""

from __future__ import annotations

import unicodedata

from PySide6.QtCore import QEvent, QPoint, QSize, QTimer, Qt, Signal
from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QDialog, QFrame, QGraphicsDropShadowEffect,
    QHBoxLayout, QInputDialog,
    QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QScrollArea, QStackedWidget, QStyle, QTextEdit,
    QVBoxLayout, QWidget,
)

from services.template_history import clear_today, display_timestamp, load_today, readable_preview, record_copy
from services.ticket_template_store import delete_template, load_saved_templates, save_template, update_template
from services.ticket_templates import (
    extract_closure_fields, render_closure, render_escalation, render_no_network,
    render_standard_installation, render_wifi_checklist,
)


class CheckChoice(QWidget):
    """Opções exclusivas visíveis, com check e sem seleção inicial."""

    def __init__(self, choices):
        super().__init__()
        self.options = list(choices)
        self.group = QButtonGroup(self)
        self.group.setExclusive(True)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(3, 0, 0, 0)
        layout.setSpacing(2)
        self.checks = []
        for index, choice in enumerate(self.options):
            checkbox = QCheckBox(choice)
            self.group.addButton(checkbox, index)
            layout.addWidget(checkbox)
            self.checks.append(checkbox)

    def currentIndex(self):
        return self.group.checkedId() + 1 if self.group.checkedId() >= 0 else 0

    def currentText(self):
        index = self.currentIndex()
        return self.options[index - 1] if index else "Não selecionado"

    def setCurrentIndex(self, index):
        self.group.setExclusive(False)
        for checkbox in self.checks:
            checkbox.setChecked(False)
        self.group.setExclusive(True)
        if 1 <= index <= len(self.checks):
            self.checks[index - 1].setChecked(True)

    def setFocus(self, reason=Qt.OtherFocusReason):
        if self.checks:
            self.checks[0].setFocus(reason)


class TicketTemplatesPopup(QDialog):
    copied = Signal(str)

    def __init__(self, parent, signature_provider, saved_path):
        super().__init__(parent)
        self.signature_provider = signature_provider
        self.saved_path = saved_path
        self.history_path = saved_path.with_name("template_history.json")
        self.editing_entry = None
        self._loaded_escalation_draft = False
        self.anchor_y = 0
        self.setObjectName("templatesPopup")
        # Uma janela de ferramenta permanece aberta quando o foco vai para o Atlas
        # ou para outro aplicativo; Qt.Popup se fecha automaticamente nesse caso.
        self.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 18)
        self.surface = QFrame()
        self.surface.setObjectName("templatesSurface")
        shadow = QGraphicsDropShadowEffect(self.surface)
        shadow.setBlurRadius(30)
        shadow.setOffset(0, 7)
        shadow.setColor(QColor(0, 9, 22, 135))
        self.surface.setGraphicsEffect(shadow)
        outer.addWidget(self.surface)
        content = QVBoxLayout(self.surface)
        content.setContentsMargins(18, 16, 18, 16)
        content.setSpacing(10)
        heading = QHBoxLayout()
        self.back_button = QPushButton("‹")
        self.back_button.setObjectName("templatesBack")
        self.back_button.setToolTip("Voltar aos templates")
        self.back_button.setFixedSize(30, 30)
        self.back_button.clicked.connect(self.go_back)
        self.back_button.hide()
        heading.addWidget(self.back_button)
        self.title = QLabel("MEUS TEMPLATES")
        self.title.setObjectName("templatesTitle")
        heading.addWidget(self.title, 1)
        history_button = QPushButton()
        history_button.setObjectName("templatesHistoryButton")
        history_button.setAccessibleName("Atendimentos de hoje")
        history_button.setToolTip("Consultar HTMLs de templates copiados hoje")
        history_button.setFixedSize(30, 30)
        clock = QPixmap(18, 18)
        clock.fill(Qt.transparent)
        clock_painter = QPainter(clock)
        clock_painter.setRenderHint(QPainter.Antialiasing)
        clock_painter.setPen(QPen(QColor("#62DDB4"), 1.7))
        clock_painter.drawEllipse(2, 2, 14, 14)
        clock_painter.drawLine(9, 9, 9, 5)
        clock_painter.drawLine(9, 9, 12, 11)
        clock_painter.end()
        history_button.setIcon(QIcon(clock))
        history_button.setIconSize(QSize(18, 18))
        history_button.clicked.connect(self.open_history)
        heading.addWidget(history_button)
        self.history_button = history_button
        close_button = QPushButton("×")
        close_button.setObjectName("templatesClose")
        close_button.setAccessibleName("Fechar meus templates")
        close_button.setFixedSize(30, 30)
        close_button.clicked.connect(self.hide)
        heading.addWidget(close_button)
        content.addLayout(heading)
        divider = QFrame()
        divider.setObjectName("templatesDivider")
        divider.setFixedHeight(2)
        content.addWidget(divider)

        self.stack = QStackedWidget()
        content.addWidget(self.stack, 1)
        menu = QWidget()
        menu.setObjectName("templatesBody")
        menu_layout = QVBoxLayout(menu)
        menu_layout.setContentsMargins(0, 0, 0, 0)
        menu_layout.setSpacing(8)
        note = QLabel("Escolha um modelo, preencha os campos e copie o HTML para o Capri.")
        note.setObjectName("templatesHint")
        note.setWordWrap(True)
        menu_layout.addWidget(note)
        for kind, title, description in (
            ("closure", "Fechamento", "Análise técnica • Ações realizadas • Resultado"),
            ("escalation", "Escalonamento", "Solicitação • Tratativa • Localização"),
            ("wifi", "Verificação Wi-Fi", "Checklist de conexão • Clearpass • AP • Localização"),
            ("installation", "Instalação padrão", "Solicitação • Motivo • Aprovações • Localização"),
            ("no_network", "Estação sem Rede/Internet", "Checklist de diagnóstico • Localização"),
        ):
            menu_layout.addWidget(self.menu_item(kind, title, description))
        self.saved_open = QPushButton("Templates salvos")
        self.saved_open.setObjectName("templatesSavedOpen")
        self.saved_open.clicked.connect(self.show_saved)
        menu_layout.addWidget(self.saved_open)
        menu_layout.addStretch(1)
        menu_scroll = QScrollArea()
        menu_scroll.setObjectName("templatesScroll")
        menu_scroll.setWidgetResizable(True)
        menu_scroll.setFrameShape(QFrame.NoFrame)
        menu_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        menu_scroll.setWidget(menu)
        self.stack.addWidget(menu_scroll)

        editor = QWidget()
        editor_layout = QVBoxLayout(editor)
        editor_layout.setContentsMargins(0, 0, 0, 0)
        editor_layout.setSpacing(9)
        scroll = QScrollArea()
        scroll.setObjectName("templatesScroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        body = QWidget()
        body.setObjectName("templatesBody")
        form = QVBoxLayout(body)
        form.setContentsMargins(2, 2, 12, 18)
        form.setSpacing(8)
        self.closure_form = QWidget()
        closure_layout = QVBoxLayout(self.closure_form)
        closure_layout.setContentsMargins(0, 0, 0, 0)
        closure_layout.setSpacing(7)
        self.analysis = self.text_field(closure_layout, "Análise técnica")
        self.actions = self.text_field(closure_layout, "Ações realizadas")
        self.result = self.text_field(closure_layout, "Resultado")
        form.addWidget(self.closure_form)

        self.escalation_form = QWidget()
        escalation_layout = QVBoxLayout(self.escalation_form)
        escalation_layout.setContentsMargins(0, 0, 0, 0)
        escalation_layout.setSpacing(7)
        self.request = self.text_field(escalation_layout, "A solicitação")
        self.treatment = self.text_field(escalation_layout, "A tratativa")
        location_title = QLabel("Localização")
        location_title.setObjectName("templatesSection")
        escalation_layout.addWidget(location_title)
        self.location, self.sector_status, self.place = self.location_fields(
            escalation_layout, external=True,
        )
        form.addWidget(self.escalation_form)
        self.wifi_form = self.build_wifi_form()
        form.addWidget(self.wifi_form)
        self.install_form = self.build_install_form()
        form.addWidget(self.install_form)
        self.no_network_form = self.build_no_network_form()
        form.addWidget(self.no_network_form)
        self.forms = {
            "closure": self.closure_form, "escalation": self.escalation_form,
            "wifi": self.wifi_form, "installation": self.install_form,
            "no_network": self.no_network_form,
        }
        form.addStretch(1)
        scroll.setWidget(body)
        self.editor_scroll = scroll
        editor_layout.addWidget(scroll, 1)
        self.scroll_status = QLabel("Role para ver todos os campos ↓")
        self.scroll_status.setObjectName("templatesScrollStatus")
        self.scroll_status.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        editor_layout.addWidget(self.scroll_status)
        scrollbar = scroll.verticalScrollBar()
        scrollbar.valueChanged.connect(self.update_scroll_status)
        scrollbar.rangeChanged.connect(lambda _minimum, _maximum: self.update_scroll_status())
        footer_line = QFrame()
        footer_line.setObjectName("templatesFooterDivider")
        footer_line.setFixedHeight(1)
        editor_layout.addWidget(footer_line)
        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.save_button = QPushButton("Salvar template")
        self.save_button.setObjectName("templatesSaveIcon")
        self.save_button.setIcon(self.style().standardIcon(QStyle.SP_DialogSaveButton))
        self.save_button.setIconSize(QSize(18, 18))
        self.save_button.setToolTip("Salvar este template preenchido com um nome")
        self.save_button.setAccessibleName("Salvar template preenchido")
        self.save_button.setFixedSize(158, 42)
        self.save_button.clicked.connect(self.save_current)
        actions.addWidget(self.save_button)
        self.finish_button = QPushButton("Finalizar e copiar HTML")
        self.finish_button.setObjectName("templatesPrimary")
        self.finish_button.setFixedHeight(42)
        self.finish_button.setToolTip("Finalizar o modelo e copiar o código-fonte HTML")
        self.finish_button.clicked.connect(self.finish)
        actions.addWidget(self.finish_button, 1)
        editor_layout.addLayout(actions)
        self.stack.addWidget(editor)

        saved_page = QWidget()
        saved_layout = QVBoxLayout(saved_page)
        saved_layout.setContentsMargins(0, 0, 0, 0)
        saved_layout.setSpacing(8)
        self.saved_hint = QLabel("Clique no nome para usar o template ou no lápis para editar o modelo salvo.")
        self.saved_hint.setObjectName("templatesHint")
        self.saved_hint.setWordWrap(True)
        saved_layout.addWidget(self.saved_hint)
        self.saved_search = QLineEdit()
        self.saved_search.setObjectName("templatesSavedSearch")
        self.saved_search.setPlaceholderText("Buscar template salvo pelo nome…")
        self.saved_search.setAccessibleName("Buscar templates salvos")
        self.saved_search.setClearButtonEnabled(True)
        search_pixmap = QPixmap(19, 19)
        search_pixmap.fill(Qt.transparent)
        painter = QPainter(search_pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(QPen(QColor("#73CFF3"), 1.7))
        painter.drawEllipse(2, 2, 10, 10)
        painter.drawLine(11, 11, 17, 17)
        painter.end()
        self.saved_search.addAction(QIcon(search_pixmap), QLineEdit.ActionPosition.LeadingPosition)
        self.saved_search.textChanged.connect(self.render_saved_rows)
        saved_layout.addWidget(self.saved_search)
        saved_scroll = QScrollArea()
        saved_scroll.setObjectName("templatesScroll")
        saved_scroll.setWidgetResizable(True)
        saved_scroll.setFrameShape(QFrame.NoFrame)
        saved_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        saved_body = QWidget()
        saved_body.setObjectName("templatesBody")
        self.saved_rows = QVBoxLayout(saved_body)
        self.saved_rows.setContentsMargins(0, 0, 6, 0)
        self.saved_rows.setSpacing(6)
        saved_scroll.setWidget(saved_body)
        saved_layout.addWidget(saved_scroll, 1)
        self.stack.addWidget(saved_page)

        legacy_page = QWidget()
        legacy_layout = QVBoxLayout(legacy_page)
        legacy_layout.setContentsMargins(0, 0, 0, 0)
        legacy_layout.setSpacing(9)
        legacy_hint = QLabel(
            "Este template antigo foi salvo sem os campos separados. Edite o HTML existente abaixo."
        )
        legacy_hint.setObjectName("templatesHint")
        legacy_hint.setWordWrap(True)
        legacy_layout.addWidget(legacy_hint)
        self.legacy_html = QTextEdit()
        self.legacy_html.setAcceptRichText(False)
        self.legacy_html.setAccessibleName("Código HTML do template salvo")
        legacy_layout.addWidget(self.legacy_html, 1)
        legacy_save = QPushButton("Salvar alterações")
        legacy_save.setObjectName("templatesPrimary")
        legacy_save.clicked.connect(self.save_legacy_html)
        legacy_layout.addWidget(legacy_save)
        self.stack.addWidget(legacy_page)
        self.build_history_dialog()
        self.show_list()

    def build_history_dialog(self):
        dialog = QDialog(self.parent())
        dialog.setObjectName("templatesHistoryDialog")
        dialog.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(16, 15, 16, 15)
        layout.setSpacing(10)
        header = QHBoxLayout()
        title = QLabel("ATENDIMENTOS DE HOJE")
        title.setObjectName("templatesHistoryTitle")
        header.addWidget(title, 1)
        close = QPushButton("×")
        close.setObjectName("templatesClose")
        close.setFixedSize(30, 30)
        close.setAccessibleName("Fechar histórico dos templates")
        close.clicked.connect(dialog.hide)
        header.addWidget(close)
        layout.addLayout(header)
        self.history_hint = QLabel()
        self.history_hint.setObjectName("templatesHint")
        self.history_hint.setWordWrap(True)
        layout.addWidget(self.history_hint)
        scroll = QScrollArea()
        scroll.setObjectName("templatesScroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        body = QWidget()
        body.setObjectName("templatesBody")
        self.history_rows = QVBoxLayout(body)
        self.history_rows.setContentsMargins(2, 2, 6, 2)
        self.history_rows.setSpacing(7)
        scroll.setWidget(body)
        layout.addWidget(scroll, 1)
        clear = QPushButton("Limpar atendimentos de hoje")
        clear.setObjectName("templatesHistoryClear")
        clear.clicked.connect(self.clear_history)
        layout.addWidget(clear, 0, Qt.AlignRight)
        self.history_clear_button = clear
        self.history_dialog = dialog

    def open_history(self):
        self.render_history()
        dialog = self.history_dialog
        anchor = self.history_button.mapToGlobal(QPoint(self.history_button.width() + 8, 0))
        screen = QApplication.screenAt(anchor) or QApplication.primaryScreen()
        bounds = screen.availableGeometry()
        width = min(540, bounds.width() - 24)
        height = min(570, bounds.height() - 24)
        dialog.resize(width, height)
        dialog.move(
            max(bounds.left() + 12, min(anchor.x(), bounds.right() - width - 11)),
            max(bounds.top() + 12, min(anchor.y(), bounds.bottom() - height - 11)),
        )
        dialog.show()
        dialog.raise_()

    def render_history(self):
        rows = self.history_rows
        while rows.count():
            item = rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        entries = list(reversed(load_today(self.history_path)))
        self.history_hint.setText(
            f"{len(entries)} HTML(s) copiado(s) hoje. Abra um registro para conferir o conteúdo ou copiá-lo novamente."
        )
        self.history_clear_button.setEnabled(bool(entries))
        if not entries:
            empty = QLabel("Nenhum atendimento registrado hoje.")
            empty.setObjectName("templatesHint")
            rows.addWidget(empty)
        for entry in entries:
            button = QPushButton(f"{display_timestamp(entry)}  •  {entry['label']}")
            button.setObjectName("templatesHistoryRow")
            button.setToolTip("Visualizar o HTML deste atendimento")
            button.setAccessibleName(f"Ver atendimento {entry['label']} de {display_timestamp(entry)}")
            button.clicked.connect(lambda _checked=False, saved=entry: self.show_history_entry(saved))
            rows.addWidget(button)
        rows.addStretch(1)

    def show_history_entry(self, entry):
        details = QDialog(self.history_dialog)
        details.setObjectName("templatesHistoryDialog")
        details.setWindowTitle(f"Atendimento • {entry['label']}")
        details.resize(600, 540)
        box = QVBoxLayout(details)
        box.setContentsMargins(17, 15, 17, 15)
        box.setSpacing(10)
        heading = QLabel(f"{entry['label']}  •  {display_timestamp(entry)}")
        heading.setObjectName("templatesHistoryTitle")
        heading.setWordWrap(True)
        box.addWidget(heading)
        explanation = QLabel("Prévia para leitura. O botão abaixo copia o HTML original completo.")
        explanation.setObjectName("templatesHistoryHint")
        explanation.setWordWrap(True)
        box.addWidget(explanation)
        preview = QPlainTextEdit()
        preview.setObjectName("templatesHistoryPreview")
        preview.setReadOnly(True)
        preview.setPlainText(readable_preview(entry["html"]))
        preview.setLineWrapMode(QPlainTextEdit.WidgetWidth)
        box.addWidget(preview, 1)
        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        copy = QPushButton("Copiar HTML")
        copy.setObjectName("templatesHistoryCopy")
        copy.setFixedHeight(40)
        copy.clicked.connect(lambda: QApplication.clipboard().setText(entry["html"]))
        buttons.addWidget(copy, 1)
        close = QPushButton("Fechar")
        close.setObjectName("templatesHistoryCloseAction")
        close.setFixedHeight(40)
        close.clicked.connect(details.accept)
        buttons.addWidget(close, 1)
        box.addLayout(buttons)
        details.exec()

    def clear_history(self):
        confirmation = QDialog(self.history_dialog)
        confirmation.setObjectName("templatesHistoryConfirm")
        confirmation.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        confirmation.setFixedWidth(380)
        layout = QVBoxLayout(confirmation)
        layout.setContentsMargins(18, 17, 18, 17)
        layout.setSpacing(11)
        title = QLabel("Limpar atendimentos?")
        title.setObjectName("templatesHistoryTitle")
        layout.addWidget(title)
        description = QLabel("Os HTMLs copiados hoje serão removidos do histórico local.")
        description.setObjectName("templatesHistoryHint")
        description.setWordWrap(True)
        layout.addWidget(description)
        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        cancel = QPushButton("Cancelar")
        cancel.setObjectName("templatesHistoryCloseAction")
        cancel.setFixedHeight(36)
        cancel.clicked.connect(confirmation.reject)
        buttons.addWidget(cancel, 1)
        clear = QPushButton("Limpar")
        clear.setObjectName("templatesHistoryDelete")
        clear.setFixedHeight(36)
        clear.clicked.connect(confirmation.accept)
        buttons.addWidget(clear, 1)
        layout.addLayout(buttons)
        if confirmation.exec() != QDialog.Accepted:
            return
        if not clear_today(self.history_path):
            QMessageBox.warning(self.history_dialog, "Atendimentos", "Não foi possível limpar o histórico local.")
            return
        self.render_history()

    def remember_copy(self, label, kind, html):
        if not record_copy(self.history_path, label, kind, html):
            QMessageBox.warning(
                self, "Histórico dos templates",
                "O HTML foi copiado, mas não foi possível registrar este atendimento no histórico local.",
            )

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # Em uma tela estreita os textos encurtam, mantendo os dois botões
        # inteiros e clicáveis sem reduzir o ícone de salvar.
        compact = self.width() < 430
        self.save_button.setText("Salvar" if compact else "Salvar template")
        self.save_button.setFixedWidth(96 if compact else 158)
        self.finish_button.setText("Copiar HTML" if compact else "Finalizar e copiar HTML")

    def menu_item(self, kind, title, description):
        item = QPushButton()
        item.setObjectName("templatesItem")
        item.setAccessibleName(f"Abrir template de {title.lower()}")
        item.setFixedHeight(72)
        line = QHBoxLayout(item)
        line.setContentsMargins(14, 8, 12, 8)
        line.setSpacing(10)
        labels = QVBoxLayout()
        labels.setContentsMargins(0, 0, 0, 0)
        labels.setSpacing(2)
        caption = QLabel(title)
        caption.setObjectName("templatesItemTitle")
        detail = QLabel(description)
        detail.setObjectName("templatesItemDetail")
        detail.setWordWrap(True)
        chevron = QLabel("›")
        chevron.setObjectName("templatesItemChevron")
        for label in (caption, detail, chevron):
            label.setAttribute(Qt.WA_TransparentForMouseEvents)
        labels.addWidget(caption)
        labels.addWidget(detail)
        line.addLayout(labels, 1)
        line.addWidget(chevron)
        item.clicked.connect(lambda _checked=False, selected=kind: self.show_form(selected))
        return item

    def update_scroll_status(self, *_args):
        scrollbar = self.editor_scroll.verticalScrollBar()
        if scrollbar.maximum() == 0:
            self.scroll_status.hide()
        else:
            self.scroll_status.setText(
                "Fim do formulário ✓" if scrollbar.value() >= scrollbar.maximum()
                else "Role para ver todos os campos ↓"
            )
            self.scroll_status.show()

    def reject(self):
        """Esc oculta a janela sem descartar o preenchimento."""
        self.hide()

    def add_field(self, layout, label_text, field):
        label = QLabel(label_text)
        label.setObjectName("templatesFieldLabel")
        layout.addWidget(label)
        layout.addWidget(field)
        field.installEventFilter(self)

    def eventFilter(self, obj, event):
        if event.type() == QEvent.FocusIn and hasattr(self, "editor_scroll"):
            QTimer.singleShot(0, lambda field=obj: self.editor_scroll.ensureWidgetVisible(field, 0, 24))
        return super().eventFilter(obj, event)

    def text_field(self, layout, label):
        field = QTextEdit()
        field.setAcceptRichText(False)
        field.setTabChangesFocus(True)
        field.setPlaceholderText(f"Descreva {label.lower()}...")
        field.setAccessibleName(label)
        field.setFixedHeight(82)
        self.add_field(layout, label, field)
        return field

    def line_field(self, layout, label, placeholder="Não informado"):
        field = QLineEdit()
        field.setPlaceholderText(placeholder)
        field.setMaxLength(300)
        field.setAccessibleName(label)
        self.add_field(layout, label, field)
        return field

    def choice_field(self, layout, label, choices):
        field = CheckChoice(choices)
        field.setAccessibleName(label)
        self.add_field(layout, label, field)
        return field

    def location_fields(self, layout, *, external=False):
        fields = {}
        for key, label in (
            ("sector", "Setor"), ("building", "Edifício"), ("complement", "Complemento"),
            ("reference", "Ponto de referência"), ("contact", "Contato"),
        ):
            fields[key] = self.line_field(layout, label)
        status = self.choice_field(layout, "Situação do setor", ("Aberto", "Fechado"))
        choices = ("Teletrabalho", "Senado", "Externo") if external else ("Teletrabalho", "Senado")
        place = self.choice_field(layout, "Local do atendimento", choices)
        return fields, status, place

    @staticmethod
    def selection(field):
        return field.currentText() if field.currentIndex() else ""

    def build_wifi_form(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        self.wifi_user_type = self.choice_field(
            layout, "1. Tipo de usuário",
            ("Cadastrado no AD", "Usuário da Câmara", "Autorizado sem conta no AD",
             "Visitante com CPF", "Visitante sem CPF", "Outros"),
        )
        self.wifi_user_other = self.line_field(layout, "Outro tipo de usuário", "Informe se selecionou Outros")
        self.wifi_time = self.line_field(layout, "2. Data e hora do evento", "Ex.: 25/11/2025 às 14h30")
        self.wifi_error = self.text_field(layout, "3. Mensagem de erro apresentada ao usuário")
        self.wifi_equipment = self.choice_field(layout, "4. Tipo de equipamento", ("Celular", "Tablet", "Notebook"))
        self.wifi_model = self.line_field(layout, "Modelo / Marca (opcional)")
        self.wifi_os = self.choice_field(layout, "5. Sistema operacional",
                                         ("Android", "iOS", "Windows", "MacOS", "Outro"))
        self.wifi_os_other = self.line_field(layout, "Outro sistema operacional", "Informe se selecionou Outro")
        self.wifi_clearpass = self.choice_field(layout, "6. Acessa o Clearpass?", ("SIM", "NÃO"))
        self.wifi_auth_error = self.choice_field(layout, "7. Erro na autenticação?", ("SIM", "NÃO"))
        self.wifi_auth_details = self.text_field(layout, "Descrição do erro na autenticação")
        self.wifi_navigates = self.choice_field(layout, "8. Consegue navegar após autenticar?", ("SIM", "NÃO"))
        action_title = QLabel("9. Ações corretivas aplicadas")
        action_title.setObjectName("templatesSection")
        layout.addWidget(action_title)
        self.wifi_corrective = {}
        for label in ("Esquecer a Rede", "Reinicializar o Equipamento", "Troca de senha", "Outras"):
            checkbox = QCheckBox(label)
            checkbox.setAccessibleName(label)
            layout.addWidget(checkbox)
            self.wifi_corrective[label] = checkbox
        self.wifi_corrective_other = self.line_field(layout, "Outras ações", "Se marcou Outras")
        self.wifi_signal = self.choice_field(layout, "10. Intensidade do sinal", ("Alta", "Média", "Baixa"))
        self.wifi_ap = self.line_field(layout, "11. Identificação do Access Point", "Ex.: AP1234")
        section = QLabel("12. Localização")
        section.setObjectName("templatesSection")
        layout.addWidget(section)
        self.wifi_location, self.wifi_sector_status, self.wifi_place = self.location_fields(layout)
        return widget

    def build_install_form(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        self.install_request = self.text_field(layout, "A solicitação")
        self.install_treatment = self.text_field(layout, "A tratativa")
        self.install_reason = self.choice_field(layout, "Motivo da solicitação",
                                                ("Lentidão", "Troca de micro", "Outros"))
        self.install_reason_other = self.line_field(layout, "Outro motivo", "Se selecionou Outros")
        self.install_authorized = self.choice_field(layout, "Autorização do chefe do setor", ("Sim", "Não"))
        self.install_shared = self.choice_field(layout, "Outros clientes utilizam o micro?", ("Sim", "Não"))
        self.install_backup = self.choice_field(layout, "Necessita de backup?", ("Sim", "Não"))
        section = QLabel("Localização")
        section.setObjectName("templatesSection")
        layout.addWidget(section)
        self.install_location, self.install_sector_status, self.install_place = self.location_fields(layout)
        return widget

    def build_no_network_form(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        section = QLabel("1. Checklist de diagnóstico")
        section.setObjectName("templatesSection")
        layout.addWidget(section)
        self.network_checks = {}
        for key, label in (
            ("other_devices", "Afeta outros equipamentos do mesmo local/setor?"),
            ("recently_installed", "Instalado, substituído ou instalação padrão recente?"),
            ("cable_connected", "O cabo de rede está devidamente conectado?"),
            ("via_ip_phone", "O computador está conectado via telefone IP?"),
            ("phone_connected", "O telefone IP está ligado e possui conectividade?"),
        ):
            self.network_checks[key] = self.choice_field(layout, label, ("Sim", "Não"))
        sites = QLabel("O computador consegue acessar:")
        sites.setObjectName("templatesFieldLabel")
        layout.addWidget(sites)
        self.network_sites = {}
        for label in ("Intranet", "Internet", "Nenhum"):
            checkbox = QCheckBox(label)
            checkbox.setAccessibleName(f"Acesso a {label}")
            layout.addWidget(checkbox)
            self.network_sites[label] = checkbox
            checkbox.toggled.connect(lambda checked, choice=label: self.update_network_sites(choice, checked))
        section = QLabel("2. Localização")
        section.setObjectName("templatesSection")
        layout.addWidget(section)
        self.network_location, self.network_sector_status, self.network_place = self.location_fields(layout)
        return widget

    def update_network_sites(self, choice, checked):
        if not checked:
            return
        conflicting = ("Intranet", "Internet") if choice == "Nenhum" else ("Nenhum",)
        for key in conflicting:
            self.network_sites[key].setChecked(False)

    def show_list(self):
        self.editing_entry = None
        self.title.setText("MEUS TEMPLATES")
        self.back_button.hide()
        self.saved_open.setText(f"Templates salvos  •  {len(load_saved_templates(self.saved_path))}")
        self.stack.setCurrentIndex(0)
        self.resize_for_section(510)

    def go_back(self):
        if self.editing_entry is not None:
            self.show_saved()
        else:
            self.show_list()

    def show_form(self, kind):
        self.editing_entry = None
        self.kind = kind
        self._loaded_escalation_draft = False
        self.title.setText({
            "closure": "FECHAMENTO", "escalation": "ESCALONAMENTO",
            "wifi": "VERIFICAÇÃO WI-FI", "installation": "INSTALAÇÃO PADRÃO",
            "no_network": "ESTAÇÃO SEM REDE/INTERNET",
        }[kind])
        for form_kind, widget in self.forms.items():
            widget.setVisible(form_kind == kind)
        self.back_button.show()
        self.stack.setCurrentIndex(1)
        self.resize_for_section(790)
        self.editor_scroll.verticalScrollBar().setValue(0)
        self.update_scroll_status()
        {
            "closure": self.analysis, "escalation": self.request,
            "wifi": self.wifi_user_type, "installation": self.install_request,
            "no_network": self.network_checks["other_devices"],
        }[kind].setFocus()

    def show_saved(self):
        self.editing_entry = None
        self.title.setText("TEMPLATES SALVOS")
        self.back_button.show()
        self.render_saved_rows()
        self.stack.setCurrentIndex(2)
        self.resize_for_section(700)
        self.saved_search.setFocus()

    @staticmethod
    def _search_key(value):
        return "".join(
            character for character in unicodedata.normalize("NFKD", str(value).casefold())
            if not unicodedata.combining(character)
        )

    def render_saved_rows(self, *_args):
        layout = self.saved_rows
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        query = self._search_key(self.saved_search.text().strip())
        entries = [entry for entry in load_saved_templates(self.saved_path)
                   if query in self._search_key(entry["name"])]
        if not entries:
            hint = QLabel(
                "Nenhum template corresponde à busca." if query
                else "Nenhum template salvo. Preencha um modelo e use o ícone de salvar."
            )
            hint.setObjectName("templatesHint")
            hint.setWordWrap(True)
            layout.addWidget(hint)
        for category, kinds in (("Fechamento", {"closure"}),
                                ("Escalonamento", {"escalation", "wifi", "installation", "no_network"})):
            group = [entry for entry in entries if entry["kind"] in kinds]
            if not group:
                continue
            heading = QLabel(f"{category}  •  {len(group)}")
            heading.setObjectName("templatesSection")
            layout.addWidget(heading)
            for entry in group:
                self.add_saved_row(layout, entry)
        layout.addStretch(1)

    def add_saved_row(self, layout, entry):
        row = QFrame()
        row.setObjectName("templatesSavedRow")
        line = QHBoxLayout(row)
        line.setContentsMargins(5, 4, 5, 4)
        label = QPushButton(entry["name"])
        label.setObjectName("templatesSavedItem")
        label.setToolTip("Abrir e completar a localização" if entry.get("draft") and entry["kind"] != "closure"
                         else "Copiar o HTML deste template")
        label.setAccessibleName(f'Abrir template {entry["name"]}')
        label.clicked.connect(
            lambda _checked=False, selected=entry: self.copy_saved(selected)
        )
        line.addWidget(label, 1)
        edit = QPushButton("✎")
        edit.setObjectName("templatesSavedEdit")
        edit.setFixedSize(28, 28)
        edit.setToolTip(f'Editar {entry["name"]}')
        edit.setAccessibleName(f'Editar template {entry["name"]}')
        edit.clicked.connect(
            lambda _checked=False, selected=entry: self.edit_saved(selected)
        )
        line.addWidget(edit)
        remove = QPushButton("×")
        remove.setObjectName("templatesSavedDelete")
        remove.setFixedSize(28, 28)
        remove.setToolTip(f'Excluir {entry["name"]}')
        remove.setAccessibleName(f'Excluir template {entry["name"]}')
        remove.clicked.connect(
            lambda _checked=False, selected=entry: self.remove_saved(selected)
        )
        line.addWidget(remove)
        layout.addWidget(row)

    def edit_saved(self, entry):
        """Reabre os campos salvos; modelos antigos sem campos mantêm edição direta do HTML."""
        kind = entry["kind"]
        draft = entry.get("draft")
        if kind == "closure" and draft is None:
            draft = extract_closure_fields(entry["html"])
        if isinstance(draft, list):
            self.show_form(kind)
            self.clear_current()
            if self.restore_draft(draft):
                self.editing_entry = entry
                return
        self.editing_entry = entry
        self.title.setText("EDITAR HTML SALVO")
        self.back_button.show()
        self.legacy_html.setPlainText(entry["html"])
        self.stack.setCurrentIndex(3)
        self.resize_for_section(790)
        self.legacy_html.setFocus()

    def save_legacy_html(self):
        entry = self.editing_entry
        if not entry:
            return
        source = self.legacy_html.toPlainText().strip()
        name, accepted = QInputDialog.getText(
            self, "Atualizar template", "Nome do template:", QLineEdit.Normal, entry["name"],
        )
        if not accepted:
            return
        try:
            update_template(self.saved_path, entry["id"], name, source, entry["kind"])
        except (ValueError, OSError) as exc:
            QMessageBox.warning(self, "Template", str(exc))
            return
        self.show_saved()

    def copy_saved(self, entry):
        if entry["kind"] != "closure" and entry.get("draft"):
            self.show_form(entry["kind"])
            self.clear_current()
            self.restore_draft(entry["draft"])
            self._clear_location(entry["kind"])
            self._loaded_escalation_draft = True
            self.editor_scroll.verticalScrollBar().setValue(0)
            return
        QApplication.clipboard().setText(entry["html"])
        self.remember_copy(entry["name"], entry["kind"], entry["html"])
        self.hide()
        self.copied.emit(entry["name"])

    def remove_saved(self, entry):
        answer = QMessageBox.question(
            self, "Excluir template", f'Excluir o template “{entry["name"]}”?'
        )
        if answer != QMessageBox.Yes:
            return
        if not delete_template(self.saved_path, entry["id"]):
            QMessageBox.warning(self, "Template", "Não foi possível excluir o template.")
            return
        self.show_saved()

    def resize_for_section(self, desired_height):
        if not self.isVisible():
            return
        screen = QApplication.screenAt(self.pos() + QPoint(10, 10)) or QApplication.primaryScreen()
        bounds = screen.availableGeometry()
        height = min(desired_height, bounds.height() - 24)
        self.resize(self.width(), height)
        y = self.anchor_y or self.y()
        self.move(self.x(), max(bounds.top() + 12, min(y, bounds.bottom() - height - 11)))

    def _source(self):
        name, role = self.signature_provider()
        if self.kind == "closure":
            source = render_closure(
                self.analysis.toPlainText(), self.actions.toPlainText(), self.result.toPlainText(),
                name, role,
            )
        elif self.kind == "escalation":
            source = render_escalation(
                self.request.toPlainText(), self.treatment.toPlainText(),
                **{key: field.text() for key, field in self.location.items()},
                sector_status=self.selection(self.sector_status),
                place=self.selection(self.place), name=name, role=role,
            )
        elif self.kind == "wifi":
            source = render_wifi_checklist(
                user_type=self.selection(self.wifi_user_type), user_other=self.wifi_user_other.text(),
                event_time=self.wifi_time.text(), error_message=self.wifi_error.toPlainText(),
                equipment=self.selection(self.wifi_equipment), equipment_model=self.wifi_model.text(),
                operating_system=self.selection(self.wifi_os), os_other=self.wifi_os_other.text(),
                clearpass=self.selection(self.wifi_clearpass), auth_error=self.selection(self.wifi_auth_error),
                auth_error_details=self.wifi_auth_details.toPlainText(),
                navigates=self.selection(self.wifi_navigates),
                corrective_actions=tuple(label for label, box in self.wifi_corrective.items()
                                         if box.isChecked()),
                corrective_other=self.wifi_corrective_other.text(),
                signal=self.selection(self.wifi_signal), access_point=self.wifi_ap.text(),
                **{key: field.text() for key, field in self.wifi_location.items()},
                sector_status=self.selection(self.wifi_sector_status),
                place=self.selection(self.wifi_place), name=name, role=role,
            )
        elif self.kind == "installation":
            source = render_standard_installation(
                self.install_request.toPlainText(), self.install_treatment.toPlainText(),
                reason=self.selection(self.install_reason), reason_other=self.install_reason_other.text(),
                authorized=self.selection(self.install_authorized),
                shared_micro=self.selection(self.install_shared), backup=self.selection(self.install_backup),
                **{key: field.text() for key, field in self.install_location.items()},
                sector_status=self.selection(self.install_sector_status),
                place=self.selection(self.install_place), name=name, role=role,
            )
        else:
            source = render_no_network(
                **{key: self.selection(field) for key, field in self.network_checks.items()},
                access_sites=tuple(label for label, box in self.network_sites.items() if box.isChecked()),
                **{key: field.text() for key, field in self.network_location.items()},
                sector_status=self.selection(self.network_sector_status),
                place=self.selection(self.network_place), name=name, role=role,
            )
        return source, self.title.text().title()

    def _collect(self):
        try:
            return self._source()
        except ValueError as exc:
            QMessageBox.warning(self, "Template incompleto", str(exc))
            return None

    def save_current(self):
        result = self._collect()
        if result is None:
            return
        source, label = result
        previous = self.editing_entry
        name, accepted = QInputDialog.getText(
            self, "Atualizar template" if previous else "Salvar template", "Nome do template:",
            QLineEdit.Normal, previous["name"] if previous else label,
        )
        if not accepted:
            return
        try:
            draft = self.capture_draft()
            if previous:
                update_template(self.saved_path, previous["id"], name, source, self.kind, draft=draft)
            else:
                save_template(self.saved_path, name, source, self.kind, draft=draft)
        except (ValueError, OSError) as exc:
            QMessageBox.warning(self, "Template", str(exc))
            return
        self.clear_current()
        if not self.isVisible():
            self.show()
        self.show_saved()

    def clear_current(self):
        widget = self.forms[self.kind]
        for field in widget.findChildren(QTextEdit):
            field.clear()
        for field in widget.findChildren(QLineEdit):
            field.clear()
        for field in widget.findChildren(CheckChoice):
            field.setCurrentIndex(0)
        for field in widget.findChildren(QCheckBox):
            field.setChecked(False)

    def _clear_location(self, kind):
        fields = {
            "escalation": (self.location, self.sector_status, self.place),
            "wifi": (self.wifi_location, self.wifi_sector_status, self.wifi_place),
            "installation": (self.install_location, self.install_sector_status, self.install_place),
            "no_network": (self.network_location, self.network_sector_status, self.network_place),
        }
        location, status, place = fields[kind]
        for field in location.values():
            field.clear()
        status.setCurrentIndex(0)
        place.setCurrentIndex(0)
        location["sector"].setFocus()

    def capture_draft(self):
        """Guarda o formulário estruturado; a localização é informada em cada uso."""
        fields = self._draft_fields()
        result = []
        for field in fields:
            if isinstance(field, QTextEdit):
                value = field.toPlainText()
            elif isinstance(field, QLineEdit):
                value = field.text()
            elif isinstance(field, CheckChoice):
                value = field.currentIndex()
            else:
                value = field.isChecked()
            result.append(value)
        return result

    def restore_draft(self, draft):
        fields = self._draft_fields()
        if not isinstance(draft, list) or len(draft) != len(fields):
            return False
        try:
            for field, value in zip(fields, draft):
                if isinstance(field, QTextEdit):
                    field.setPlainText(str(value))
                elif isinstance(field, QLineEdit):
                    field.setText(str(value))
                elif isinstance(field, CheckChoice):
                    field.setCurrentIndex(int(value))
                else:
                    field.setChecked(bool(value))
        except (TypeError, ValueError):
            return False
        return True

    def _draft_fields(self):
        return [field for field in self.forms[self.kind].findChildren(QWidget)
                if isinstance(field, (QTextEdit, QLineEdit, CheckChoice, QCheckBox))
                and not (isinstance(field, QCheckBox) and isinstance(field.parent(), CheckChoice))]

    def finish(self):
        if self._loaded_escalation_draft:
            location = {
                "escalation": (self.location, self.place),
                "wifi": (self.wifi_location, self.wifi_place),
                "installation": (self.install_location, self.install_place),
                "no_network": (self.network_location, self.network_place),
            }
            fields, place = location[self.kind]
            if not fields["sector"].text().strip() or not self.selection(place):
                QMessageBox.warning(
                    self, "Localização pendente",
                    "Informe o setor e selecione o local do atendimento antes de copiar o HTML.",
                )
                fields["sector"].setFocus()
                return
        result = self._collect()
        if result is not None:
            self._copy_result(result)

    def _copy_result(self, result):
        source, label = result
        QApplication.clipboard().setText(source)
        self.remember_copy(label, self.kind, source)
        self.hide()
        self.clear_current()
        self.editing_entry = None
        self.copied.emit(label)
