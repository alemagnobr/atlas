"""Componentes visuais reutilizáveis do Atlas."""

