from __future__ import annotations

from PySide6.QtCore import QEvent
from PySide6.QtWidgets import QComboBox, QFrame


class NoWheelComboBox(QComboBox):
    """Evita alterações acidentais pelo scroll; teclado e clique continuam ativos."""

    def wheelEvent(self, event):
        event.ignore()


def section_separator() -> QFrame:
    separator = QFrame()
    separator.setObjectName("sectionSeparator")
    separator.setFixedHeight(2)
    separator.setFrameShape(QFrame.NoFrame)
    return separator

