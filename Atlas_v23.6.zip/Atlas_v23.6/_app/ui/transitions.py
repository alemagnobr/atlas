"""Transições visuais reutilizáveis e não bloqueantes do ATLAS."""

from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, Qt, QTimer
from PySide6.QtGui import QPainter, QPixmap
from PySide6.QtWidgets import QGraphicsOpacityEffect, QWidget


class _ThemeSnapshotOverlay(QWidget):
    """Quadro congelado do tema anterior, imune às mudanças globais de QSS."""

    def __init__(self, pixmap: QPixmap, parent: QWidget):
        super().__init__(parent)
        self._pixmap = pixmap
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setGeometry(parent.rect())

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        painter.drawPixmap(self.rect(), self._pixmap)


def fade_theme_change(
    owner: QWidget,
    target: QWidget,
    apply_theme: Callable[[], None],
    completed: Callable[[], None],
    *,
    duration_ms: int = 420,
    apply_delay_ms: int = 0,
) -> None:
    """Faz crossfade do quadro antigo para o novo sem apagar o conteúdo."""
    token = object()
    owner._theme_transition_token = token
    previous_overlay = getattr(owner, "_theme_transition_overlay", None)
    if previous_overlay is not None:
        previous_overlay.hide()
        previous_overlay.deleteLater()

    snapshot = target.grab()
    if snapshot.isNull():
        try:
            apply_theme()
        finally:
            owner._theme_transition_token = None
            completed()
        return

    overlay = _ThemeSnapshotOverlay(snapshot, target)
    overlay.show()
    overlay.raise_()
    owner._theme_transition_overlay = overlay

    effect = QGraphicsOpacityEffect(overlay)
    effect.setOpacity(1.0)
    overlay.setGraphicsEffect(effect)
    owner._theme_transition_effect = effect

    def finish_once() -> None:
        if getattr(owner, "_theme_transition_token", None) is not token:
            return
        owner._theme_transition_token = None
        overlay.hide()
        overlay.setGraphicsEffect(None)
        overlay.deleteLater()
        owner._theme_transition_overlay = None
        owner._theme_transition_effect = None
        completed()

    def reveal_new_theme() -> None:
        if getattr(owner, "_theme_transition_token", None) is not token:
            return
        fade = QPropertyAnimation(effect, b"opacity", owner)
        fade.setDuration(duration_ms)
        fade.setStartValue(1.0)
        fade.setEndValue(0.0)
        fade.setEasingCurve(QEasingCurve.Type.InOutCubic)
        fade.finished.connect(finish_once)
        owner._theme_crossfade = fade
        fade.start()

    def prepare_new_theme() -> None:
        if getattr(owner, "_theme_transition_token", None) is not token:
            return
        try:
            apply_theme()
            target.update()
        except Exception:
            finish_once()
            raise
        # Um quadro dá ao Qt tempo para desenhar o novo QSS atrás da captura.
        # A dissolução começa somente depois disso, evitando clarão ou vazio.
        QTimer.singleShot(24, reveal_new_theme)

    if apply_delay_ms > 0:
        # Na sessão logada, devolve primeiro um quadro ao seletor. Assim o
        # movimento começa imediatamente antes do recálculo do QSS volumoso.
        QTimer.singleShot(apply_delay_ms, prepare_new_theme)
    else:
        prepare_new_theme()
    QTimer.singleShot(duration_ms + 900, finish_once)
