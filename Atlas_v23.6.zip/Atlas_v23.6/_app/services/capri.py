from __future__ import annotations

import json


def build_ticket_payload(*, scope: str, display_name: str, operator_login: str,
                         date_from: str, date_to: str, cache_path: str,
                         refresh_existing: bool = False,
                         recheck_numbers: list[str] | None = None) -> str:
    """Monta o contrato estável enviado ao bridge de chamados do Capri."""
    return json.dumps({
        "scope": scope,
        "display_name": display_name,
        "operator_login": operator_login,
        "date_from": date_from,
        "date_to": date_to,
        "status": "all",
        "cache_path": cache_path,
        "refresh_existing": refresh_existing,
        "recheck_numbers": recheck_numbers or [],
    }, ensure_ascii=False, separators=(",", ":"))


def build_user_ticket_preview_payload(*, login: str, display_name: str) -> str:
    """Monta consulta efêmera dos 25 chamados mais recentes de um usuário."""
    return json.dumps({
        "scope": "customer",
        "display_name": display_name,
        "customer_login": login,
        "date_from": "",
        "date_to": "",
        "status": "all",
        "cache_path": "",
        "refresh_existing": True,
        "preview_only": True,
        "limit": 25,
    }, ensure_ascii=False, separators=(",", ":"))
