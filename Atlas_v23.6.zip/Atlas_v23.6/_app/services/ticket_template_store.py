"""Modelos pessoais persistentes no perfil Windows do operador."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from storage.json_store import load_json, save_json

KINDS = {"closure", "escalation", "wifi", "installation", "no_network"}
MAX_SAVED = 100
MAX_HTML = 100_000


def load_saved_templates(path: Path) -> list[dict[str, str]]:
    data = load_json(Path(path))
    source = data.get("templates", [])
    if not isinstance(source, list):
        return []
    items = []
    for entry in source[:MAX_SAVED]:
        if not isinstance(entry, dict):
            continue
        name, html, identity, kind = (str(entry.get(key) or "") for key in ("name", "html", "id", "kind"))
        if (not name.strip() or len(name) > 80 or not identity
                or kind not in KINDS or not html.startswith("<") or len(html) > MAX_HTML):
            continue
        draft = entry.get("draft")
        if not isinstance(draft, list) or len(draft) > 100 or any(
            not isinstance(value, (str, int, bool)) or len(str(value)) > 5000 for value in draft
        ):
            draft = None
        items.append({"name": name, "html": html, "id": identity, "kind": kind,
                      "saved_at": str(entry.get("saved_at") or ""), "draft": draft})
    return items


def save_template(path: Path, name: str, html: str, kind: str, *, draft=None) -> dict:
    name = str(name).strip()
    if not name or len(name) > 80:
        raise ValueError("Informe um nome com até 80 caracteres.")
    if kind not in KINDS or not str(html).startswith("<") or len(html) > MAX_HTML:
        raise ValueError("O HTML do template é inválido ou excede o limite.")
    if draft is not None and (
        not isinstance(draft, list) or len(draft) > 100 or any(
            not isinstance(value, (str, int, bool)) or len(str(value)) > 5000 for value in draft
        )
    ):
        raise ValueError("O preenchimento do template é inválido ou excede o limite.")
    items = load_saved_templates(path)
    if len(items) >= MAX_SAVED:
        raise ValueError("Limite de 100 templates salvos atingido.")
    if any(item["name"].casefold() == name.casefold() for item in items):
        raise ValueError("Já existe um template salvo com esse nome.")
    entry = {
        "id": uuid4().hex, "name": name, "kind": kind, "html": html,
        "draft": draft,
        "saved_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    if not save_json(Path(path), {"version": 1, "templates": [*items, entry]}):
        raise OSError("Não foi possível salvar o template no perfil Windows.")
    return entry


def update_template(path: Path, identity: str, name: str, html: str, kind: str, *, draft=None) -> dict:
    """Atualiza o mesmo registro, preservando seu ID e sem apagar o anterior se a gravação falhar."""
    name = str(name).strip()
    if not name or len(name) > 80:
        raise ValueError("Informe um nome com até 80 caracteres.")
    if kind not in KINDS or not str(html).startswith("<") or len(html) > MAX_HTML:
        raise ValueError("O HTML do template é inválido ou excede o limite.")
    if draft is not None and (
        not isinstance(draft, list) or len(draft) > 100 or any(
            not isinstance(value, (str, int, bool)) or len(str(value)) > 5000 for value in draft
        )
    ):
        raise ValueError("O preenchimento do template é inválido ou excede o limite.")
    items = load_saved_templates(path)
    index = next((i for i, item in enumerate(items) if item["id"] == identity), None)
    if index is None:
        raise ValueError("O template salvo não foi encontrado.")
    if any(item["id"] != identity and item["name"].casefold() == name.casefold() for item in items):
        raise ValueError("Já existe um template salvo com esse nome.")
    updated = dict(items[index])
    updated.update(name=name, html=html, kind=kind, draft=draft,
                   updated_at=datetime.now(timezone.utc).isoformat(timespec="seconds"))
    items[index] = updated
    if not save_json(Path(path), {"version": 1, "templates": items}):
        raise OSError("Não foi possível atualizar o template no perfil Windows.")
    return updated


def delete_template(path: Path, identity: str) -> bool:
    items = load_saved_templates(path)
    kept = [item for item in items if item["id"] != identity]
    return len(kept) < len(items) and save_json(Path(path), {"version": 1, "templates": kept})
