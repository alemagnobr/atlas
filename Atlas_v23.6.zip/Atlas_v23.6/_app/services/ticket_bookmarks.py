"""Favoritos e monitorados; somente chamados escolhidos fora do catálogo têm cópia local."""

from __future__ import annotations

import re
from pathlib import Path

from storage.json_store import load_json, save_json

KINDS = ("favorites", "monitored")
MAX_PER_LIST = 300
SNAPSHOT_FIELDS = {
    "number": 20, "title": 500, "state": 120, "state_kind": 40,
    "queue": 300, "category": 300, "customer": 300, "creator": 300,
    "owner": 300, "responsible": 300, "created": 80, "changed": 80,
    "content": 6000, "url": 1000, "state_verified_at": 80,
}


def ticket_number(value: object) -> str:
    number = re.sub(r"\D", "", str(value or ""))
    return number if 6 <= len(number) <= 20 else ""


def load_bookmarks(path: Path) -> dict:
    data = load_json(Path(path))
    result = {}
    for kind in KINDS:
        values = data.get(kind, [])
        result[kind] = {ticket_number(value) for value in values[:MAX_PER_LIST]
                        if ticket_number(value)} if isinstance(values, list) else set()
    referenced = result["favorites"] | result["monitored"]
    source = data.get("snapshots", {})
    result["snapshots"] = {
        number: snapshot_ticket(item) for raw_number, item in source.items()
        if isinstance(item, dict)
        and (number := ticket_number(raw_number)) in referenced
        and number == ticket_number(item.get("number") or item.get("id"))
    } if isinstance(source, dict) else {}
    return result


def snapshot_ticket(ticket: dict) -> dict:
    """Guarda só os campos necessários para localizar, ler e conferir o chamado escolhido."""
    if not isinstance(ticket, dict):
        return {}
    number = ticket_number(ticket.get("number") or ticket.get("id"))
    if not number:
        return {}
    snapshot = {"number": number}
    for key, limit in SNAPSHOT_FIELDS.items():
        if key == "number":
            continue
        value = str(ticket.get(key) or "").strip()[:limit]
        if value and (key != "url" or value.startswith("https://capri.senado.leg.br/")):
            snapshot[key] = value
    return snapshot


def save_bookmarks(path: Path, saved: dict) -> bool:
    referenced = saved["favorites"] | saved["monitored"]
    snapshots = {number: snapshot_ticket(item) for number, item in saved.get("snapshots", {}).items()
                 if number in referenced and isinstance(item, dict)}
    return save_json(Path(path), {
        "version": 2, **{kind: sorted(saved[kind]) for kind in KINDS},
        "snapshots": snapshots,
    })


def toggle_bookmark(path: Path, kind: str, number: str, ticket: dict | None = None) -> tuple[bool, dict]:
    if kind not in KINDS:
        raise ValueError("Lista de chamados inválida.")
    number = ticket_number(number)
    if not number:
        raise ValueError("O chamado não tem um número válido.")
    saved = load_bookmarks(path)
    items = saved[kind]
    if number in items:
        items.remove(number)
        if number not in saved["favorites"] | saved["monitored"]:
            saved["snapshots"].pop(number, None)
        added = False
    else:
        if len(items) >= MAX_PER_LIST:
            raise ValueError("O limite de chamados desta lista foi atingido.")
        items.add(number)
        if ticket is not None:
            snapshot = snapshot_ticket(ticket)
            if snapshot.get("number") != number:
                raise ValueError("Os dados do chamado não conferem com o número selecionado.")
            saved["snapshots"].setdefault(number, snapshot)
        added = True
    if not save_bookmarks(path, saved):
        raise OSError("Não foi possível salvar esta lista no perfil Windows.")
    return added, saved


def mapped_bookmarks(catalog: dict, saved: dict, kind: str) -> list[dict]:
    """Prefere o catálogo mapeado, complementado apenas por seleções explícitas do usuário."""
    if kind not in KINDS:
        return []
    mapped = [item for item in catalog.get("items", []) if isinstance(item, dict)
              and ticket_number(item.get("number") or item.get("id")) in saved[kind]]
    seen = {ticket_number(item.get("number") or item.get("id")) for item in mapped}
    mapped.extend(item for number, item in saved.get("snapshots", {}).items()
                  if number in saved[kind] and number not in seen)
    return mapped
