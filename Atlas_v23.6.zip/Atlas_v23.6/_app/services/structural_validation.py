"""Integridade e manutenção conservadora, independentes da interface do Atlas."""

from __future__ import annotations

import ast
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path


VALIDATION_INTERVALS = (
    ("disabled", "Desativada", 0),
    ("daily", "Diariamente", 1),
    ("weekly", "Semanalmente (recomendado)", 7),
    ("monthly", "Mensalmente", 30),
)


def default_validation_settings() -> dict:
    return {
        "interval": "weekly",
        "safe_cleanup": True,
        "last_checked": "",
        "last_status": "never",
        "last_summary": "Ainda não executada.",
        "last_cleanup_files": 0,
        "last_cleanup_bytes": 0,
    }


def validation_is_due(settings: dict, now: datetime | None = None) -> bool:
    interval = str(settings.get("interval") or "weekly")
    days = next((days for key, _label, days in VALIDATION_INTERVALS if key == interval), 7)
    if days <= 0:
        return False
    raw = str(settings.get("last_checked") or "").strip()
    if not raw:
        return True
    try:
        checked = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if checked.tzinfo is None:
            checked = checked.replace(tzinfo=timezone.utc)
    except ValueError:
        return True
    current = now or datetime.now(timezone.utc)
    return current >= checked + timedelta(days=days)


def validate_installation(root: Path, expected_version: str) -> dict:
    """Verifica estrutura, sintaxe e contratos locais sem acessar rede, AD ou Capri."""
    root = Path(root)
    issues: list[str] = []
    checked = 0

    source_mode = (root / "main.py").is_file()
    required = [
        "scripts/bridge.ps1", "scripts/bridge_launcher.ps1", "scripts/remote_message.ps1", "scripts/remote_inventory.ps1",
        "data/escalation_targets.json",
        "assets/logo_full_light.png", "assets/logo_full_dark.png",
        "assets/logo_compact_light.png", "assets/logo_compact_dark.png",
        "data/orientations_catalog.json",
    ]
    if source_mode:
        required.extend((
            "main.py", "run.bat", "services/capri.py", "storage/json_store.py",
            "ui/widgets.py", "ui/transitions.py",
        ))
    for relative in required:
        checked += 1
        path = root / relative
        if not path.is_file() or path.stat().st_size == 0:
            issues.append(f"Arquivo obrigatório ausente ou vazio: {relative}")

    python_files = [] if not source_mode else (
        sorted(root.glob("*.py")) + sorted((root / "services").glob("*.py"))
        + sorted((root / "storage").glob("*.py")) + sorted((root / "ui").glob("*.py"))
    )
    for path in python_files:
        checked += 1
        try:
            ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        except (OSError, SyntaxError, UnicodeError) as exc:
            issues.append(f"Módulo inválido: {path.relative_to(root)} ({exc})")

    for path in sorted((root / "data").glob("*.json")):
        checked += 1
        try:
            json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, ValueError, UnicodeError) as exc:
            issues.append(f"Catálogo inválido: {path.relative_to(root)} ({exc})")

    version_contracts = {
        "main.py": f'VERSION = "{expected_version}"',
        "run.bat": f"AtlasSuporteAvancado\\v{expected_version}",
        "installer/Atlas_Setup.iss": f'#define MyAppVersion "{expected_version}"',
    }
    for relative, marker in version_contracts.items():
        path = root / relative
        if not path.exists():
            continue
        checked += 1
        try:
            if marker not in path.read_text(encoding="utf-8-sig"):
                issues.append(f"Versão divergente em: {relative}")
        except (OSError, UnicodeError) as exc:
            issues.append(f"Não foi possível ler: {relative} ({exc})")

    status = "ok" if not issues else "attention"
    summary = (
        f"Estrutura íntegra: {checked} verificações concluídas."
        if not issues else f"Validação concluída com {len(issues)} ocorrência(s)."
    )
    return {
        "last_checked": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "last_status": status,
        "last_summary": summary,
        "checked_items": checked,
        "issues": issues,
    }


def cleanup_regenerable_files(
    storage_root: Path,
    *,
    now: datetime | None = None,
    minimum_age: timedelta = timedelta(hours=24),
) -> dict:
    """Remove somente temporários abandonados no armazenamento próprio do Atlas.

    Os arquivos persistentes (catálogos, preferências, credenciais, sessões e
    históricos) nunca entram na seleção. ``*.tmp`` é o formato intermediário
    usado pelas gravações atômicas do Atlas e só é removido depois de envelhecer,
    evitando disputa com uma escrita que ainda esteja em andamento.
    """
    root = Path(storage_root)
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None:
        current = current.replace(tzinfo=timezone.utc)
    removed_files = 0
    removed_bytes = 0
    skipped_files = 0
    issues: list[str] = []
    if not root.is_dir():
        return {
            "cleanup_files": 0,
            "cleanup_bytes": 0,
            "cleanup_skipped": 0,
            "cleanup_issues": [],
        }

    try:
        root_resolved = root.resolve()
    except OSError:
        root_resolved = root.absolute()
    try:
        candidates = list(root.rglob("*.tmp"))
    except OSError as exc:
        return {
            "cleanup_files": 0,
            "cleanup_bytes": 0,
            "cleanup_skipped": 0,
            "cleanup_issues": [f"Não foi possível examinar temporários: {exc}"],
        }

    for path in candidates:
        try:
            resolved = path.resolve()
            if path.is_symlink() or root_resolved not in resolved.parents:
                skipped_files += 1
                continue
            stat = path.stat()
            if not path.is_file():
                skipped_files += 1
                continue
            modified = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)
            if current - modified < minimum_age:
                skipped_files += 1
                continue
            size = max(0, int(stat.st_size))
            path.unlink()
            removed_files += 1
            removed_bytes += size
        except OSError as exc:
            issues.append(f"Temporário preservado ({path.name}): {exc}")

    return {
        "cleanup_files": removed_files,
        "cleanup_bytes": removed_bytes,
        "cleanup_skipped": skipped_files,
        "cleanup_issues": issues,
    }
