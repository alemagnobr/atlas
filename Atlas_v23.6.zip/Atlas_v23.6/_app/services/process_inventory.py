"""Organização dos processos transitórios do usuário remoto."""


def group_processes_by_memory(items: list[dict]) -> list[tuple[str, list[dict], float]]:
    """Agrupa por software e ordena os totais e instâncias por memória decrescente."""
    groups: dict[str, list[dict]] = {}
    for item in items:
        groups.setdefault(str(item.get("name") or "Processo desconhecido").casefold(), []).append(item)
    ordered = []
    for name, processes in groups.items():
        processes = sorted(
            processes,
            key=lambda item: (-float(item.get("memory_mb") or 0), int(item.get("pid") or 0)),
        )
        total = sum(float(item.get("memory_mb") or 0) for item in processes)
        ordered.append((str(processes[0].get("name") or "Processo desconhecido"), processes, total))
    return sorted(ordered, key=lambda group: (-group[2], group[0].casefold()))
