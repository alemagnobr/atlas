"""Regras da escala de apoio técnico e da ordem de escalonamento."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def brasilia_now() -> datetime:
    try:
        zone = ZoneInfo("America/Sao_Paulo")
    except ZoneInfoNotFoundError:
        # Windows sem tzdata: Brasília está em UTC−03 neste calendário.
        zone = timezone(timedelta(hours=-3))
    return datetime.now(zone)


def on_duty(target: dict, now: datetime | None = None) -> bool:
    """Compara a escala à hora de Brasília, independentemente do fuso do micro."""
    current = now or brasilia_now()
    minutes = current.hour * 60 + current.minute

    def parse(value: str) -> int:
        hour, minute = map(int, value.split(":"))
        return hour * 60 + minute

    start, end = parse(target["start"]), parse(target["end"])
    in_shift = start <= minutes < end if start <= end else minutes >= start or minutes < end
    if not in_shift:
        return False
    if target.get("lunch_start") and target.get("lunch_end"):
        lunch_start, lunch_end = parse(target["lunch_start"]), parse(target["lunch_end"])
        if lunch_start <= minutes < lunch_end:
            return False
    return True


def may_escalate(target: dict, targets: list[dict], *, leader_contacted: bool,
                 reason: str, now: datetime | None = None) -> bool:
    """Usa somente a escala; supervisão exige contato prévio com o líder em turno."""
    if not on_duty(target, now):
        return False
    if target["key"] == "leader":
        return True
    leader = next((item for item in targets if item["key"] == "leader"), None)
    leader_on_duty = bool(leader and on_duty(leader, now))
    return not leader_on_duty or (leader_contacted and bool(reason.strip()))
