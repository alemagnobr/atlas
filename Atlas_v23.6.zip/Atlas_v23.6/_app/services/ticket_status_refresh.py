"""Seleção e reconciliação segura de estados de chamados já salvos."""

from __future__ import annotations

import re
from collections.abc import Callable, Iterable


VERIFIED_KINDS = frozenset({
    "open", "pending", "closed_success", "closed_unsuccessful",
    "closed_other", "rejected", "customer_cancelled",
})


def open_ticket_numbers(items: Iterable[dict], classify: Callable) -> list[str]:
    numbers = set()
    for item in items:
        if not isinstance(item, dict):
            continue
        if classify(item.get("state"), item.get("state_kind")) not in {"open", "pending"}:
            continue
        number = re.sub(r"\D", "", str(item.get("number") or item.get("id") or ""))
        if 6 <= len(number) <= 20:
            numbers.add(number)
    return sorted(numbers)


def apply_state_updates(tickets: dict[str, dict], updates: Iterable[dict],
                        classify: Callable, verified_at: str) -> tuple[int, list[tuple[str, str, str]]]:
    checked = 0
    changes = []
    for update in updates:
        if not isinstance(update, dict):
            continue
        number = re.sub(r"\D", "", str(update.get("number") or ""))
        ticket = tickets.get(number)
        state = str(update.get("state") or "").strip()
        kind = classify(state)
        if not ticket or not state or kind not in VERIFIED_KINDS:
            continue
        previous_state = str(ticket.get("state") or "").strip()
        previous_kind = classify(previous_state, ticket.get("state_kind"))
        checked += 1
        if previous_kind != kind or previous_state != state:
            changes.append((number, previous_state, state))
        ticket.update(state=state, state_kind=kind, closed=kind.startswith("closed_"),
                      successful=kind == "closed_success", state_verified_at=verified_at)
    return checked, changes
