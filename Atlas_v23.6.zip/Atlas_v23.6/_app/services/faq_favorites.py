"""Favoritos pessoais de FAQ, independentes do catálogo reconstruível do Capri."""

from __future__ import annotations

import re
from pathlib import Path

from storage.json_store import load_json, save_json

MAX_FAVORITES = 200
CAPRI_PREFIX = "https://capri.senado.leg.br/"


def faq_number(value: object) -> str:
    return re.sub(r"\D", "", str(value or ""))[:20]


def load_favorites(path: Path) -> list[dict[str, str]]:
    source = load_json(Path(path)).get("items", [])
    if not isinstance(source, list):
        return []
    result = []
    seen = set()
    for raw in source[:MAX_FAVORITES]:
        if not isinstance(raw, dict):
            continue
        number = faq_number(raw.get("id"))
        title = str(raw.get("title") or "").strip()[:220]
        url = str(raw.get("url") or "").strip()[:2048]
        if number and number not in seen and url.lower().startswith(CAPRI_PREFIX):
            result.append({"id": number, "title": title or f"FAQ {number}", "url": url})
            seen.add(number)
    return result


def toggle_favorite(path: Path, faq: dict) -> tuple[bool, list[dict[str, str]]]:
    """Retorna (agora favorito, lista persistida); falha sem alterar a lista em memória."""
    items = load_favorites(path)
    number = faq_number(faq.get("id"))
    if not number:
        raise ValueError("Esta FAQ não possui número para ser favoritada.")
    was_saved = any(item["id"] == number for item in items)
    if was_saved:
        updated = [item for item in items if item["id"] != number]
    else:
        if len(items) >= MAX_FAVORITES:
            raise ValueError("O limite de 200 FAQs favoritas foi atingido.")
        url = str(faq.get("url") or "").strip()
        if not url.lower().startswith(CAPRI_PREFIX) or len(url) > 2048:
            raise ValueError("O endereço oficial desta FAQ não está disponível.")
        updated = [*items, {
            "id": number,
            "title": str(faq.get("title") or f"FAQ {number}").strip()[:220],
            "url": url,
        }]
    if not save_json(Path(path), {"version": 1, "items": updated}):
        raise OSError("Não foi possível salvar os favoritos no perfil Windows.")
    return not was_saved, updated
