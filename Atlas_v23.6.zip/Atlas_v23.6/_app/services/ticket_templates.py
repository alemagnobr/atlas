"""Modelos HTML para colar no editor de código-fonte do Capri.

O conteúdo digitado é texto simples. A conversão para HTML é feita apenas
na hora de copiar, preservando as quebras de linha e impedindo que valores
digitados alterem a estrutura do template.
"""

from __future__ import annotations

from html import escape, unescape
import re


ATTACHMENTS = (
    '<p><img alt="" height="29" src="https://capri.senado.leg.br/otrs/index.pl?'
    'Action=AgentTicketAttachment;Subaction=HTMLView;TicketID=881370;ArticleID=4547609;FileID=2"'
    ' width="110" />&nbsp; &nbsp;<img alt="" height="30"'
    ' src="https://capri.senado.leg.br/otrs/index.pl?'
    'Action=AgentTicketAttachment;Subaction=HTMLView;TicketID=881370;ArticleID=4547609;FileID=3"'
    ' width="383" /></p><p><img alt="" height="15"'
    ' src="https://capri.senado.leg.br/otrs/index.pl?'
    'Action=AgentTicketAttachment;Subaction=HTMLView;TicketID=881370;ArticleID=4547609;FileID=4"'
    ' width="567" /></p>'
)


def _filled(value: str, field: str) -> str:
    if not str(value).strip():
        raise ValueError(f"Preencha o campo {field}.")
    return escape(str(value).strip(), quote=True).replace("\r\n", "\n").replace("\n", "<br />")


def _optional(value: str) -> str:
    return escape(str(value).strip() or "Não informado", quote=True)


def _signature(name: str, role: str) -> str:
    safe_name = escape(str(name).strip() or "Nome não disponível no AD", quote=True)
    safe_role = escape(str(role).strip() or "Cargo não informado no AD", quote=True)
    return (
        '<p>Atenciosamente,</p><p>--<br /><strong><em>' + safe_name +
        '</em></strong><br /><em>' + safe_role +
        '<br />Senado Federal | PRODASEN | COATEN | SEARP'
        '<br />Ramal: (61) 3303- 2000</em></p>' + ATTACHMENTS
    )


def render_closure(analysis: str, actions: str, result: str, name: str, role: str) -> str:
    """Fechamento: três blocos editáveis, avaliação e assinatura do operador."""
    analysis_html = _filled(analysis, "Análise técnica")
    actions_html = _filled(actions, "Ações realizadas")
    result_html = _filled(result, "Resultado")
    return (
        '<div style="font-family:Arial,Helvetica,sans-serif; font-size:12px; color:#111827">'
        '<div style="font-size:12px">'
        '<div style="border:1px solid #e5e7eb; border-radius:10px; padding:10px 14px;'
        ' background:#fafafa; margin:10px 0 10px 0">'
        '<div style="border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px;'
        ' margin-bottom:8px; background:#ffffff">'
        '<div style="font-weight:bold; margin-bottom:4px">Análise técnica:</div>'
        '<div style="margin-left:40px">' + analysis_html + '</div></div>'
        '<div style="border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px;'
        ' margin-bottom:8px; background:#ffffff">'
        '<div style="font-weight:bold; margin-bottom:4px">Ações realizadas:</div>'
        '<div style="margin-left:40px">' + actions_html + '</div></div>'
        '<div style="border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px;'
        ' margin-bottom:8px; background:#ffffff">'
        '<div style="font-weight:bold; margin-bottom:4px">Resultado:</div>'
        '<div style="margin-left:40px">' + result_html + '</div></div>'
        '<div style="border:1px solid #f59e0b; border-radius:10px; padding:10px 12px;'
        ' background:#fffbeb; color:#92400e">'
        '<div style="font-weight:bold; margin-bottom:4px">Sua opinião é importante!</div>'
        '<div>Após o fechamento deste chamado, '
        '<em><u>você receberá um novo e-mail com um link para a pesquisa de satisfação</u></em>.'
        ' Sua participação é muito importante para melhorarmos continuamente nosso atendimento.'
        '<br /><br />Muito obrigado!</div></div></div>'
        + _signature(name, role) + '</div></div>'
    )


def extract_closure_fields(source: str) -> list[str] | None:
    """Recupera os três campos dos fechamentos antigos salvos apenas em HTML."""
    blocks = re.findall(r'<div style="margin-left:40px">(.*?)</div>', source, re.DOTALL)
    if len(blocks) != 3:
        return None
    return [unescape(re.sub(r"<br\s*/?>", "\n", block, flags=re.IGNORECASE))
            for block in blocks]


def _choice(options: tuple[str, ...], selected: str) -> str:
    if selected and selected not in options:
        raise ValueError("Seleção de localização inválida.")
    return "&nbsp;&nbsp; ".join(
        f'({"X" if option == selected else " "}) {escape(option)}' for option in options
    )


def render_escalation(
    request: str, treatment: str, *, sector: str = "", building: str = "",
    complement: str = "", reference: str = "", contact: str = "",
    sector_status: str = "", place: str = "", name: str = "", role: str = "",
) -> str:
    """Escalonamento: localização estruturada e opções convertidas para (X)."""
    request_html = _filled(request, "A solicitação")
    treatment_html = _filled(treatment, "A tratativa")
    location = "".join(
        f'<div>{label}:&nbsp;{_optional(value)}</div>'
        for label, value in (
            ("Setor", sector), ("Edifício", building), ("Complemento", complement),
            ("Ponto de referência", reference), ("Contato", contact),
        )
    )
    return (
        '<div style="font-size:12px; color:#000000; margin-bottom:8px">'
        '<strong>Prezados,</strong><br /><br /><strong>A solicitação</strong>:&nbsp;'
        + request_html +
        '<div style="border:1px solid #e5e7eb; border-radius:10px; padding:10px 14px;'
        ' background:#fafafa; margin:10px 0 10px 0">'
        '<div style="border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px;'
        ' margin-bottom:8px; background:#ffffff">'
        '<div style="font-weight:bold; margin-bottom:4px"><u>A tratativa</u></div>'
        '<div>' + treatment_html + '</div></div>'
        '<div style="border:1px solid #e5e7eb; border-radius:10px; padding:10px 12px;'
        ' background:#ffffff">'
        '<div style="font-weight:bold; margin-bottom:4px"><u>Localização</u></div>'
        + location +
        '<div style="margin-top:6px">Setor:&nbsp; '
        + _choice(("Aberto", "Fechado"), sector_status) + '</div>'
        '<div style="margin-top:4px">Local:&nbsp; '
        + _choice(("Teletrabalho", "Senado", "Externo"), place) + '</div>'
        '</div></div>' + _signature(name, role) + '</div>'
    )


def _checklist_box(title: str, content: str, hint: str = "", *, last: bool = False) -> str:
    margin = "" if last else " margin-bottom:8px;"
    helper = (
        '<div style="font-size:11px; color:#6b7280; margin-bottom:4px">'
        + hint + '</div>'
    ) if hint else ""
    return (
        '<div style="border:1px solid #e5e7eb; border-radius:10px;'
        ' padding:10px 12px;' + margin + ' background:#ffffff">'
        '<div style="font-weight:bold; margin-bottom:4px">' + title + '</div>'
        + helper + content + '</div>'
    )


def _many_choices(options: tuple[str, ...], selected: tuple[str, ...]) -> str:
    if not set(selected).issubset(options):
        raise ValueError("Seleção do checklist inválida.")
    return "&nbsp;&nbsp; ".join(
        f'({"X" if option in selected else " "}) {escape(option)}'
        for option in options
    )


def _location_html(
    sector: str, building: str, complement: str, reference: str, contact: str,
    sector_status: str, place: str, *, external: bool = False,
) -> str:
    parts = [
        f'<div>{label}:&nbsp;{_optional(value)}</div>'
        for label, value in (
            ("Setor", sector), ("Edifício", building), ("Complemento", complement),
            ("Ponto de referência", reference), ("Contato", contact),
        )
    ]
    place_options = ("Teletrabalho", "Senado", "Externo") if external else ("Teletrabalho", "Senado")
    parts.extend((
        '<div style="margin-top:6px">Setor:&nbsp; ' + _choice(("Aberto", "Fechado"), sector_status) + '</div>',
        '<div style="margin-top:4px">Local:&nbsp; ' + _choice(place_options, place) + '</div>',
    ))
    return "".join(parts)


def render_wifi_checklist(
    *, user_type: str = "", user_other: str = "", event_time: str = "",
    error_message: str = "", equipment: str = "", equipment_model: str = "",
    operating_system: str = "", os_other: str = "", clearpass: str = "",
    auth_error: str = "", auth_error_details: str = "", navigates: str = "",
    corrective_actions: tuple[str, ...] = (), corrective_other: str = "",
    signal: str = "", access_point: str = "", sector: str = "", building: str = "",
    complement: str = "", reference: str = "", contact: str = "",
    sector_status: str = "", place: str = "", name: str = "", role: str = "",
) -> str:
    """Checklist Wi-Fi com seleção e dados transcritos para os 12 blocos."""
    users = ("Cadastrado no AD", "Usuário da Câmara", "Autorizado sem conta no AD",
             "Visitante com CPF", "Visitante sem CPF", "Outros")
    if user_type and user_type not in users:
        raise ValueError("Tipo de usuário inválido.")
    if operating_system and operating_system not in ("Android", "iOS", "Windows", "MacOS", "Outro"):
        raise ValueError("Sistema operacional inválido.")
    if not set(corrective_actions).issubset((
        "Esquecer a Rede", "Reinicializar o Equipamento", "Troca de senha", "Outras",
    )):
        raise ValueError("Ação corretiva inválida.")
    body = [
        _checklist_box(
            "1. Tipo de usuário",
            '<div>' + _choice(users[:3], user_type if user_type in users[:3] else "") + '<br />'
            + _choice(users[3:], user_type if user_type in users[3:] else "") + '&nbsp;'
            + (escape(user_other.strip()) if user_type == "Outros" else "") + '</div>',
            "Indique o perfil do usuário que está tentando acessar a rede Wi-Fi.",
        ),
        _checklist_box(
            "2. Data e hora do evento",
            '<div>Data/hora:&nbsp; ' + _optional(event_time) + '</div>',
            "Informe quando ocorreu o problema (aproximado ou exato).",
        ),
        _checklist_box(
            "3. Mensagem de erro apresentada ao usuário",
            '<div>' + _optional(error_message).replace("\n", "<br />") + '</div>',
            "Copiar/transcrever exatamente a mensagem exibida ao usuário, se possível.",
        ),
        _checklist_box(
            "4. Modelo de equipamento",
            '<div>' + _choice(("Celular", "Tablet", "Notebook"), equipment) + '</div>'
            '<div style="margin-top:4px">Modelo/Marca (opcional):&nbsp;'
            + _optional(equipment_model) + '</div>',
        ),
        _checklist_box(
            "5. Sistema operacional",
            '<div>' + _choice(("Android", "iOS", "Windows", "MacOS"),
                              operating_system if operating_system != "Outro" else "")
            + '&nbsp;&nbsp; (' + ("X" if operating_system == "Outro" else " ") + ') Outro:&nbsp;'
            + (escape(os_other.strip()) if operating_system == "Outro" else "") + '</div>',
        ),
        _checklist_box(
            "6. Autenticação – página Clearpass",
            '<div>' + _choice(("SIM", "NÃO"), clearpass) + '</div>',
            'Acessa a página de autenticação Clearpass '
            '(<span style="font-family:Consolas,monospace">'
            'clearpass.senado.leg.br/guest/portal_login.php</span>)?',
        ),
        _checklist_box(
            "7. Erro no procedimento de autenticação",
            '<div>Apresenta erro no procedimento de autenticação?&nbsp;'
            + _choice(("SIM", "NÃO"), auth_error) + '</div>'
            '<div style="font-size:11px; color:#6b7280; margin-top:4px; margin-bottom:4px">'
            'Descreva o erro (passo em que ocorre, prints, etc.):</div>'
            '<div>' + _optional(auth_error_details).replace("\n", "<br />") + '</div>',
        ),
        _checklist_box(
            "8. Navegação após autenticação",
            '<div>Após autenticação, consegue navegar na rede?&nbsp;'
            + _choice(("SIM", "NÃO"), navigates) + '</div>',
        ),
        _checklist_box(
            "9. Ações corretivas aplicadas",
            '<div>' + _many_choices(
                ("Esquecer a Rede", "Reinicializar o Equipamento", "Troca de senha"),
                tuple(action for action in corrective_actions if action != "Outras"),
            ) + '&nbsp;&nbsp; (' + ("X" if "Outras" in corrective_actions else " ")
            + ') Outras:&nbsp;'
            + (escape(corrective_other.strip()) if "Outras" in corrective_actions else "")
            + '</div>',
        ),
        _checklist_box(
            "10. Intensidade do sinal Wi-Fi",
            '<div>' + _choice(("Alta", "Média", "Baixa"), signal) + '</div>',
        ),
        _checklist_box(
            "11. Identificação do Access Point",
            '<div>AP:&nbsp; ' + _optional(access_point) + '</div>',
        ),
        _checklist_box(
            "12. Localização",
            _location_html(sector, building, complement, reference, contact, sector_status, place),
            last=True,
        ),
    ]
    return (
        '<!-- CHECKLIST WI-FI – MODELO PARA ATENDENTE -->'
        '<div style="font-family:Arial,Helvetica,sans-serif; font-size:12px; color:#111827">'
        '<div style="font-size:11px; color:#6b7280; margin-bottom:8px">'
        '<span style="color:#000000"><span style="font-size:12px"><strong>Prezados,</strong></span>'
        '<br /><br /><span style="font-size:12px"><strong>A solicitação</strong>: '
        'Usuário solicita verificação de acesso à rede Wi-Fi.<br />'
        '<strong>A tratativa</strong>: Foi realizado o checklist de informações abaixo.'
        '</span></span></div><div style="font-size:12px">'
        '<div style="border:1px solid #e5e7eb; border-radius:10px; padding:10px 14px;'
        ' background:#fafafa; margin:10px 0 10px 0">' + "".join(body) + '</div>'
        '<!-- /CAIXA BASE -->' + _signature(name, role) + '</div></div>'
    )


def render_standard_installation(
    request: str, treatment: str, *, reason: str = "", reason_other: str = "",
    authorized: str = "", shared_micro: str = "", backup: str = "",
    sector: str = "", building: str = "", complement: str = "",
    reference: str = "", contact: str = "", sector_status: str = "",
    place: str = "", name: str = "", role: str = "",
) -> str:
    request_html = _filled(request, "A solicitação")
    treatment_html = _filled(treatment, "A tratativa")
    return (
        '<div style="font-family:Arial,Helvetica,sans-serif; font-size:12px; color:#111827">'
        '<div style="font-size:12px; margin-bottom:8px"><strong>Prezados,</strong></div>'
        '<div style="border:1px solid #e5e7eb; border-radius:10px; padding:10px 14px;'
        ' background:#fafafa; margin:10px 0">'
        + _checklist_box("A solicitação:", '<div>' + request_html + '</div>')
        + _checklist_box("A tratativa:", '<div>' + treatment_html + '</div>')
        + _checklist_box(
            "Motivo da solicitação:",
            '<div>' + _choice(("Lentidão", "Troca de micro", "Outros"), reason)
            + '&nbsp;' + (escape(reason_other.strip()) if reason == "Outros" else "") + '</div>',
        )
        + _checklist_box("Autorização do chefe do setor:",
                         '<div>' + _choice(("Sim", "Não"), authorized) + '</div>')
        + _checklist_box("Outros clientes utilizam o micro:",
                         '<div>' + _choice(("Sim", "Não"), shared_micro) + '</div>')
        + _checklist_box("Necessita de backup:",
                         '<div>' + _choice(("Sim", "Não"), backup) + '</div>')
        + _checklist_box(
            "Localização",
            _location_html(sector, building, complement, reference, contact, sector_status, place),
            last=True,
        )
        + '</div>' + _signature(name, role) + '</div>'
    )


def render_no_network(
    *, other_devices: str = "", recently_installed: str = "", cable_connected: str = "",
    via_ip_phone: str = "", phone_connected: str = "", access_sites: tuple[str, ...] = (),
    sector: str = "", building: str = "", complement: str = "", reference: str = "",
    contact: str = "", sector_status: str = "", place: str = "",
    name: str = "", role: str = "",
) -> str:
    """Checklist de estação sem rede, com marcações e localização para o Capri."""
    yes_no = ("Sim", "Não")
    if not set(access_sites).issubset({"Intranet", "Internet", "Nenhum"}):
        raise ValueError("Seleção de acesso aos sites inválida.")
    if "Nenhum" in access_sites and len(access_sites) > 1:
        raise ValueError("Nenhum acesso não pode ser marcado junto com Intranet ou Internet.")
    checklist = (
        '<div>Afeta outros equipamentos do mesmo local/setor?&nbsp;&nbsp;'
        + _choice(yes_no, other_devices) + '</div>'
        '<div style="margin-top:4px">O equipamento foi instalado, substituído ou realizado instalação padrão recentemente?&nbsp;&nbsp;'
        + _choice(yes_no, recently_installed) + '</div>'
        '<div style="margin-top:4px">O cabo de rede está devidamente conectado?&nbsp;&nbsp;'
        + _choice(yes_no, cable_connected) + '</div>'
        '<div style="margin-top:4px">O computador está conectado via telefone IP?&nbsp;&nbsp;'
        + _choice(yes_no, via_ip_phone) + '</div>'
        '<div style="margin-top:4px; margin-left:14px">Em caso positivo, o telefone IP está ligado e possui conectividade?&nbsp;&nbsp;'
        + _choice(yes_no, phone_connected) + '</div>'
        '<div style="margin-top:4px">O computador consegue realizar acesso aos seguintes sites?&nbsp;&nbsp;'
        + _many_choices(("Intranet", "Internet", "Nenhum"), access_sites) + '</div>'
    )
    return (
        '<div style="font-family:Arial,Helvetica,sans-serif; font-size:12px; color:#111827">'
        '<div style="font-size:11px; color:#6b7280; margin-bottom:8px">'
        '<span style="color:#000000"><span style="font-size:12px"><strong>Prezados,</strong></span>'
        '<br /><br /><span style="font-size:12px"><strong>A solicitação</strong>: Estação sem Rede/Internet.<br />'
        '<strong>A tratativa</strong>: necessidade de atendimento especializado para solução do chamado.'
        '</span></span></div><div style="font-size:12px">'
        '<div style="border:1px solid #e5e7eb; border-radius:10px; padding:10px 14px;'
        ' background:#fafafa; margin:10px 0 10px 0">'
        + _checklist_box("1. Checklist de diagnóstico", checklist,
                         "Informações básicas para o atendimento especializado.")
        + _checklist_box("2. Localização",
                         _location_html(sector, building, complement, reference, contact,
                                        sector_status, place),
                         "Dados do local para facilitar o deslocamento ou contato da equipe responsável.",
                         last=True)
        + '</div>' + _signature(name, role) + '</div></div>'
    )
