"""Histórico local, limitado aos HTMLs de templates copiados no dia."""

from __future__ import annotations

from datetime import datetime
from html.parser import HTMLParser
from pathlib import Path
from uuid import uuid4

from storage.json_store import load_json, save_json

MAX_ENTRIES = 100
MAX_HTML = 100_000


class _ReadableTemplateParser(HTMLParser):
    """Extrai texto para consulta sem tentar reproduzir CSS ou imagens remotas."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.ignored = 0

    def _newline(self):
        if self.parts and not self.parts[-1].endswith("\n"):
            self.parts.append("\n")

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style"}:
            self.ignored += 1
        elif tag == "br":
            self.parts.append("\n")
        elif tag in {"div", "p", "li", "section"}:
            self._newline()

    def handle_endtag(self, tag):
        if tag in {"script", "style"}:
            self.ignored = max(0, self.ignored - 1)
        elif tag in {"div", "p", "li", "section"}:
            self._newline()

    def handle_data(self, data):
        if not self.ignored:
            self.parts.append(data)


def readable_preview(source: str) -> str:
    parser = _ReadableTemplateParser()
    parser.feed(str(source))
    lines = [" ".join(line.replace("\xa0", " ").split())
             for line in "".join(parser.parts).splitlines()]
    cleaned = []
    for line in filter(None, lines):
        if cleaned and (line.endswith(":") or line == "Sua opinião é importante!"
                        or line.startswith("Atenciosamente")
                        or (len(line) > 2 and line[0].isdigit() and line[1:3] == ". ")):
            cleaned.append("")
        cleaned.append(line)
    return "\n".join(cleaned).strip()


def load_today(path: Path, *, today=None) -> list[dict]:
    day = (today or datetime.now().date()).isoformat()
    data = load_json(Path(path))
    if data.get("date") != day:
        return []
    entries = data.get("entries")
    if not isinstance(entries, list):
        return []
    return [
        {"id": entry["id"], "date": day, "time": entry["time"], "label": entry["label"],
         "kind": entry["kind"], "html": entry["html"]}
        for entry in entries[-MAX_ENTRIES:] if isinstance(entry, dict)
        and isinstance(entry.get("id"), str) and isinstance(entry.get("time"), str)
        and isinstance(entry.get("label"), str) and isinstance(entry.get("kind"), str)
        and isinstance(entry.get("html"), str) and entry["html"].startswith("<")
        and len(entry["html"]) <= MAX_HTML
    ]


def display_timestamp(entry: dict) -> str:
    """Mantém data e hora legíveis inclusive para registros feitos antes desta revisão."""
    day = str(entry.get("date") or "")
    try:
        day = datetime.strptime(day, "%Y-%m-%d").strftime("%d/%m/%Y")
    except ValueError:
        day = "Data não informada"
    return f"{day} às {entry.get('time') or 'horário não informado'}"


def record_copy(path: Path, label: str, kind: str, html: str, *, now=None) -> bool:
    timestamp = now or datetime.now()
    if not str(html).startswith("<") or len(html) > MAX_HTML:
        return False
    entry = {"id": uuid4().hex, "time": timestamp.strftime("%H:%M:%S"),
             "label": str(label)[:120], "kind": str(kind)[:40], "html": html}
    entries = [*load_today(path, today=timestamp.date()), entry][-MAX_ENTRIES:]
    return save_json(Path(path), {"version": 1, "date": timestamp.date().isoformat(),
                                  "entries": entries})


def clear_today(path: Path) -> bool:
    try:
        Path(path).unlink(missing_ok=True)
        return True
    except OSError:
        return False
