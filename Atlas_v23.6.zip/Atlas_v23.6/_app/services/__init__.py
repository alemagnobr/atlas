"""Integrações externas do Atlas."""

