"""Regras de acesso a impressão colorida com dados já consultados no AD."""

import re


def color_printing_allowed(department: str, groups: list[str]) -> bool:
    """GABSEN no departamento ou associação direta ao grupo ImpressaoColorida."""
    department_tokens = re.split(r"[^A-Z0-9]+", str(department or "").upper())
    if "GABSEN" in department_tokens:
        return True
    return any(str(group).strip().casefold() == "impressaocolorida" for group in (groups or []))
