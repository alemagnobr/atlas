"""Constrói o Atlas.exe portátil com a logo incorporada nos recursos PE."""

from __future__ import annotations

import io
import struct
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile, ZipInfo


APP_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = APP_ROOT.parent
ICON_PATH = APP_ROOT / "assets" / "app_icon.ico"
OUTPUT = PACKAGE_ROOT / "Atlas.exe"
EMBEDDED_MAIN = r'''from pathlib import Path
import ctypes
import os
import sys

root = Path(sys.argv[0]).resolve().parent
launcher = root / "_app" / "run.bat"
if not launcher.is_file():
    ctypes.windll.user32.MessageBoxW(
        None,
        "A pasta interna do Atlas não foi encontrada.\n\nExtraia o ZIP completamente e mantenha Atlas.exe ao lado da pasta _app.",
        "Atlas — Inicialização",
        0x10,
    )
    raise SystemExit(1)
os.startfile(str(launcher))
'''


def _pe_layout(data: bytes) -> tuple[int, list[tuple[int, int, int, int]]]:
    if data[:2] != b"MZ":
        raise ValueError("O lançador-base não é um executável PE.")
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe_offset:pe_offset + 4] != b"PE\0\0":
        raise ValueError("Cabeçalho PE inválido.")
    section_count = struct.unpack_from("<H", data, pe_offset + 6)[0]
    optional_size = struct.unpack_from("<H", data, pe_offset + 20)[0]
    optional = pe_offset + 24
    magic = struct.unpack_from("<H", data, optional)[0]
    directory = optional + (112 if magic == 0x20B else 96)
    resource_rva = struct.unpack_from("<I", data, directory + 16)[0]
    sections_offset = optional + optional_size
    sections = []
    for index in range(section_count):
        offset = sections_offset + index * 40
        virtual_size, virtual_address, raw_size, raw_offset = struct.unpack_from("<IIII", data, offset + 8)
        sections.append((virtual_address, max(virtual_size, raw_size), raw_offset, raw_size))
    return resource_rva, sections


def _rva_offset(rva: int, sections: list[tuple[int, int, int, int]]) -> int:
    for virtual_address, extent, raw_offset, _raw_size in sections:
        if virtual_address <= rva < virtual_address + extent:
            return raw_offset + rva - virtual_address
    raise ValueError(f"RVA não localizado: {rva:#x}")


def _resource_leaves(data: bytes) -> dict[tuple[int, ...], tuple[int, int]]:
    resource_rva, sections = _pe_layout(data)
    root = _rva_offset(resource_rva, sections)
    leaves: dict[tuple[int, ...], tuple[int, int]] = {}

    def walk(relative: int, path: tuple[int, ...]) -> None:
        directory = root + relative
        named, identified = struct.unpack_from("<HH", data, directory + 12)
        for index in range(named + identified):
            name, child = struct.unpack_from("<II", data, directory + 16 + index * 8)
            if name & 0x80000000:
                continue
            identifier = name & 0xFFFF
            target = child & 0x7FFFFFFF
            if child & 0x80000000:
                walk(target, path + (identifier,))
            else:
                data_rva, size = struct.unpack_from("<II", data, root + target)
                leaves[path + (identifier,)] = (_rva_offset(data_rva, sections), size)

    walk(0, ())
    return leaves


def _ico_images(data: bytes) -> dict[tuple[int, int, int], bytes]:
    reserved, icon_type, count = struct.unpack_from("<HHH", data, 0)
    if reserved != 0 or icon_type != 1:
        raise ValueError("Arquivo ICO inválido.")
    images = {}
    for index in range(count):
        width, height, _colors, _reserved, _planes, bits, size, offset = struct.unpack_from(
            "<BBBBHHII", data, 6 + index * 16
        )
        images[(width or 256, height or 256, bits)] = data[offset:offset + size]
    return images


def embed_atlas_icon(stub: bytes, icon: bytes) -> tuple[bytes, int]:
    """Substitui os recursos 32-bit de 16, 32 e 48 px no lançador-base."""
    output = bytearray(stub)
    leaves = _resource_leaves(stub)
    group_offset, _group_size = leaves[(14, 101, 0)]
    count = struct.unpack_from("<H", stub, group_offset + 4)[0]
    source_images = _ico_images(icon)
    replaced = 0
    for index in range(count):
        entry = group_offset + 6 + index * 14
        width, height, _colors, _reserved, _planes, bits, size, resource_id = struct.unpack_from(
            "<BBBBHHIH", stub, entry
        )
        key = (width or 256, height or 256, bits)
        source = source_images.get(key)
        destination = leaves.get((3, resource_id, 0))
        if key[0] not in (16, 32, 48) or bits != 32 or source is None or destination is None:
            continue
        offset, capacity = destination
        if len(source) != size or len(source) != capacity:
            raise ValueError(f"Recurso de ícone incompatível: {key}")
        output[offset:offset + capacity] = source
        replaced += 1
    if replaced != 3:
        raise ValueError(f"Esperados 3 recursos da logo; incorporados: {replaced}.")
    return bytes(output), replaced


def build_zip_main() -> bytes:
    stream = io.BytesIO()
    with ZipFile(stream, "w", compression=ZIP_STORED) as archive:
        info = ZipInfo("__main__.py", date_time=(2026, 9, 28, 10, 0, 0))
        archive.writestr(info, EMBEDDED_MAIN.encode("utf-8"))
    return stream.getvalue()


def main() -> None:
    from pip._vendor.distlib import scripts as distlib_scripts

    stub_path = Path(distlib_scripts.__file__).with_name("w64.exe")
    if not stub_path.is_file() or not ICON_PATH.is_file():
        raise SystemExit("Lançador-base ou ícone do Atlas não encontrado.")
    stub, count = embed_atlas_icon(stub_path.read_bytes(), ICON_PATH.read_bytes())
    OUTPUT.write_bytes(stub + b"#!pyw.exe -3\r\n" + build_zip_main())
    print(f"{OUTPUT} ({count} recursos de ícone incorporados)")


if __name__ == "__main__":
    main()
