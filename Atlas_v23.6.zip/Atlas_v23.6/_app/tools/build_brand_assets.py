"""Gera o ícone multirresolução do ATLAS a partir da arte compacta."""

from __future__ import annotations

import io
import struct
from pathlib import Path

from PIL import Image


ASSETS = Path(__file__).resolve().parents[1] / "assets"
SOURCE = ASSETS / "logo_compact_light.png"


def _icon_bitmap(image: Image.Image) -> bytes:
    """BITMAPINFOHEADER + BGRA e máscara AND para recurso ICO clássico."""
    width, height = image.size
    image = image.convert("RGBA")
    header = struct.pack("<IiiHHIIiiII", 40, width, height * 2, 1, 32,
                         0, width * height * 4, 0, 0, 0, 0)
    color = bytearray()
    alpha = bytearray()
    mask_stride = ((width + 31) // 32) * 4
    for y in range(height - 1, -1, -1):
        row = [image.getpixel((x, y)) for x in range(width)]
        for red, green, blue, opacity in row:
            color.extend((blue, green, red, opacity))
        bits = bytearray(mask_stride)
        for x, (*_rgb, opacity) in enumerate(row):
            if opacity == 0:
                bits[x // 8] |= 0x80 >> (x % 8)
        alpha.extend(bits)
    return header + color + alpha


def build() -> None:
    source = Image.open(SOURCE).convert("RGBA")
    # A arte de apresentação tem respiro ao redor; o ícone do Windows precisa
    # preencher sua área útil para continuar reconhecível em 16 e 32 px.
    visible = source.getchannel("A").point(lambda value: 255 if value >= 5 else 0).getbbox()
    if visible:
        left, top, right, bottom = visible
        side = round(max(right - left, bottom - top) * 1.04)
        center_x, center_y = (left + right) // 2, (top + bottom) // 2
        source = source.crop((center_x - side // 2, center_y - side // 2,
                              center_x - side // 2 + side, center_y - side // 2 + side))
    source.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
    source.resize((512, 512), Image.Resampling.LANCZOS).save(ASSETS / "app_icon.png")
    sizes = (16, 32, 48, 64, 128, 256)
    entries = []
    for size in sizes:
        image = source.resize((size, size), Image.Resampling.LANCZOS)
        if size == 256:
            stream = io.BytesIO()
            image.save(stream, format="PNG", optimize=True)
            data = stream.getvalue()
        else:
            data = _icon_bitmap(image)
        entries.append((size, data))

    directory = bytearray(struct.pack("<HHH", 0, 1, len(entries)))
    offset = 6 + len(entries) * 16
    for size, data in entries:
        directory.extend(struct.pack("<BBBBHHII", size % 256, size % 256,
                                     0, 0, 1, 32, len(data), offset))
        offset += len(data)
    (ASSETS / "app_icon.ico").write_bytes(
        bytes(directory) + b"".join(data for _, data in entries)
    )


if __name__ == "__main__":
    build()
