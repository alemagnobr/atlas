from __future__ import annotations

import json
import re
import sys
import unicodedata
from datetime import datetime, timezone
from pathlib import Path


HEADER_RE = re.compile(
    r"^#\d+\s+-\s+FAQ#:\s*(?P<id>\d+)\s+[—–-]\s+(?P<title>.+?)\s*$",
    re.MULTILINE,
)
PATH_RE = re.compile(
    r"Intranet\s*>\s*Central\s+de\s+Serviços(?:\s*>\s*[^\r\n]+)?",
    re.IGNORECASE,
)
CONTACT_CUE_RE = re.compile(
    r"\b(?:ramal(?:es)?|telefone|tel\.?|0800|entre\s+em\s+contato|ligar|contatar)\b",
    re.IGNORECASE,
)
CONTACT_NUMBER_RE = re.compile(
    r"(?<!\d)(?:0800[\s.-]*\d{4,7}|(?:\(?\d{2}\)?[\s.-]*)?\d{4,5}[\s.-]?\d{0,4})(?!\d)",
    re.IGNORECASE,
)


def clean_inline(value: str) -> str:
    value = re.sub(r"\[\*\*(.*?)\*\*\]\([^)]*\)", r"\1", value)
    value = re.sub(r"[*_`#]", "", value)
    value = re.sub(r"\s+", " ", value).strip(" \t\r\n-•")
    return value


def clean_path(value: str) -> str:
    value = clean_inline(value)
    value = re.split(r"\s+(?:Link|Observa(?:ção|cao)|Atenção|Importante)\s*:", value, maxsplit=1, flags=re.I)[0]
    value = re.sub(r"\s*>\s*", " > ", value)
    return value.rstrip(" .;,:)")


def field(block: str, name: str) -> str:
    match = re.search(
        rf"\*\*{re.escape(name)}:\*\*\s*(.+?)(?=\n\s*\n|\n\*\*|\n📌|\n🔗|\nOBSERVAÇÕES:|$)",
        block,
        re.IGNORECASE | re.DOTALL,
    )
    return clean_inline(match.group(1)) if match else ""


def nearest_guidance(procedure: str, start: int) -> str:
    before = procedure[:start]
    candidates = []
    chunks = re.split(r"\n+|(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ])", before)
    for position, raw in enumerate(chunks):
        value = clean_inline(re.sub(r"^\d+[.)]\s*|^-\s*", "", raw.strip()))
        if (not value or "📌" in raw or value.lower().startswith(("caminho", "intranet", "acesso e utilização"))
                or len(value) > 360):
            continue
        score = sum(
            token in normalize(value)
            for token in ("solicit", "necessar", "devera", "deve", "somente", "apenas", "chef", "obrigator")
        )
        if score:
            candidates.append((position, score, len(value), value))
    if not candidates:
        return ""
    # A frase mais próxima ao caminho costuma conter a regra operacional exata
    # (chefia responsável, necessidade de autorização ou restrição de acesso).
    value = max(candidates, key=lambda item: (item[0], item[1], -item[2]))[3]
    return value[:320].rstrip(" ,;:") + ("." if value[-1:] not in ".!?" else "")


def extract_contacts(procedure: str) -> str:
    """Preserva a orientação oficial que relaciona setor e telefone/ramal."""
    chunks = re.split(r"\n+|(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ])", procedure)
    contacts = []
    seen = set()
    for raw in chunks:
        value = clean_inline(re.sub(r"^\d+[.)]\s*|^-\s*", "", raw.strip()))
        if not value or len(value) < 12 or len(value) > 900 or not CONTACT_CUE_RE.search(value) or not CONTACT_NUMBER_RE.search(value):
            continue
        # Ignora instruções genéricas de telefonia sem um destino de contato.
        normalized = normalize(value)
        if "ramal desejado" in normalized and not re.search(r"\b\d{4}\b", value):
            continue
        key = normalize(value)
        if key in seen:
            continue
        seen.add(key)
        contacts.append(value[:420].rstrip(" ,;:") + ("." if value[-1:] not in ".!?" else ""))
        if len(contacts) == 3:
            break
    return " ".join(contacts)


def extract_user_guidance(procedure: str) -> str:
    """Preserva ações para o usuário e rejeita instruções técnicas internas."""
    cue = re.compile(r"\b(?:solicite|solicitar|acesse|acessar|clique|entre em contato|contatar|ligar|comparecer|abrir (?:um )?chamado|procure|informe|deverá|deve)\b", re.I)
    technical = re.compile(r"\b(?:powershell|cmd\.exe|regedit|registro do windows|gpupdate|script|executável|\.exe|driver|dll|servidor|fila|supervisão|nível [123]|\bN[123]\b|equipe técnica|atendimento interno)\b", re.I)
    values, seen = [], set()
    for raw in re.split(r"\n+|(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ])", procedure):
        value = clean_inline(re.sub(r"^\d+[.)]\s*|^[-•]\s*", "", raw.strip()))
        key = normalize(value)
        if 25 <= len(value) <= 360 and cue.search(value) and not technical.search(value) and key not in seen:
            seen.add(key)
            values.append(value.rstrip(" ,;:") + ("." if value[-1:] not in ".!?" else ""))
        if len(values) == 2:
            break
    return " ".join(values)


def normalize(value: str) -> str:
    decomposed = unicodedata.normalize("NFKD", value)
    return "".join(ch for ch in decomposed if not unicodedata.combining(ch)).casefold()


def infer_group(path: str, source_category: str) -> tuple[str, str]:
    segments = [part.strip() for part in path.split(">") if part.strip()]
    after = segments[2:] if len(segments) > 2 else []
    major = after[0] if after else (source_category.split(">", 1)[0].strip() or "Outras orientações")
    topic = after[1] if len(after) > 1 else (source_category.split(">")[-1].strip() or "Procedimentos")
    return major, topic


def make_summary(subject: str, title: str, guidance: str) -> str:
    purpose = subject or title
    purpose = purpose.rstrip(" .") if purpose else "Procedimento disponível na Central de Serviços"
    return f"Para tratar de “{purpose}”, peça ao chefe do seu setor que abra um chamado pelo caminho indicado abaixo."


def parse(source: str) -> dict:
    matches = list(HEADER_RE.finditer(source))
    items = []
    seen = set()
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(source)
        block = source[match.start():end]
        item_id_match = re.search(r"Página original:.*?[?&]ItemID=(\d+)", block, re.IGNORECASE)
        header_number = match.group("id")
        if item_id_match:
            faq_number = str(10_000_000 + int(item_id_match.group(1)))
        elif header_number.startswith("1000") and len(header_number) < 8:
            # Algumas FAQs antigas não trazem Página original e o exportador
            # concatena o ItemID sem completar quatro posições.
            faq_number = "1000" + header_number[4:].zfill(4)
        else:
            faq_number = header_number
        procedure_match = re.search(r"\nPROCEDIMENTO:\s*(.*?)(?=\nOBSERVAÇÕES:|\Z)", block, re.DOTALL | re.I)
        procedure = procedure_match.group(1) if procedure_match else block
        category_match = re.search(r"^Categoria:\s*(.+)$", block, re.MULTILINE | re.I)
        source_category = clean_inline(category_match.group(1)) if category_match else "Outras orientações"
        subject = field(procedure, "ASSUNTO")
        service = field(procedure, "SERVIÇO")
        request_type = field(procedure, "TIPO")
        contact = extract_contacts(procedure)
        user_guidance = extract_user_guidance(procedure)
        faq_item_count = 0
        for path_match in PATH_RE.finditer(procedure):
            path = clean_path(path_match.group(0))
            if path.count(">") < 2:
                continue
            key = (faq_number, normalize(path))
            if key in seen:
                continue
            seen.add(key)
            guidance = nearest_guidance(procedure, path_match.start())
            major, topic = infer_group(path, source_category)
            title = clean_inline(match.group("title"))
            faq_item_count += 1
            items.append({
                "id": f"{faq_number}:{faq_item_count}",
                "faq_number": faq_number,
                "title": title,
                "category": major,
                "topic": topic,
                "source_category": source_category,
                "request_type": request_type,
                "service": service,
                "subject": subject,
                "summary": make_summary(subject, title, guidance),
                "guidance": user_guidance,
                "important_note": guidance,
                "path": path,
                "contact": contact,
                "orientation_type": "service_path",
                "search_text": " ".join(filter(None, [
                    faq_number, title, source_category, major, topic, subject, service,
                    path, contact, clean_inline(procedure),
                ])),
            })
        if (contact or user_guidance) and faq_item_count == 0:
            title = clean_inline(match.group("title"))
            major = source_category.split(">", 1)[0].strip() or "Outras orientações"
            topic = "Contatos e orientações" if contact else "Orientações ao usuário"
            purpose = (subject or title).rstrip(" .")
            items.append({
                "id": f"{faq_number}:contact",
                "faq_number": faq_number,
                "title": title,
                "category": major,
                "topic": topic,
                "source_category": source_category,
                "request_type": request_type,
                "service": service,
                "subject": subject,
                "summary": f"Para obter orientação sobre “{purpose}”, utilize o contato do setor responsável indicado abaixo.",
                "guidance": user_guidance,
                "important_note": "",
                "path": "",
                "contact": contact,
                "orientation_type": "contact" if contact else "user_guidance",
                "search_text": " ".join(filter(None, [
                    faq_number, title, source_category, major, topic, subject, service,
                    contact, clean_inline(procedure),
                ])),
            })
    items.sort(key=lambda item: (normalize(item["category"]), normalize(item["topic"]), normalize(item["title"]), item["path"]))
    return {
        "schema": 2,
        "source_faq_count": len(matches),
        "count": len(items),
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "items": items,
    }


def main() -> int:
    if len(sys.argv) != 3:
        print("Uso: build_orientation_catalog.py <faqs.txt> <orientations_catalog.json>", file=sys.stderr)
        return 2
    source_path, output_path = map(Path, sys.argv[1:])
    catalog = parse(source_path.read_text(encoding="utf-8-sig"))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: catalog[key] for key in ("source_faq_count", "count", "generated_at")}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
