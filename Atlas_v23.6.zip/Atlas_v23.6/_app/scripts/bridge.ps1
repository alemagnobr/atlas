﻿param(
    [Parameter(Mandatory=$true)][string]$Action,
    [string]$Computer = "",
    [string]$Value = "",
    [string]$ModuleRoot = ""
)
$ErrorActionPreference = "Stop"

function Get-AtlasCredentialText([string]$EncodedName, [string]$LegacyName) {
    $encoded = [Environment]::GetEnvironmentVariable($EncodedName)
    if (![string]::IsNullOrWhiteSpace($encoded)) {
        try { return [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($encoded)) }
        catch { throw 'A credencial do Capri não pôde ser decodificada com segurança.' }
    }
    return [Environment]::GetEnvironmentVariable($LegacyName)
}

function Get-CapriSessionPath {
    $cacheRoot = Join-Path $env:LOCALAPPDATA 'AtlasSuporteAvancado\cache'
    if (!(Test-Path -LiteralPath $cacheRoot)) { [IO.Directory]::CreateDirectory($cacheRoot) | Out-Null }
    return (Join-Path $cacheRoot 'capri_session.protected')
}

function Save-CapriWebSession([Microsoft.PowerShell.Commands.WebRequestSession]$Session) {
    # O cookie de autenticação do OTRS costuma usar Path=/otrs e não aparece
    # quando o CookieContainer é consultado somente pela raiz do domínio.
    $cookieUris = @(
        [uri]'https://capri.senado.leg.br/',
        [uri]'https://capri.senado.leg.br/otrs/',
        [uri]'https://capri.senado.leg.br/otrs/index.pl'
    )
    $uniqueCookies = [ordered]@{}
    foreach ($cookieUri in $cookieUris) {
        foreach ($cookie in @($Session.Cookies.GetCookies($cookieUri))) {
            $key = "$($cookie.Domain)|$($cookie.Path)|$($cookie.Name)"
            $uniqueCookies[$key] = $cookie
        }
    }
    $records = @($uniqueCookies.Values | ForEach-Object {
        [ordered]@{ Name=$_.Name; Value=$_.Value; Path=$_.Path; Domain=$_.Domain; Expires=$_.Expires.ToString('o'); Secure=$_.Secure; HttpOnly=$_.HttpOnly }
    })
    if (!$records.Count) { return }
    $json = ConvertTo-Json -InputObject @($records) -Depth 4 -Compress
    $protected = ConvertFrom-SecureString (ConvertTo-SecureString $json -AsPlainText -Force)
    $path = Get-CapriSessionPath
    $temporary = "$path.tmp"
    [IO.File]::WriteAllText($temporary, $protected, (New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $temporary -Destination $path -Force
}

function Restore-CapriWebSession([Microsoft.PowerShell.Commands.WebRequestSession]$Session) {
    $path = Get-CapriSessionPath
    if (!(Test-Path -LiteralPath $path -PathType Leaf)) { return $false }
    try {
        $protected = [IO.File]::ReadAllText($path, [Text.Encoding]::UTF8)
        $secure = ConvertTo-SecureString $protected
        $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
        try { $json = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
        foreach ($record in @($json | ConvertFrom-Json -ErrorAction Stop)) {
            $cookie = New-Object Net.Cookie([string]$record.Name, [string]$record.Value, ([string]$record.Path), ([string]$record.Domain))
            $cookie.Secure = [bool]$record.Secure
            $cookie.HttpOnly = [bool]$record.HttpOnly
            $expires = [datetime]::MinValue
            if ([datetime]::TryParse([string]$record.Expires, [ref]$expires) -and $expires.Year -gt 2000) { $cookie.Expires = $expires }
            $Session.Cookies.Add($cookie)
        }
        return $true
    } catch {
        Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
        return $false
    }
}

function Get-PasswordManagerSessionPath {
    $cacheRoot = Join-Path $env:LOCALAPPDATA 'AtlasSuporteAvancado\cache'
    if (!(Test-Path -LiteralPath $cacheRoot)) { [IO.Directory]::CreateDirectory($cacheRoot) | Out-Null }
    return (Join-Path $cacheRoot 'password_manager_session.protected')
}

function Save-PasswordManagerWebSession([Microsoft.PowerShell.Commands.WebRequestSession]$Session) {
    $cookieUris = @(
        [uri]'https://gestorsenhas.senado.leg.br/',
        [uri]'https://gestorsenhas.senado.leg.br/private/',
        [uri]'https://gestorsenhas.senado.leg.br/public/'
    )
    $uniqueCookies = [ordered]@{}
    foreach ($cookieUri in $cookieUris) {
        foreach ($cookie in @($Session.Cookies.GetCookies($cookieUri))) {
            $key = "$($cookie.Domain)|$($cookie.Path)|$($cookie.Name)"
            $uniqueCookies[$key] = $cookie
        }
    }
    $records = @($uniqueCookies.Values | ForEach-Object {
        [ordered]@{ Name=$_.Name; Value=$_.Value; Path=$_.Path; Domain=$_.Domain; Expires=$_.Expires.ToString('o'); Secure=$_.Secure; HttpOnly=$_.HttpOnly }
    })
    if (!$records.Count) { return $false }
    $json = ConvertTo-Json -InputObject @($records) -Depth 4 -Compress
    $protected = ConvertFrom-SecureString (ConvertTo-SecureString $json -AsPlainText -Force)
    $path = Get-PasswordManagerSessionPath
    $temporary = "$path.tmp"
    [IO.File]::WriteAllText($temporary, $protected, (New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $temporary -Destination $path -Force
    return $true
}

function Restore-PasswordManagerWebSession([Microsoft.PowerShell.Commands.WebRequestSession]$Session) {
    $path = Get-PasswordManagerSessionPath
    if (!(Test-Path -LiteralPath $path -PathType Leaf)) { return $false }
    try {
        $protected = [IO.File]::ReadAllText($path, [Text.Encoding]::UTF8)
        $secure = ConvertTo-SecureString $protected
        $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
        try { $json = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
        foreach ($record in @($json | ConvertFrom-Json -ErrorAction Stop)) {
            $cookie = New-Object Net.Cookie([string]$record.Name, [string]$record.Value, ([string]$record.Path), ([string]$record.Domain))
            $cookie.Secure = [bool]$record.Secure
            $cookie.HttpOnly = [bool]$record.HttpOnly
            $expires = [datetime]::MinValue
            if ([datetime]::TryParse([string]$record.Expires, [ref]$expires) -and $expires.Year -gt 2000) { $cookie.Expires = $expires }
            $Session.Cookies.Add($cookie)
        }
        return $true
    } catch {
        Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
        return $false
    }
}

function Get-PasswordManagerCredentialText([string]$EncodedName) {
    $encoded = [Environment]::GetEnvironmentVariable($EncodedName)
    if ([string]::IsNullOrWhiteSpace($encoded)) { return '' }
    try { return [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($encoded)) }
    catch { throw 'A credencial do Gestor de Senhas não pôde ser decodificada com segurança.' }
}

function Test-PasswordManagerLoginPage([string]$Html) {
    if ([string]::IsNullOrWhiteSpace($Html)) { return $true }
    $hasPassword = $Html -match '(?is)<input[^>]+(?:type=["'']password["'']|name=["''](?:password|senha|j_password)["''])'
    $hasAuthenticatedMarker = $Html -match '(?i)(?:/private/(?!login)|logout|sair|suporte\s*t[eé]cnico|hist[oó]rico\s+de\s+senhas)'
    return ($hasPassword -and !$hasAuthenticatedMarker)
}

function Get-AtlasCdpTarget([int]$Port) {
    if ($Port -lt 1024 -or $Port -gt 65535) { throw 'A porta local do navegador PWM é inválida.' }
    $targets = @(Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/list" -TimeoutSec 4 -ErrorAction Stop)
    $target = $targets | Where-Object {
        $_.type -eq 'page' -and ([string]$_.url) -match '(?i)gestorsenhas\.senado\.leg\.br'
    } | Sort-Object @{ Expression = {
        # Se o portal abriu uma segunda aba após autenticar, a página privada
        # tem prioridade sobre a aba antiga que permaneceu em /private/login.
        if (([string]$_.url) -match '(?i)/private/login(?:[/?#]|$)') { 1 } else { 0 }
    }} | Select-Object -First 1
    if (!$target) { $target = $targets | Where-Object { $_.type -eq 'page' } | Select-Object -First 1 }
    if (!$target -or [string]::IsNullOrWhiteSpace([string]$target.webSocketDebuggerUrl)) {
        throw 'A aba exclusiva do PWM não respondeu à ponte local.'
    }
    return $target
}

function Invoke-AtlasCdpCommand([string]$WebSocketUrl, [string]$Method, $Parameters = $null) {
    $socket = New-Object System.Net.WebSockets.ClientWebSocket
    try {
        $connect = $socket.ConnectAsync([uri]$WebSocketUrl, [Threading.CancellationToken]::None)
        if (!$connect.Wait(8000)) { throw 'Tempo limite ao conectar à janela exclusiva do PWM.' }
        $requestId = 9173
        $message = [ordered]@{ id=$requestId; method=$Method; params=$(if ($null -eq $Parameters) { @{} } else { $Parameters }) }
        $bytes = [Text.Encoding]::UTF8.GetBytes(($message | ConvertTo-Json -Depth 10 -Compress))
        $sendSegment = New-Object 'System.ArraySegment[byte]' -ArgumentList (,$bytes)
        $send = $socket.SendAsync($sendSegment, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [Threading.CancellationToken]::None)
        if (!$send.Wait(8000)) { throw 'Tempo limite ao consultar a janela exclusiva do PWM.' }
        $builder = New-Object Text.StringBuilder
        do {
            $buffer = New-Object byte[] 32768
            $receiveSegment = New-Object 'System.ArraySegment[byte]' -ArgumentList (,$buffer)
            $receive = $socket.ReceiveAsync($receiveSegment, [Threading.CancellationToken]::None)
            if (!$receive.Wait(8000)) { throw 'O navegador PWM não devolveu os cookies no prazo esperado.' }
            $part = $receive.Result
            if ($part.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) {
                throw 'A janela exclusiva do PWM foi fechada antes da validação.'
            }
            [void]$builder.Append([Text.Encoding]::UTF8.GetString($buffer, 0, $part.Count))
        } while (!$part.EndOfMessage)
        $response = $builder.ToString() | ConvertFrom-Json -ErrorAction Stop
        if ($response.error) { throw ([string]$response.error.message) }
        return $response.result
    } finally {
        try { $socket.Dispose() } catch {}
    }
}

function Close-AtlasPwmBrowser([int]$Port) {
    try {
        $target = Get-AtlasCdpTarget $Port
        $null = Invoke-AtlasCdpCommand ([string]$target.webSocketDebuggerUrl) 'Browser.close'
    } catch {}
}

function Get-AtlasPwmBrowserState([int]$Port) {
    $target = Get-AtlasCdpTarget $Port
    $expression = @'
(() => {
  const bodyText = (document.body && document.body.innerText ? document.body.innerText : '').slice(0, 16000);
  return {
    href: String(location.href || ''),
    title: String(document.title || ''),
    hasPassword: Boolean(document.querySelector('input[type="password"]')),
    text: bodyText,
    userAgent: String(navigator.userAgent || '')
  };
})()
'@
    $evaluation = Invoke-AtlasCdpCommand ([string]$target.webSocketDebuggerUrl) 'Runtime.evaluate' @{
        expression=$expression
        returnByValue=$true
        awaitPromise=$true
    }
    $value = $evaluation.result.value
    if (!$value) { throw 'O PWM ainda não concluiu o carregamento da página autenticada.' }
    $href = [string]$value.href
    $text = [string]$value.text
    $hasPassword = [bool]$value.hasPassword
    $authenticatedMarker = $text -match '(?i)(?:suporte\s+t[eé]cnico|hist[oó]rico\s+de\s+senhas|pol[ií]tica\s+de\s+senha|mudar\s+senha|desbloquear|logout|\bsair\b)'
    $leftLoginRoute = $href -match '^https://gestorsenhas\.senado\.leg\.br/private/' -and
        $href -notmatch '(?i)/private/login(?:[/?#]|$)'
    return [PSCustomObject]@{
        Target=$target
        Href=$href
        UserAgent=[string]$value.userAgent
        Authenticated=(!$hasPassword -and ($authenticatedMarker -or $leftLoginRoute))
    }
}

function Import-AtlasPwmBrowserCookies(
    [Microsoft.PowerShell.Commands.WebRequestSession]$Session,
    [int]$Port
) {
    $target = Get-AtlasCdpTarget $Port
    try {
        $result = Invoke-AtlasCdpCommand ([string]$target.webSocketDebuggerUrl) 'Network.getAllCookies'
    } catch {
        $result = Invoke-AtlasCdpCommand ([string]$target.webSocketDebuggerUrl) 'Storage.getCookies'
    }
    $imported = 0
    foreach ($record in @($result.cookies)) {
        $domain = ([string]$record.domain).Trim()
        $normalizedDomain = $domain.TrimStart('.').ToLowerInvariant()
        if (!$domain -or ($normalizedDomain -ne 'senado.leg.br' -and !$normalizedDomain.EndsWith('.senado.leg.br'))) { continue }
        try {
            $path = if ([string]::IsNullOrWhiteSpace([string]$record.path)) { '/' } else { [string]$record.path }
            $cookie = New-Object Net.Cookie([string]$record.name, [string]$record.value, $path, $domain)
            $cookie.Secure = [bool]$record.secure
            $cookie.HttpOnly = [bool]$record.httpOnly
            $unixExpiry = 0.0
            if ([double]::TryParse(
                [string]$record.expires,
                [Globalization.NumberStyles]::Float,
                [Globalization.CultureInfo]::InvariantCulture,
                [ref]$unixExpiry
            ) -and $unixExpiry -gt 0) {
                $cookie.Expires = [DateTimeOffset]::FromUnixTimeSeconds([long][Math]::Floor($unixExpiry)).LocalDateTime
            }
            $Session.Cookies.Add($cookie)
            $imported++
        } catch {}
    }
    return $imported
}

function ConvertTo-AtlasHtmlLines([string]$Html) {
    if ([string]::IsNullOrWhiteSpace($Html)) { return @() }
    $text = $Html -replace '(?is)<(?:br\s*/?|/div|/p|/li|/tr|/td|/th|/label|/button|/a)>', "`n"
    $text = $text -replace '(?is)<script\b[^>]*>.*?</script>', ''
    $text = $text -replace '(?is)<style\b[^>]*>.*?</style>', ''
    $text = $text -replace '(?is)<[^>]+>', ' '
    $text = [Net.WebUtility]::HtmlDecode($text)
    return @($text -split "[`r`n]+" | ForEach-Object { ($_ -replace '\s+', ' ').Trim() } | Where-Object { $_ })
}

function ConvertTo-AtlasComparableText([string]$Text) {
    if ([string]::IsNullOrWhiteSpace($Text)) { return '' }
    $decomposed = $Text.Normalize([Text.NormalizationForm]::FormD)
    $builder = New-Object Text.StringBuilder
    foreach ($character in $decomposed.ToCharArray()) {
        $category = [Globalization.CharUnicodeInfo]::GetUnicodeCategory($character)
        if ($category -ne [Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$builder.Append($character)
        }
    }
    return (($builder.ToString().ToLowerInvariant() -replace '\s+', ' ').Trim())
}

function Get-AtlasHtmlField([string[]]$Lines, [string]$LabelPattern) {
    for ($index = 0; $index -lt $Lines.Count; $index++) {
        $line = [string]$Lines[$index]
        if ($line -match "(?i)^\s*(?:$LabelPattern)\s*[:：]?\s*(?<inline>.+)?$") {
            $inline = ([string]$matches['inline']).Trim()
            if ($inline -and $inline -notmatch '^[*:：-]+$') { return $inline }
            for ($next = $index + 1; $next -lt [Math]::Min($Lines.Count, $index + 4); $next++) {
                $candidate = ([string]$Lines[$next]).Trim()
                if ($candidate -and $candidate -notmatch '^[*:：-]+$') { return $candidate }
            }
        }
    }
    return 'Não informado'
}

function Get-AtlasHtmlForm([string]$Html, [string]$PreferredFieldPattern = '') {
    $forms = @([regex]::Matches($Html, '(?is)<form\b(?<attrs>[^>]*)>(?<body>.*?)</form>'))
    if (!$forms.Count) { return $null }
    $selected = $null
    foreach ($form in $forms) {
        $body = [string]$form.Groups['body'].Value
        if ($PreferredFieldPattern -and $body -match $PreferredFieldPattern) { $selected = $form; break }
        if (!$selected -and $body -match '(?is)<input\b') { $selected = $form }
    }
    if (!$selected) { return $null }
    $attrs = [string]$selected.Groups['attrs'].Value
    $bodyHtml = [string]$selected.Groups['body'].Value
    $actionMatch = [regex]::Match($attrs, '(?is)\baction\s*=\s*["''](?<value>[^"'']*)')
    $methodMatch = [regex]::Match($attrs, '(?is)\bmethod\s*=\s*["''](?<value>[^"'']*)')
    $fields = [ordered]@{}
    $inputs = @()
    foreach ($input in @([regex]::Matches($bodyHtml, '(?is)<input\b(?<attrs>[^>]*)>'))) {
        $inputAttrs = [string]$input.Groups['attrs'].Value
        $nameMatch = [regex]::Match($inputAttrs, '(?is)\bname\s*=\s*["''](?<value>[^"'']+)')
        if (!$nameMatch.Success) { continue }
        $name = [Net.WebUtility]::HtmlDecode($nameMatch.Groups['value'].Value)
        $typeMatch = [regex]::Match($inputAttrs, '(?is)\btype\s*=\s*["''](?<value>[^"'']+)')
        $valueMatch = [regex]::Match($inputAttrs, '(?is)\bvalue\s*=\s*["''](?<value>[^"'']*)')
        $type = if ($typeMatch.Success) { $typeMatch.Groups['value'].Value.ToLowerInvariant() } else { 'text' }
        $value = if ($valueMatch.Success) { [Net.WebUtility]::HtmlDecode($valueMatch.Groups['value'].Value) } else { '' }
        # Somente campos ocultos são reaproveitados automaticamente. Botões
        # como Continuar e Cancelar são mutuamente exclusivos e o chamador
        # precisa selecionar explicitamente qual deles será enviado.
        if ($type -eq 'hidden') { $fields[$name] = $value }
        $inputs += [PSCustomObject]@{ Name=$name; Type=$type; Value=$value }
    }
    foreach ($button in @([regex]::Matches($bodyHtml, '(?is)<button\b(?<attrs>[^>]*)>(?<text>.*?)</button>'))) {
        $buttonAttrs = [string]$button.Groups['attrs'].Value
        $nameMatch = [regex]::Match($buttonAttrs, '(?is)\bname\s*=\s*["''](?<value>[^"'']+)')
        $valueMatch = [regex]::Match($buttonAttrs, '(?is)\bvalue\s*=\s*["''](?<value>[^"'']*)')
        $name = if ($nameMatch.Success) { [Net.WebUtility]::HtmlDecode($nameMatch.Groups['value'].Value) } else { '' }
        $buttonText = ((ConvertTo-AtlasHtmlLines ([string]$button.Groups['text'].Value)) -join ' ')
        $value = if ($valueMatch.Success) { [Net.WebUtility]::HtmlDecode($valueMatch.Groups['value'].Value) } else { $buttonText }
        $inputs += [PSCustomObject]@{ Name=$name; Type='button'; Value=$value }
    }
    return [PSCustomObject]@{
        Action = $(if ($actionMatch.Success) { [Net.WebUtility]::HtmlDecode($actionMatch.Groups['value'].Value) } else { '' })
        Method = $(if ($methodMatch.Success) { $methodMatch.Groups['value'].Value.ToUpperInvariant() } else { 'POST' })
        Fields = $fields
        Inputs = @($inputs)
        Html = $bodyHtml
    }
}

function Resolve-AtlasFormUri([uri]$BaseUri, [string]$Action) {
    if ([string]::IsNullOrWhiteSpace($Action)) { return $BaseUri }
    $resolved = [uri]::new($BaseUri, $Action)
    if ($resolved.Scheme -ne 'https' -or $resolved.Host -ne 'gestorsenhas.senado.leg.br') {
        throw 'O Gestor de Senhas forneceu um formulário fora do domínio autorizado.'
    }
    return $resolved
}
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

if (![string]::IsNullOrWhiteSpace($ModuleRoot)) {
    $certificateModule = Join-Path $ModuleRoot 'certificates_remote.ps1'
    if (Test-Path -LiteralPath $certificateModule -PathType Leaf) {
        . $certificateModule
    }
}

function Require-Computer {
    if ([string]::IsNullOrWhiteSpace($Computer)) { throw "Nenhum computador foi informado." }
}

function Test-LocalComputer {
    if ([string]::IsNullOrWhiteSpace($Computer)) { return $false }
    $clean = $Computer.Replace('\', '').Trim()
    return ($clean -ieq '.' -or $clean -ieq 'localhost' -or $clean -ieq '127.0.0.1' -or
            $clean -ieq '::1' -or $clean -ieq $env:COMPUTERNAME)
}

function Get-LocalProfileCertificates {
    $items = [System.Collections.Generic.List[object]]::new()
    foreach ($definition in @(
        [PSCustomObject]@{ Path='Cert:\CurrentUser\My'; StoreType='CurrentUserMy'; Scope="Usuário local: $env:USERDOMAIN\$env:USERNAME"; User=$env:USERNAME },
        [PSCustomObject]@{ Path='Cert:\LocalMachine\My'; StoreType='LocalMachineMy'; Scope='Computador local'; User='' }
    )) {
        foreach ($certificate in @(Get-ChildItem -LiteralPath $definition.Path -ErrorAction SilentlyContinue)) {
            $display = [string]$certificate.FriendlyName
            if ([string]::IsNullOrWhiteSpace($display)) {
                $commonName = [regex]::Match([string]$certificate.Subject, '(?i)(?:^|,\s*)CN=(?<name>[^,]+)')
                $display = if ($commonName.Success) { $commonName.Groups['name'].Value.Trim() } else { [string]$certificate.Subject }
            }
            if ([string]::IsNullOrWhiteSpace($display)) { $display = [string]$certificate.Thumbprint }
            $now = Get-Date
            $items.Add([PSCustomObject]@{
                FriendlyName=$display; Subject=[string]$certificate.Subject; Issuer=[string]$certificate.Issuer
                NotBefore=$certificate.NotBefore; NotAfter=$certificate.NotAfter
                Thumbprint=[string]$certificate.Thumbprint; SerialNumber=[string]$certificate.SerialNumber
                StoreType=$definition.StoreType; UserAccount=$definition.User; UserSid=''
                HasPrivateKey=[bool]$certificate.HasPrivateKey; IsExpired=($certificate.NotAfter -lt $now)
                IsSigad=($display -match '(?i)SIGAD'); StorageSource='CertProviderLocal'
            })
        }
    }
    return @($items)
}

function Require-RemoteComputer {
    Require-Computer
    $cleanComputer = $Computer.Replace('\', '').Trim()
    if ($cleanComputer -ieq 'localhost' -or $cleanComputer -ieq '127.0.0.1' -or $cleanComputer -ieq $env:COMPUTERNAME) {
        throw 'Esta opção trabalha somente com o computador remoto conectado.'
    }
    if (!(Get-Command Get-CurrentUserProfileCertificates -ErrorAction SilentlyContinue)) {
        throw 'O módulo de certificados remotos não foi carregado.'
    }
}

function ConvertFrom-CertificateRegistryBlob {
    param([byte[]]$Blob)
    if (!$Blob -or $Blob.Length -lt 1) { return $null }
    # O valor Blob do registro é um conjunto de propriedades. A propriedade
    # CERT_CERT_PROP_ID (32) contém o DER que o X509Certificate2 consegue ler.
    $offset = 0
    while (($offset + 12) -le $Blob.Length) {
        $propertyId = [BitConverter]::ToUInt32($Blob, $offset)
        $length = [BitConverter]::ToUInt32($Blob, $offset + 8)
        $dataOffset = $offset + 12
        if ($length -gt ($Blob.Length - $dataOffset)) { break }
        if ($propertyId -eq 32 -and $length -gt 0) {
            $certificateBytes = New-Object byte[] $length
            [Array]::Copy($Blob, $dataOffset, $certificateBytes, 0, $length)
            return $certificateBytes
        }
        $offset = $dataOffset + [int]$length
    }
    # Alguns provedores gravam diretamente o DER, sem o envelope de propriedades.
    return $Blob
}

function Get-RemotePersonalCertificates {
    Require-Computer
    $stdReg = [WMICLASS]"\\$Computer\root\default:StdRegProv"
    $HKLM = 2147483650
    $HKU = 2147483651
    $loggedUser = ''
    $loggedSid = ''
    try { $loggedUser = [string](Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName } catch {}
    if ($loggedUser) {
        try {
            $account = New-Object System.Security.Principal.NTAccount -ArgumentList $loggedUser
            $loggedSid = $account.Translate([System.Security.Principal.SecurityIdentifier]).Value
        } catch {}
        if (!$loggedSid) {
            try {
                $userOnly = ($loggedUser -split '\\')[-1]
                $profile = Get-WmiObject Win32_UserProfile -ComputerName $Computer -ErrorAction SilentlyContinue |
                    Where-Object { $_.Loaded -and $_.LocalPath -match "\\$([regex]::Escape($userOnly))$" } |
                    Select-Object -First 1
                if ($profile) { $loggedSid = [string]$profile.SID }
            } catch {}
        }
    }

    $stores = [System.Collections.Generic.List[object]]::new()
    $loadedSids = [System.Collections.Generic.List[string]]::new()
    if ($loggedSid -match '^S-1-5-21-') { $loadedSids.Add($loggedSid) }
    try {
        $hkuEnumeration = $stdReg.EnumKey([uint32]$HKU, '')
        foreach ($candidateSid in @($hkuEnumeration.sNames)) {
            $candidateSid = [string]$candidateSid
            if ($candidateSid -match '^S-1-5-21-[0-9-]+$' -and !$loadedSids.Contains($candidateSid)) {
                $loadedSids.Add($candidateSid)
            }
        }
    } catch {}
    foreach ($sid in $loadedSids) {
        $owner = ''
        if ($sid -eq $loggedSid -and $loggedUser) { $owner = $loggedUser }
        if (!$owner) {
            try {
                $identity = New-Object System.Security.Principal.SecurityIdentifier -ArgumentList $sid
                $owner = $identity.Translate([System.Security.Principal.NTAccount]).Value
            } catch { $owner = $sid }
        }
        $stores.Add([PSCustomObject]@{
            hive = 'HKU'; root = $HKU; sid = $sid
            path = "$sid\Software\Microsoft\SystemCertificates\My\Certificates"
            scope = "Usuário remoto: $owner"
        })
    }
    $stores.Add([PSCustomObject]@{
        hive = 'HKLM'; root = $HKLM; sid = ''
        path = 'SOFTWARE\Microsoft\SystemCertificates\My\Certificates'
        scope = 'Computador remoto'
    })

    $items = [System.Collections.Generic.List[object]]::new()
    $parseFailures = 0
    foreach ($store in $stores) {
        $keys = $stdReg.EnumKey([uint32]$store.root, [string]$store.path)
        foreach ($registryKey in @($keys.sNames)) {
            if ([string]::IsNullOrWhiteSpace([string]$registryKey)) { continue }
            try {
                $certificatePath = "$($store.path)\$registryKey"
                $blob = $stdReg.GetBinaryValue([uint32]$store.root, $certificatePath, 'Blob')
                if (!$blob.uValue) { continue }
                $certificateBytes = ConvertFrom-CertificateRegistryBlob -Blob ([byte[]]$blob.uValue)
                $certificate = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new([byte[]]$certificateBytes)
                $displayName = [string]$certificate.GetNameInfo([System.Security.Cryptography.X509Certificates.X509NameType]::SimpleName, $false)
                if ([string]::IsNullOrWhiteSpace($displayName)) { $displayName = [string]$certificate.Subject }
                if ([string]::IsNullOrWhiteSpace($displayName)) { $displayName = [string]$certificate.Thumbprint }
                $now = Get-Date
                $status = if ($certificate.NotAfter -lt $now) { 'Expirado' } elseif ($certificate.NotBefore -gt $now) { 'Ainda não válido' } else { 'Válido' }
                $items.Add([PSCustomObject]@{
                    display_name = $displayName
                    subject = [string]$certificate.Subject
                    issuer = [string]$certificate.Issuer
                    valid_from = $certificate.NotBefore.ToString('dd/MM/yyyy HH:mm')
                    valid_to = $certificate.NotAfter.ToString('dd/MM/yyyy HH:mm')
                    status = $status
                    thumbprint = ([string]$certificate.Thumbprint).ToUpperInvariant()
                    serial = [string]$certificate.SerialNumber
                    scope = [string]$store.scope
                    hive = [string]$store.hive
                    sid = [string]$store.sid
                    registry_key = [string]$registryKey
                })
            } catch { $parseFailures++ }
        }
    }
    return [PSCustomObject]@{
        station = $Computer
        logged_user = $(if ($loggedUser) { $loggedUser } else { 'Nenhum usuário conectado' })
        count = $items.Count
        parse_failures = $parseFailures
        user_store_count = $loadedSids.Count
        items = @($items)
    }
}

function Get-RemoteMappedDrivePath {
    param([string]$Letter = 'X', [string]$LoggedUser = '')
    Require-Computer
    $drive = $Letter.TrimEnd(':').ToUpper()
    $candidateSids = [System.Collections.Generic.List[string]]::new()
    if (![string]::IsNullOrWhiteSpace($LoggedUser)) {
        try {
            $account = New-Object System.Security.Principal.NTAccount -ArgumentList $LoggedUser
            $candidateSids.Add($account.Translate([System.Security.Principal.SecurityIdentifier]).Value)
        } catch {}
        try {
            $userOnly = ($LoggedUser -split '\\')[-1]
            foreach ($profile in @(Get-WmiObject Win32_UserProfile -ComputerName $Computer -ErrorAction SilentlyContinue |
                Where-Object { $_.Loaded -and $_.LocalPath -match "\\$([regex]::Escape($userOnly))$" })) {
                if ($profile.SID -and !$candidateSids.Contains([string]$profile.SID)) { $candidateSids.Add([string]$profile.SID) }
            }
        } catch {}
    }
    try {
        $stdReg = [WMICLASS]"\\$Computer\root\default:StdRegProv"
        $HKU = 2147483651
        foreach ($sid in @($candidateSids)) {
            $result = $stdReg.GetStringValue($HKU, "$sid\Network\$drive", 'RemotePath')
            if (![string]::IsNullOrWhiteSpace([string]$result.sValue)) { return [string]$result.sValue }
        }

        # A tradução de conta para SID pode falhar entre domínios ou sessões.
        # Percorre todos os perfis carregados para refletir o Explorer real.
        $users = $stdReg.EnumKey($HKU, '')
        foreach ($loadedSid in @($users.sNames)) {
            if ($loadedSid -notlike 'S-1-5-21-*' -or $loadedSid -like '*_Classes') { continue }
            $result = $stdReg.GetStringValue($HKU, "$loadedSid\Network\$drive", 'RemotePath')
            if (![string]::IsNullOrWhiteSpace([string]$result.sValue)) { return [string]$result.sValue }
        }

        # O Explorer pode manter o compartilhamento em MountPoints2 mesmo
        # quando a consulta administrativa não devolve HKU\Network\X.
        if ($drive -eq 'X') {
            foreach ($loadedSid in @($users.sNames)) {
                if ($loadedSid -notlike 'S-1-5-21-*' -or $loadedSid -like '*_Classes') { continue }
                $mounts = $stdReg.EnumKey($HKU, "$loadedSid\Software\Microsoft\Windows\CurrentVersion\Explorer\MountPoints2")
                foreach ($mount in @($mounts.sNames)) {
                    if ($mount -like '##*') {
                        $remote = '\\' + ($mount.Substring(2) -replace '#', '\')
                        $normalized = $remote.ToLowerInvariant() -replace '[\s_]+', ''
                        if ($normalized -match '\\(dru|fs)(\.[^\\]+)?\\central(de)?atendimento$') {
                            return '\\DRU\CENTRAL_ATENDIMENTO'
                        }
                    }
                }
            }
        }
    } catch {}
    try {
        $mapped = Get-WmiObject Win32_MappedLogicalDisk -ComputerName $Computer -Filter "Name='$drive`:'" -ErrorAction SilentlyContinue |
            Select-Object -First 1
        if ($mapped -and $mapped.ProviderName) { return [string]$mapped.ProviderName }
    } catch {}
    return ''
}

function Get-SoftwareCategory {
    param([string]$Text)
    $value = $Text.ToLowerInvariant()
    if ($value -match 'chrome|firefox|edge|opera|browser|navegador|internet') { return 'Navegadores e Internet' }
    if ($value -match 'teams|zoom|webex|skype|comunica|reuni|mensage') { return 'Comunicação e Colaboração' }
    if ($value -match 'office|microsoft 365|word|excel|powerpoint|libreoffice|acrobat|adobe|pdf') { return 'Produtividade e Escritório' }
    if ($value -match 'vpn|anyconnect|forti|token|certifica|antivirus|defender|endpoint|security|seguran') { return 'Segurança e Acesso' }
    if ($value -match 'sccm|cmrc|remote|remoto|teamviewer|anydesk|support|suporte') { return 'Suporte e Acesso Remoto' }
    if ($value -match 'visual studio|vscode|python|node|jdk|java|git|developer|desenvolv') { return 'Desenvolvimento' }
    if ($value -match '7-zip|7zip|winrar|compact|utilit|cleanup|cleaner|notepad\+\+') { return 'Compactação e Utilitários' }
    if ($value -match 'driver|firmware|intel|dell|lenovo|hardware|chipset|scanner') { return 'Drivers e Hardware' }
    if ($value -match 'senado|prodasen|corporativ|sistema|cliente|portal') { return 'Sistemas Corporativos' }
    return 'Outros softwares'
}

function Get-FaqClassification {
    param([string]$Text)
    $value = ([string]$Text).ToLowerInvariant()
    $category = 'Outros assuntos'
    $subcategory = 'Orientações gerais'

    if ($value -match 'outlook|correio|e-mail|email|teams|onedrive|sharepoint|word|excel|powerpoint|office|microsoft 365|m365') {
        $category = 'Microsoft 365'
        if ($value -match 'outlook|correio|e-mail|email') { $subcategory = 'Outlook' }
        elseif ($value -match 'teams|reuni[aã]o|videoconfer') { $subcategory = 'Teams' }
        elseif ($value -match 'onedrive') { $subcategory = 'OneDrive' }
        elseif ($value -match 'sharepoint') { $subcategory = 'SharePoint' }
        elseif ($value -match 'word') { $subcategory = 'Word' }
        elseif ($value -match 'excel') { $subcategory = 'Excel' }
        elseif ($value -match 'powerpoint') { $subcategory = 'PowerPoint' }
        else { $subcategory = 'Microsoft 365 — Geral' }
    }
    elseif ($value -match 'impress|scanner|digitaliza|driver hp|spooler|fila de impress') {
        $category = 'Impressoras'
        if ($value -match 'driver|hp|firmware') { $subcategory = 'Drivers' }
        elseif ($value -match 'mapear|mapeamento|adicionar|conectar|fila') { $subcategory = 'Mapeamento' }
        elseif ($value -match 'instala|configura') { $subcategory = 'Instalação' }
        elseif ($value -match 'scanner|digitaliza') { $subcategory = 'Digitalização' }
        else { $subcategory = 'Solução de problemas' }
    }
    elseif ($value -match 'desktop|notebook|monitor|mouse|teclado|headset|webcam|perif[eé]ric|equipamento|hardware|dock') {
        $category = 'Equipamentos'
        if ($value -match 'notebook|laptop') { $subcategory = 'Notebook' }
        elseif ($value -match 'monitor|tela|v[ií]deo') { $subcategory = 'Monitor' }
        elseif ($value -match 'desktop|microcomputador|esta[cç][aã]o') { $subcategory = 'Desktop' }
        else { $subcategory = 'Periféricos' }
    }
    elseif ($value -match 'capri|otrs|ergon|sigad|senado|prodasen|sistema corporativo|portal corporativo') {
        $category = 'Sistemas corporativos'
        if ($value -match 'capri|otrs') { $subcategory = 'Capri' }
        elseif ($value -match 'ergon') { $subcategory = 'Ergon' }
        elseif ($value -match 'sigad') { $subcategory = 'SIGAD' }
        else { $subcategory = 'Outros sistemas' }
    }
    elseif ($value -match 'chrome|edge|firefox|navegador|internet explorer') {
        $category = 'Navegadores e internet'
        if ($value -match 'edge') { $subcategory = 'Microsoft Edge' }
        elseif ($value -match 'chrome') { $subcategory = 'Google Chrome' }
        elseif ($value -match 'firefox') { $subcategory = 'Mozilla Firefox' }
        else { $subcategory = 'Navegação' }
    }
    elseif ($value -match 'vpn|antiv[ií]rus|defender|mfa|token|seguran[cç]a') {
        $category = 'Segurança e acesso remoto'
        if ($value -match 'vpn') { $subcategory = 'VPN' }
        elseif ($value -match 'mfa|token|duplo fator') { $subcategory = 'MFA e token' }
        elseif ($value -match 'antiv[ií]rus|defender') { $subcategory = 'Proteção da estação' }
        else { $subcategory = 'Acesso seguro' }
    }
    elseif ($value -match 'windows|computador|esta[cç][aã]o|rede|wifi|wi-fi|dns|certific|senha|login|acesso|autentica|atualiza') {
        $category = 'Windows'
        if ($value -match 'certific') { $subcategory = 'Certificados' }
        elseif ($value -match 'rede|wifi|wi-fi|dns|conectividade|ip ') { $subcategory = 'Rede' }
        elseif ($value -match 'senha|login|acesso|autentica|perfil de usu[aá]rio') { $subcategory = 'Acesso e autenticação' }
        elseif ($value -match 'atualiza|windows update|vers[aã]o|upgrade') { $subcategory = 'Atualizações' }
        elseif ($value -match 'arquivo|pasta|explorer') { $subcategory = 'Arquivos e pastas' }
        else { $subcategory = 'Sistema e desempenho' }
    }

    $procedure = 'Orientações gerais'
    if ($value -match 'erro|falha|problema|n[aã]o abre|n[aã]o funciona|corrigir|solu[cç][aã]o') { $procedure = 'Correção de problemas' }
    elseif ($value -match 'senha|login|acesso|autentica|permiss') { $procedure = 'Acesso e autenticação' }
    elseif ($value -match 'instala|adicionar|configura|habilitar') { $procedure = 'Instalação e configuração' }
    elseif ($value -match 'atualiza|vers[aã]o|upgrade') { $procedure = 'Atualização' }
    elseif ($value -match 'remover|excluir|desinstala|limpar') { $procedure = 'Remoção e limpeza' }
    elseif ($value -match 'como|procedimento|passo|orienta') { $procedure = 'Procedimentos' }
    return [PSCustomObject]@{
        Category = $category
        Subcategory = $subcategory
        Procedure = $procedure
        Tool = $subcategory
    }
}

function Add-PrinterName {
    param($List, [string]$Raw)
    if ([string]::IsNullOrWhiteSpace($Raw)) { return }
    $name = $Raw.Trim()
    if ($name -match '^,+([^,]+),(.+)$') { $name = "\\$($matches[1])\$($matches[2])" }
    if ($name -match '\\') { $name = $name.Split('\')[-1].Trim() }
    if ($name -match '(?i)PDF|OneNote|XPS|Fax|Microsoft|Send To|Root|CutePDF|Virtual|Generic|Document Writer') { return }
    if ($name -match '^\{[0-9a-fA-F-]+\}$') { return }
    if ($name -and !$List.Contains($name)) { $List.Add($name) }
}

function Get-PrinterReachability {
    param([string]$PrinterName)
    if ([string]::IsNullOrWhiteSpace($PrinterName)) { return 'Offline' }

    $hostName = $PrinterName.Trim()
    if ($hostName -match '\\') { $hostName = $hostName.Split('\')[-1].Trim() }
    if ([string]::IsNullOrWhiteSpace($hostName)) { return 'Offline' }

    try {
        $ping = [System.Net.NetworkInformation.Ping]::new()
        try {
            $reply = $ping.Send($hostName, 800)
            if ($reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) { return 'Online' }
        } finally {
            $ping.Dispose()
        }
    } catch {}
    return 'Offline'
}

function Get-AllRemotePrinters {
    Require-Computer
    $list = [System.Collections.Generic.List[string]]::new()
    try {
        $regLM = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $Computer)
        foreach ($path in @(
            'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Connections',
            'SYSTEM\CurrentControlSet\Control\Print\Printers'
        )) {
            $key = $regLM.OpenSubKey($path)
            if ($key) { foreach ($sub in $key.GetSubKeyNames()) { Add-PrinterName $list $sub }; $key.Close() }
        }
        $csr = $regLM.OpenSubKey('SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Providers\Client Side Rendering Print Provider\Servers')
        if ($csr) {
            foreach ($server in $csr.GetSubKeyNames()) {
                $pk = $csr.OpenSubKey("$server\Printers")
                if ($pk) { foreach ($share in $pk.GetSubKeyNames()) { Add-PrinterName $list "\\$server\$share" }; $pk.Close() }
            }
            $csr.Close()
        }
        $lanman = $regLM.OpenSubKey('SYSTEM\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers')
        if ($lanman) {
            foreach ($server in $lanman.GetSubKeyNames()) {
                $pk = $lanman.OpenSubKey("$server\Printers")
                if ($pk) { foreach ($share in $pk.GetSubKeyNames()) { Add-PrinterName $list "\\$server\$share" }; $pk.Close() }
            }
            $lanman.Close()
        }
        $regLM.Close()
    } catch {}
    try {
        $regUsers = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::Users, $Computer)
        foreach ($sid in $regUsers.GetSubKeyNames()) {
            if ($sid -match 'Classes$|^\.DEFAULT$|^S-1-5-1[89]$|^S-1-5-20$') { continue }
            $conn = $regUsers.OpenSubKey("$sid\Printers\Connections")
            if ($conn) { foreach ($sub in $conn.GetSubKeyNames()) { Add-PrinterName $list $sub }; $conn.Close() }
            foreach ($path in @(
                "$sid\Software\Microsoft\Windows NT\CurrentVersion\PrinterPorts",
                "$sid\Software\Microsoft\Windows NT\CurrentVersion\Devices"
            )) {
                $key = $regUsers.OpenSubKey($path)
                if ($key) { foreach ($valueName in $key.GetValueNames()) { Add-PrinterName $list $valueName }; $key.Close() }
            }
        }
        $regUsers.Close()
    } catch {}
    try {
        $stdReg = [WMICLASS]"\\$Computer\root\default:StdRegProv"
        $HKLM = 2147483650
        $HKU = 2147483651
        $connections = $stdReg.EnumKey($HKLM, 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Connections')
        foreach ($name in @($connections.sNames)) { Add-PrinterName $list $name }
        $servers = $stdReg.EnumKey($HKLM, 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Providers\Client Side Rendering Print Provider\Servers')
        foreach ($server in @($servers.sNames)) {
            $shares = $stdReg.EnumKey($HKLM, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Providers\Client Side Rendering Print Provider\Servers\$server\Printers")
            foreach ($share in @($shares.sNames)) { Add-PrinterName $list "\\$server\$share" }
        }
        $lanmanServers = $stdReg.EnumKey($HKLM, 'SYSTEM\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers')
        foreach ($server in @($lanmanServers.sNames)) {
            $shares = $stdReg.EnumKey($HKLM, "SYSTEM\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers\$server\Printers")
            foreach ($share in @($shares.sNames)) { Add-PrinterName $list "\\$server\$share" }
        }
        $users = $stdReg.EnumKey($HKU, '')
        foreach ($sid in @($users.sNames)) {
            if ($sid -match 'Classes$|^\.DEFAULT$|^S-1-5-1[89]$|^S-1-5-20$') { continue }
            $userConnections = $stdReg.EnumKey($HKU, "$sid\Printers\Connections")
            foreach ($name in @($userConnections.sNames)) { Add-PrinterName $list $name }
            foreach ($path in @(
                "$sid\Software\Microsoft\Windows NT\CurrentVersion\PrinterPorts",
                "$sid\Software\Microsoft\Windows NT\CurrentVersion\Devices"
            )) {
                $values = $stdReg.EnumValues($HKU, $path)
                foreach ($name in @($values.sNames)) { Add-PrinterName $list $name }
            }
        }
    } catch {}
    try {
        foreach ($printer in @(Get-WmiObject Win32_Printer -ComputerName $Computer -ErrorAction SilentlyContinue)) {
            Add-PrinterName $list $printer.Name
            if ($printer.PortName -like '\\*') { Add-PrinterName $list $printer.PortName }
            if ($printer.ServerName -and $printer.ShareName) { Add-PrinterName $list "\\$($printer.ServerName.TrimStart('\'))\$($printer.ShareName)" }
        }
    } catch {}
    return $list
}

function Get-RemoteDefaultPrinter {
    param([string]$LoggedUser)
    Require-Computer
    if ([string]::IsNullOrWhiteSpace($LoggedUser)) { return "" }
    $userOnly = ($LoggedUser -split '\\')[-1]
    $sid = ""
    try {
        $account = New-Object System.Security.Principal.NTAccount -ArgumentList $LoggedUser
        $sid = $account.Translate([System.Security.Principal.SecurityIdentifier]).Value
    } catch {}
    if ([string]::IsNullOrWhiteSpace($sid)) {
        try {
            $profile = Get-WmiObject Win32_UserProfile -ComputerName $Computer -ErrorAction Stop |
                Where-Object { $_.Loaded -and $_.LocalPath -match "\\$([regex]::Escape($userOnly))$" } |
                Select-Object -First 1
            if ($profile) { $sid = $profile.SID }
        } catch {}
    }
    if (![string]::IsNullOrWhiteSpace($sid)) {
        try {
            $regUsers = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::Users, $Computer)
            $windowsKey = $regUsers.OpenSubKey("$sid\Software\Microsoft\Windows NT\CurrentVersion\Windows")
            if ($windowsKey) {
                $device = [string]$windowsKey.GetValue('Device', '')
                $windowsKey.Close()
                $regUsers.Close()
                if (![string]::IsNullOrWhiteSpace($device)) {
                    $name = ($device -split ',')[0].Trim()
                    if ($name -match '\\') { $name = $name.Split('\')[-1].Trim() }
                    if ($name) { return $name }
                }
            } else { $regUsers.Close() }
        } catch {}
        try {
            $stdReg = [WMICLASS]"\\$Computer\root\default:StdRegProv"
            $deviceResult = $stdReg.GetStringValue(2147483651, "$sid\Software\Microsoft\Windows NT\CurrentVersion\Windows", 'Device')
            $device = [string]$deviceResult.sValue
            if (![string]::IsNullOrWhiteSpace($device)) {
                $name = ($device -split ',')[0].Trim()
                if ($name -match '\\') { $name = $name.Split('\')[-1].Trim() }
                if ($name) { return $name }
            }
        } catch {}
    }
    try {
        $default = Get-WmiObject Win32_Printer -ComputerName $Computer -ErrorAction Stop |
            Where-Object { $_.Default } | Select-Object -First 1
        if ($default) {
            $name = [string]$default.Name
            if ($name -match '\\') { $name = $name.Split('\')[-1].Trim() }
            return $name
        }
    } catch {}
    return ""
}

function Remove-RemoteScheduledTaskQuiet {
    param([string]$TaskName, [switch]$EndFirst)
    if ([string]::IsNullOrWhiteSpace($TaskName) -or [string]::IsNullOrWhiteSpace($Computer)) { return }
    $scheduler = Join-Path $env:SystemRoot 'System32\schtasks.exe'
    try {
        if ($EndFirst) {
            $endArguments = @('/end', '/s', $Computer, '/tn', $TaskName)
            $null = Start-Process -FilePath $scheduler -ArgumentList $endArguments -WindowStyle Hidden -Wait -PassThru
        }
        $deleteArguments = @('/delete', '/s', $Computer, '/tn', $TaskName, '/f')
        $null = Start-Process -FilePath $scheduler -ArgumentList $deleteArguments -WindowStyle Hidden -Wait -PassThru
    } catch {}
}

function Invoke-InteractiveTask {
    param(
        [string]$TaskName,
        [string]$Command,
        [string]$Arguments,
        [string]$RunLevel = 'LeastPrivilege',
        [bool]$DeleteAfterStart = $true,
        [string]$InteractiveUser = '',
        [int]$PostStartDelayMilliseconds = 3000
    )
    Require-Computer
    $user = $InteractiveUser
    if ([string]::IsNullOrWhiteSpace($user)) {
        $user = (Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
    }
    if (!$user) { throw 'Nenhum usuario conectado foi identificado.' }
    $xmlPath = Join-Path $env:TEMP "$TaskName.xml"
    $safeUser = [Security.SecurityElement]::Escape($user)
    $safeCommand = [Security.SecurityElement]::Escape($Command)
    $safeArguments = [Security.SecurityElement]::Escape($Arguments)
    $xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
 <Principals><Principal id="Author"><UserId>$safeUser</UserId><LogonType>InteractiveToken</LogonType><RunLevel>$RunLevel</RunLevel></Principal></Principals>
 <Settings><AllowStartOnDemand>true</AllowStartOnDemand><Enabled>true</Enabled><Hidden>false</Hidden><ExecutionTimeLimit>PT1H</ExecutionTimeLimit></Settings>
 <Actions Context="Author"><Exec><Command>$safeCommand</Command><Arguments>$safeArguments</Arguments></Exec></Actions>
</Task>
"@
    try {
        [IO.File]::WriteAllText($xmlPath, $xml, [Text.Encoding]::Unicode)
        $created = schtasks /create /s $Computer /tn $TaskName /xml $xmlPath /f 2>&1
        if ($LASTEXITCODE -ne 0) { throw "Falha ao criar tarefa: $created" }
        $started = schtasks /run /s $Computer /tn $TaskName 2>&1
        if ($LASTEXITCODE -ne 0) { throw "Falha ao iniciar tarefa: $started" }
        if ($PostStartDelayMilliseconds -gt 0) {
            Start-Sleep -Milliseconds $PostStartDelayMilliseconds
        }
    } finally {
        if ($DeleteAfterStart) {
            Remove-RemoteScheduledTaskQuiet -TaskName $TaskName
        }
        Remove-Item -LiteralPath $xmlPath -Force -ErrorAction SilentlyContinue
    }
}

function Load-AtlasRemoteMessage {
    $path = Join-Path $ModuleRoot 'remote_message.ps1'
    if (!(Test-Path -LiteralPath $path -PathType Leaf)) { throw 'O módulo de mensagens remotas não foi localizado.' }
    return [scriptblock]::Create((Get-Content -LiteralPath $path -Raw -Encoding UTF8))
}

function Show-RemoteServiceEvaluation {
    . (Load-AtlasRemoteMessage)
    Invoke-AtlasRemoteMessage -Kind 'evaluation'
}

function Show-RemoteUserOrientation {
    . (Load-AtlasRemoteMessage)
    Invoke-AtlasRemoteMessage -Kind 'orientation'
}

function Show-RemoteSupportEscalation {
    . (Load-AtlasRemoteMessage)
    Invoke-AtlasRemoteMessage -Kind 'escalation'
}

function Open-RemoteBrowserClearPage {
    param([ValidateSet('chrome','edge')][string]$Browser)
    Require-Computer
    $token = [guid]::NewGuid().ToString('N').Substring(0, 8)
    $taskName = "Suporte_LimpezaNavegador_${Browser}_$token"
    $page = if ($Browser -eq 'chrome') { 'chrome://settings/clearBrowserData' } else { 'edge://settings/clearBrowserData' }

    # A URL interna do Chromium pode ser ignorada quando a instancia existente
    # e reaproveitada. O atalho Ctrl+Shift+Delete e nativo no Chrome e no Edge e
    # abre diretamente o painel de limpeza de dados de navegacao.
    $remoteCode = @"
`$ErrorActionPreference = 'Stop'
`$browser = '$Browser'
`$appName = if (`$browser -eq 'chrome') { 'chrome.exe' } else { 'msedge.exe' }
`$key = "HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\`$appName"
`$machineKey = "HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\`$appName"
`$paths = New-Object 'System.Collections.Generic.List[string]'
foreach (`$registryPath in @(`$key, `$machineKey)) {
    try {
        `$registered = [string](Get-Item -LiteralPath `$registryPath -ErrorAction Stop).GetValue('')
        if (`$registered) { `$paths.Add(`$registered) }
    } catch {}
}

if (`$browser -eq 'chrome') {
    `$paths.Add((Join-Path `$env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'))
    `$paths.Add((Join-Path `$env:ProgramFiles 'Google\Chrome\Application\chrome.exe'))
    if (`${env:ProgramFiles(x86)}) { `$paths.Add((Join-Path `${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe')) }
} else {
    `$paths.Add((Join-Path `$env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'))
    if (`${env:ProgramFiles(x86)}) { `$paths.Add((Join-Path `${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe')) }
    `$paths.Add((Join-Path `$env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'))
}

`$exe = `$paths | Where-Object { `$_ -and (Test-Path -LiteralPath `$_ -PathType Leaf) } | Select-Object -First 1
if (!`$exe) { throw "Executavel de `$browser nao encontrado na sessao remota." }

# Abre/ativa o navegador na sessao interativa do usuario.
Start-Process -FilePath `$exe | Out-Null
Start-Sleep -Seconds 2

# Localiza uma janela real do navegador. O processo devolvido por Start-Process
# pode ser apenas o broker quando ja existe uma instancia aberta.
`$processName = if (`$browser -eq 'chrome') { 'chrome' } else { 'msedge' }
`$windowProc = `$null
for (`$i = 0; `$i -lt 12 -and -not `$windowProc; `$i++) {
    `$windowProc = Get-Process -Name `$processName -ErrorAction SilentlyContinue |
        Where-Object { `$_.MainWindowHandle -ne 0 } |
        Sort-Object StartTime -Descending |
        Select-Object -First 1
    if (-not `$windowProc) { Start-Sleep -Milliseconds 250 }
}

`$shell = New-Object -ComObject WScript.Shell
`$activated = `$false
if (`$windowProc) {
    try { `$activated = [bool]`$shell.AppActivate([int]`$windowProc.Id) } catch {}
}
if (-not `$activated) {
    `$title = if (`$browser -eq 'chrome') { 'Google Chrome' } else { 'Microsoft Edge' }
    try { `$activated = [bool]`$shell.AppActivate(`$title) } catch {}
}
if (-not `$activated) { throw 'Nao foi possivel ativar a janela do navegador na sessao remota.' }

Start-Sleep -Milliseconds 700
# Atalho nativo dos navegadores Chromium para "Limpar dados de navegacao".
`$shell.SendKeys('^+{DELETE}')
"@
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($remoteCode))
    Invoke-InteractiveTask -TaskName $taskName -Command 'powershell.exe' -Arguments "-NoProfile -WindowStyle Hidden -EncodedCommand $encoded"
    Write-Output ("Solicitacao enviada para abrir {0} e acionar Ctrl+Shift+Delete na sessao do usuario remoto. A limpeza ainda precisa ser confirmada no navegador." -f $Browser)
}

function Close-RemoteBrowser {
    param([ValidateSet('chrome','edge')][string]$Browser)
    Require-Computer
    $processName = if ($Browser -eq 'chrome') { 'chrome.exe' } else { 'msedge.exe' }
    $displayName = if ($Browser -eq 'chrome') { 'Google Chrome' } else { 'Microsoft Edge' }

    $before = @(Get-WmiObject Win32_Process -ComputerName $Computer -Filter "Name='$processName'" -ErrorAction Stop)
    if (!$before.Count) {
        Write-Output "$displayName já estava completamente fechado em $Computer."
        return
    }

    # Um PID isolado pode recusar o taskkill mesmo quando os demais são
    # encerrados. Por isso cada tentativa usa WMI e taskkill como mecanismos
    # complementares, sem transformar o stderr do comando nativo em falha
    # prematura. Somente a verificação final determina o resultado da ação.
    $remaining = $before
    for ($attempt = 1; $attempt -le 3 -and $remaining.Count; $attempt++) {
        foreach ($process in $remaining) {
            try { $null = $process.Terminate() } catch {}
        }
        try {
            $taskkillPath = Join-Path $env:SystemRoot 'System32\taskkill.exe'
            $null = Start-Process -FilePath $taskkillPath `
                -ArgumentList @('/S', $Computer, '/IM', $processName, '/F') `
                -WindowStyle Hidden -Wait -PassThru -ErrorAction SilentlyContinue
        } catch {}
        Start-Sleep -Milliseconds 700
        $remaining = @(Get-WmiObject Win32_Process -ComputerName $Computer -Filter "Name='$processName'" -ErrorAction SilentlyContinue)
    }
    if ($remaining.Count) {
        $remainingPids = (@($remaining | ForEach-Object { $_.ProcessId }) -join ', ')
        throw "Não foi possível encerrar completamente o $displayName em $Computer após 3 tentativas. PID(s) restante(s): $remainingPids."
    }
    Write-Output "$displayName fechado completamente em $Computer. $($before.Count) processo(s) encerrado(s)."
}

function Close-RemoteOutlook {
    Require-Computer
    $filter = "Name='OUTLOOK.EXE' OR Name='olk.exe'"
    $remaining = @(Get-WmiObject Win32_Process -ComputerName $Computer -Filter $filter -ErrorAction Stop)
    if (!$remaining.Count) {
        Write-Output "Outlook já estava fechado em $Computer. Nenhum processo encontrado."
        return
    }
    $initialCount = $remaining.Count
    $taskkillPath = Join-Path $env:SystemRoot 'System32\taskkill.exe'
    for ($attempt = 1; $attempt -le 3 -and $remaining.Count; $attempt++) {
        foreach ($process in $remaining) {
            try { $null = $process.Terminate() } catch {}
        }
        Start-Sleep -Milliseconds 350
        $remaining = @(Get-WmiObject Win32_Process -ComputerName $Computer -Filter $filter -ErrorAction Stop)
        if (!$remaining.Count) { break }
        # Tenta taskkill apenas para os executáveis ainda presentes. A saída
        # nativa de “processo não encontrado” não determina o resultado.
        foreach ($processName in @($remaining | Select-Object -ExpandProperty Name -Unique)) {
            try {
                $null = Start-Process -FilePath $taskkillPath `
                    -ArgumentList @('/S', $Computer, '/IM', $processName, '/F') `
                    -WindowStyle Hidden -Wait -PassThru -ErrorAction Stop
            } catch {}
        }
        Start-Sleep -Milliseconds 550
        $remaining = @(Get-WmiObject Win32_Process -ComputerName $Computer -Filter $filter -ErrorAction Stop)
    }
    if ($remaining.Count) {
        $remainingPids = (@($remaining | ForEach-Object { $_.ProcessId }) -join ', ')
        throw "O Outlook ainda está aberto em $Computer após 3 tentativas. PID(s) restante(s): $remainingPids."
    }
    Write-Output "Outlook fechado e confirmado em $Computer. $initialCount processo(s) encerrado(s)."
}

function Get-RemoteSessionExecutables {
    param([string]$LoggedUser)
    Require-Computer
    if ([string]::IsNullOrWhiteSpace($LoggedUser)) { return @() }
    $candidateSids = [System.Collections.Generic.List[string]]::new()
    try {
        $account = New-Object System.Security.Principal.NTAccount -ArgumentList $LoggedUser
        $candidateSids.Add($account.Translate([System.Security.Principal.SecurityIdentifier]).Value)
    } catch {}
    try {
        foreach ($profile in @(Get-WmiObject Win32_UserProfile -ComputerName $Computer -ErrorAction SilentlyContinue | Where-Object { $_.Loaded -and $_.SID })) {
            if (!$candidateSids.Contains([string]$profile.SID)) { $candidateSids.Add([string]$profile.SID) }
        }
    } catch {}
    $token = [guid]::NewGuid().ToString('N')
    $valueName = "Catalog_$token"
    $remoteScript = @"
`$items = @(Get-ChildItem -LiteralPath 'X:\' -Filter '*.exe' -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object { `$_.FullName })
`$json = ConvertTo-Json -InputObject @(`$items) -Compress
New-Item -Path 'HKCU:\Software\GerenciadorSuporteSenado' -Force -ErrorAction SilentlyContinue | Out-Null
Set-ItemProperty -Path 'HKCU:\Software\GerenciadorSuporteSenado' -Name '$valueName' -Value `$json -Type String -Force
"@
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($remoteScript))
    $taskName = 'Suporte_CatalogoSoftware_' + $token.Substring(0, 8)
    Invoke-InteractiveTask -TaskName $taskName -Command 'powershell.exe' -Arguments "-NoProfile -WindowStyle Hidden -EncodedCommand $encoded"
    try {
        $stdReg = [WMICLASS]"\\$Computer\root\default:StdRegProv"
        $HKU = 2147483651
        try {
            $loadedUsers = $stdReg.EnumKey($HKU, '')
            foreach ($loadedSid in @($loadedUsers.sNames)) {
                if ($loadedSid -like 'S-1-5-21-*' -and $loadedSid -notlike '*_Classes' -and !$candidateSids.Contains([string]$loadedSid)) {
                    $candidateSids.Add([string]$loadedSid)
                }
            }
        } catch {}
        for ($attempt = 0; $attempt -lt 15; $attempt++) {
            foreach ($sid in @($candidateSids)) {
                $result = $stdReg.GetStringValue($HKU, "$sid\Software\GerenciadorSuporteSenado", $valueName)
                $json = [string]$result.sValue
                if (![string]::IsNullOrWhiteSpace($json)) {
                    try { $stdReg.DeleteValue($HKU, "$sid\Software\GerenciadorSuporteSenado", $valueName) | Out-Null } catch {}
                    return @($json | ConvertFrom-Json)
                }
            }
            Start-Sleep -Seconds 1
        }
    } catch {}
    return @()
}

function Get-RemoteInteractiveUsers {
    Require-Computer
    $users = [System.Collections.Generic.List[string]]::new()
    $primaryUser = ''
    try { $primaryUser = [string](Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName } catch {}
    if (![string]::IsNullOrWhiteSpace($primaryUser)) { $users.Add($primaryUser.Trim()) }

    # O proprietário do explorer.exe representa a sessão que realmente exibe
    # os mapeamentos. É mais confiável que Win32_ComputerSystem em RDP, troca
    # rápida de usuário e máquinas que mantêm mais de uma sessão carregada.
    try {
        foreach ($process in @(Get-WmiObject Win32_Process -ComputerName $Computer -Filter "Name='explorer.exe'" -ErrorAction SilentlyContinue)) {
            try {
                $owner = $process.GetOwner()
                if ($owner.ReturnValue -eq 0 -and $owner.User) {
                    $qualified = if ($owner.Domain) { "$($owner.Domain)\$($owner.User)" } else { [string]$owner.User }
                    if (!$users.Contains($qualified)) { $users.Add($qualified) }
                }
            } catch {}
        }
    } catch {}
    return @($users)
}

<# A implementação avançada foi movida para network_drives.ps1. Mantemos este
   bloco somente como histórico local, sem permitir que sua análise sintática
   interfira nas ações básicas de conexão do bridge.
function Get-CanonicalNetworkPath {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return '' }
    $clean = $Path.Trim().TrimEnd('\', '/')
    $parts = @($clean -split '[\\/]+' | Where-Object { $_ })
    if ($parts.Count -lt 2) { return $clean }
    $server = $parts[0].ToLowerInvariant()
    $share = $parts[1]
    $shareKey = $share.ToLowerInvariant() -replace '[\s_]+', ''
    if ($server -eq 'fs' -or $server -eq 'dru' -or $server -like 'fs.*' -or $server -like 'dru.*') {
        if ($shareKey -match '^biblioteca(setorial)?$') { return '\\DRU\BIBLIOTECA_SETORIAL' }
        if ($shareKey -match '^central(de)?atendimento$') { return '\\DRU\CENTRAL_ATENDIMENTO' }
        return "\\DRU\$($share.ToUpperInvariant())"
    }
    if (($server -eq 'scanserver' -or $server -like 'scanserver.*') -and $shareKey -match '^scanfolders?$') {
        return '\\scanserver\scanfolders'
    }
    return $clean
}

function Get-StandardNetworkLetter {
    param([string]$Path, [string]$Sector = '')
    $canonical = Get-CanonicalNetworkPath $Path
    $parts = @($canonical -split '[\\/]+' | Where-Object { $_ })
    if ($parts.Count -lt 2) { return '' }
    $server = $parts[0].ToLowerInvariant()
    $shareKey = $parts[1].ToLowerInvariant() -replace '[\s_]+', '' -replace '^centralde', 'central'
    if ($server -like 'scanserver*' -or $shareKey -match '^scanfolders?$') { return 'R:' }
    if ($shareKey -eq 'share') { return 'V:' }
    if ($shareKey -match '^biblioteca(setorial)?$') { return 'W:' }
    if ($shareKey -eq 'centralatendimento') { return 'X:' }
    $sectorKey = $Sector.ToLowerInvariant() -replace '[\s_]+', ''
    if ($server -eq 'dru' -and (($sectorKey -and $shareKey -eq $sectorKey) -or $shareKey -notmatch '^(share|biblioteca(setorial)?|centralatendimento)$')) { return 'U:' }
    return ''
}

function Get-RemoteExplorerNetworkDrives {
    param([string]$LoggedUser = '')
    Require-Computer
    $results = [System.Collections.Generic.List[object]]::new()
    $seenLetters = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    $seenPaths = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    $sector = ''
    try {
        $userOnly = ($LoggedUser -split '\\')[-1] -replace '(?i)_INS$', ''
        if ($userOnly) {
            $searcher = New-Object DirectoryServices.DirectorySearcher
            $searcher.Filter = "(&(objectCategory=person)(objectClass=user)(sAMAccountName=$userOnly))"
            @('scriptpath','department') | ForEach-Object { [void]$searcher.PropertiesToLoad.Add($_) }
            $entry = $searcher.FindOne()
            if ($entry) {
                $scriptPath = [string]$entry.Properties['scriptpath'][0]
                if ($scriptPath) { $sector = ([IO.Path]::GetFileNameWithoutExtension($scriptPath)).ToUpperInvariant() }
                elseif ($entry.Properties['department']) { $sector = [string]$entry.Properties['department'][0] }
            }
        }
    } catch {}

    $addDrive = {
        param([string]$Letter, [string]$Remote, [string]$Source, [bool]$AllowInference)
        if ([string]::IsNullOrWhiteSpace($Remote)) { return }
        $canonical = Get-CanonicalNetworkPath $Remote
        $pathKey = $canonical.ToLowerInvariant().TrimEnd('\')
        $drive = ([string]$Letter).Trim().ToUpperInvariant()
        if ($drive -and $drive -notmatch ':$') { $drive += ':' }
        if ($drive -notmatch '^[A-Z]:$' -and $AllowInference) { $drive = Get-StandardNetworkLetter -Path $canonical -Sector $sector }
        if ($drive -notmatch '^[A-Z]:$') { return }
        if ($seenLetters.Contains($drive)) { return }
        [void]$seenLetters.Add($drive); [void]$seenPaths.Add($pathKey)
        $label = try { Split-Path $canonical.TrimEnd('\') -Leaf } catch { 'Unidade de rede' }
        $results.Add([PSCustomObject]@{ drive=$drive; provider=$canonical; size=[int64]0; free=[int64]0; label=$label; filesystem=''; source=$Source })
    }

    # Fontes persistidas pelo Explorer para todos os perfis carregados.
    try {
        $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::Users, $Computer)
        foreach ($sid in @($reg.GetSubKeyNames())) {
            if ($sid -notlike 'S-1-5-21-*' -or $sid -like '*_Classes') { continue }
            $network = $reg.OpenSubKey("$sid\Network")
            if ($network) {
                foreach ($letter in @($network.GetSubKeyNames())) {
                    $key = $network.OpenSubKey($letter)
                    $remote = if ($key) { [string]$key.GetValue('RemotePath', '') } else { '' }
                    if ($key) { $key.Close() }
                    & $addDrive $letter $remote 'HKU\Network' $false
                }
                $network.Close()
            }
            $mounts = $reg.OpenSubKey("$sid\Software\Microsoft\Windows\CurrentVersion\Explorer\MountPoints2")
            if ($mounts) {
                foreach ($name in @($mounts.GetSubKeyNames())) {
                    if ($name -like '##*') {
                        $remote = '\\' + ($name.Substring(2) -replace '#', '\')
                        & $addDrive '' $remote 'Explorer\MountPoints2' $true
                    }
                }
                $mounts.Close()
            }
        }
        $reg.Close()
    } catch {}

    # WinRM acrescenta as fontes visíveis no contexto remoto quando disponível.
    try {
        $remoteRecords = @(Invoke-Command -ComputerName $Computer -ErrorAction Stop -ScriptBlock {
            $items = @()
            foreach ($d in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
                if ($d.DisplayRoot) { $items += [PSCustomObject]@{ drive="$($d.Name):"; provider=[string]$d.DisplayRoot; source='Get-PSDrive' } }
            }
            try {
                $network = New-Object -ComObject WScript.Network
                $mapped = $network.EnumNetworkDrives()
                for ($i=0; $i -lt $mapped.Count; $i+=2) { $items += [PSCustomObject]@{ drive=[string]$mapped.Item($i); provider=[string]$mapped.Item($i+1); source='WScript.Network' } }
            } catch {}
            foreach ($line in @(net use 2>$null)) {
                if ($line -match '([A-Z]:)\s+(\\\\[^\s]+)') { $items += [PSCustomObject]@{ drive=$matches[1]; provider=$matches[2]; source='net use' } }
            }
            $items
        })
        foreach ($record in $remoteRecords) { & $addDrive ([string]$record.drive) ([string]$record.provider) ([string]$record.source) $false }
    } catch {}
    return @($results)
}
#>

function Get-RemoteWtsMappedDrives {
    Require-Computer
    $token = [guid]::NewGuid().ToString('N')
    $taskName = 'Suporte_WtsDrives_' + $token.Substring(0, 8)
    $registryPath = "SOFTWARE\GSS\WTS_$token"
    $valueName = 'Result'
    $serviceName = 'GSSWts_' + $token.Substring(0, 12)
    $remoteScript = @"
Add-Type @'
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;

public sealed class GssWtsDriveRecord {
    public int SessionId { get; set; }
    public string Owner { get; set; }
    public string Drive { get; set; }
    public string Remote { get; set; }
    public string Label { get; set; }
    public string FileSystem { get; set; }
    public long Total { get; set; }
    public long Free { get; set; }
}

public static class GssWtsDriveCollector {
    private enum WTS_CONNECTSTATE_CLASS { Active, Connected, ConnectQuery, Shadow, Disconnected, Idle, Listen, Reset, Down, Init }
    [StructLayout(LayoutKind.Sequential)]
    private struct WTS_SESSION_INFO {
        public int SessionID;
        public IntPtr WinStationName;
        public WTS_CONNECTSTATE_CLASS State;
    }
    [DllImport("wtsapi32.dll", SetLastError=true)]
    private static extern bool WTSEnumerateSessions(IntPtr server, int reserved, int version, out IntPtr sessions, out int count);
    [DllImport("wtsapi32.dll")]
    private static extern void WTSFreeMemory(IntPtr memory);
    [DllImport("wtsapi32.dll", SetLastError=true)]
    private static extern bool WTSQueryUserToken(uint sessionId, out IntPtr token);
    [DllImport("kernel32.dll")]
    private static extern bool CloseHandle(IntPtr handle);
    [DllImport("mpr.dll", CharSet=CharSet.Unicode)]
    private static extern int WNetGetConnection(string localName, StringBuilder remoteName, ref int length);

    public static List<GssWtsDriveRecord> Collect() {
        var records = new List<GssWtsDriveRecord>();
        IntPtr sessions = IntPtr.Zero;
        int count = 0;
        if (!WTSEnumerateSessions(IntPtr.Zero, 0, 1, out sessions, out count)) return records;
        int dataSize = Marshal.SizeOf(typeof(WTS_SESSION_INFO));
        try {
            for (int index = 0; index < count; index++) {
                var info = (WTS_SESSION_INFO)Marshal.PtrToStructure(IntPtr.Add(sessions, index * dataSize), typeof(WTS_SESSION_INFO));
                if (info.State != WTS_CONNECTSTATE_CLASS.Active && info.State != WTS_CONNECTSTATE_CLASS.Connected && info.State != WTS_CONNECTSTATE_CLASS.Disconnected) continue;
                IntPtr userToken = IntPtr.Zero;
                if (!WTSQueryUserToken((uint)info.SessionID, out userToken) || userToken == IntPtr.Zero) continue;
                try {
                    using (var identity = new WindowsIdentity(userToken))
                    using (var context = identity.Impersonate()) {
                        for (char letter = 'A'; letter <= 'Z'; letter++) {
                            string drive = letter + ":";
                            int capacity = 32768;
                            var buffer = new StringBuilder(capacity);
                            if (WNetGetConnection(drive, buffer, ref capacity) != 0 || buffer.Length == 0) continue;
                            var record = new GssWtsDriveRecord {
                                SessionId = info.SessionID,
                                Owner = identity.Name,
                                Drive = drive,
                                Remote = buffer.ToString(),
                                Label = "",
                                FileSystem = "",
                                Total = 0,
                                Free = 0
                            };
                            try {
                                var disk = new DriveInfo(drive + "\\");
                                if (disk.IsReady) {
                                    record.Label = disk.VolumeLabel;
                                    record.FileSystem = disk.DriveFormat;
                                    record.Total = disk.TotalSize;
                                    record.Free = disk.AvailableFreeSpace;
                                }
                            } catch { }
                            if (String.IsNullOrWhiteSpace(record.Label)) {
                                string trimmed = record.Remote.TrimEnd('\\');
                                int slash = trimmed.LastIndexOf('\\');
                                record.Label = slash >= 0 ? trimmed.Substring(slash + 1) : trimmed;
                            }
                            records.Add(record);
                        }
                    }
                } catch { }
                finally { CloseHandle(userToken); }
            }
        } finally { if (sessions != IntPtr.Zero) WTSFreeMemory(sessions); }
        return records;
    }
}
'@
`$records = [GssWtsDriveCollector]::Collect()
`$json = ConvertTo-Json -InputObject @(`$records) -Compress
New-Item -Path 'HKLM:\$registryPath' -Force -ErrorAction Stop | Out-Null
Set-ItemProperty -Path 'HKLM:\$registryPath' -Name '$valueName' -Value `$json -Type String -Force -ErrorAction Stop
"@
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($remoteScript))
    try {
        # O script completo fica temporariamente no registro. A ação da tarefa
        # permanece curta e não depende de arquivo XML ou caminho temporário.
        $stdReg = [WMICLASS]"\\$Computer\root\default:StdRegProv"
        $HKLM = 2147483650
        $createKeyResult = $stdReg.CreateKey($HKLM, $registryPath)
        if ($createKeyResult.ReturnValue -ne 0) { throw "Não foi possível preparar o registro do coletor (código $($createKeyResult.ReturnValue))." }
        $setScriptResult = $stdReg.SetStringValue($HKLM, $registryPath, 'Script', $encoded)
        if ($setScriptResult.ReturnValue -ne 0) { throw "Não foi possível enviar o coletor (código $($setScriptResult.ReturnValue))." }

        $loaderAction = "powershell.exe -NoProfile -WindowStyle Hidden -Command `"`$e=(Get-ItemProperty -LiteralPath 'HKLM:\$registryPath').Script; powershell.exe -NoProfile -ExecutionPolicy Bypass -EncodedCommand `$e`""
        $serviceAction = "cmd.exe /c start `"`" /b $loaderAction"
        $launcher = ''
        $serviceError = ''
        try {
            $serviceClass = [WMICLASS]"\\$Computer\root\cimv2:Win32_Service"
            $serviceCreate = $serviceClass.Create(
                $serviceName, $serviceName, $serviceAction, 16, 1,
                'Manual', $false, 'LocalSystem', $null, $null, $null, $null
            )
            if ($serviceCreate.ReturnValue -eq 0) {
                $service = Get-WmiObject Win32_Service -ComputerName $Computer -Filter "Name='$serviceName'" -ErrorAction Stop
                $serviceStart = $service.StartService()
                # Um executável comum não se registra como serviço; o SCM pode
                # devolver 1053, mas o filho SYSTEM iniciado pelo cmd continua.
                $launcher = "serviço temporário (retorno $($serviceStart.ReturnValue))"
            } else {
                $serviceError = "criação do serviço retornou $($serviceCreate.ReturnValue)"
            }
        } catch {
            $serviceError = $_.Exception.Message
        }

        if (!$launcher) {
            # Contingência para ambientes onde a criação de serviço é bloqueada.
            $createArguments = @('/create','/s',$Computer,'/tn',$taskName,'/tr',$loaderAction,'/sc','ONSTART','/ru','SYSTEM','/rl','HIGHEST','/f')
            $previousPreference = $ErrorActionPreference
            try {
                $ErrorActionPreference = 'Continue'
                $created = & schtasks.exe @createArguments 2>&1
                if ($LASTEXITCODE -ne 0) { throw "Agendador: $($created -join ' ')"
                }
                $started = & schtasks.exe /run /s $Computer /tn $taskName 2>&1
                if ($LASTEXITCODE -ne 0) { throw "Agendador ao iniciar: $($started -join ' ')" }
                $launcher = 'tarefa SYSTEM'
            } catch {
                throw "Serviço: $serviceError | $($_.Exception.Message)"
            } finally {
                $ErrorActionPreference = $previousPreference
            }
        }
        for ($attempt = 0; $attempt -lt 20; $attempt++) {
            $result = $stdReg.GetStringValue($HKLM, $registryPath, $valueName)
            $json = [string]$result.sValue
            if (![string]::IsNullOrWhiteSpace($json)) {
                $records = @($json | ConvertFrom-Json)
                $script:WtsDriveDiagnostic = "Coleta WTS concluída por ${launcher}: $($records.Count) drive(s) de rede em sessão existente."
                return $records
            }
            Start-Sleep -Milliseconds 500
        }
        $script:WtsDriveDiagnostic = 'O coletor WTS iniciou, mas não devolveu dados em 10 segundos.'
    } catch {
        $script:WtsDriveDiagnostic = "Falha no coletor WTS: $($_.Exception.Message)"
    } finally {
        try {
            $service = Get-WmiObject Win32_Service -ComputerName $Computer -Filter "Name='$serviceName'" -ErrorAction SilentlyContinue
            if ($service) { $service.Delete() | Out-Null }
        } catch {}
        try {
            $stdReg = [WMICLASS]"\\$Computer\root\default:StdRegProv"
            $stdReg.DeleteKey(2147483650, $registryPath) | Out-Null
        } catch {}
        try {
            $previousPreference = $ErrorActionPreference
            $ErrorActionPreference = 'SilentlyContinue'
            & schtasks.exe /delete /s $Computer /tn $taskName /f 2>&1 | Out-Null
        } catch {} finally {
            $ErrorActionPreference = $previousPreference
        }
    }
    return @()
}

function Get-RemoteSessionMappedDrives {
    param([string]$LoggedUser)
    Require-Computer
    $script:MappedDriveDiagnostic = 'Coleta interativa não iniciada.'
    if ([string]::IsNullOrWhiteSpace($LoggedUser)) { return @() }
    $sid = ''
    try {
        $account = New-Object System.Security.Principal.NTAccount -ArgumentList $LoggedUser
        $sid = $account.Translate([System.Security.Principal.SecurityIdentifier]).Value
    } catch {}
    $candidateSids = [System.Collections.Generic.List[string]]::new()
    if (![string]::IsNullOrWhiteSpace($sid)) { $candidateSids.Add($sid) }
    try {
        $userOnly = ($LoggedUser -split '\\')[-1]
        foreach ($profile in @(Get-WmiObject Win32_UserProfile -ComputerName $Computer -ErrorAction SilentlyContinue |
            Where-Object { $_.Loaded -and $_.SID -like 'S-1-5-21-*' })) {
            $profileSid = [string]$profile.SID
            if ($profile.LocalPath -match "\\$([regex]::Escape($userOnly))$" -and !$candidateSids.Contains($profileSid)) {
                $candidateSids.Insert(0, $profileSid)
            } elseif (!$candidateSids.Contains($profileSid)) {
                $candidateSids.Add($profileSid)
            }
        }
    } catch {}
    if ($candidateSids.Count -eq 0) { return @() }

    $token = [guid]::NewGuid().ToString('N')
    $valueName = "MappedDrives_$token"
    $remoteScript = @"
`$mapped = @{}
`$shellNames = @{}
try {
    `$shell = New-Object -ComObject Shell.Application
    `$computerFolder = `$shell.Namespace(17)
    `$folderItems = `$computerFolder.Items()
    for (`$itemIndex = 0; `$itemIndex -lt `$folderItems.Count; `$itemIndex++) {
        `$item = `$folderItems.Item(`$itemIndex)
        `$itemPath = ([string]`$item.Path).Trim()
        `$itemName = ([string]`$item.Name).Trim()
        `$shellDrive = ''
        if (`$itemPath -match '^([A-Z]:)\\?$') {
            `$shellDrive = `$matches[1].ToUpperInvariant()
        } elseif (`$itemName -match '\(([A-Z]:)\)\s*$') {
            `$shellDrive = `$matches[1].ToUpperInvariant()
        }
        if (`$shellDrive) {
            `$shellLabel = `$itemName
            `$shellLabel = `$shellLabel -replace '\s*\([A-Z]:\)\s*$',''
            `$shellLabel = `$shellLabel -replace '\s*\(\\\\[^\)]*\)\s*$',''
            if (`$shellLabel) { `$shellNames[`$shellDrive] = `$shellLabel }
            if (`$itemPath -like '\\*') { `$mapped[`$shellDrive] = `$itemPath }
            if (!`$mapped.ContainsKey(`$shellDrive)) {
                foreach (`$propertyName in @('System.ItemPathDisplay','System.ParsingPath','System.Link.TargetParsingPath')) {
                    try {
                        `$candidatePath = ([string]`$item.ExtendedProperty(`$propertyName)).Trim()
                        if (`$candidatePath -like '\\*') { `$mapped[`$shellDrive] = `$candidatePath; break }
                    } catch {}
                }
            }
            if (!`$mapped.ContainsKey(`$shellDrive) -and `$itemName -match '^(.*?)\s+\(\\\\([^\)]+)\)\s+\(([A-Z]:)\)\s*$') {
                `$shareName = `$matches[1].Trim()
                `$serverName = `$matches[2].Trim()
                if (`$shareName -and `$serverName) { `$mapped[`$shellDrive] = "\\`$serverName\`$shareName" }
            }
        }
    }
} catch {}
try {
    if (-not ('GssNativeNetwork' -as [type])) {
        Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class GssNativeNetwork {
    [DllImport("mpr.dll", CharSet = CharSet.Unicode)]
    public static extern int WNetGetConnection(string localName, StringBuilder remoteName, ref int length);
}
'@
    }
    foreach (`$code in 65..90) {
        `$letter = ([char]`$code).ToString() + ':'
        `$capacity = 32768
        `$buffer = New-Object System.Text.StringBuilder `$capacity
        `$result = [GssNativeNetwork]::WNetGetConnection(`$letter, `$buffer, [ref]`$capacity)
        if (`$result -eq 0 -and `$buffer.Length -gt 0) { `$mapped[`$letter] = `$buffer.ToString() }
    }
} catch {}
try {
    `$network = New-Object -ComObject WScript.Network
    `$enumerated = `$network.EnumNetworkDrives()
    for (`$index = 0; `$index -lt `$enumerated.Count; `$index += 2) {
        `$letter = ([string]`$enumerated.Item(`$index)).Trim().ToUpper()
        `$provider = ([string]`$enumerated.Item(`$index + 1)).Trim()
        if (`$letter -match '^[A-Z]:$' -and `$provider) { `$mapped[`$letter] = `$provider }
    }
} catch {}
try {
    foreach (`$line in @(net.exe use 2>`$null)) {
        if ([string]`$line -match '(?i)([A-Z]:)\s+(\\\\[^\s]+)') {
            `$mapped[`$matches[1].ToUpperInvariant()] = `$matches[2]
        }
    }
} catch {}
try {
    foreach (`$drive in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
        `$letter = ([string]`$drive.Name).Trim().ToUpper() + ':'
        `$provider = [string]`$drive.DisplayRoot
        if (`$letter -match '^[A-Z]:$' -and `$provider -like '\\*') { `$mapped[`$letter] = `$provider }
    }
} catch {}
`$items = @()
`$driveLetters = @(`$mapped.Keys + `$shellNames.Keys | Sort-Object -Unique)
foreach (`$driveLetter in `$driveLetters) {
    `$providerPath = if (`$mapped.ContainsKey(`$driveLetter)) { [string]`$mapped[`$driveLetter] } else { '' }
    `$total = [int64]0; `$free = [int64]0; `$label = ''; `$filesystem = ''
    try {
        `$disk = New-Object System.IO.DriveInfo((`$driveLetter + '\'))
        if (`$disk.IsReady) {
            `$total = [int64]`$disk.TotalSize
            `$free = [int64]`$disk.AvailableFreeSpace
            `$label = [string]`$disk.VolumeLabel
            `$filesystem = [string]`$disk.DriveFormat
        }
    } catch {}
    if (`$shellNames.ContainsKey(`$driveLetter)) { `$label = [string]`$shellNames[`$driveLetter] }
    if (![string]`$label -and `$providerPath) {
        try { `$label = Split-Path `$providerPath.TrimEnd('\') -Leaf } catch {}
    }
    `$items += [PSCustomObject]@{
        drive = [string]`$driveLetter
        provider = `$providerPath
        is_network = ![string]::IsNullOrWhiteSpace(`$providerPath)
        size = `$total
        free = `$free
        label = `$label
        filesystem = `$filesystem
    }
}
`$json = ConvertTo-Json -InputObject @(`$items) -Compress
New-Item -Path 'HKCU:\Software\GerenciadorSuporteSenado' -Force -ErrorAction SilentlyContinue | Out-Null
Set-ItemProperty -Path 'HKCU:\Software\GerenciadorSuporteSenado' -Name '$valueName' -Value `$json -Type String -Force
"@
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($remoteScript))
    $taskName = 'Suporte_DrivesMapeados_' + $token.Substring(0, 8)
    $xmlPath = Join-Path $env:TEMP "$taskName.xml"
    $safeUser = [Security.SecurityElement]::Escape($LoggedUser)
    $taskArguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -EncodedCommand $encoded"
    $safeArguments = [Security.SecurityElement]::Escape($taskArguments)
    $taskXml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
 <Principals><Principal id="Author"><UserId>$safeUser</UserId><LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel></Principal></Principals>
 <Settings><AllowStartOnDemand>true</AllowStartOnDemand><Enabled>true</Enabled><Hidden>true</Hidden><ExecutionTimeLimit>PT2M</ExecutionTimeLimit></Settings>
 <Actions Context="Author"><Exec><Command>powershell.exe</Command><Arguments>$safeArguments</Arguments></Exec></Actions>
</Task>
"@
    try {
        [IO.File]::WriteAllText($xmlPath, $taskXml, [Text.Encoding]::Unicode)
        $created = schtasks /create /s $Computer /tn $taskName /xml $xmlPath /f 2>&1
        if ($LASTEXITCODE -ne 0) { throw "Falha ao preparar a coleta interativa: $created" }
        $started = schtasks /run /s $Computer /tn $taskName 2>&1
        if ($LASTEXITCODE -ne 0) { throw "Falha ao iniciar a coleta interativa: $started" }
        $stdReg = [WMICLASS]"\\$Computer\root\default:StdRegProv"
        $HKU = 2147483651
        for ($attempt = 0; $attempt -lt 30; $attempt++) {
            foreach ($candidateSid in @($candidateSids)) {
                $result = $stdReg.GetStringValue($HKU, "$candidateSid\Software\GerenciadorSuporteSenado", $valueName)
                $json = [string]$result.sValue
                if (![string]::IsNullOrWhiteSpace($json)) {
                    try { $stdReg.DeleteValue($HKU, "$candidateSid\Software\GerenciadorSuporteSenado", $valueName) | Out-Null } catch {}
                    $mappedResult = @($json | ConvertFrom-Json)
                    $script:MappedDriveDiagnostic = "Coleta interativa concluída: $($mappedResult.Count) unidade(s) recebida(s)."
                    return $mappedResult
                }
            }
            Start-Sleep -Seconds 1
        }
        $script:MappedDriveDiagnostic = 'A tarefa interativa iniciou, mas não devolveu dados dentro de 30 segundos.'
    } catch {
        $script:MappedDriveDiagnostic = "Falha na tarefa interativa: $($_.Exception.Message)"
    } finally {
        schtasks /delete /s $Computer /tn $taskName /f 2>$null | Out-Null
        Remove-Item -LiteralPath $xmlPath -Force -ErrorAction SilentlyContinue
    }
    return @()
}

function Get-RemoteRegistryMappedDrives {
    param([string]$LoggedUser)
    Require-Computer
    $items = @()
    $candidateSids = [System.Collections.Generic.List[string]]::new()
    if (![string]::IsNullOrWhiteSpace($LoggedUser)) {
        try {
            $account = New-Object System.Security.Principal.NTAccount -ArgumentList $LoggedUser
            $translatedSid = $account.Translate([System.Security.Principal.SecurityIdentifier]).Value
            if ($translatedSid) { $candidateSids.Add([string]$translatedSid) }
        } catch {}
    }
    try {
        foreach ($profile in @(Get-WmiObject Win32_UserProfile -ComputerName $Computer -ErrorAction SilentlyContinue |
            Where-Object { $_.Loaded -and $_.SID -like 'S-1-5-21-*' })) {
            if (!$candidateSids.Contains([string]$profile.SID)) { $candidateSids.Add([string]$profile.SID) }
        }
    } catch {}
    try {
        $stdReg = [WMICLASS]"\\$Computer\root\default:StdRegProv"
        $HKU = 2147483651
        foreach ($sid in @($candidateSids)) {
            $enumResult = $stdReg.EnumKey($HKU, "$sid\Network")
            foreach ($letter in @($enumResult.sNames)) {
                $driveId = ([string]$letter).Trim().ToUpperInvariant() + ':'
                if ($driveId -notmatch '^[A-Z]:$') { continue }
                $pathResult = $stdReg.GetStringValue($HKU, "$sid\Network\$letter", 'RemotePath')
                $remotePath = ([string]$pathResult.sValue).Trim()
                if (!$remotePath) { continue }
                $label = ''
                try { $label = Split-Path $remotePath.TrimEnd('\') -Leaf } catch {}
                $items += [PSCustomObject]@{
                    drive = $driveId
                    provider = $remotePath
                    size = [int64]0
                    free = [int64]0
                    label = $label
                    filesystem = ''
                }
            }
            # O primeiro SID e o usuario resolvido; se ele possui mapeamentos,
            # nao misturamos letras pertencentes a outra sessao carregada.
            if ($items.Count -gt 0) { break }
        }
    } catch {}
    return @($items)
}

function Invoke-RemoteTempCleanup {
    Require-Computer
    $loggedUser = (Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
    if ([string]::IsNullOrWhiteSpace($loggedUser)) { throw "Nenhum usuário conectado foi identificado." }
    $token = [guid]::NewGuid().ToString('N')
    $taskName = "Suporte_LimpaTemp_$token"
    $localXml = Join-Path $env:TEMP "$taskName.xml"
    try {
        $cleanup = '$p=$env:TEMP; Get-ChildItem -LiteralPath $p -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue'
        $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($cleanup))
        $safeUser = [Security.SecurityElement]::Escape($loggedUser)
        $xml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
 <Principals><Principal id="Author"><UserId>$safeUser</UserId><LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel></Principal></Principals>
 <Settings><AllowStartOnDemand>true</AllowStartOnDemand><Enabled>true</Enabled><Hidden>true</Hidden><ExecutionTimeLimit>PT1H</ExecutionTimeLimit></Settings>
 <Actions Context="Author"><Exec><Command>powershell.exe</Command><Arguments>-NoProfile -WindowStyle Hidden -EncodedCommand $encoded</Arguments></Exec></Actions>
</Task>
"@
        [IO.File]::WriteAllText($localXml, $xml, [Text.Encoding]::Unicode)
        $created = schtasks /create /s $Computer /tn $taskName /xml $localXml /f 2>&1
        if ($LASTEXITCODE -ne 0) { throw "Falha ao criar tarefa remota: $created" }
        $started = schtasks /run /s $Computer /tn $taskName 2>&1
        if ($LASTEXITCODE -ne 0) { throw "Falha ao iniciar tarefa remota: $started" }
        Start-Sleep -Seconds 3
        Write-Output "Limpeza executada na sessão de $loggedUser. Arquivos em uso foram preservados."
    } finally {
        schtasks /delete /s $Computer /tn $taskName /f 2>$null | Out-Null
        Remove-Item -LiteralPath $localXml -Force -ErrorAction SilentlyContinue
    }
}

function Get-RemoteFolderSizeBytes {
    param([string]$ComputerName, [string]$LocalPath)
    if ([string]::IsNullOrWhiteSpace($LocalPath)) { return [int64]0 }
    $candidates = New-Object System.Collections.Generic.List[string]
    if ($LocalPath -match '^([A-Za-z]):\\(.+)$') {
        $candidates.Add("\\$ComputerName\$($matches[1])`$\$($matches[2])")
    }
    $folder = Split-Path $LocalPath -Leaf
    foreach ($drive in @('D','C')) {
        foreach ($root in @('Users','Usuários','Usuarios')) {
            $candidate = "\\$ComputerName\$drive`$\$root\$folder"
            if (!$candidates.Contains($candidate)) { $candidates.Add($candidate) }
        }
    }
    foreach ($targetPath in $candidates) {
        if (!(Test-Path -LiteralPath $targetPath -ErrorAction SilentlyContinue)) { continue }
        try {
            $fso = New-Object -ComObject Scripting.FileSystemObject
            if ($fso.FolderExists($targetPath)) {
                $size = [int64]$fso.GetFolder($targetPath).Size
                if ($size -gt 0) { return $size }
            }
        } catch {}
        try {
            $dummy = Join-Path $env:TEMP "profile_measure_$([guid]::NewGuid().ToString('N'))"
            $result = robocopy "$targetPath" "$dummy" /L /S /NFL /NDL /NJH /BYTES /XJ /R:0 /W:0 2>$null
            foreach ($line in $result) {
                if ($line -match 'Bytes\s*:\s*(\d+)') {
                    $size = [int64]$matches[1]
                    if ($size -gt 0) { return $size }
                }
            }
        } catch {}
        try {
            $measure = Get-ChildItem -LiteralPath $targetPath -Recurse -Force -File -Attributes !ReparsePoint -ErrorAction SilentlyContinue |
                Measure-Object -Property Length -Sum
            if ($measure.Sum -gt 0) { return [int64]$measure.Sum }
        } catch {}
    }
    return [int64]0
}

function Get-BoundedWmiObject {
    param(
        [Parameter(Mandatory=$true)][string]$ComputerName,
        [Parameter(Mandatory=$true)][string]$ClassName,
        [string]$Filter = '',
        [int]$TimeoutSeconds = 8
    )
    # Mantém o mesmo provedor DCOM de Get-WmiObject usado nas versões estáveis.
    # -AsJob permite impor prazo sem trocar para CIM/WSMan ou ManagementScope,
    # que podem ser bloqueados de forma diferente pela política corporativa.
    $parameters = @{
        Class = $ClassName
        ComputerName = $ComputerName
        AsJob = $true
        ErrorAction = 'Stop'
    }
    if (![string]::IsNullOrWhiteSpace($Filter)) { $parameters.Filter = $Filter }
    $job = Get-WmiObject @parameters
    try {
        $completed = Wait-Job -Job $job -Timeout $TimeoutSeconds
        if (!$completed) {
            Stop-Job -Job $job -ErrorAction SilentlyContinue
            throw "Tempo limite de $TimeoutSeconds segundos em $ClassName no micro $ComputerName."
        }
        return @(Receive-Job -Job $job -ErrorAction Stop)
    } finally {
        Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
    }
}

function Normalize-AtlasNetworkLogin([string]$Login) {
    $value = ([string]$Login).Trim()
    if ($value -match '\\') { $value = ($value -split '\\')[-1] }
    if ($value -match '@') { $value = ($value -split '@')[0] }
    if ($value -notmatch '^[A-Za-z0-9._-]{1,128}$') {
        throw 'Informe um login de rede válido, sem espaços ou caracteres especiais.'
    }
    return $value
}

function Get-AtlasAdUserData([string]$Login) {
    $userOnly = Normalize-AtlasNetworkLogin $Login
    $escapedLogin = $userOnly.Replace('\', '\5c').Replace('*', '\2a').Replace('(', '\28').Replace(')', '\29')
    $searcher = New-Object DirectoryServices.DirectorySearcher
    $searcher.Filter = "(&(objectCategory=person)(objectClass=user)(sAMAccountName=$escapedLogin))"
    foreach ($property in @(
        'displayName','givenName','sn','employeeID','sAMAccountName','userPrincipalName','distinguishedName',
        'mail','telephoneNumber','homePhone','pager','mobile','facsimileTelephoneNumber','ipPhone','info',
        'company','department','title','manager','physicalDeliveryOfficeName','description','profilePath',
        'homeDirectory','homeDrive','scriptPath','canonicalName','memberOf',
        'userAccountControl','msDS-User-Account-Control-Computed','lockoutTime','lastLogonTimestamp',
        'pwdLastSet','whenCreated','accountExpires','msDS-UserPasswordExpiryTimeComputed'
    )) { [void]$searcher.PropertiesToLoad.Add($property) }
    $result = $searcher.FindOne()
    if (!$result) { throw "Usuário $userOnly não localizado no Active Directory." }

    function Read-AtlasAdProperty([string]$Name) {
        $values = @($result.Properties[$Name])
        if ($values.Count -and $null -ne $values[0] -and [string]$values[0] -ne '') { return [string]$values[0] }
        return 'Não informado'
    }
    function Format-AtlasAdFileTime([string]$Name) {
        try {
            $raw = @($result.Properties[$Name])[0]
            $number = [long]$raw
            if ($number -gt 0 -and $number -lt [long]::MaxValue) { return [DateTime]::FromFileTime($number).ToString('dd/MM/yyyy HH:mm') }
        } catch {}
        return 'Não informado'
    }

    $displayName = Read-AtlasAdProperty 'displayname'
    $manager = Read-AtlasAdProperty 'manager'
    if ($manager -match '^CN=([^,]+)') { $manager = $matches[1] -replace '\\,', ',' }
    $uac = 0
    try { $uac = [int](Read-AtlasAdProperty 'useraccountcontrol') } catch {}
    $enabled = if (($uac -band 2) -eq 0) { 'Ativa' } else { 'Desabilitada' }
    $locked = 'Não'
    try { if ([long](Read-AtlasAdProperty 'lockouttime') -gt 0) { $locked = 'Sim' } } catch {}
    $created = Read-AtlasAdProperty 'whencreated'
    try { $created = ([datetime]$created).ToString('dd/MM/yyyy HH:mm') } catch {}
    $accountExpiration = Format-AtlasAdFileTime 'accountexpires'
    $computedUac = 0
    try { $computedUac = [int](Read-AtlasAdProperty 'msds-user-account-control-computed') } catch {}
    $passwordNeverExpires = if (($uac -band 0x10000) -ne 0) { 'Sim' } else { 'Não' }
    $passwordExpirationRaw = [long]0
    try { $passwordExpirationRaw = [long]@($result.Properties['msds-userpasswordexpirytimecomputed'])[0] } catch {}
    $passwordExpirationDate = $null
    if ($passwordExpirationRaw -gt 0 -and $passwordExpirationRaw -lt [long]::MaxValue) {
        try { $passwordExpirationDate = [DateTime]::FromFileTime($passwordExpirationRaw) } catch {}
    }
    $passwordExpiration = if ($passwordNeverExpires -eq 'Sim') {
        'Não expira'
    } elseif ($passwordExpirationDate) {
        $passwordExpirationDate.ToString('dd/MM/yyyy HH:mm')
    } else {
        'Não informado'
    }
    $passwordExpired = if (
        (($computedUac -band 0x800000) -ne 0) -or
        ($passwordExpirationDate -and $passwordExpirationDate -le (Get-Date))
    ) { 'Sim' } else { 'Não' }
    $groups = @($result.Properties['memberof'] | ForEach-Object {
        if ([string]$_ -match '^CN=([^,]+)') { $matches[1] -replace '\\,', ',' }
    } | Where-Object { $_ } | Sort-Object)

    return [ordered]@{
        user = "$displayName  •  SENADO\$userOnly"
        login = $userOnly
        display_name = $displayName
        source = 'Active Directory'
        identity = [ordered]@{
            'Nome completo' = $displayName
            'Primeiro nome' = (Read-AtlasAdProperty 'givenname')
            'Sobrenome' = (Read-AtlasAdProperty 'sn')
            'Login de rede' = "SENADO\$userOnly"
            'Nome de entrada' = (Read-AtlasAdProperty 'userprincipalname')
            'Identificador funcional' = (Read-AtlasAdProperty 'employeeid')
        }
        organization = [ordered]@{
            'Empresa' = (Read-AtlasAdProperty 'company')
            'Departamento' = (Read-AtlasAdProperty 'department')
            'Cargo' = (Read-AtlasAdProperty 'title')
            'Unidade / sala' = (Read-AtlasAdProperty 'physicaldeliveryofficename')
            'Gestor' = $manager
        }
        contact = [ordered]@{
            'E-mail institucional' = (Read-AtlasAdProperty 'mail')
            'Telefone comercial' = (Read-AtlasAdProperty 'telephonenumber')
            'Residência' = (Read-AtlasAdProperty 'homephone')
            'Pager' = (Read-AtlasAdProperty 'pager')
            'Celular' = (Read-AtlasAdProperty 'mobile')
            'Fax' = (Read-AtlasAdProperty 'facsimiletelephonenumber')
            'Telefone IP' = (Read-AtlasAdProperty 'ipphone')
        }
        notes = (Read-AtlasAdProperty 'info')
        account = [ordered]@{
            'Status da conta' = $enabled
            'Conta bloqueada' = $locked
            'Conta expira em' = $accountExpiration
            'Último logon registrado' = (Format-AtlasAdFileTime 'lastlogontimestamp')
            'Conta criada em' = $created
            'Objeto no AD' = (Read-AtlasAdProperty 'distinguishedname')
        }
        password = [ordered]@{
            'Senha expirada no AD' = $passwordExpired
            'Senha nunca expira' = $passwordNeverExpires
            'Última definição da senha' = (Format-AtlasAdFileTime 'pwdlastset')
            'Vencimento calculado' = $passwordExpiration
        }
        profile = [ordered]@{
            'Descrição' = (Read-AtlasAdProperty 'description')
            'Caminho do perfil' = (Read-AtlasAdProperty 'profilepath')
            'Pasta base' = (Read-AtlasAdProperty 'homedirectory')
            'Unidade base' = (Read-AtlasAdProperty 'homedrive')
            'Script de logon' = (Read-AtlasAdProperty 'scriptpath')
            'Nome do objeto canônico' = (Read-AtlasAdProperty 'canonicalname')
        }
        groups = @($groups)
    }
}

function Invoke-AtlasPasswordManagerForm {
    param(
        [Parameter(Mandatory=$true)]$Form,
        [Parameter(Mandatory=$true)][uri]$BaseUri,
        [Parameter(Mandatory=$true)][Microsoft.PowerShell.Commands.WebRequestSession]$Session,
        [Parameter(Mandatory=$true)][hashtable]$Overrides,
        [int]$TimeoutSeconds = 35
    )
    $body = [ordered]@{}
    foreach ($entry in $Form.Fields.GetEnumerator()) { $body[[string]$entry.Key] = [string]$entry.Value }
    foreach ($entry in $Overrides.GetEnumerator()) { $body[[string]$entry.Key] = [string]$entry.Value }
    $targetUri = Resolve-AtlasFormUri $BaseUri ([string]$Form.Action)
    if ([string]$Form.Method -eq 'GET') {
        $queryParts = @($body.GetEnumerator() | ForEach-Object {
            "$([uri]::EscapeDataString([string]$_.Key))=$([uri]::EscapeDataString([string]$_.Value))"
        })
        $separator = if ([string]::IsNullOrWhiteSpace($targetUri.Query)) { '?' } else { '&' }
        $getUri = [uri]($targetUri.AbsoluteUri + $separator + ($queryParts -join '&'))
        return Invoke-WebRequest -Uri $getUri -Method Get -WebSession $Session `
            -UseDefaultCredentials -UseBasicParsing -TimeoutSec $TimeoutSeconds -ErrorAction Stop
    }
    return Invoke-WebRequest -Uri $targetUri -Method Post -Body $body -WebSession $Session `
        -UseDefaultCredentials -UseBasicParsing -TimeoutSec $TimeoutSeconds -ErrorAction Stop
}

function Invoke-PasswordRecoveryLookup {
    param(
        [Parameter(Mandatory=$true)][Microsoft.PowerShell.Commands.WebRequestSession]$Session,
        [Parameter(Mandatory=$true)][string]$Login,
        [Parameter(Mandatory=$true)][string]$FullName
    )
    $recoveryUri = [uri]'https://gestorsenhas.senado.leg.br/public/forgottenpassword'
    $first = Invoke-WebRequest -Uri $recoveryUri -WebSession $Session -UseDefaultCredentials -UseBasicParsing -TimeoutSec 35 -ErrorAction Stop
    $form = Get-AtlasHtmlForm ([string]$first.Content) '(?i)(?:forgotten|login|usu[aá]rio|username)'
    if (!$form) { throw 'O formulário público de recuperação não foi localizado.' }
    $loginField = @($form.Inputs | Where-Object { $_.Type -notin @('hidden','submit','button','password') -and $_.Name -match '(?i)(?:login|user|usuario|usu[aá]rio|account)' })[0]
    $nameField = @($form.Inputs | Where-Object { $_.Type -notin @('hidden','submit','button','password') -and $_.Name -match '(?i)(?:fullname|full_name|nome.*completo|nome|name)' -and (!$loginField -or $_.Name -ne $loginField.Name) })[0]
    if (!$loginField) { $loginField = @($form.Inputs | Where-Object { $_.Type -in @('text','email','') })[0] }
    if (!$nameField) { $nameField = @($form.Inputs | Where-Object { $_.Type -in @('text','email','') -and (!$loginField -or $_.Name -ne $loginField.Name) })[0] }
    if (!$loginField -or !$nameField) { throw 'Os campos de login e nome completo não foram identificados na recuperação.' }
    $response = Invoke-AtlasPasswordManagerForm -Form $form -BaseUri $first.BaseResponse.ResponseUri -Session $Session -Overrides @{
        ([string]$loginField.Name) = $Login
        ([string]$nameField.Name) = $FullName
    }
    return [PSCustomObject]@{ Response=$response; Login=$Login; FullName=$FullName }
}

switch ($Action) {
    "remote_process_list" {
        Require-Computer
        . (Join-Path $ModuleRoot 'remote_inventory.ps1')
        Get-AtlasUserProcesses
    }
    "remote_process_end" {
        Require-Computer
        . (Join-Path $ModuleRoot 'remote_inventory.ps1')
        Stop-AtlasUserProcess
    }
    "remote_process_end_group" {
        Require-Computer
        . (Join-Path $ModuleRoot 'remote_inventory.ps1')
        Stop-AtlasUserProcessGroup
    }
    "user_software_list" {
        Require-Computer
        . (Join-Path $ModuleRoot 'remote_inventory.ps1')
        Get-AtlasUserSoftware
    }
    "user_evaluation_show" {
        Show-RemoteServiceEvaluation
    }
    "user_orientation_show" {
        Show-RemoteUserOrientation
    }
    "support_escalation_show" {
        Show-RemoteSupportEscalation
    }
    "status" {
        Require-Computer
        Write-Output "[STATUS] Testando conectividade com $Computer..."
        $online = $false
        $pingTtl = $null
        $pingResult = 'Tempo de limite perdido'
        $pingCommandRan = $false
        try {
            # Captura o mesmo TTL= exibido pelo ping.exe, inclusive quando
            # PingReply.Options é nulo no Windows apesar da resposta ICMP.
            $pingOutput = (& ping.exe -n 1 -w 1800 $Computer 2>&1 | Out-String)
            $pingCommandRan = $true
            $ttlMatch = [regex]::Match([string]$pingOutput, '(?i)\bTTL\s*=\s*(\d{1,3})\b')
            if ($LASTEXITCODE -eq 0 -and $ttlMatch.Success) {
                $pingTtl = [int]$ttlMatch.Groups[1].Value
                $online = $true
            }
        } catch {}
        if ($pingCommandRan -and !$online -and [string]$pingOutput -match '(?i)(?:could not find host|couldn.t find host|n[aã]o p[oô]de encontrar o host|n[aã]o encontrou o host|n[aã]o foi poss[ií]vel localizar o host)') {
            throw "O endereço lógico '$Computer' não foi encontrado. Confira o nome do micro e consulte novamente."
        }
        if (!$pingCommandRan) {
            try {
                $pingClient = [System.Net.NetworkInformation.Ping]::new()
                try {
                    $pingReply = $pingClient.Send($Computer, 1800)
                    $online = $pingReply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success
                    if ($online -and $pingReply.Options) { $pingTtl = [int]$pingReply.Options.Ttl }
                } finally { $pingClient.Dispose() }
            } catch {}
        }
        if ($pingCommandRan -and !$online -and $LASTEXITCODE -eq 0) { $online = $true }
        if ($online -and !$pingTtl) {
            try {
                $pingObject = @(Test-Connection -ComputerName $Computer -Count 1 -ErrorAction Stop)[0]
                if ($pingObject -and $pingObject.ResponseTimeToLive) {
                    $pingTtl = [int]$pingObject.ResponseTimeToLive
                }
            } catch {}
        }
        if ($online) { $pingResult = if ($pingTtl) { 'Resposta recebida' } else { 'TTL indisponível' } }
        if (!$online) { Write-Output "Aviso: a estação não respondeu ao ping." }
        Write-Output "[STATUS] Consultando Windows e usuário via WMI..."
        try { $cs = @(Get-BoundedWmiObject -ComputerName $Computer -ClassName 'Win32_ComputerSystem')[0] } catch { $cs = $null }
        try { $os = @(Get-BoundedWmiObject -ComputerName $Computer -ClassName 'Win32_OperatingSystem')[0] } catch { $os = $null }
        $boot = $null
        if ($os -and $os.LastBootUpTime) {
            try { $boot = [System.Management.ManagementDateTimeConverter]::ToDateTime([string]$os.LastBootUpTime) } catch {}
        }
        $uptime = if ($boot) { (Get-Date) - $boot } else { $null }
        $user = if ($cs) { [string]$cs.UserName } else { '' }
        $userOnly = if ($user) { ($user -split '\\')[-1] } else { "-" }
        $remoteUserDisplay = if ($userOnly -ne "-") { $userOnly } else { "Nenhum usuário logado" }
        $remoteUserAdName = ''
        $coreStatusData = [ordered]@{
            station = $Computer
            status = if ($online) { "Conectado" } else { "Sem resposta ao ping" }
            ping_ttl = $pingTtl
            ping_result = $pingResult
            windows = if ($os) { "$($os.Caption) ($($os.OSArchitecture))" } else { "WMI não respondeu no prazo" }
            user = if ($user) { $user } else { "Nenhum usuário logado" }
            user_display = $remoteUserDisplay
            user_ad_name = if ($user) { "Consultando nome no AD..." } else { '' }
            admin = "Concluindo consulta..."
            rdp = "Concluindo consulta..."
            uptime = if ($uptime -and $boot) { "$($uptime.Days)d $($uptime.Hours)h $($uptime.Minutes)m (Boot: $($boot.ToString('dd/MM HH:mm')))" } else { "Não informado" }
            disk_d = "Concluindo consulta..."
            sccm = "Concluindo consulta..."
            printers = "Concluindo consulta..."
            printer_names = "Concluindo consulta..."
            default_printer = "Concluindo consulta..."
            printer_groups = "Concluindo consulta..."
            software_access = $false
            software_root = ''
        }
        Write-Output ("@@STATUS@@" + ($coreStatusData | ConvertTo-Json -Compress))
        Write-Output "[STATUS] Dados principais entregues à interface; concluindo detalhes..."
        $isAdmin = "Não foi possível consultar"
        $rdpUsers = 'Não foi possível consultar'
        Write-Output "[STATUS] Consultando permissões locais..."
        try {
            $adminGroup = [ADSI]"WinNT://$Computer/Administradores,group"
            $adminMembers = @($adminGroup.psbase.Invoke('Members'))
            $adminNames = $adminMembers | ForEach-Object { $_.GetType().InvokeMember('Name','GetProperty',$null,$_,$null) }
            $isAdmin = if ($adminNames -contains $userOnly) { "SIM ($user)" } else { "NÃO" }
        } catch {}
        try {
            # Exibe os membros de fato cadastrados no grupo local da estação.
            # O usuário logado pode ser diferente da conta mostrada no lusrmgr.
            $rdpGroup = [ADSI]"WinNT://$Computer/Usuários da área de trabalho remota,group"
            $rdpMembers = @($rdpGroup.psbase.Invoke('Members'))
            $rdpNames = @($rdpMembers | ForEach-Object {
                $member = $_
                $memberName = [string]$member.GetType().InvokeMember('Name','GetProperty',$null,$member,$null)
                try {
                    $memberPath = [string]$member.GetType().InvokeMember('ADsPath','GetProperty',$null,$member,$null)
                    $parts = @(($memberPath -replace '^WinNT://','' -replace ',.*$','') -split '/')
                    if ($parts.Count -ge 2 -and $parts[-2] -and $parts[-1]) {
                        "$($parts[-2])\$($parts[-1])"
                    } else { $memberName }
                } catch { $memberName }
            } | Where-Object { $_ } | Sort-Object -Unique)
            $rdpUsers = if ($rdpNames.Count) { $rdpNames -join ', ' } else { 'Nenhum membro cadastrado' }
        } catch {}
        $diskD = 'Não foi possível consultar'
        Write-Output "[STATUS] Consultando espaço livre na unidade D:..."
        try {
            $dataDrive = @(Get-BoundedWmiObject -ComputerName $Computer -ClassName 'Win32_LogicalDisk' -Filter "DeviceID='D:'")[0]
            if (!$dataDrive) {
                $diskD = 'Unidade D: não encontrada'
            } elseif ([double]$dataDrive.Size -gt 0) {
                $culture = [System.Globalization.CultureInfo]::GetCultureInfo('pt-BR')
                $free = ([double]$dataDrive.FreeSpace / 1GB).ToString('N1', $culture)
                $total = ([double]$dataDrive.Size / 1GB).ToString('N1', $culture)
                $diskD = "$free GB livres de $total GB"
            } else {
                $diskD = 'Espaço indisponível'
            }
        } catch {}
        $sccm = "Não instalado"
        try {
            $ccm = @(Get-BoundedWmiObject -ComputerName $Computer -ClassName 'Win32_Service' -Filter "Name='CcmExec'")[0]
            if ($ccm) { $sccm = "Instalado ($($ccm.State))" }
        } catch {}
        $printers = @()
        Write-Output "[STATUS] Consultando impressoras e Registro remoto..."
        try {
            $printers = @(Get-AllRemotePrinters)
        } catch {}
        $defaultPrinter = ""
        try { $defaultPrinter = Get-RemoteDefaultPrinter -LoggedUser $user } catch {}
        $printerNames = [System.Collections.Generic.List[string]]::new()
        foreach ($printer in @($printers)) {
            if ($printer -and !$printerNames.Contains([string]$printer)) { $printerNames.Add([string]$printer) }
        }
        if ($defaultPrinter -and !($printerNames -icontains $defaultPrinter)) { $printerNames.Add($defaultPrinter) }
        $displayPrinters = @($printerNames | ForEach-Object {
            $reachability = Get-PrinterReachability -PrinterName $_
            $defaultSuffix = if ($defaultPrinter -and $_ -ieq $defaultPrinter) { " (Padrão)" } else { "" }
            "$_ — $reachability$defaultSuffix"
        })
        $printerGroups = @()
        Write-Output "[STATUS] Consultando usuário e grupos no Active Directory..."
        if ($userOnly -ne "-") {
            try {
                $uSearcher = [adsisearcher]"(&(objectCategory=user)(sAMAccountName=$userOnly))"
                $uResult = $uSearcher.FindOne()
                if ($uResult) {
                    $givenName = [string]$uResult.Properties['givenname'][0]
                    $surname = [string]$uResult.Properties['sn'][0]
                    $displayName = [string]$uResult.Properties['displayname'][0]
                    $remoteUserAdName = if ($displayName.Trim()) { $displayName.Trim() } else { "$givenName $surname".Trim() }
                    if ($givenName -and $surname) {
                        $remoteUserDisplay = "$(($givenName -split '\s+')[0]) $(($surname -split '\s+')[-1])"
                    } elseif ($displayName) {
                        $displayParts = @($displayName -split '\s+' | Where-Object { $_ })
                        $remoteUserDisplay = if ($displayParts.Count -gt 1) { "$($displayParts[0]) $($displayParts[-1])" } else { $displayName }
                    }
                    $remoteUserDisplay = ($remoteUserDisplay -replace '(?i)(?:[._-]?_?ins)$','').Trim(' ','.','_','-')
                    $userGroupsDNs = [System.Collections.Generic.List[string]]::new()
                    $userGroupsDNs.Add([string]$uResult.Properties['distinguishedname'][0])
                    foreach ($memberDn in @($uResult.Properties['memberof'])) {
                        if (!$userGroupsDNs.Contains([string]$memberDn)) { $userGroupsDNs.Add([string]$memberDn) }
                    }
                    $domainDN = ([ADSI]'LDAP://RootDSE').defaultNamingContext
                    $pSearcher = [adsisearcher]'(&(objectCategory=group)(sAMAccountName=*-ImprimirDoc))'
                    try { $pSearcher.SearchRoot = [ADSI]"LDAP://OU=Impressoras_OU,$domainDN" } catch {}
                    $foundCodes = [System.Collections.Generic.List[string]]::new()
                    foreach ($pResult in $pSearcher.FindAll()) {
                        $groupName = [string]$pResult.Properties['samaccountname'][0]
                        $groupEntry = $pResult.GetDirectoryEntry()
                        $hasPermission = $false
                        foreach ($memberDn in @($groupEntry.Properties['member'])) {
                            if ($userGroupsDNs.Contains([string]$memberDn)) { $hasPermission = $true; break }
                        }
                        if ($hasPermission) {
                            $code = $groupName -replace '-ImprimirDoc$',''
                            if (!$foundCodes.Contains($code)) { $foundCodes.Add($code) }
                        }
                    }
                    $printerGroups = @($foundCodes | Sort-Object)
                }
            } catch {}
        }
        $softwareRoot = ''
        Write-Output "[STATUS] Verificando o acesso ao catálogo de softwares..."
        try { $softwareRoot = Get-RemoteMappedDrivePath -Letter 'X' -LoggedUser $user } catch {}
        $statusData = [ordered]@{
            station = $Computer
            status = if ($online) { "Conectado" } else { "Sem resposta ao ping" }
            ping_ttl = $pingTtl
            ping_result = $pingResult
            windows = if ($os) { "$($os.Caption) ($($os.OSArchitecture))" } else { "WMI não respondeu no prazo" }
            user = if ($user) { $user } else { "Nenhum usuário logado" }
            user_display = $remoteUserDisplay
            user_ad_name = $remoteUserAdName
            admin = $isAdmin
            rdp = $rdpUsers
            uptime = if ($uptime -and $boot) { "$($uptime.Days)d $($uptime.Hours)h $($uptime.Minutes)m (Boot: $($boot.ToString('dd/MM HH:mm')))" } else { "Não informado" }
            disk_d = $diskD
            sccm = $sccm
            printers = if ($displayPrinters.Count) { $displayPrinters -join ", " } else { "Nenhuma" }
            printer_names = if ($printerNames.Count) { $printerNames -join ", " } else { "Nenhuma" }
            default_printer = if ($defaultPrinter) { $defaultPrinter } else { "Não identificada" }
            printer_groups = if ($printerGroups.Count) { $printerGroups -join ", " } else { "Nenhum" }
            software_access = (![string]::IsNullOrWhiteSpace($softwareRoot))
            software_root = $softwareRoot
        }
        Write-Output ("@@STATUS@@" + ($statusData | ConvertTo-Json -Compress))
        Write-Output "Estação: $Computer"
        Write-Output "Status: $(if($online){'ONLINE'}else{'SEM RESPOSTA AO PING'})"
        Write-Output "Usuário: $(if($user){$user}else{'Não informado'})"
        Write-Output "Windows: $(if($os){"$($os.Caption) $($os.OSArchitecture)"}else{'WMI não respondeu no prazo'})"
        Write-Output "Último boot: $boot"
        Write-Output "Espaço Dados (D:): $diskD"
    }
    "printer_status" {
        Require-Computer
        Write-Output "[IMPRESSORAS] Consultando somente as impressoras de $Computer..."
        try { $cs = @(Get-BoundedWmiObject -ComputerName $Computer -ClassName 'Win32_ComputerSystem')[0] } catch { $cs = $null }
        $loggedUser = if ($cs) { [string]$cs.UserName } else { '' }
        $printers = @()
        try { $printers = @(Get-AllRemotePrinters) } catch {}
        $defaultPrinter = ''
        try { $defaultPrinter = Get-RemoteDefaultPrinter -LoggedUser $loggedUser } catch {}
        $printerNames = [System.Collections.Generic.List[string]]::new()
        foreach ($printer in @($printers)) {
            if ($printer -and !$printerNames.Contains([string]$printer)) { $printerNames.Add([string]$printer) }
        }
        if ($defaultPrinter -and !($printerNames -icontains $defaultPrinter)) { $printerNames.Add($defaultPrinter) }
        $displayPrinters = @($printerNames | ForEach-Object {
            $reachability = Get-PrinterReachability -PrinterName $_
            $defaultSuffix = if ($defaultPrinter -and $_ -ieq $defaultPrinter) { ' (Padrão)' } else { '' }
            "$_ — $reachability$defaultSuffix"
        })
        $printerStatus = [ordered]@{
            station = $Computer
            printers = if ($displayPrinters.Count) { $displayPrinters -join ', ' } else { 'Nenhuma' }
            printer_names = if ($printerNames.Count) { $printerNames -join ', ' } else { 'Nenhuma' }
            default_printer = if ($defaultPrinter) { $defaultPrinter } else { 'Não identificada' }
        }
        Write-Output ('@@PRINTER_STATUS@@' + ($printerStatus | ConvertTo-Json -Compress))
        Write-Output "Impressoras de $Computer atualizadas sem recarregar os demais dados da estação."
    }
    "admin_status" {
        Require-Computer
        Write-Output "[ADMIN LOCAL] Consultando somente o estado administrativo de $Computer..."
        try { $cs = @(Get-BoundedWmiObject -ComputerName $Computer -ClassName 'Win32_ComputerSystem')[0] } catch { $cs = $null }
        $loggedUser = if ($cs) { [string]$cs.UserName } else { '' }
        $userOnly = if ($loggedUser) { ($loggedUser -split '\\')[-1] } else { '-' }
        $isAdmin = 'Não foi possível consultar'
        if ($userOnly -ne '-') {
            try {
                $adminGroup = [ADSI]"WinNT://$Computer/Administradores,group"
                $adminMembers = @($adminGroup.psbase.Invoke('Members'))
                $adminNames = $adminMembers | ForEach-Object { $_.GetType().InvokeMember('Name','GetProperty',$null,$_,$null) }
                $isAdmin = if ($adminNames -contains $userOnly) { "SIM ($loggedUser)" } else { 'NÃO' }
            } catch {}
        }
        Write-Output ('@@ADMIN_STATUS@@' + ([ordered]@{ station=$Computer; admin=$isAdmin } | ConvertTo-Json -Compress))
        Write-Output "Estado de Admin local atualizado sem recarregar a estação."
    }
    "ping" {
        Require-Computer
        Start-Process cmd.exe -ArgumentList "/k ping -t $Computer"
        Write-Output "Teste de ping contínuo iniciado para $Computer em uma janela separada."
    }
    "ping_printer" {
        Require-Computer
        Write-Output "PING DA IMPRESSORA — $Computer"
        $replies = @(Test-Connection -ComputerName $Computer -Count 4 -ErrorAction SilentlyContinue)
        if (!$replies.Count) { throw "A impressora $Computer não respondeu ao ping." }
        foreach ($reply in $replies) {
            Write-Output ("Resposta de {0}: tempo={1}ms  TTL={2}" -f $reply.Address, $reply.ResponseTime, $reply.ResponseTimeToLive)
        }
        $average = [math]::Round(($replies | Measure-Object -Property ResponseTime -Average).Average, 1)
        Write-Output "Conectividade confirmada. Média: $average ms."
    }
    "cmrc" {
        Require-Computer
        $paths = @(
            "$env:SMS_ADMIN_UI_PATH\i386\CmRcViewer.exe",
            "$env:SMS_ADMIN_UI_PATH\CmRcViewer.exe",
            "$env:ProgramFiles\Microsoft Endpoint Manager\AdminConsole\bin\i386\CmRcViewer.exe",
            "${env:ProgramFiles(x86)}\Microsoft Endpoint Manager\AdminConsole\bin\i386\CmRcViewer.exe",
            "$PSScriptRoot\..\CmRcViewer.exe"
        )
        $viewer = $paths | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
        if (!$viewer) { throw "CmRcViewer.exe não localizado." }
        Start-Process $viewer -ArgumentList $Computer
        Write-Output "Controle remoto iniciado para $Computer."
    }
    "outlook" {
        Close-RemoteOutlook
    }
    "dns" {
        Require-Computer
        try {
            Invoke-InteractiveTask -TaskName 'Suporte_FlushDNS' -Command 'cmd.exe' -Arguments '/c "title Limpar DNS Remoto & ipconfig /flushdns & timeout /t 8"'
            Write-Output 'FlushDNS executado e exibido na sessao do usuario.'
        } catch {
            Invoke-WmiMethod -ComputerName $Computer -Class Win32_Process -Name Create -ArgumentList 'cmd.exe /c ipconfig /flushdns' | Out-Null
            Write-Output 'FlushDNS enviado em segundo plano via WMI.'
        }
    }
    "gpupdate" {
        Require-Computer
        try {
            Invoke-InteractiveTask -TaskName 'Suporte_GPUpdate' -Command 'cmd.exe' -Arguments '/c "title GPUpdate Remoto & echo N | gpupdate /force & timeout /t 8"'
            Write-Output 'GPUpdate executado e exibido na sessao do usuario.'
        } catch {
            Invoke-WmiMethod -ComputerName $Computer -Class Win32_Process -Name Create -ArgumentList 'cmd.exe /c echo N | gpupdate /force' | Out-Null
            Write-Output 'GPUpdate enviado em segundo plano via WMI.'
        }
    }
    "trellix_config" {
        Require-Computer
        $candidateAgents = @(
            'C:\Program Files\McAfee\Agent\cmdagent.exe',
            'C:\Program Files\Trellix\Agent\cmdagent.exe',
            'C:\Program Files (x86)\McAfee\Agent\cmdagent.exe'
        )
        $agent = ''
        foreach ($candidate in $candidateAgents) {
            $adminPath = "\\$Computer\$($candidate.Substring(0, 1))`$$($candidate.Substring(2))"
            if (Test-Path -LiteralPath $adminPath -PathType Leaf -ErrorAction SilentlyContinue) {
                $agent = $candidate
                break
            }
            try {
                $wqlName = $candidate.Replace('\', '\\').Replace("'", "''")
                $remoteFile = Get-WmiObject CIM_DataFile -ComputerName $Computer -Filter "Name='$wqlName'" -ErrorAction Stop
                if ($remoteFile) { $agent = $candidate; break }
            } catch {}
        }
        if ([string]::IsNullOrWhiteSpace($agent)) {
            throw "O agente Trellix/McAfee não foi localizado em $Computer nos caminhos homologados."
        }
        $loggedUser = (Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
        if ([string]::IsNullOrWhiteSpace($loggedUser)) { throw "Nenhum usuário conectado foi identificado em $Computer." }
        $token = [guid]::NewGuid().ToString('N')
        $escapedAgent = $agent.Replace("'", "''")
        $remoteScript = @"
`$agent = '$escapedAgent'
`$steps = @('/p','/c','/e')
try {
    foreach (`$argument in `$steps) {
        `$process = Start-Process -FilePath `$agent -ArgumentList `$argument -PassThru -NoNewWindow
        if (!`$process.WaitForExit(45000)) {
            try { `$process.Kill() } catch {}
            continue
        }
    }
} catch {}
"@
        $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($remoteScript))
        $taskName = 'Suporte_Trellix_' + $token.Substring(0, 8)
        $xmlPath = Join-Path $env:TEMP "$taskName.xml"
        $safeUser = [Security.SecurityElement]::Escape($loggedUser)
        $arguments = "-NoProfile -ExecutionPolicy Bypass -EncodedCommand $encoded"
        $safeArguments = [Security.SecurityElement]::Escape($arguments)
        $taskXml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
 <Principals><Principal id="Author"><UserId>$safeUser</UserId><LogonType>InteractiveToken</LogonType><RunLevel>HighestAvailable</RunLevel></Principal></Principals>
 <Settings><AllowStartOnDemand>true</AllowStartOnDemand><Enabled>true</Enabled><Hidden>true</Hidden><ExecutionTimeLimit>PT3M</ExecutionTimeLimit></Settings>
 <Actions Context="Author"><Exec><Command>powershell.exe</Command><Arguments>$safeArguments</Arguments></Exec></Actions>
</Task>
"@
        try {
            [IO.File]::WriteAllText($xmlPath, $taskXml, [Text.Encoding]::Unicode)
            $created = schtasks.exe /create /s $Computer /tn $taskName /xml $xmlPath /f 2>&1
            if ($LASTEXITCODE -ne 0) { throw "Falha ao criar a tarefa interativa: $created" }
            $started = schtasks.exe /run /s $Computer /tn $taskName 2>&1
            if ($LASTEXITCODE -ne 0) { throw "Falha ao iniciar a tarefa interativa: $started" }
            Start-Sleep -Seconds 2
            $taskState = (schtasks.exe /query /s $Computer /tn $taskName /fo LIST /v 2>&1 | Out-String).Trim()
            if ($LASTEXITCODE -ne 0) { throw "A tarefa foi enviada, mas o Windows não confirmou sua execução: $taskState" }
            Write-Output "Atualização Trellix iniciada na sessão de $loggedUser em $Computer."
            Write-Output 'Os comandos /p, /c e /e continuarão em segundo plano; o aplicativo foi liberado sem aguardar o encerramento do agente.'
        } finally {
            # Excluir a definição não encerra a instância que já está rodando.
            schtasks.exe /delete /s $Computer /tn $taskName /f 2>$null | Out-Null
            Remove-Item -LiteralPath $xmlPath -Force -ErrorAction SilentlyContinue
        }
    }
    "atlas_repair" {
        Require-Computer
        Write-Output "ATLAS REPAIR — iniciando manutenção completa em $Computer."
        $steps = @(
            [PSCustomObject]@{ Action='temp'; Label='Limpeza da pasta TEMP' },
            [PSCustomObject]@{ Action='dns'; Label='Limpeza do cache DNS' },
            [PSCustomObject]@{ Action='gpupdate'; Label='Atualização das políticas' },
            [PSCustomObject]@{ Action='trellix_config'; Label='Configuração do Trellix' }
        )
        $launcherPath = Join-Path $ModuleRoot 'bridge_launcher.ps1'
        $bridgePath = Join-Path $ModuleRoot 'bridge.ps1'
        if (!(Test-Path -LiteralPath $launcherPath -PathType Leaf) -or !(Test-Path -LiteralPath $bridgePath -PathType Leaf)) {
            throw 'Os componentes internos do Atlas Repair não foram localizados.'
        }
        $completedSteps = 0
        foreach ($step in $steps) {
            Write-Output "[ATLAS REPAIR] $($completedSteps + 1)/$($steps.Count) — $($step.Label)..."
            try {
                $stepOutput = powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $launcherPath -Script $bridgePath -Action $step.Action -Computer $Computer 2>&1
                $stepExitCode = $LASTEXITCODE
                if ($stepOutput) { $stepOutput | ForEach-Object { Write-Output ([string]$_) } }
                if ($stepExitCode -ne 0) { throw "A etapa retornou o código $stepExitCode." }
                $completedSteps++
                Write-Output "[ATLAS REPAIR] Concluído: $($step.Label)."
            } catch {
                throw "Atlas Repair interrompido em '$($step.Label)' após $completedSteps etapa(s) concluída(s): $($_.Exception.Message)"
            }
        }
        Write-Output "ATLAS REPAIR CONCLUÍDO — $completedSteps de $($steps.Count) etapas iniciadas com sucesso em $Computer."
    }
    "logoff" {
        Require-Computer
        $osRemote = Get-WmiObject Win32_OperatingSystem -ComputerName $Computer -ErrorAction Stop
        $result = $osRemote.Win32Shutdown(4)
        if ($result.ReturnValue -ne 0) { throw "Falha no logoff. Codigo: $($result.ReturnValue)" }
        Write-Output 'Logoff forcado executado com sucesso.'
    }
    "restart" {
        Require-Computer
        shutdown.exe /r /f /t 0 /m "\\$Computer"
        if ($LASTEXITCODE -ne 0) { throw "Falha ao enviar reinicializacao. Codigo: $LASTEXITCODE" }
        Write-Output 'Comando de reinicializacao enviado.'
    }
    "temp" { Invoke-RemoteTempCleanup }
    "install_printer" {
        Require-Computer
        if ([string]::IsNullOrWhiteSpace($Value)) { throw 'Informe o codigo da impressora.' }
        $code = $Value.Trim() -replace '^\\+','' -replace '^printserver\\',''
        $unc = "\\printserver\$code"
        try {
            Invoke-InteractiveTask -TaskName 'Suporte_InstalarImpressora' -Command 'rundll32.exe' -Arguments "printui.dll,PrintUIEntry /in /n`"$unc`""
            Write-Output "Instalacao de $unc iniciada na sessao do usuario."
        } catch {
            $cmd = "cmd.exe /c rundll32.exe printui.dll,PrintUIEntry /ga /n`"$unc`" /q & net stop spooler & net start spooler"
            $result = Invoke-WmiMethod -ComputerName $Computer -Class Win32_Process -Name Create -ArgumentList $cmd -ErrorAction Stop
            if ($result.ReturnValue -ne 0) { throw "Falha WMI: retorno $($result.ReturnValue)" }
            Write-Output "Instalacao global de $unc enviada via WMI."
        }
    }
    "remove_printer" {
        Require-Computer
        if ([string]::IsNullOrWhiteSpace($Value)) { throw 'Informe a impressora.' }
        $printer = $Value.Trim() -replace '\s*\(Padr[aã]o\)$',''
        if ($printer -notlike '\\*') { $printer = "\\printserver\$printer" }
        $globalConnection = $false
        try {
            $stdReg = [WMICLASS]"\\$Computer\root\default:StdRegProv"
            $connections = $stdReg.EnumKey(2147483650, 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Connections')
            $expected = $printer.Replace('\', ',')
            $globalConnection = @($connections.sNames | Where-Object { [string]$_ -ieq $expected }).Count -gt 0
        } catch {}
        $removedInSession = $false
        try {
            Invoke-InteractiveTask -TaskName 'Suporte_ExcluirImpressora' -Command 'rundll32.exe' -Arguments "printui.dll,PrintUIEntry /dn /n`"$printer`" /q"
            $removedInSession = $true
            Write-Output "Exclusao de $printer iniciada na sessao do usuario."
        } catch {}
        if ($globalConnection -or !$removedInSession) {
            $cmd = "cmd.exe /c rundll32.exe printui.dll,PrintUIEntry /gd /n`"$printer`" /q & net stop spooler & net start spooler"
            $result = Invoke-WmiMethod -ComputerName $Computer -Class Win32_Process -Name Create -ArgumentList $cmd -ErrorAction Stop
            if ($result.ReturnValue -ne 0) { throw "Falha WMI: retorno $($result.ReturnValue)" }
            Write-Output "Exclusao global de $printer enviada via WMI."
        }
    }
    "remove_hp_driver" {
        Require-Computer
        $path = 'X:\Driver Impressoras (Prodasen)\Remove Driver Impressoras HP (Prodasen).exe'
        $logged = (Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
        $root = Get-RemoteMappedDrivePath -Letter 'X' -LoggedUser $logged
        if ([string]::IsNullOrWhiteSpace($root)) { throw 'O drive X: não está disponível para o usuário conectado.' }
        $uncPath = Join-Path $root $path.Substring(3)
        if ((Test-Path -LiteralPath $root) -and !(Test-Path -LiteralPath $uncPath -PathType Leaf)) { throw 'O assistente de remoção HP não foi localizado no drive X:.' }
        try {
            Invoke-InteractiveTask -TaskName ('Suporte_RemoveDriverHP_' + [guid]::NewGuid().ToString('N').Substring(0, 8)) -Command $path -Arguments '' -RunLevel 'HighestAvailable'
            Write-Output 'Assistente de remocao do driver HP iniciado na sessao do usuario.'
        } catch {
            $result = Invoke-WmiMethod -ComputerName $Computer -Class Win32_Process -Name Create -ArgumentList "cmd.exe /c start `"`" `"$uncPath`"" -ErrorAction Stop
            if ($result.ReturnValue -ne 0) { throw "Falha WMI: retorno $($result.ReturnValue)" }
            Write-Output 'Remocao do driver HP iniciada via WMI.'
        }
    }
    "install_hp_driver" {
        Require-Computer
        $path = 'X:\Driver Impressoras (Prodasen)\Driver Impressoras HP (Prodasen).exe'
        $logged = (Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
        $root = Get-RemoteMappedDrivePath -Letter 'X' -LoggedUser $logged
        if ([string]::IsNullOrWhiteSpace($root)) { throw 'O drive X: não está disponível para o usuário conectado.' }
        $uncPath = Join-Path $root $path.Substring(3)
        if ((Test-Path -LiteralPath $root) -and !(Test-Path -LiteralPath $uncPath -PathType Leaf)) { throw 'O instalador do driver HP não foi localizado no drive X:.' }
        try {
            Invoke-InteractiveTask -TaskName ('Suporte_InstallDriverHP_' + [guid]::NewGuid().ToString('N').Substring(0, 8)) -Command $path -Arguments '' -RunLevel 'HighestAvailable'
            Write-Output 'Assistente de instalacao do driver HP iniciado na sessao do usuario.'
        } catch {
            $result = Invoke-WmiMethod -ComputerName $Computer -Class Win32_Process -Name Create -ArgumentList "cmd.exe /c start `"`" `"$uncPath`"" -ErrorAction Stop
            if ($result.ReturnValue -ne 0) { throw "Falha WMI: retorno $($result.ReturnValue)" }
            Write-Output 'Instalacao do driver HP iniciada via WMI.'
        }
    }
    "test_print" {
        Require-Computer
        if ([string]::IsNullOrWhiteSpace($Value)) { throw 'Informe a impressora.' }
        $printer = $Value.Trim()
        if ($printer -notlike '\\*') { $printer = "\\printserver\$printer" }
        $escaped = $printer -replace '\\','\\'
        $wmiPrinter = Get-WmiObject Win32_Printer -ComputerName $Computer -Filter "Name='$escaped'" -ErrorAction SilentlyContinue
        if ($wmiPrinter) {
            $result = $wmiPrinter.PrintTestPage()
            if ($result.ReturnValue -eq 0) { Write-Output "Pagina de teste enviada para $printer."; break }
        }
        Invoke-InteractiveTask -TaskName 'Suporte_ImprimirTeste' -Command 'rundll32.exe' -Arguments "printui.dll,PrintUIEntry /k /n`"$printer`""
        Write-Output "Pagina de teste solicitada na sessao do usuario para $printer."
    }
    "set_default_printer" {
        Require-Computer
        if ([string]::IsNullOrWhiteSpace($Value)) { throw 'Informe a impressora.' }
        $printer = $Value.Trim()
        if ($printer -notlike '\\*') { $printer = "\\printserver\$printer" }
        Invoke-InteractiveTask -TaskName 'Suporte_SetDefaultPrinter' -Command 'rundll32.exe' -Arguments "printui.dll,PrintUIEntry /y /n`"$printer`""
        Write-Output "$printer definida como padrao na sessao do usuario."
    }
    "spooler" {
        Require-Computer
        $svc = Get-WmiObject -ComputerName $Computer -Class Win32_Service -Filter "Name='Spooler'" -ErrorAction Stop
        $svc.StopService() | Out-Null
        Start-Sleep -Seconds 2
        $path = "\\$Computer\C$\Windows\System32\spool\PRINTERS"
        if (Test-Path $path) {
            Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        } else {
            Invoke-WmiMethod -ComputerName $Computer -Class Win32_Process -Name Create -ArgumentList 'cmd.exe /c del /f /q /s %systemroot%\System32\spool\PRINTERS\*.*' | Out-Null
        }
        $svc.StartService() | Out-Null
        Write-Output "Fila de impressão limpa e spooler reiniciado sem WinRM."
    }
    "authorized_software_list" {
        Require-Computer
        $logged = (Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
        if (!$logged) { throw 'Nenhum usuário conectado foi identificado.' }
        $root = Get-RemoteMappedDrivePath -Letter 'X' -LoggedUser $logged
        if ([string]::IsNullOrWhiteSpace($root)) {
            throw 'O drive X: não está mapeado para o usuário conectado. A central de softwares não foi liberada.'
        }
        $excluded = @(
            'Driver Impressoras HP (Prodasen).exe',
            'Remove Driver Impressoras HP (Prodasen).exe'
        )
        $items = @()
        $rootClean = $root.TrimEnd('\')
        $records = @()
        if (Test-Path -LiteralPath $rootClean) {
            $records = @(Get-ChildItem -LiteralPath $rootClean -Filter '*.exe' -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                $fileDescription = ''
                try { $fileDescription = [string]$_.VersionInfo.FileDescription } catch {}
                [PSCustomObject]@{ FullName = $_.FullName; Name = $_.Name; BaseName = $_.BaseName; Description = $fileDescription; IsDrivePath = $false }
            })
        } else {
            $records = @(Get-RemoteSessionExecutables -LoggedUser $logged | ForEach-Object {
                $remoteFile = [string]$_
                [PSCustomObject]@{ FullName = $remoteFile; Name = [IO.Path]::GetFileName($remoteFile); BaseName = [IO.Path]::GetFileNameWithoutExtension($remoteFile); Description = ''; IsDrivePath = $true }
            })
        }
        if (!$records.Count) {
            throw 'O drive X: foi identificado, mas nenhum executável pôde ser lido pela sessão administrativa nem pela sessão do usuário.'
        }
        foreach ($file in $records) {
            if ($excluded -icontains [string]$file.Name) { continue }
            $relative = if ($file.IsDrivePath) { ([string]$file.FullName).Substring(3) } else { ([string]$file.FullName).Substring($rootClean.Length).TrimStart('\') }
            $description = ''
            try { $description = [string]$file.Description } catch {}
            # O nome visível precisa ser idêntico ao arquivo no X:, pois a
            # versão costuma fazer parte do próprio nome do executável.
            $displayName = [string]$file.Name
            $folder = Split-Path $relative -Parent
            $category = Get-SoftwareCategory "$relative $description"
            $items += [ordered]@{
                name = $displayName
                file = $file.Name
                category = $category
                folder = if ($folder) { $folder } else { 'Raiz do drive X:' }
                path = "X:\$relative"
            }
        }
        $items = @($items | Sort-Object category, name, path)
        $data = [ordered]@{
            access = $true
            drive = 'X:'
            source = $root
            count = $items.Count
            items = $items
        }
        Write-Output ('@@SOFTWARES@@' + ($data | ConvertTo-Json -Depth 5 -Compress))
        Write-Output "$($items.Count) executáveis autorizados foram organizados por categoria."
    }
    "capri_login" {
        $origin = 'https://capri.senado.leg.br'
        $targetUrl = "$origin/otrs/index.pl?Action=AgentTicketSearch"
        $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
        [void](Restore-CapriWebSession $webSession)
        function Test-CapriSessionLogin([string]$Html) {
            if ([string]::IsNullOrWhiteSpace($Html)) { return $true }
            if ($Html -match '(?i)(?:Action=|Action%3D)Logout(?:;|&|%3B|%26|["''])') { return $false }
            if ($Html -match '(?i)(?:Action=|Action%3D)AgentTicketZoom' -or
                $Html -match '(?is)<input[^>]+name=["'']CustomerUserLogin["'']' -or
                $Html -match '(?is)<input[^>]+name=["'']TicketCreateTimeStartDay["'']') { return $false }
            return ($Html -match '(?is)<input[^>]+name=["''](?:User|UserLogin)["'']' -and
                $Html -match '(?is)<input[^>]+name=["'']Password["'']')
        }
        $response = Invoke-WebRequest -Uri $targetUrl -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 35 -ErrorAction Stop
        if (Test-CapriSessionLogin ([string]$response.Content)) {
            $capriUser = Get-AtlasCredentialText 'GERENCIADOR_CAPRI_USER_B64' 'GERENCIADOR_CAPRI_USER'
            $capriPassword = Get-AtlasCredentialText 'GERENCIADOR_CAPRI_PASSWORD_B64' 'GERENCIADOR_CAPRI_PASSWORD'
            if (!$capriUser -or !$capriPassword) { throw 'A sessão persistente do Capri não está disponível. Informe o login do Capri.' }
            $challenge = ''
            $challengeMatch = [regex]::Match([string]$response.Content, '(?is)<input[^>]+name=["'']ChallengeToken["''][^>]+value=["''](?<value>[^"'']*)')
            if ($challengeMatch.Success) { $challenge = [Net.WebUtility]::HtmlDecode($challengeMatch.Groups['value'].Value) }
            $loginBody = @{ Action='Login'; RequestedURL='Action=AgentTicketSearch'; User=$capriUser; UserLogin=$capriUser; Password=$capriPassword }
            if ($challenge) { $loginBody['ChallengeToken'] = $challenge }
            $null = Invoke-WebRequest -Uri "$origin/otrs/index.pl" -Method Post -Body $loginBody -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 35 -ErrorAction Stop
            $response = Invoke-WebRequest -Uri $targetUrl -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 35 -ErrorAction Stop
            if (Test-CapriSessionLogin ([string]$response.Content)) { throw 'O Capri recusou a autenticação ou atingiu o limite de sessões ativas.' }
        }
        Save-CapriWebSession $webSession
        Remove-Item Env:GERENCIADOR_CAPRI_PASSWORD, Env:GERENCIADOR_CAPRI_PASSWORD_B64 -ErrorAction SilentlyContinue
        Write-Output '@@CAPRI_SESSION@@{"connected":true}'
        Write-Output '[CAPRI] Sessão persistente validada e pronta para reutilização.'
    }
    "capri_logout" {
        $sessionPath = Get-CapriSessionPath
        if (!(Test-Path -LiteralPath $sessionPath -PathType Leaf)) {
            Write-Output '@@CAPRI_LOGOUT@@{"disconnected":true,"session":false}'
            Write-Output '[CAPRI] Nenhuma sessão persistente estava ativa.'
            break
        }
        $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
        if (!(Restore-CapriWebSession $webSession)) {
            Remove-Item -LiteralPath $sessionPath -Force -ErrorAction SilentlyContinue
            Write-Output '@@CAPRI_LOGOUT@@{"disconnected":true,"session":false}'
            Write-Output '[CAPRI] O arquivo de sessão inválido foi removido.'
            break
        }
        $origin = 'https://capri.senado.leg.br'
        $restrictedUrl = "$origin/otrs/index.pl?Action=AgentTicketSearch"
        $restrictedPage = Invoke-WebRequest -Uri $restrictedUrl -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 25 -ErrorAction Stop
        $restrictedHtml = [string]$restrictedPage.Content
        $alreadyLoggedOut = ($restrictedHtml -match '(?is)<input[^>]+name=["''](?:User|UserLogin)["'']' -and
            $restrictedHtml -match '(?is)<input[^>]+name=["'']Password["'']')
        if ($alreadyLoggedOut) {
            Remove-Item -LiteralPath $sessionPath -Force -ErrorAction Stop
            Write-Output '@@CAPRI_LOGOUT@@{"disconnected":true,"session":false,"verified":true}'
            Write-Output '[CAPRI] A sessão já estava encerrada; cache local removido.'
            break
        }

        # O link fornecido pelo OTRS pode conter ChallengeToken ou outro parâmetro
        # da sessão. Usar Action=Logout sozinho não invalida todas as instalações.
        $logoutMatch = [regex]::Match(
            $restrictedHtml,
            '(?is)href=["''](?<href>[^"'']*(?:Action=|Action%3D)Logout[^"'']*)["'']'
        )
        if (!$logoutMatch.Success) { throw 'O Capri não forneceu o link autenticado de logout.' }
        $logoutHref = [Net.WebUtility]::HtmlDecode($logoutMatch.Groups['href'].Value)
        $logoutUri = [uri]::new([uri]"$origin/otrs/index.pl", $logoutHref)
        if ($logoutUri.Scheme -ne 'https' -or $logoutUri.Host -ne 'capri.senado.leg.br') {
            throw 'O Capri forneceu um endereço de logout fora do domínio autorizado.'
        }
        $null = Invoke-WebRequest -Uri $logoutUri.AbsoluteUri -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 25 -ErrorAction Stop

        # Não basta receber HTTP 200: o Capri pode redirecionar de volta para uma
        # sessão ainda autenticada. Reabre uma área restrita com o mesmo cookie e
        # só considera o logout concluído quando a tela de login reaparece.
        $verificationUrl = $restrictedUrl
        $verification = Invoke-WebRequest -Uri $verificationUrl -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 25 -ErrorAction Stop
        $verificationHtml = [string]$verification.Content
        $hasUserField = $verificationHtml -match '(?is)<input[^>]+name=["''](?:User|UserLogin)["'']'
        $hasPasswordField = $verificationHtml -match '(?is)<input[^>]+name=["'']Password["'']'
        $stillAuthenticated = $verificationHtml -match '(?i)(?:Action=|Action%3D)Logout(?:;|&|%3B|%26|["''])'
        if ($stillAuthenticated -or !($hasUserField -and $hasPasswordField)) {
            throw 'O Capri manteve a sessão ativa após a tentativa de logout.'
        }
        Remove-Item -LiteralPath $sessionPath -Force -ErrorAction Stop
        Write-Output '@@CAPRI_LOGOUT@@{"disconnected":true,"session":true,"verified":true}'
        Write-Output '[CAPRI] Logout confirmado pelo servidor; cache local removido.'
    }
    "password_manager_import_cookies" {
        try { $records = @($Value | ConvertFrom-Json -ErrorAction Stop) }
        catch { throw 'Os cookies recebidos do Chrome não são válidos.' }
        if (!$records.Count) { throw 'A extensão não encontrou uma sessão ativa do PWM no Chrome.' }
        $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
        foreach ($record in $records) {
            $domain = ([string]$record.domain).Trim()
            $name = ([string]$record.name).Trim()
            if (!$domain -or !$name) { continue }
            $normalizedDomain = $domain.TrimStart('.').ToLowerInvariant()
            if ($normalizedDomain -ne 'senado.leg.br' -and !$normalizedDomain.EndsWith('.senado.leg.br')) { continue }
            $path = if ([string]::IsNullOrWhiteSpace([string]$record.path)) { '/' } else { [string]$record.path }
            $cookie = New-Object Net.Cookie($name, [string]$record.value, $path, $domain)
            $cookie.Secure = [bool]$record.secure
            $cookie.HttpOnly = [bool]$record.httpOnly
            $expiry = 0.0
            if ([double]::TryParse([string]$record.expirationDate, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$expiry) -and $expiry -gt 0) {
                try { $cookie.Expires = [DateTimeOffset]::FromUnixTimeSeconds([long][Math]::Floor($expiry)).LocalDateTime } catch {}
            }
            [void]$webSession.Cookies.Add($cookie)
        }
        if (!(Save-PasswordManagerWebSession $webSession)) {
            throw 'A sessão do Chrome não trouxe cookies reutilizáveis do PWM.'
        }
        Write-Output '@@PASSWORD_MANAGER_CHROME_SESSION@@{"connected":true}'
        Write-Output '[PWM] Sessão ativa do Chrome recebida e protegida localmente.'
    }
    "password_manager_browser_session" {
        try { $browserRequest = $Value | ConvertFrom-Json -ErrorAction Stop }
        catch { throw 'A solicitação da sessão persistente do PWM é inválida.' }
        $debugPort = [int]$browserRequest.port
        $interactive = [bool]$browserRequest.interactive
        $deadline = (Get-Date).AddSeconds($(if ($interactive) { 240 } else { 12 }))
        $validated = $false
        $lastFailure = ''
        try {
            while ((Get-Date) -lt $deadline -and !$validated) {
                try {
                    $browserState = Get-AtlasPwmBrowserState $debugPort
                    $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
                    $imported = Import-AtlasPwmBrowserCookies -Session $webSession -Port $debugPort
                    if ($imported -gt 0) {
                        $loginUri = [uri]'https://gestorsenhas.senado.leg.br/private/login'
                        $requestArguments = @{
                            Uri=$loginUri
                            WebSession=$webSession
                            UseDefaultCredentials=$true
                            UseBasicParsing=$true
                            TimeoutSec=20
                            ErrorAction='Stop'
                        }
                        if ($browserState.UserAgent) { $requestArguments['UserAgent'] = $browserState.UserAgent }
                        $response = Invoke-WebRequest @requestArguments
                        $httpAuthenticated = !(Test-PasswordManagerLoginPage ([string]$response.Content))
                        # A interface autenticada no próprio navegador é a
                        # fonte de verdade. Alguns layouts do PWM mantêm a URL
                        # /private/login ou fragmentos do formulário no HTML,
                        # embora a sessão já tenha sido concluída.
                        if ($httpAuthenticated -or $browserState.Authenticated) {
                            if (!(Save-PasswordManagerWebSession $webSession)) {
                                throw 'O PWM autenticou, mas nenhum cookie reutilizável foi recebido.'
                            }
                            $validated = $true
                            break
                        }
                    }
                } catch {
                    $lastFailure = [string]$_.Exception.Message
                }
                if (!$interactive) { break }
                Start-Sleep -Milliseconds 900
            }
        } finally {
            Close-AtlasPwmBrowser $debugPort
        }
        if (!$validated) {
            if (!$interactive) {
                Write-Output '@@PASSWORD_MANAGER_BROWSER_REQUIRED@@{"required":true}'
                throw 'A sessão persistente do PWM não existe ou expirou.'
            }
            $suffix = if ($lastFailure) { " Detalhe: $lastFailure" } else { '' }
            throw "O login do PWM não foi confirmado no prazo esperado.$suffix"
        }
        Write-Output '@@PASSWORD_MANAGER_SESSION@@{"connected":true,"persistent_browser":true}'
        Write-Output '[PWM] Sessão validada no perfil exclusivo e salva para reutilização.'
    }
    "password_manager_login" {
        $loginUri = [uri]'https://gestorsenhas.senado.leg.br/private/login'
        $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
        [void](Restore-PasswordManagerWebSession $webSession)
        $response = Invoke-WebRequest -Uri $loginUri -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 35 -ErrorAction Stop
        if (Test-PasswordManagerLoginPage ([string]$response.Content)) {
            $managerUser = Get-PasswordManagerCredentialText 'ATLAS_PASSWORD_MANAGER_USER_B64'
            $managerPassword = Get-PasswordManagerCredentialText 'ATLAS_PASSWORD_MANAGER_PASSWORD_B64'
            if (!$managerUser -or !$managerPassword) { throw 'Informe o login e a senha do Gestor de Senhas.' }
            $form = Get-AtlasHtmlForm ([string]$response.Content) '(?is)(?:type=["'']password["'']|name=["''](?:password|senha|j_password)["''])'
            if (!$form) { throw 'O formulário de autenticação do Gestor de Senhas não foi localizado.' }
            $passwordField = @($form.Inputs | Where-Object { $_.Type -eq 'password' -or $_.Name -match '(?i)(?:password|senha|j_password)' })[0]
            $userField = @($form.Inputs | Where-Object {
                $_.Type -notin @('hidden','submit','button','password') -and $_.Name -match '(?i)(?:user|login|username|j_username|usuario|usu[aá]rio)'
            })[0]
            if (!$userField) { $userField = @($form.Inputs | Where-Object { $_.Type -in @('text','email','') })[0] }
            if (!$userField -or !$passwordField) { throw 'Os campos de autenticação do Gestor de Senhas não foram identificados.' }
            $response = Invoke-AtlasPasswordManagerForm -Form $form -BaseUri $response.BaseResponse.ResponseUri -Session $webSession -Overrides @{
                ([string]$userField.Name) = $managerUser
                ([string]$passwordField.Name) = $managerPassword
            }
            if (Test-PasswordManagerLoginPage ([string]$response.Content)) {
                throw 'O Gestor de Senhas recusou a autenticação ou manteve a tela de login.'
            }
        }
        if (!(Save-PasswordManagerWebSession $webSession)) {
            throw 'O Gestor autenticou, mas não forneceu um cookie reutilizável.'
        }
        Remove-Item Env:ATLAS_PASSWORD_MANAGER_PASSWORD_B64 -ErrorAction SilentlyContinue
        Write-Output '@@PASSWORD_MANAGER_SESSION@@{"connected":true}'
        Write-Output '[GESTOR DE SENHAS] Sessão validada e pronta para reutilização.'
    }
    "password_manager_logout" {
        $sessionPath = Get-PasswordManagerSessionPath
        $serverLogout = $false
        if (Test-Path -LiteralPath $sessionPath -PathType Leaf) {
            $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
            if (Restore-PasswordManagerWebSession $webSession) {
                try {
                    $loginUri = [uri]'https://gestorsenhas.senado.leg.br/private/login'
                    $response = Invoke-WebRequest -Uri $loginUri -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 25 -ErrorAction Stop
                    if (!(Test-PasswordManagerLoginPage ([string]$response.Content))) {
                        foreach ($link in @([regex]::Matches([string]$response.Content, '(?is)<a\b[^>]*href=["''](?<href>[^"'']+)["''][^>]*>(?<text>.*?)</a>'))) {
                            $plain = ((ConvertTo-AtlasHtmlLines ([string]$link.Groups['text'].Value)) -join ' ')
                            if ($plain -match '(?i)^(?:sair|logout|encerrar)') {
                                $logoutUri = Resolve-AtlasFormUri $response.BaseResponse.ResponseUri ([Net.WebUtility]::HtmlDecode($link.Groups['href'].Value))
                                $null = Invoke-WebRequest -Uri $logoutUri -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 25 -ErrorAction Stop
                                $serverLogout = $true
                                break
                            }
                        }
                    } else { $serverLogout = $true }
                } catch {}
            }
            Remove-Item -LiteralPath $sessionPath -Force -ErrorAction SilentlyContinue
        }
        Write-Output ("@@PASSWORD_MANAGER_LOGOUT@@" + (@{ disconnected=$true; server=$serverLogout } | ConvertTo-Json -Compress))
        Write-Output '[GESTOR DE SENHAS] Sessão local encerrada e cookies protegidos removidos.'
    }
    "password_manager_user_lookup" {
        $lookupRequest = $null
        if (([string]$Value).Trim().StartsWith('{')) {
            try { $lookupRequest = $Value | ConvertFrom-Json -ErrorAction Stop } catch {}
        }
        $requestedLogin = if ($lookupRequest) { [string]$lookupRequest.login } else { [string]$Value }
        $userOnly = Normalize-AtlasNetworkLogin $requestedLogin
        $fullName = if ($lookupRequest) { ([string]$lookupRequest.full_name).Trim() } else { '' }
        $institutionalEmail = if ($lookupRequest) { ([string]$lookupRequest.institutional_email).Trim() } else { '' }
        $fullNameKey = ConvertTo-AtlasComparableText $fullName
        $emailKey = ConvertTo-AtlasComparableText $institutionalEmail
        $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
        if (!(Restore-PasswordManagerWebSession $webSession)) { throw 'A sessão do Gestor de Senhas não está conectada.' }
        $loginUri = [uri]'https://gestorsenhas.senado.leg.br/private/login'
        $response = Invoke-WebRequest -Uri $loginUri -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 20 -ErrorAction Stop
        if (Test-PasswordManagerLoginPage ([string]$response.Content)) {
            Remove-Item -LiteralPath (Get-PasswordManagerSessionPath) -Force -ErrorAction SilentlyContinue
            Write-Output '@@PASSWORD_MANAGER_EXPIRED@@{"connected":false}'
            throw 'A sessão do Gestor de Senhas expirou. Conecte novamente.'
        }

        $currentResponse = $response
        foreach ($link in @([regex]::Matches([string]$response.Content, '(?is)<a\b[^>]*href=["''](?<href>[^"'']+)["''][^>]*>(?<text>.*?)</a>'))) {
            $plain = ((ConvertTo-AtlasHtmlLines ([string]$link.Groups['text'].Value)) -join ' ')
            if ($plain -match '(?i)suporte\s*t[eé]cnico') {
                $supportUri = Resolve-AtlasFormUri $response.BaseResponse.ResponseUri ([Net.WebUtility]::HtmlDecode($link.Groups['href'].Value))
                $currentResponse = Invoke-WebRequest -Uri $supportUri -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 20 -ErrorAction Stop
                break
            }
        }

        $searchForm = Get-AtlasHtmlForm ([string]$currentResponse.Content) '(?i)(?:login|user|usuario|usu[aá]rio|search|pesquis)'
        if (!$searchForm) { throw 'A pesquisa de Suporte Técnico não foi localizada no PWM.' }
        $searchField = @($searchForm.Inputs | Where-Object {
            $_.Type -notin @('hidden','submit','button','password') -and $_.Name -match '(?i)(?:login|user|usuario|usu[aá]rio|search|query|termo)'
        })[0]
        if (!$searchField) { $searchField = @($searchForm.Inputs | Where-Object { $_.Type -in @('text','search','email','') })[0] }
        if (!$searchField) { throw 'O campo de login da pesquisa do PWM não foi identificado.' }
        $searchOverrides = @{ ([string]$searchField.Name) = $userOnly }
        $searchButton = @($searchForm.Inputs | Where-Object {
            $_.Type -in @('submit','button') -and $_.Name -and (($_.Name + ' ' + $_.Value) -match '(?i)(?:pesquis|buscar|search|consult)')
        })[0]
        if (!$searchButton) {
            $searchButton = @($searchForm.Inputs | Where-Object { $_.Type -in @('submit','button') -and $_.Name })[0]
        }
        if ($searchButton -and $searchButton.Name) {
            $searchOverrides[[string]$searchButton.Name] = [string]$searchButton.Value
        }
        $currentResponse = Invoke-AtlasPasswordManagerForm `
            -Form $searchForm -BaseUri $currentResponse.BaseResponse.ResponseUri `
            -Session $webSession -Overrides $searchOverrides -TimeoutSeconds 20
        if (Test-PasswordManagerLoginPage ([string]$currentResponse.Content)) { throw 'A sessão expirou durante a consulta do usuário.' }

        $detailLink = $null
        $detailCandidates = @()
        foreach ($link in @([regex]::Matches([string]$currentResponse.Content, '(?is)<a\b[^>]*href=["''](?<href>[^"'']+)["''][^>]*>(?<text>.*?)</a>'))) {
            $plain = ((ConvertTo-AtlasHtmlLines ([string]$link.Groups['text'].Value)) -join ' ')
            $plainKey = ConvertTo-AtlasComparableText $plain
            $href = [Net.WebUtility]::HtmlDecode([string]$link.Groups['href'].Value)
            $hrefKey = ConvertTo-AtlasComparableText $href
            $matchesIdentity = (
                $plainKey -match [regex]::Escape($userOnly.ToLowerInvariant()) -or
                $hrefKey -match [regex]::Escape($userOnly.ToLowerInvariant()) -or
                ($fullNameKey -and $plainKey.Contains($fullNameKey)) -or
                ($emailKey -and $plainKey.Contains($emailKey))
            )
            if ($matchesIdentity) {
                $detailLink = $link
                break
            }
            if ($href -match '(?i)(?:user|usuario|account|detail|profile|perfil|support|suporte)' -and
                    $plain -notmatch '(?i)^(?:perfil|status|hist[oó]rico|pol[ií]tica|sair|logout)$') {
                $detailCandidates += $link
            }
        }
        if (!$detailLink -and $detailCandidates.Count -eq 1) { $detailLink = $detailCandidates[0] }
        if ($detailLink) {
            $detailUri = Resolve-AtlasFormUri $currentResponse.BaseResponse.ResponseUri ([Net.WebUtility]::HtmlDecode($detailLink.Groups['href'].Value))
            $currentResponse = Invoke-WebRequest -Uri $detailUri -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 20 -ErrorAction Stop
        } else {
            $resultText = ConvertTo-AtlasComparableText ((ConvertTo-AtlasHtmlLines ([string]$currentResponse.Content)) -join ' ')
            $alreadyOnProfile = $resultText -match '(?:primeiro nome|email institucional|organizacao)' -and
                ($resultText -match [regex]::Escape($userOnly.ToLowerInvariant()) -or
                 ($fullNameKey -and $resultText.Contains($fullNameKey)))
            if (!$alreadyOnProfile) {
                throw 'O PWM respondeu à pesquisa, mas o registro correto do usuário não pôde ser selecionado.'
            }
        }

        $sectionPages = [ordered]@{ 'Perfil'=[string]$currentResponse.Content }
        $statusLoaded = $false
        foreach ($link in @([regex]::Matches([string]$currentResponse.Content, '(?is)<a\b[^>]*href=["''](?<href>[^"'']+)["''][^>]*>(?<text>.*?)</a>'))) {
            $label = ((ConvertTo-AtlasHtmlLines ([string]$link.Groups['text'].Value)) -join ' ')
            if ($label -notmatch '(?i)^Status$') { continue }
            try {
                $tabUri = Resolve-AtlasFormUri $currentResponse.BaseResponse.ResponseUri ([Net.WebUtility]::HtmlDecode($link.Groups['href'].Value))
                $tabResponse = Invoke-WebRequest -Uri $tabUri -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 20 -ErrorAction Stop
                if (!(Test-PasswordManagerLoginPage ([string]$tabResponse.Content))) {
                    $sectionPages[$label] = [string]$tabResponse.Content
                    $statusLoaded = $true
                }
            } catch {}
            break
        }
        if (!$statusLoaded) {
            throw 'O usuário foi localizado no PWM, mas a aba Status não pôde ser carregada.'
        }
        $profileLines = ConvertTo-AtlasHtmlLines ([string]$sectionPages['Perfil'])
        $statusHtml = @($sectionPages.GetEnumerator() | Where-Object { $_.Key -match '(?i)^Status$' } | Select-Object -First 1).Value
        $statusLines = ConvertTo-AtlasHtmlLines $statusHtml
        $statusData = [ordered]@{
            'Nome de usuário' = (Get-AtlasHtmlField $statusLines 'Nome\s+de\s+usu[aá]rio')
            'DN do usuário' = (Get-AtlasHtmlField $statusLines 'DN\s+do\s+Usu[aá]rio')
            'E-mail de recuperação' = (Get-AtlasHtmlField $statusLines 'E-?mail')
            'Conta habilitada' = (Get-AtlasHtmlField $statusLines 'Conta\s+Habilitada')
            'Conta expirada' = (Get-AtlasHtmlField $statusLines 'Conta\s+Expirada')
            'Último login' = (Get-AtlasHtmlField $statusLines 'Hor[aá]rio\s+do\s+[ÚU]ltimo\s+Login')
            'Senha expirada' = (Get-AtlasHtmlField $statusLines 'Senha\s+Expirada')
            'Definição da senha' = (Get-AtlasHtmlField $statusLines 'Hor[aá]rio\s+de\s+Defini[cç][aã]o\s+da\s+Senha')
            'Vencimento da senha' = (Get-AtlasHtmlField $statusLines 'Hor[aá]rio\s+de\s+Vencimento\s+da\s+Senha')
            'Bloqueio por intrusão' = (Get-AtlasHtmlField $statusLines 'Senha\s+Bloqueada.*Intrus[aã]o')
        }
        $essentialStatus = @(@(
            $statusData['E-mail de recuperação'], $statusData['Conta habilitada'],
            $statusData['Senha expirada'], $statusData['Vencimento da senha']
        ) | Where-Object { $_ -and $_ -ne 'Não informado' })
        if (!$essentialStatus.Count) {
            throw 'O usuário foi localizado no PWM, mas a aba Status não devolveu os dados da conta.'
        }
        $data = [ordered]@{
            source = 'Gestor de Senhas'
            login = $userOnly
            profile = [ordered]@{
                'Nome' = (Get-AtlasHtmlField $profileLines 'Nome')
                'Cargo' = (Get-AtlasHtmlField $profileLines 'Cargo')
                'Primeiro nome' = (Get-AtlasHtmlField $profileLines 'Primeiro\s+Nome')
                'Sobrenome' = (Get-AtlasHtmlField $profileLines 'Sobrenome')
                'E-mail institucional' = (Get-AtlasHtmlField $profileLines 'E-?mail\s+institucional')
                'Organização' = (Get-AtlasHtmlField $profileLines 'Organiza[cç][aã]o')
                'Órgão' = (Get-AtlasHtmlField $profileLines '[ÓO]rg[aã]o')
            }
            status = $statusData
            password_history = @()
            password_policy = [ordered]@{}
        }
        Save-PasswordManagerWebSession $webSession
        Write-Output ("@@PASSWORD_MANAGER_USER@@" + ($data | ConvertTo-Json -Depth 6 -Compress))
        Write-Output "[GESTOR DE SENHAS] Dados complementares carregados para SENADO\\$userOnly."
    }
    "password_recovery_preview" {
        try { $request = $Value | ConvertFrom-Json -ErrorAction Stop } catch { throw 'Os dados da recuperação são inválidos.' }
        $userOnly = Normalize-AtlasNetworkLogin ([string]$request.login)
        $fullName = ([string]$request.full_name).Trim()
        if (!$fullName -or $fullName.Length -gt 180) { throw 'O nome completo do usuário não está disponível.' }
        $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
        [void](Restore-PasswordManagerWebSession $webSession)
        $lookup = Invoke-PasswordRecoveryLookup -Session $webSession -Login $userOnly -FullName $fullName
        $lines = ConvertTo-AtlasHtmlLines ([string]$lookup.Response.Content)
        $maskedEmail = @($lines | Where-Object { $_ -match '(?i)[A-Z0-9._%+*-]+@(?:[A-Z0-9*-]+\.)+[A-Z*]{2,}' } | Select-Object -First 1)
        if ($maskedEmail.Count) { $maskedEmail = [string]$maskedEmail[0] } else { $maskedEmail = 'Endereço protegido pelo Gestor de Senhas' }
        $confirmationForm = Get-AtlasHtmlForm ([string]$lookup.Response.Content) '(?i)(?:continuar|confirm|token|security|seguran[cç]a)'
        if (!$confirmationForm) { throw 'O Gestor não apresentou a etapa de confirmação do envio.' }
        Save-PasswordManagerWebSession $webSession
        $data = [ordered]@{ ready=$true; login=$userOnly; masked_email=$maskedEmail }
        Write-Output ("@@PASSWORD_RECOVERY_PREVIEW@@" + ($data | ConvertTo-Json -Compress))
        Write-Output '[RECUPERAÇÃO] Destino protegido validado; aguardando confirmação explícita do operador.'
    }
    "password_recovery_send" {
        try { $request = $Value | ConvertFrom-Json -ErrorAction Stop } catch { throw 'Os dados da recuperação são inválidos.' }
        $userOnly = Normalize-AtlasNetworkLogin ([string]$request.login)
        $fullName = ([string]$request.full_name).Trim()
        if (!$fullName -or $fullName.Length -gt 180) { throw 'O nome completo do usuário não está disponível.' }
        $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
        [void](Restore-PasswordManagerWebSession $webSession)
        $lookup = Invoke-PasswordRecoveryLookup -Session $webSession -Login $userOnly -FullName $fullName
        $confirmationForm = Get-AtlasHtmlForm ([string]$lookup.Response.Content) '(?i)(?:continuar|confirm|token|security|seguran[cç]a)'
        if (!$confirmationForm) { throw 'A confirmação da recuperação não foi localizada.' }
        $submitOverrides = @{}
        $continueButton = @($confirmationForm.Inputs | Where-Object { $_.Type -in @('submit','button') -and (($_.Name + ' ' + $_.Value) -match '(?i)(?:continuar|confirm|enviar)') })[0]
        if ($continueButton -and $continueButton.Name) { $submitOverrides[[string]$continueButton.Name] = [string]$continueButton.Value }
        $sent = Invoke-AtlasPasswordManagerForm -Form $confirmationForm -BaseUri $lookup.Response.BaseResponse.ResponseUri -Session $webSession -Overrides $submitOverrides
        $sentLines = ConvertTo-AtlasHtmlLines ([string]$sent.Content)
        $successText = @($sentLines | Where-Object { $_ -match '(?i)(?:e-?mail|mensagem|c[oó]digo).*(?:enviad|encaminhad|sucesso)' } | Select-Object -First 1)
        $explicitFailure = @($sentLines | Where-Object {
            $_ -match '(?i)(?:não|nao)\s+foi\s+poss[ií]vel' -or
            $_ -match '(?i)usu[aá]rio\s+(?:não|nao)\s+(?:localizado|encontrado)' -or
            $_ -match '(?i)solicita[cç][aã]o\s+(?:recusada|bloqueada)' -or
            $_ -match '(?i)limite\s+de\s+(?:envios|tentativas).*excedido' -or
            $_ -match '(?i)dados\s+inv[aá]lidos'
        } | Select-Object -First 1)
        if ($explicitFailure.Count) {
            throw "O Gestor recusou a solicitação de recuperação: $([string]$explicitFailure[0])"
        }
        $statusCode = 0
        try { $statusCode = [int]$sent.StatusCode } catch {}
        $accepted = ($statusCode -ge 200 -and $statusCode -lt 400)
        if (!$accepted) {
            throw "O servidor não aceitou a solicitação de recuperação (HTTP $statusCode). Nenhuma repetição automática foi realizada."
        }
        $result = [ordered]@{
            sent = $true
            confirmed = [bool]$successText.Count
            status_code = $statusCode
        }
        Write-Output ("@@PASSWORD_RECOVERY_SENT@@" + ($result | ConvertTo-Json -Compress))
        if ($successText.Count) {
            Write-Output '[RECUPERAÇÃO] O Gestor confirmou textualmente o encaminhamento da solicitação.'
        } else {
            Write-Output '[RECUPERAÇÃO] Solicitação aceita pelo servidor sem confirmação textual; nenhuma repetição foi realizada.'
        }
    }
    "ticket_catalog" {
        try { $request = $Value | ConvertFrom-Json -ErrorAction Stop } catch { throw 'Os filtros da consulta de chamados são inválidos.' }
        $previewOnly = [bool]$request.preview_only
        $previewLimit = if ($previewOnly) { 25 } else { 10000 }
        Write-Output '@@TICKET_PROGRESS@@3'
        $origin = 'https://capri.senado.leg.br'
        $searchUrl = "$origin/otrs/index.pl?Action=AgentTicketSearch"
        $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
        [void](Restore-CapriWebSession $webSession)
        function Test-CapriTicketLogin([string]$Html) {
            if ([string]::IsNullOrWhiteSpace($Html)) { return $false }
            # Páginas autenticadas do OTRS podem manter um formulário/modal de
            # login no HTML. A ação de logout confirma a sessão e tem prioridade.
            if ($Html -match '(?i)(?:Action=|Action%3D)Logout(?:;|&|%3B|%26|["''])') { return $false }
            if ($Html -match '(?i)(?:Action=|Action%3D)AgentTicketZoom' -or
                $Html -match '(?is)<input[^>]+name=["'']CustomerUserLogin["'']' -or
                $Html -match '(?is)<input[^>]+name=["'']TicketCreateTimeStartDay["'']') { return $false }
            $hasUserField = $Html -match '(?is)<input[^>]+name=["'']User["'']'
            $hasPasswordField = $Html -match '(?is)<input[^>]+name=["'']Password["'']'
            $hasLoginAction = ($Html -match '(?is)<form[^>]+action=["''][^"'']*(?:\?|&)Action=Login(?:&|["''])' -or
                $Html -match '(?is)<input[^>]+name=["'']Action["''][^>]+value=["'']Login["'']')
            # A pesquisa possui campos como CustomerUserLogin. Eles não podem,
            # isoladamente, ser confundidos com a tela de autenticação.
            return ($hasUserField -and $hasPasswordField -and $hasLoginAction)
        }
        function Get-TicketPlainText([string]$Html) {
            $value = $Html -replace '(?is)<(script|style|svg)\b[^>]*>.*?</\1>', ' '
            $value = $value -replace '(?i)<br\s*/?>', "`n"
            $value = $value -replace '(?i)</(?:td|th|div|p|li|tr|h[1-6])>', "`n"
            return ([Net.WebUtility]::HtmlDecode(($value -replace '(?is)<[^>]+>', ' ')) -replace '[ \t]+', ' ').Trim()
        }
        function Get-CapriTicketPageUrls([string]$Html) {
            $urls = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
            foreach ($attribute in [regex]::Matches($Html, '(?is)(?:href|data-url)=["''](?<url>[^"'']+)["'']')) {
                $candidate = [Net.WebUtility]::HtmlDecode($attribute.Groups['url'].Value)
                if ($candidate -notmatch '(?i)AgentTicketSearch' -or $candidate -notmatch '(?i)(?:StartHit|Page)(?:=|%3D)\d+') { continue }
                try { [void]$urls.Add(([uri]::new([uri]$origin, $candidate)).AbsoluteUri) } catch {}
            }
            # Alguns temas do OTRS guardam o endereço dentro de onclick.
            foreach ($embedded in [regex]::Matches($Html, '(?is)(?<url>(?:/otrs/|https?://[^/]+/otrs/)index\.pl\?[^"''<>\s]+(?:StartHit|Page)(?:=|%3D)\d+[^"''<>\s]*)')) {
                $candidate = [Net.WebUtility]::HtmlDecode($embedded.Groups['url'].Value)
                try { [void]$urls.Add(([uri]::new([uri]$origin, $candidate)).AbsoluteUri) } catch {}
            }
            return @($urls)
        }
        function Invoke-CapriTicketLogin([string]$Html, [string]$UserName, [string]$Password) {
            $challenge = ''
            $challengeMatch = [regex]::Match($Html, '(?is)<input[^>]+name=["'']ChallengeToken["''][^>]+value=["''](?<value>[^"'']*)')
            if ($challengeMatch.Success) { $challenge = [Net.WebUtility]::HtmlDecode($challengeMatch.Groups['value'].Value) }
            # Uma única tentativa compatível com os nomes de campo usados nas
            # diferentes versões do Capri, evitando criar sessões duplicadas.
            $loginBody = @{ Action='Login'; RequestedURL='Action=AgentTicketSearch'; Password=$Password; User=$UserName; UserLogin=$UserName; Login=$UserName }
            if ($challenge) { $loginBody['ChallengeToken'] = $challenge }
            # O Capri pode incluir campos hidden adicionais de sessão ou idioma.
            foreach ($hidden in [regex]::Matches($Html, '(?is)<input[^>]+type=["'']hidden["''][^>]*>')) {
                $nameMatch = [regex]::Match($hidden.Value, '(?is)name=["''](?<name>[^"'']+)["'']')
                $valueMatch = [regex]::Match($hidden.Value, '(?is)value=["''](?<value>[^"'']*)["'']')
                if ($nameMatch.Success -and $valueMatch.Success -and !$loginBody.ContainsKey($nameMatch.Groups['name'].Value)) {
                    $loginBody[$nameMatch.Groups['name'].Value] = [Net.WebUtility]::HtmlDecode($valueMatch.Groups['value'].Value)
                }
            }
            $null = Invoke-WebRequest -Uri "$origin/otrs/index.pl" -Method Post -Body $loginBody -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 35 -ErrorAction Stop
            $after = Invoke-WebRequest -Uri $searchUrl -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 35 -ErrorAction Stop
            return [string]$after.Content
        }
        function Get-TicketColumnIndex([object[]]$Headers, [string]$Pattern) {
            for ($index = 0; $index -lt $Headers.Count; $index++) {
                if ([string]$Headers[$index] -match $Pattern) { return $index }
            }
            return -1
        }
        function Get-CapriCsvValue([object]$Record, [string]$Pattern) {
            foreach ($property in @($Record.PSObject.Properties)) {
                $header = (([Net.WebUtility]::HtmlDecode([string]$property.Name) -replace '^\uFEFF', '') -replace '\s+', ' ').Trim()
                if ($header -match $Pattern) { return ([string]$property.Value).Trim() }
            }
            return ''
        }
        function Get-CapriStateKind([string]$State) {
            if ($State -match '(?i)rejeitad|reject') { return 'rejected' }
            if ($State -match '(?i)cancelad.*cliente|customer.*cancel') { return 'customer_cancelled' }
            if ($State -match '(?i)sem êxito|sem exito|unsuccessful') { return 'closed_unsuccessful' }
            if ($State -match '(?i)successful|com êxito|sucesso' -and $State -notmatch '(?i)unsuccessful|sem êxito') { return 'closed_success' }
            if ($State -match '(?i)pending|pendente') { return 'pending' }
            if ($State -match '(?i)\b(?:open|new|aberto|novo)\b') { return 'open' }
            if ($State -match '(?i)closed|fechado') { return 'closed_other' }
            return 'other'
        }
        function Get-CapriTicketStateByNumber([string]$Number) {
            # A página do chamado é a fonte direta do estado atual. O Zoom do
            # OTRS resolve TicketNumber em TicketID, inclusive para registros
            # antigos que não aparecem na busca de ontem e hoje.
            try {
                $detail = Invoke-WebRequest -Uri "$origin/otrs/index.pl?Action=AgentTicketZoom;TicketNumber=$Number" -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 25 -ErrorAction Stop
                $detailHtml = [string]$detail.Content
                if (Test-CapriTicketLogin $detailHtml) { throw 'A sessão do Capri expirou.' }
                $plain = Get-TicketPlainText $detailHtml
                if ([regex]::IsMatch($plain, '(?<!\d)' + $Number + '(?!\d)')) {
                    $knownStates = 'fechado\s+com\s+êxito|fechado\s+sem\s+êxito|closed\s+successful|closed\s+unsuccessful|cancelad[oa]\s+pel[oa]\s+cliente|customer\s+cancelled|pending\s+reminder|pending\s+auto|pendente|rejeitad[oa]|rejected|aberto|open|novo|new|fechado|closed'
                    $current = [regex]::Match($plain, "(?is)\b(?:Estado|Situação|State)\s*:?\s*(?<state>$knownStates)(?=\b|\s|`$)")
                    if ($current.Success) {
                        $state = ($current.Groups['state'].Value -replace '\s+', ' ').Trim()
                        $kind = Get-CapriStateKind $state
                        if ($kind -ne 'other') { return [ordered]@{ number=$Number; state=$state; state_kind=$kind } }
                    }
                }
            } catch {
                # Alguns perfis não abrem o Zoom pelo número; usa a pesquisa
                # pontual como alternativa sem alterar o cache em caso de erro.
            }
            $lookup = [ordered]@{
                Action='AgentTicketSearch'; Subaction='Search'; ResultForm='Normal'
                Search='Pesquisar'; TicketNumber=$Number; SortBy='Age'
                OrderBy='Down'; Limit='25'; PageShown='25'
            }
            # O CSV preserva as colunas Estado e Chamado# sem depender do
            # cabeçalho HTML de cada tema visual do Capri.
            try {
                $csvLookup = [ordered]@{}
                foreach ($entry in $lookup.GetEnumerator()) { $csvLookup[$entry.Key] = $entry.Value }
                $csvLookup['ResultForm'] = 'CSV'
                $csvPage = Invoke-WebRequest -Uri "$origin/otrs/index.pl" -Method Post -Body $csvLookup -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 30 -ErrorAction Stop
                $csvText = [string]$csvPage.Content
                if (Test-CapriTicketLogin $csvText) { throw 'A sessão do Capri expirou.' }
                $csvParts = @($csvText -split '\r?\n', 2)
                $firstLine = $csvParts[0]
                if ($firstLine -match '^sep=(?<delimiter>.)\s*$') {
                    $delimiter = [char]$matches.delimiter
                    $csvText = if ($csvParts.Count -gt 1) { $csvParts[1] } else { '' }
                } else {
                    $delimiter = if (($firstLine.ToCharArray() | Where-Object { $_ -eq ';' }).Count -gt ($firstLine.ToCharArray() | Where-Object { $_ -eq ',' }).Count) { ';' } else { ',' }
                }
                foreach ($record in @($csvText | ConvertFrom-Csv -Delimiter $delimiter)) {
                    $published = Get-CapriCsvValue $record '(?i)(?:CHAMADO|TICKET).*(?:#|N[ÚU]MERO|NUMBER)'
                    if (!$published) { $published = Get-CapriCsvValue $record '(?i)^(?:CHAMADO|TICKET)#?$' }
                    $matchedNumber = [regex]::Match($published, '(?<!\d)(?<number>\d{6,20})(?!\d)')
                    if (!$matchedNumber.Success -or $matchedNumber.Groups['number'].Value -ne $Number) { continue }
                    $state = Get-CapriCsvValue $record '(?i)^(?:ESTADO|SITUA[CÇ][ÃA]O|STATE)$'
                    $kind = Get-CapriStateKind $state
                    if ($kind -ne 'other') { return [ordered]@{ number=$Number; state=$state; state_kind=$kind } }
                }
            } catch {
                # Se o exportador estiver indisponível, tenta a grade HTML.
            }
            $page = Invoke-WebRequest -Uri "$origin/otrs/index.pl" -Method Post -Body $lookup -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 20 -ErrorAction Stop
            $html = [string]$page.Content
            if (Test-CapriTicketLogin $html) { throw 'A sessão do Capri expirou durante a conferência dos estados.' }
            $header = [regex]::Match($html, '(?is)<tr\b[^>]*>(?<row>(?:(?!</tr>).)*<th\b.*?</tr>)')
            if (!$header.Success) { return $null }
            $headers = @([regex]::Matches($header.Groups['row'].Value, '(?is)<th\b[^>]*>(?<cell>.*?)</th>') |
                ForEach-Object { (Get-TicketPlainText $_.Groups['cell'].Value).ToUpperInvariant() })
            $numberColumn = Get-TicketColumnIndex $headers 'CHAMADO|TICKET'
            $stateColumn = Get-TicketColumnIndex $headers 'ESTADO|SITUA[CÇ][ÃA]O|STATE'
            if ($numberColumn -lt 0 -or $stateColumn -lt 0) { return $null }
            foreach ($rowMatch in [regex]::Matches($html, '(?is)<tr\b[^>]*>(?<row>.*?)</tr>')) {
                $cells = @([regex]::Matches($rowMatch.Groups['row'].Value, '(?is)<td\b[^>]*>(?<cell>.*?)</td>') |
                    ForEach-Object { Get-TicketPlainText $_.Groups['cell'].Value })
                if ($numberColumn -ge $cells.Count -or $stateColumn -ge $cells.Count) { continue }
                $published = [regex]::Match([string]$cells[$numberColumn], '(?<!\d)(?<number>\d{6,20})(?!\d)')
                if (!$published.Success -or $published.Groups['number'].Value -ne $Number) { continue }
                $state = ([string]$cells[$stateColumn]).Trim()
                $kind = Get-CapriStateKind $state
                if (!$state -or $kind -eq 'other') { return $null }
                return [ordered]@{ number=$Number; state=$state; state_kind=$kind }
            }
            return $null
        }
        function Get-NormalizedPersonName([string]$Name) {
            if ([string]::IsNullOrWhiteSpace($Name)) { return '' }
            $decomposed = $Name.Normalize([Text.NormalizationForm]::FormD)
            $builder = New-Object Text.StringBuilder
            foreach ($character in $decomposed.ToCharArray()) {
                if ([Globalization.CharUnicodeInfo]::GetUnicodeCategory($character) -ne [Globalization.UnicodeCategory]::NonSpacingMark) { [void]$builder.Append($character) }
            }
            return (($builder.ToString().Normalize([Text.NormalizationForm]::FormC) -replace '\s+', ' ').Trim().ToUpperInvariant())
        }
        function Get-CapriTicketIdentity([string]$TicketUrl) {
            try {
                $detail = Invoke-WebRequest -Uri $TicketUrl -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 45 -ErrorAction Stop
            } catch { throw "Não foi possível abrir o chamado para conferir o campo 'Criado por': $($_.Exception.Message)" }
            if (Test-CapriTicketLogin ([string]$detail.Content)) { throw 'A sessão do Capri expirou durante a conferência do campo Criado por.' }
            $detailHtml = [string]$detail.Content
            $creatorMatch = [regex]::Match($detailHtml, '(?is)>\s*Criado\s+por\s*:??\s*</[^>]+>\s*<[^>]+>\s*(?<creator>.*?)\s*</[^>]+>')
            if (!$creatorMatch.Success) {
                $creatorMatch = [regex]::Match((Get-TicketPlainText $detailHtml), '(?is)\bCriado\s+por\s*:\s*(?<creator>.+?)(?=\s+(?:Estado|Bloqueio|Fila|Servi[cç]o|Prioridade)\s*:)')
            }
            $plainDetail = Get-TicketPlainText $detailHtml
            $creator = if ($creatorMatch.Success) { ((Get-TicketPlainText $creatorMatch.Groups['creator'].Value) -replace '\s+', ' ').Trim() } else { '' }
            $createdMatch = [regex]::Match($plainDetail, '(?i)(?<!por\s)\bCriado\s*:\s*(?<created>\d{1,2}/\d{1,2}/\d{4}(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?)')
            if (!$createdMatch.Success) {
                $createdMatch = [regex]::Match($plainDetail, '(?i)\bCreated\s*:\s*(?<created>\d{4}-\d{2}-\d{2}(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?)')
            }
            return [ordered]@{ creator=$creator; created=$(if ($createdMatch.Success) { $createdMatch.Groups['created'].Value.Trim() } else { '' }) }
        }
        function Convert-CapriTicketDate([string]$Value) {
            if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
            $formats = @('dd/MM/yyyy HH:mm:ss','dd/MM/yyyy HH:mm','dd/MM/yyyy','yyyy-MM-dd HH:mm:ss','yyyy-MM-dd HH:mm','yyyy-MM-dd')
            $parsed = [datetime]::MinValue
            foreach ($format in $formats) {
                if ([datetime]::TryParseExact($Value.Trim(), $format, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$parsed)) { return $parsed }
            }
            if ([datetime]::TryParse($Value, [Globalization.CultureInfo]::GetCultureInfo('pt-BR'), [Globalization.DateTimeStyles]::None, [ref]$parsed)) { return $parsed }
            return $null
        }
        function Get-CapriPreviewSortDate([object]$Ticket) {
            $created = Convert-CapriTicketDate ([string]$Ticket.created)
            if ($created) { return $created }
            # O identificador do Capri começa pelo horário de abertura no
            # formato yyyyMMddHHmmss, mesmo quando a grade só mostra “Idade”.
            $number = ([string]$Ticket.number -replace '\D', '')
            $stamp = [regex]::Match($number, '^(?<date>\d{14})\d{0,6}$')
            if ($stamp.Success) {
                $parsed = [datetime]::MinValue
                if ([datetime]::TryParseExact($stamp.Groups['date'].Value, 'yyyyMMddHHmmss', [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$parsed)) { return $parsed }
            }
            return [datetime]::MinValue
        }
        $capriUser = Get-AtlasCredentialText 'GERENCIADOR_CAPRI_USER_B64' 'GERENCIADOR_CAPRI_USER'
        try {
            $first = Invoke-WebRequest -Uri $searchUrl -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 35 -ErrorAction Stop
        } catch { throw "Não foi possível abrir a pesquisa de chamados no Capri: $($_.Exception.Message)" }
        Write-Output '@@TICKET_PROGRESS@@10'
        if (Test-CapriTicketLogin ([string]$first.Content)) {
            $capriPassword = Get-AtlasCredentialText 'GERENCIADOR_CAPRI_PASSWORD_B64' 'GERENCIADOR_CAPRI_PASSWORD'
            if (!$capriUser -or !$capriPassword) { throw 'O Capri solicitou autenticação. Atualize a credencial pelo cadeado da área FAQs.' }
            $firstContent = Invoke-CapriTicketLogin ([string]$first.Content) $capriUser $capriPassword
            if (Test-CapriTicketLogin $firstContent) { throw 'A sessão persistente do Capri não pôde ser renovada. Redefina os acessos na tela inicial e autentique novamente.' }
            Write-Output '[CHAMADOS] Autenticação aceita; sessão web do Capri confirmada.'
        }
        Save-CapriWebSession $webSession
        Remove-Item Env:GERENCIADOR_CAPRI_PASSWORD, Env:GERENCIADOR_CAPRI_PASSWORD_B64 -ErrorAction SilentlyContinue
        if ([bool]$request.status_only) {
            $requestedNumbers = @($request.recheck_numbers | ForEach-Object { [string]$_ } | Sort-Object -Unique)
            if (!$requestedNumbers.Count -or $requestedNumbers.Count -gt 300 -or
                @($requestedNumbers | Where-Object { $_ -notmatch '^\d{6,20}$' }).Count) {
                throw 'A lista de chamados para atualização de situação é inválida.'
            }
            $confirmed = [System.Collections.Generic.List[object]]::new()
            $failed = [System.Collections.Generic.List[string]]::new()
            foreach ($numberToCheck in $requestedNumbers) {
                try {
                    $currentState = Get-CapriTicketStateByNumber $numberToCheck
                    if ($currentState) { $confirmed.Add($currentState) }
                    else { $failed.Add($numberToCheck) }
                } catch { $failed.Add($numberToCheck) }
            }
            Save-CapriWebSession $webSession
            Write-Output ('@@TICKET_STATUS@@' + ([ordered]@{
                complete=$true; requested_count=$requestedNumbers.Count
                updates=@($confirmed.ToArray()); failed=@($failed.ToArray())
            } | ConvertTo-Json -Depth 5 -Compress))
            break
        }
        $displayName = ([string]$request.display_name).Trim()
        if (!$displayName) { throw 'Informe o nome completo ou login usado como filtro no Capri.' }
        if ($previewOnly -and [string]$request.customer_login -notmatch '^[A-Za-z0-9._-]{1,128}$') {
            throw 'O login confirmado no Active Directory não é válido para consultar os chamados.'
        }
        $resolvedLogin = $displayName
        $resolvedDisplayName = $displayName
        if ($previewOnly -and [string]$request.customer_login -match '^[A-Za-z0-9._-]{1,128}$') {
            $resolvedLogin = ([string]$request.customer_login).Trim()
            $resolvedDisplayName = $displayName
            Write-Output "[CHAMADOS] Conta do AD confirmada para consulta temporária: $resolvedDisplayName ($resolvedLogin)."
        } elseif ([string]$request.scope -ne 'operator') {
            function ConvertTo-LdapFilterValue([string]$Value) {
                return $Value.Replace('\', '\5c').Replace('*', '\2a').Replace('(', '\28').Replace(')', '\29').Replace(([string][char]0), '\00')
            }
            try {
                $ldapValue = ConvertTo-LdapFilterValue $displayName
                $directory = New-Object DirectoryServices.DirectorySearcher
                $directory.PageSize = 20
                $directory.SizeLimit = 3
                $directory.Filter = "(&(objectCategory=person)(objectClass=user)(|(sAMAccountName=$ldapValue)(displayName=$ldapValue)(givenName=$ldapValue)(sn=$ldapValue)(displayName=*$ldapValue*)))"
                [void]$directory.PropertiesToLoad.Add('sAMAccountName')
                [void]$directory.PropertiesToLoad.Add('displayName')
                [void]$directory.PropertiesToLoad.Add('givenName')
                [void]$directory.PropertiesToLoad.Add('sn')
                $matchesFound = @($directory.FindAll())
                if ($matchesFound.Count -gt 1) {
                    $exactMatches = @($matchesFound | Where-Object {
                        ([string]$_.Properties['samaccountname'][0]).Equals($displayName, [StringComparison]::OrdinalIgnoreCase) -or
                        ([string]$_.Properties['displayname'][0]).Equals($displayName, [StringComparison]::OrdinalIgnoreCase)
                    })
                    if ($exactMatches.Count -eq 1) { $matchesFound = $exactMatches }
                    else { throw "Mais de um usuário corresponde a '$displayName'. Informe o login exato para continuar." }
                }
                if ($matchesFound.Count -eq 1) {
                    $resolvedLogin = ([string]$matchesFound[0].Properties['samaccountname'][0]).Trim()
                    $resolvedDisplayName = ([string]$matchesFound[0].Properties['displayname'][0]).Trim()
                    if (!$resolvedDisplayName) {
                        $resolvedDisplayName = (([string]$matchesFound[0].Properties['givenname'][0]) + ' ' + ([string]$matchesFound[0].Properties['sn'][0])).Trim()
                    }
                    Write-Output "[CHAMADOS] Usuário identificado: $resolvedDisplayName ($resolvedLogin)."
                } else {
                    Write-Output "[CHAMADOS] Usuário não localizado no AD; o Capri pesquisará diretamente por '$displayName'."
                }
            } catch {
                if ($_.Exception.Message -like 'Mais de um usuário*') { throw $_.Exception.Message }
                Write-Output "[CHAMADOS] A identificação no AD não ficou disponível; o Capri pesquisará diretamente por '$displayName'."
            }
        }
        $cachedNumbers = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        $cachePath = [string]$request.cache_path
        if (!$previewOnly -and $cachePath -and (Test-Path -LiteralPath $cachePath)) {
            try {
                $savedCatalog = Get-Content -LiteralPath $cachePath -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
                $sameOperator = ([string]$savedCatalog.scope -eq 'operator' -and
                    (Get-NormalizedPersonName ([string]$savedCatalog.subject)) -eq (Get-NormalizedPersonName $displayName))
                if ($sameOperator -and [bool]$savedCatalog.complete) {
                    foreach ($savedTicket in @($savedCatalog.items)) {
                        $savedValue = if ($savedTicket.number) { $savedTicket.number } else { $savedTicket.id }
                        $savedNumber = ([string]$savedValue -replace '\D', '')
                        if ($savedNumber) { [void]$cachedNumbers.Add($savedNumber) }
                    }
                }
            } catch {
                Write-Output '[CHAMADOS] O cache anterior não pôde ser lido; a consulta seguirá sem reaproveitamento.'
            }
        }
        $sortOrder = if ($previewOnly) { 'Up' } else { 'Down' }
        $body = [ordered]@{ Action='AgentTicketSearch'; Subaction='Search'; ResultForm='Normal'; Search='Pesquisar'; Fulltext=''; SortBy='Age'; OrderBy=$sortOrder; Limit=[string]$previewLimit; PageShown=[string]$previewLimit }
        # Nesta instalação, "Criado por" é informação do detalhe do chamado,
        # não um controle da pesquisa. No escopo do operador, coletamos todas
        # as páginas e confirmamos o criador dentro de cada chamado.
        if ([string]$request.scope -eq 'operator') {
            # Reduz o universo usando o nome completo, mas a inclusão final só
            # ocorre após a confirmação do campo Criado por no detalhe.
            $body['Fulltext'] = $displayName
        } elseif ($previewOnly) {
            # A prévia deve pesquisar o nome integral exibido pelo AD no texto
            # indexado pelo Capri, em vez de limitar a consulta ao login da conta.
            $body['Fulltext'] = $displayName
            Write-Output '[CHAMADOS] Usando o nome completo recebido do Active Directory no filtro do Capri.'
        } else {
            # O catálogo regular relaciona o cliente pelo login confirmado no AD.
            $body['CustomerUserLogin'] = $resolvedLogin
            $body['CustomerUser'] = $resolvedLogin
        }
        if ([string]$request.date_from -match '^(?<y>\d{4})-(?<m>\d{2})-(?<d>\d{2})$') {
            $body['TicketCreateTimeNewerDate'] = "$($request.date_from) 00:00:00"
            $body['TicketCreateTimeNewerDay'] = $matches.d; $body['TicketCreateTimeNewerMonth'] = $matches.m; $body['TicketCreateTimeNewerYear'] = $matches.y
            $body['TimeSearchType'] = 'TimeSlot'
            $body['TicketCreateTimeStartDay'] = $matches.d
            $body['TicketCreateTimeStartMonth'] = $matches.m
            $body['TicketCreateTimeStartYear'] = $matches.y
        }
        if ([string]$request.date_to -match '^(?<y>\d{4})-(?<m>\d{2})-(?<d>\d{2})$') {
            $body['TicketCreateTimeOlderDate'] = "$($request.date_to) 23:59:59"
            $body['TicketCreateTimeOlderDay'] = $matches.d; $body['TicketCreateTimeOlderMonth'] = $matches.m; $body['TicketCreateTimeOlderYear'] = $matches.y
            $body['TimeSearchType'] = 'TimeSlot'
            $body['TicketCreateTimeStopDay'] = $matches.d
            $body['TicketCreateTimeStopMonth'] = $matches.m
            $body['TicketCreateTimeStopYear'] = $matches.y
        }
        if (!$previewOnly -and !$body['TimeSearchType']) { throw 'O período da consulta não foi informado corretamente.' }
        if ($previewOnly) {
            Write-Output '[CHAMADOS] Consultando os chamados mais recentes do usuário no Capri (limite 25; somente visualização).'
        } else {
            Write-Output "[CHAMADOS] Consultando no Capri somente o intervalo $($request.date_from) a $($request.date_to)."
        }
        $requestedFrom = Convert-CapriTicketDate ([string]$request.date_from)
        $requestedTo = Convert-CapriTicketDate ([string]$request.date_to)
        if ($requestedTo) { $requestedTo = $requestedTo.Date.AddDays(1).AddTicks(-1) }
        if ([string]$request.status -eq 'open') { $body['StateType'] = @('new','open') }
        elseif ([string]$request.status -eq 'pending') { $body['StateType'] = @('pending reminder','pending auto') }
        elseif ([string]$request.status -eq 'successful') { $body['State'] = 'closed successful' }
        elseif ([string]$request.status -eq 'closed_other') { $body['StateType'] = @('closed') }
        try {
            $response = Invoke-WebRequest -Uri "$origin/otrs/index.pl" -Method Post -Body $body -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 60 -ErrorAction Stop
        } catch { throw "A pesquisa de chamados no Capri falhou: $($_.Exception.Message)" }
        Write-Output '@@TICKET_PROGRESS@@24'
        if (Test-CapriTicketLogin ([string]$response.Content)) { throw 'A sessão do Capri expirou durante a pesquisa de chamados.' }
        if ([string]::IsNullOrWhiteSpace([string]$response.Content)) { throw 'O Capri retornou uma resposta vazia durante a pesquisa de chamados. Tente novamente.' }
        if ([string]$request.scope -ne 'operator' -and !$previewOnly -and [string]$response.Content -notmatch '(?i)Action=AgentTicketZoom') {
            Write-Output "[CHAMADOS] Nenhum resultado pelo campo Usuário cliente; tentando também o campo de pesquisa por $resolvedLogin."
            $fallbackBody = [ordered]@{}
            foreach ($entry in $body.GetEnumerator()) { $fallbackBody[$entry.Key] = $entry.Value }
            $fallbackBody.Remove('CustomerUserLogin')
            $fallbackBody.Remove('CustomerUser')
            $fallbackBody['Fulltext'] = $resolvedLogin
            try {
                $response = Invoke-WebRequest -Uri "$origin/otrs/index.pl" -Method Post -Body $fallbackBody -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 60 -ErrorAction Stop
                $body = $fallbackBody
            } catch { throw "A pesquisa alternativa de chamados no Capri falhou: $($_.Exception.Message)" }
            if (Test-CapriTicketLogin ([string]$response.Content)) { throw 'A sessão do Capri expirou durante a pesquisa alternativa de chamados.' }
        }
        $expectedTotal = 0
        $totalMatch = [regex]::Match((Get-TicketPlainText ([string]$response.Content)), '(?i)\b\d+\s*-\s*\d+\s+(?:de|of)\s+(?<total>[\d\.]+)')
        if ($totalMatch.Success) { [void][int]::TryParse(($totalMatch.Groups['total'].Value -replace '\D', ''), [ref]$expectedTotal) }
        Write-Output '@@TICKET_PROGRESS@@30'
        $items = [System.Collections.Generic.List[object]]::new()
        $seen = [System.Collections.Generic.HashSet[string]]::new()
        $csvComplete = $false
        # A saída CSV do AgentTicketSearch não é limitada às 25 linhas da
        # grade. Ela é a rota principal para catálogos grandes; a navegação
        # HTML permanece como contingência para instalações sem exportação.
        if ([string]$request.scope -ne 'operator' -and !$previewOnly) { try {
            $csvBody = [ordered]@{}
            foreach ($entry in $body.GetEnumerator()) { $csvBody[$entry.Key] = $entry.Value }
            $csvBody['ResultForm'] = 'CSV'
            $csvResponse = Invoke-WebRequest -Uri "$origin/otrs/index.pl" -Method Post -Body $csvBody -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 180 -ErrorAction Stop
            $csvText = [string]$csvResponse.Content
            if ($csvText -and !(Test-CapriTicketLogin $csvText)) {
                $csvParts = @($csvText -split '\r?\n', 2)
                $firstLine = $csvParts[0]
                if ($firstLine -match '^sep=(?<delimiter>.)\s*$') {
                    $delimiter = [char]$matches.delimiter
                    $csvText = if ($csvParts.Count -gt 1) { $csvParts[1] } else { '' }
                } else {
                    $delimiter = if (($firstLine.ToCharArray() | Where-Object { $_ -eq ';' }).Count -gt ($firstLine.ToCharArray() | Where-Object { $_ -eq ',' }).Count) { ';' } else { ',' }
                }
                $csvRecords = @($csvText | ConvertFrom-Csv -Delimiter $delimiter)
                foreach ($record in $csvRecords) {
                    $number = Get-CapriCsvValue $record '(?i)^(?:CHAMADO|TICKET)(?:#|\s*(?:N[ÚU]MERO|NUMBER))?$'
                    if (!$number) { $number = Get-CapriCsvValue $record '(?i)(?:CHAMADO|TICKET).*(?:#|N[ÚU]MERO|NUMBER)' }
                    $numberMatch = [regex]::Match($number, '(?<!\d)(?<number>\d{6,20})(?!\d)')
                    if (!$numberMatch.Success) { continue }
                    $number = $numberMatch.Groups['number'].Value
                    if (!$seen.Add("N:$number")) { continue }
                    $title = Get-CapriCsvValue $record '(?i)^(?:T[ÍI]TULO|TITLE)$'
                    $state = Get-CapriCsvValue $record '(?i)^(?:ESTADO|SITUA[CÇ][ÃA]O|STATE)$'
                    $queue = Get-CapriCsvValue $record '(?i)^(?:FILA|QUEUE)$'
                    $owner = Get-CapriCsvValue $record '(?i)^(?:PROPRIET[ÁA]RIO|OWNER)$'
                    $responsible = Get-CapriCsvValue $record '(?i)^(?:RESPONS[ÁA]VEL|RESPONSIBLE)$'
                    $customer = Get-CapriCsvValue $record '(?i)(?:NOME DO USU[ÁA]RIO CLIENTE|CUSTOMER.*NAME)'
                    $created = Get-CapriCsvValue $record '(?i)^(?:CRIADO|CREATED|DATA DE CRIA[CÇ][ÃA]O)$'
                    $stateKind = Get-CapriStateKind $state
                    $items.Add([ordered]@{
                        id=$number; number=$number; title=$(if ($title) { $title } else { "Chamado $number" }); state=$(if ($state) { $state } else { 'Estado não identificado' }); state_kind=$stateKind
                        closed=($stateKind -like 'closed_*'); successful=($stateKind -eq 'closed_success'); queue=$queue; category=''; customer=$customer
                        creator=''; owner=$owner; responsible=$responsible; created=$created
                        changed=''; content=(Get-TicketPlainText (($record.PSObject.Properties.Value -join ' '))); url="$origin/otrs/index.pl?Action=AgentTicketSearch;Subaction=Search;TicketNumber=$number"
                    })
                }
                $csvComplete = ($expectedTotal -gt 0 -and $items.Count -ge $expectedTotal)
                if ($csvComplete) { Write-Output '@@TICKET_PROGRESS@@62' }
            }
        } catch {
            $items.Clear(); $seen.Clear()
        } }
        $visitedPageUrls = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        # A resposta inicial foi obtida por POST e não possui uma URL de página
        # reutilizável. As demais URLs descobertas são registradas antes da
        # consulta para impedir ciclos entre os controles 1, 2, 3, >> e >|.
        $pageQueue = [System.Collections.Generic.Queue[string]]::new()
        if (!$csvComplete) {
            $items.Clear(); $seen.Clear()
            $pageQueue.Enqueue([string]$response.Content)
        }
        $pageCount = 0
        $nextStartHit = 2
        $paginationMode = 'normal'
        while ($pageQueue.Count -gt 0 -and $pageCount -lt 500 -and (!$previewOnly -or $items.Count -lt $previewLimit)) {
          $resultHtml = $pageQueue.Dequeue()
          $pageCount++
          $itemsBeforePage = $items.Count
          $headers = @()
          $headerRow = [regex]::Match($resultHtml, '(?is)<tr\b[^>]*>(?<row>(?:(?!</tr>).)*<th\b.*?</tr>)')
          if ($headerRow.Success) {
              $headers = @([regex]::Matches($headerRow.Groups['row'].Value, '(?is)<th\b[^>]*>(?<cell>.*?)</th>') | ForEach-Object { (Get-TicketPlainText $_.Groups['cell'].Value).ToUpperInvariant() })
          }
          $numberColumn = Get-TicketColumnIndex $headers 'CHAMADO'
          $titleColumn = Get-TicketColumnIndex $headers '[TÍI]TULO'
          $stateColumn = Get-TicketColumnIndex $headers 'ESTADO'
          $queueColumn = Get-TicketColumnIndex $headers 'FILA'
          $ownerColumn = Get-TicketColumnIndex $headers 'PROPRIET'
          $responsibleColumn = Get-TicketColumnIndex $headers 'RESPONS'
          $customerColumn = Get-TicketColumnIndex $headers 'NOME DO USU.RIO CLIENTE'
          $createdColumn = Get-TicketColumnIndex $headers '^(CRIADO|CREATED|DATA DE CRIA)'
          $changedColumn = Get-TicketColumnIndex $headers '(ALTERADO|MODIFICADO|CHANGED|UPDATED)'
          foreach ($rowMatch in [regex]::Matches($resultHtml, '(?is)<tr\b[^>]*>(?<row>.*?)</tr>')) {
            $row = [string]$rowMatch.Groups['row'].Value
            $zoom = $null
            $ticketLink = $null
            foreach ($anchorCandidate in [regex]::Matches($row, '(?is)<a\b(?<attrs>[^>]*)>(?<title>.*?)</a>')) {
                $candidateLink = [regex]::Match($anchorCandidate.Groups['attrs'].Value, '(?is)\bhref=["''](?<href>[^"'']*Action=AgentTicketZoom[^"'']*TicketID=(?<id>\d+)[^"'']*)["'']')
                if ($candidateLink.Success) {
                    $zoom = $anchorCandidate
                    $ticketLink = $candidateLink
                    break
                }
            }
            if (!$zoom -or !$ticketLink) { continue }
            $ticketId = $ticketLink.Groups['id'].Value
            $rowText = Get-TicketPlainText $row
            $title = (Get-TicketPlainText $zoom.Groups['title'].Value) -replace '^\s*\d+\s*[-–—:]?\s*', ''
            $anchorTitle = [regex]::Match($zoom.Groups['attrs'].Value, '(?is)\btitle=["''](?<value>.*?)["'']')
            if ($anchorTitle.Success) { $title = Get-TicketPlainText $anchorTitle.Groups['value'].Value }
            $numberMatch = [regex]::Match($rowText, '(?<!\d)(?<number>\d{6,20})(?!\d)')
            $number = if ($numberMatch.Success) { $numberMatch.Groups['number'].Value } else { $ticketId }
            $stateMatch = [regex]::Match($rowText, '(?i)\b(?<state>closed successful|closed unsuccessful|pending[^|•;]*|open|new|fechado com êxito|fechado sem êxito|pendente|aberto|novo)\b')
            $state = if ($stateMatch.Success) { $stateMatch.Groups['state'].Value } else { 'Estado não identificado' }
            $href = [Net.WebUtility]::HtmlDecode($ticketLink.Groups['href'].Value)
            try { $absolute = ([uri]::new([uri]$origin, $href)).AbsoluteUri } catch { $absolute = "$origin/otrs/index.pl?Action=AgentTicketZoom;TicketID=$ticketId" }
            $cells = @([regex]::Matches($row, '(?is)<td\b[^>]*>(?<cell>.*?)</td>') | ForEach-Object { Get-TicketPlainText $_.Groups['cell'].Value })
            if ($numberColumn -ge 0 -and $numberColumn -lt $cells.Count) {
                $publishedNumber = [regex]::Match([string]$cells[$numberColumn], '(?<!\d)(?<number>\d{6,20})(?!\d)')
                if ($publishedNumber.Success) { $number = $publishedNumber.Groups['number'].Value }
            }
            if (!$anchorTitle.Success -and $titleColumn -ge 0 -and $titleColumn -lt $cells.Count -and $cells[$titleColumn]) { $title = [string]$cells[$titleColumn] }
            if ($stateColumn -ge 0 -and $stateColumn -lt $cells.Count -and $cells[$stateColumn]) { $state = [string]$cells[$stateColumn] }
            $queue = if ($queueColumn -ge 0 -and $queueColumn -lt $cells.Count) { [string]$cells[$queueColumn] } else { '' }
            $owner = if ($ownerColumn -ge 0 -and $ownerColumn -lt $cells.Count) { [string]$cells[$ownerColumn] } else { '' }
            $responsible = if ($responsibleColumn -ge 0 -and $responsibleColumn -lt $cells.Count) { [string]$cells[$responsibleColumn] } else { '' }
            $customer = if ($customerColumn -ge 0 -and $customerColumn -lt $cells.Count) { [string]$cells[$customerColumn] } else { '' }
            if ($previewOnly) {
                # Inclui somente o usuário cliente exato ou um título que
                # contenha o nome integral confirmado pelo Active Directory.
                $targetName = Get-NormalizedPersonName $resolvedDisplayName
                $customerMatches = $targetName -and (Get-NormalizedPersonName $customer) -eq $targetName
                $titleMatches = $targetName -and (Get-NormalizedPersonName $title).Contains($targetName)
                # A coluna da grade pode truncar o valor ou não corresponder
                # ao índice do cabeçalho nesta versão do Capri. O Fulltext já
                # restringiu os resultados; a linha inteira cobre esses casos.
                $rowNameMatches = $targetName -and (Get-NormalizedPersonName $rowText).Contains($targetName)
                if (!$targetName -or (!$customerMatches -and !$titleMatches -and !$rowNameMatches)) { continue }
            }
            if (!$seen.Add($ticketId)) { continue }
            $createdValue = if ($createdColumn -ge 0 -and $createdColumn -lt $cells.Count) { [string]$cells[$createdColumn] } else { '' }
            $changedValue = if ($changedColumn -ge 0 -and $changedColumn -lt $cells.Count) { [string]$cells[$changedColumn] } else { '' }
            $closed = $state -match '(?i)closed|fechado'
            $successful = $state -match '(?i)successful|com êxito|sucesso' -and $state -notmatch '(?i)unsuccessful|sem êxito'
            $stateKind = Get-CapriStateKind $state
            $items.Add([ordered]@{
                id=$ticketId; number=$number; title=$(if ($title) { $title } else { "Chamado $number" }); state=$state; state_kind=$stateKind
                closed=$closed; successful=$successful; queue=$queue; category=''; customer=$customer
                creator=''; owner=$owner; responsible=$responsible; created=$createdValue
                changed=$changedValue; state_since=$changedValue; content=$rowText; url=$absolute
            })
          }
          # O Capri entrega 25 registros por página e, nesta instalação, os
          # controles seguintes são montados por JavaScript. Reenvia a mesma
          # pesquisa com StartHit até não surgir nenhum TicketID novo.
            $newItems = $items.Count - $itemsBeforePage
          if ($previewOnly -and $items.Count -ge $previewLimit) {
              Write-Output '@@TICKET_PROGRESS@@94'
              break
          }
          if ($expectedTotal -gt 0) {
              $collectionProgress = 30 + [Math]::Min(32, [Math]::Floor(($items.Count * 32.0) / $expectedTotal))
              Write-Output ("@@TICKET_PROGRESS@@" + $collectionProgress)
          }
          $requestNextPage = $false
          foreach ($linkedPageUrl in (Get-CapriTicketPageUrls $resultHtml)) {
              if (!$visitedPageUrls.Add($linkedPageUrl)) { continue }
              try {
                  $linkedResponse = Invoke-WebRequest -Uri $linkedPageUrl -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 60 -ErrorAction Stop
                  if (!(Test-CapriTicketLogin ([string]$linkedResponse.Content))) { $pageQueue.Enqueue([string]$linkedResponse.Content) }
              } catch { throw "A página de chamados '$linkedPageUrl' não pôde ser consultada: $($_.Exception.Message)" }
          }
          if ($pageQueue.Count -gt 0) {
              $requestNextPage = $false
          } elseif ($paginationMode -eq 'normal' -and $newItems -ge 25) {
              # A saída de impressão do OTRS normalmente ignora a paginação
              # visual e devolve todo o conjunto encontrado.
              $paginationMode = 'print'
              $requestNextPage = $true
          } elseif ($paginationMode -eq 'print' -and $newItems -eq 0) {
              $paginationMode = 'page'
              $nextStartHit = 2
              $requestNextPage = $true
          } elseif ($paginationMode -eq 'print') {
              # A página de impressão já representa o conjunto completo.
              $requestNextPage = $false
          } elseif ($paginationMode -eq 'page' -and $newItems -eq 0 -and $nextStartHit -eq 2) {
              # Compatibilidade com instalações que tratam StartHit como
              # deslocamento absoluto em vez de número da página.
              $paginationMode = 'offset'
              $nextStartHit = 26
              $requestNextPage = $true
          } elseif ($newItems -ge 25) {
              $nextStartHit = if ($paginationMode -eq 'offset') { $nextStartHit + 25 } else { $nextStartHit + 1 }
              $requestNextPage = $true
          }
          if ($requestNextPage) {
              $pageBody = [ordered]@{}
              foreach ($entry in $body.GetEnumerator()) { $pageBody[$entry.Key] = $entry.Value }
              if ($paginationMode -eq 'print') {
                  $pageBody['ResultForm'] = 'Print'
                  $pageBody.Remove('StartHit')
              } else {
                  $pageBody['ResultForm'] = 'Normal'
                  $pageBody['StartHit'] = [string]$nextStartHit
              }
              try {
                  $pageResponse = Invoke-WebRequest -Uri "$origin/otrs/index.pl" -Method Post -Body $pageBody -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 60 -ErrorAction Stop
                  if (Test-CapriTicketLogin ([string]$pageResponse.Content)) { throw 'A sessão do Capri expirou durante a paginação.' }
                  $pageQueue.Enqueue([string]$pageResponse.Content)
              } catch { throw "A paginação dos chamados falhou após $($items.Count) registros: $($_.Exception.Message)" }
          }
        }
        $receivedCount = $items.Count
        if (!$previewOnly -and $expectedTotal -gt 0 -and $receivedCount -lt $expectedTotal) {
            throw "O Capri informou $expectedTotal chamados, mas somente $($items.Count) foram recebidos após $pageCount página(s). O catálogo anterior foi preservado; a coleta incompleta não será salva."
        }
        if (!$previewOnly -and $expectedTotal -eq 0 -and $receivedCount -ge 25) {
            throw "O Capri não informou o total da pesquisa e devolveu $($items.Count) registros. O catálogo anterior foi preservado porque não foi possível confirmar a coleta integral."
        }
        if ([string]$request.scope -eq 'operator') {
            # Antes de abrir os detalhes, reduz o conjunto pela coluna Criado.
            # Registros sem data permanecem para conferência segura no detalhe.
            if ($requestedFrom -or $requestedTo) {
                $periodItems = [System.Collections.Generic.List[object]]::new()
                foreach ($ticket in @($items)) {
                    $listedDate = Convert-CapriTicketDate ([string]$ticket.created)
                    if (!$listedDate -or ((!$requestedFrom -or $listedDate -ge $requestedFrom.Date) -and (!$requestedTo -or $listedDate -le $requestedTo))) {
                        $periodItems.Add($ticket)
                    }
                }
                $items = $periodItems
            }
            if ($cachedNumbers.Count -gt 0 -and ![bool]$request.refresh_existing) {
                $unmappedItems = [System.Collections.Generic.List[object]]::new()
                $reusedCount = 0
                foreach ($ticket in @($items)) {
                    $ticketValue = if ($ticket.number) { $ticket.number } else { $ticket.id }
                    $ticketNumber = ([string]$ticketValue -replace '\D', '')
                    if ($ticketNumber -and $cachedNumbers.Contains($ticketNumber)) {
                        $reusedCount++
                    } else {
                        $unmappedItems.Add($ticket)
                    }
                }
                $items = $unmappedItems
                Write-Output "[CHAMADOS] Cache incremental: $reusedCount chamado(s) já mapeado(s) foram ignorados; $($items.Count) novo(s) candidato(s)."
            }
            $candidateCount = $items.Count
            Write-Output '@@TICKET_PROGRESS@@65'
            Write-Output "[CHAMADOS] Período aplicado: $candidateCount candidato(s) entre $($request.date_from) e $($request.date_to)."
            $targetCreator = Get-NormalizedPersonName $displayName
            $confirmedItems = [System.Collections.Generic.List[object]]::new()
            $checked = 0
            foreach ($ticket in @($items)) {
                $checked++
                $identity = Get-CapriTicketIdentity ([string]$ticket.url)
                $creator = [string]$identity.creator
                if (!$creator) { throw "O campo 'Criado por' não pôde ser lido no chamado $($ticket.number). O catálogo anterior foi preservado." }
                $ticket.creator = $creator
                if ([string]$identity.created) { $ticket.created = [string]$identity.created }
                $createdDate = Convert-CapriTicketDate ([string]$ticket.created)
                if (($requestedFrom -or $requestedTo) -and !$createdDate) {
                    throw "A data de criação do chamado $($ticket.number) não pôde ser confirmada. O catálogo anterior foi preservado para não incluir registros fora do período."
                }
                $insidePeriod = (!$requestedFrom -or $createdDate -ge $requestedFrom.Date) -and (!$requestedTo -or $createdDate -le $requestedTo)
                if ($insidePeriod -and (Get-NormalizedPersonName $creator) -eq $targetCreator) { $confirmedItems.Add($ticket) }
                if (($checked % 25) -eq 0 -or $checked -eq $candidateCount) {
                    Write-Output "[CHAMADOS] Conferindo Criado por: $checked de $candidateCount; $($confirmedItems.Count) confirmado(s)."
                    if ($candidateCount -gt 0) {
                        $identityProgress = 65 + [Math]::Min(32, [Math]::Floor(($checked * 32.0) / $candidateCount))
                        Write-Output ("@@TICKET_PROGRESS@@" + $identityProgress)
                    }
                }
            }
            $items = $confirmedItems
        } else {
            $candidateCount = $items.Count
        }
        foreach ($ticket in @($items)) {
            $ticket | Add-Member -NotePropertyName query_subject -NotePropertyValue $(if ([string]$request.scope -eq 'operator') { $displayName } else { $resolvedLogin }) -Force
            $ticket | Add-Member -NotePropertyName query_display_name -NotePropertyValue $resolvedDisplayName -Force
            $ticket | Add-Member -NotePropertyName query_scope -NotePropertyValue ([string]$request.scope) -Force
        }
        $stateUpdates = [System.Collections.Generic.List[object]]::new()
        $stateRecheckFailed = [System.Collections.Generic.List[string]]::new()
        $numbersToRecheck = @()
        if (!$previewOnly -and [bool]$request.refresh_existing) {
            $numbersToRecheck = @($request.recheck_numbers | Where-Object { [string]$_ -match '^\d{6,20}$' } | Select-Object -Unique)
            $checkedStateCount = 0
            foreach ($numberToCheck in $numbersToRecheck) {
                $checkedStateCount++
                try {
                    $currentState = Get-CapriTicketStateByNumber ([string]$numberToCheck)
                    if ($currentState) { $stateUpdates.Add($currentState) }
                    else {
                        $stateRecheckFailed.Add([string]$numberToCheck)
                        Write-Output "[CHAMADOS] Estado de $numberToCheck não confirmado no Capri; cache preservado."
                    }
                } catch {
                    $stateRecheckFailed.Add([string]$numberToCheck)
                    Write-Output "[CHAMADOS] Estado de $numberToCheck não confirmado: $($_.Exception.Message)"
                }
                if (($checkedStateCount % 10) -eq 0 -or $checkedStateCount -eq $numbersToRecheck.Count) {
                    Write-Output "[CHAMADOS] Estados antigos: $checkedStateCount de $($numbersToRecheck.Count) conferidos; $($stateRecheckFailed.Count) sem confirmação."
                    Write-Output ("@@TICKET_PROGRESS@@" + (97 + [Math]::Floor($checkedStateCount * 2.0 / $numbersToRecheck.Count)))
                }
            }
        }
        if ($previewOnly) {
            $items = @($items | Sort-Object -Property @{
                Expression = { Get-CapriPreviewSortDate $_ }; Descending = $true
            }, @{
                Expression = { [string]$_.number }; Descending = $true
            } | Select-Object -First $previewLimit)
        }
        $isComplete = if ($previewOnly) { $true } else { ($expectedTotal -eq 0 -and $receivedCount -lt 25) -or ($expectedTotal -gt 0 -and $receivedCount -ge $expectedTotal) }
        $data = [ordered]@{ schema_version=4; source=$searchUrl; preview_only=$previewOnly; result_limit=$(if ($previewOnly) { $previewLimit } else { 0 }); sort_order=$(if ($previewOnly) { 'recent' } else { 'default' }); filter_field=$(if ([string]$request.scope -eq 'operator') { 'Criado por + período de criação' } elseif ($previewOnly) { 'Nome do usuário cliente igual ao AD ou título contendo o nome completo' } else { 'Usuário cliente por nome, sobrenome ou login' }); requested_subject=$displayName; subject=$(if ([string]$request.scope -eq 'operator' -or $previewOnly) { $displayName } else { $resolvedLogin }); display_name=$resolvedDisplayName; scope=[string]$request.scope; date_from=[string]$request.date_from; date_to=[string]$request.date_to; expected_count=$expectedTotal; source_count=$receivedCount; scanned_count=$candidateCount; complete=$isComplete; page_count=$pageCount; count=$items.Count; updated_at=(Get-Date).ToString('s'); items=@($items); state_updates=@($stateUpdates); recheck_failed=@($stateRecheckFailed); state_recheck_total=$numbersToRecheck.Count }
        Save-CapriWebSession $webSession
        Write-Output '@@TICKET_PROGRESS@@99'
        Write-Output ('@@TICKETS@@' + ($data | ConvertTo-Json -Depth 6 -Compress))
        if ($previewOnly) {
            Write-Output "$($items.Count) chamado(s) recente(s) preparado(s) para visualização temporária; nenhum catálogo local foi alterado."
        } else {
            Write-Output "$($items.Count) chamado(s) foram estruturados e entregues ao cache local."
        }
    }
    "faq_catalog" {
        $faqRequest = @{}
        if ($Value) { try { $faqRequest = $Value | ConvertFrom-Json -ErrorAction Stop } catch { $faqRequest = @{} } }
        $cachedFaqUrls = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        $cachedFaqIds = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        $faqCachePath = [string]$faqRequest.cache_path
        if (!$faqCachePath) { $faqCachePath = Join-Path $env:LOCALAPPDATA 'AtlasSuporteAvancado\cache\faq_catalog.json' }
        if (Test-Path -LiteralPath $faqCachePath) {
            try {
                $savedFaqCatalog = Get-Content -LiteralPath $faqCachePath -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
                if ([bool]$savedFaqCatalog.items) {
                    foreach ($savedFaq in @($savedFaqCatalog.items)) {
                        $savedFaqId = ([string]$savedFaq.id -replace '\D', '')
                        if ($savedFaqId) { [void]$cachedFaqIds.Add($savedFaqId) }
                        if ($savedFaq.url) {
                            $savedUrl = ([string]$savedFaq.url -replace '(?i);(?:Nav|SessionID)=[^;]+', '')
                            [void]$cachedFaqUrls.Add($savedUrl)
                        }
                    }
                }
            } catch { Write-Output '[FAQ] Cache anterior não pôde ser lido; novas FAQs serão coletadas normalmente.' }
        }
        $rootUrl = 'https://capri.senado.leg.br/otrs/index.pl?Action=AgentFAQExplorer;CategoryID=21;Nav='
        $origin = 'https://capri.senado.leg.br'
        $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
        [void](Restore-CapriWebSession $webSession)
        function Test-CapriLoginPage([string]$Html) {
            if ([string]::IsNullOrWhiteSpace($Html)) { return $true }
            return ($Html -match '(?is)<form[^>]+(?:Action=["'']?Login|id=["''][^"'']*Login)' -or
                    $Html -match '(?is)<input[^>]+name=["''](?:User|Password)["'']' -or
                    $Html -match '(?i)(?:UserLogin|LoginBox|ChallengeToken).{0,500}(?:Password|Anmelden|Entrar)')
        }
        function Invoke-CapriGet([string]$Url) {
            Invoke-WebRequest -Uri $Url -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 30 -ErrorAction Stop
        }
        function Resolve-CapriFaqTitle([string]$Url, [string]$FaqId, [string]$Candidate) {
            $candidateTitle = ([Net.WebUtility]::HtmlDecode([string]$Candidate) -replace '\s+', ' ').Trim()
            $candidateTitle = ($candidateTitle -replace "(?i)^FAQ#?\s*:?\s*$([regex]::Escape($FaqId))\s*(?:[-–—:]\s*)?", '').Trim()
            if ($candidateTitle -and $candidateTitle -notmatch '^\d+$') { return $candidateTitle }
            try {
                $detailResponse = Invoke-CapriGet $Url
                $detailHtml = [string]$detailResponse.Content
                if (Test-CapriLoginPage $detailHtml) { return "FAQ $FaqId" }
                $patterns = @(
                    "(?is)FAQ#?\s*:?\s*$([regex]::Escape($FaqId))\s*(?:&mdash;|&#8212;|—|–|-)\s*(?<title>[^<\r\n]+)",
                    '(?is)<title[^>]*>(?<title>.*?)</title>',
                    '(?is)<h[1-3][^>]*>(?<title>.*?)</h[1-3]>'
                )
                foreach ($pattern in $patterns) {
                    $match = [regex]::Match($detailHtml, $pattern)
                    if (!$match.Success) { continue }
                    $resolved = ([Net.WebUtility]::HtmlDecode(($match.Groups['title'].Value -replace '(?is)<[^>]+>', ' ')) -replace '\s+', ' ').Trim()
                    $resolved = ($resolved -replace "(?i)^FAQ#?\s*:?\s*$([regex]::Escape($FaqId))\s*(?:[-–—:]\s*)?", '').Trim()
                    if ($resolved -and $resolved -notmatch '^\d+$|^(FAQ|Capri|OTRS)$') { return $resolved }
                }
            } catch {}
            return "FAQ $FaqId"
        }
        function Resolve-CapriPublishedFaqId([string]$Url, [string]$ItemId, [string]$Candidate) {
            # ItemID é uma chave interna e não permite inferir o número público.
            # Usa exclusivamente o número que o Capri realmente publica.
            $candidateMatch = [regex]::Match([Net.WebUtility]::HtmlDecode([string]$Candidate), '(?i)FAQ#?\s*:?\s*(?<id>\d+)')
            if ($candidateMatch.Success) { return $candidateMatch.Groups['id'].Value }
            try {
                $detail = Invoke-CapriGet $Url
                if (!(Test-CapriLoginPage ([string]$detail.Content))) {
                    $detailMatch = [regex]::Match([string]$detail.Content, '(?i)FAQ#?\s*:?\s*(?<id>\d+)')
                    if ($detailMatch.Success) { return $detailMatch.Groups['id'].Value }
                }
            } catch {}
            return $ItemId
        }
        try {
            $firstResponse = Invoke-CapriGet $rootUrl
        } catch {
            throw "Não foi possível acessar o Capri: $($_.Exception.Message)"
        }
        if (Test-CapriLoginPage ([string]$firstResponse.Content)) {
            $capriUser = Get-AtlasCredentialText 'GERENCIADOR_CAPRI_USER_B64' 'GERENCIADOR_CAPRI_USER'
            $capriPassword = Get-AtlasCredentialText 'GERENCIADOR_CAPRI_PASSWORD_B64' 'GERENCIADOR_CAPRI_PASSWORD'
            if ([string]::IsNullOrWhiteSpace($capriUser) -or [string]::IsNullOrWhiteSpace($capriPassword)) {
                throw 'O Capri solicitou autenticação. Clique no cadeado da área FAQ e informe sua conta do Capri.'
            }
            $challenge = ''
            $challengeMatch = [regex]::Match([string]$firstResponse.Content, '(?is)<input[^>]+name=["'']ChallengeToken["''][^>]+value=["''](?<value>[^"'']*)')
            if (!$challengeMatch.Success) {
                $challengeMatch = [regex]::Match([string]$firstResponse.Content, '(?is)<input[^>]+value=["''](?<value>[^"'']*)["''][^>]+name=["'']ChallengeToken["'']')
            }
            if ($challengeMatch.Success) { $challenge = [Net.WebUtility]::HtmlDecode($challengeMatch.Groups['value'].Value) }
            $loginBody = @{
                Action = 'Login'
                RequestedURL = 'Action=AgentFAQExplorer;CategoryID=21;Nav='
                User = $capriUser
                Password = $capriPassword
            }
            if ($challenge) { $loginBody['ChallengeToken'] = $challenge }
            try {
                $null = Invoke-WebRequest -Uri "$origin/otrs/index.pl" -Method Post -Body $loginBody -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 30 -ErrorAction Stop
                $firstResponse = Invoke-CapriGet $rootUrl
            } catch {
                throw "A autenticação do Capri não foi concluída: $($_.Exception.Message)"
            } finally {
                Remove-Item Env:GERENCIADOR_CAPRI_PASSWORD, Env:GERENCIADOR_CAPRI_PASSWORD_B64 -ErrorAction SilentlyContinue
            }
            if (Test-CapriLoginPage ([string]$firstResponse.Content)) {
                throw 'O Capri recusou a autenticação. Confira o usuário e a senha pelo cadeado da área FAQ.'
            }
        }
        Save-CapriWebSession $webSession
        $queue = [System.Collections.Generic.Queue[object]]::new()
        $queue.Enqueue([PSCustomObject]@{ Url = $rootUrl; Path = 'Capri' })
        $visited = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        $faqIds = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        $items = [System.Collections.Generic.List[object]]::new()
        $cachedOnResult = 0
        $cachedResultUrls = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        $pageSignatures = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        $pageCount = 0
        $expectedTotal = 0
        while ($queue.Count -gt 0 -and $pageCount -lt 4000) {
            $node = $queue.Dequeue()
            $categoryKeyMatch = [regex]::Match([string]$node.Url, '(?i)(?:[?;&]|^)CategoryID=(?<id>\d+)')
            $pageKeyMatch = [regex]::Match([string]$node.Url, '(?i)(?:[?;&]|^)(?:StartHit|Page|PageNumber)=(?<page>\d+)')
            $categoryKey = if ($categoryKeyMatch.Success) { $categoryKeyMatch.Groups['id'].Value } else { [string]$node.Url }
            $pageKey = if ($pageKeyMatch.Success) { $pageKeyMatch.Groups['page'].Value } else { '1' }
            # Nav, SortBy e Order geram URLs diferentes para a mesma página.
            # A chave canônica impede ciclos sem bloquear a paginação real.
            if (!$visited.Add("$categoryKey|$pageKey")) { continue }
            $pageCount++
            try {
                $response = if ($pageCount -eq 1) { $firstResponse } else { Invoke-CapriGet ([string]$node.Url) }
            } catch {
                if ($pageCount -eq 1) { throw "Não foi possível autenticar ou acessar o Capri: $($_.Exception.Message)" }
                continue
            }
            $html = [string]$response.Content
            if (Test-CapriLoginPage $html) {
                throw 'A sessão do Capri expirou durante a leitura. Clique no cadeado da área FAQ para autenticar novamente.'
            }
            if ($pageCount -eq 1) {
                foreach ($rootRow in [regex]::Matches($html, '(?is)<tr\b[^>]*>(?<row>.*?)</tr>')) {
                    $rootHtml = $rootRow.Groups['row'].Value
                    if ($rootHtml -notmatch 'AgentFAQExplorer') { continue }
                    $rootCells = [regex]::Matches($rootHtml, '(?is)<td\b[^>]*>(?<cell>.*?)</td>')
                    if ($rootCells.Count -lt 2) { continue }
                    $lastCell = ([Net.WebUtility]::HtmlDecode(($rootCells[$rootCells.Count - 1].Groups['cell'].Value -replace '(?is)<[^>]+>', ' ')) -replace '\s+', '').Trim()
                    if ($lastCell -match '^\d+$') { $expectedTotal += [int]$lastCell }
                }
            }
            # Algumas instalações ignoram StartHit e devolvem sempre a mesma
            # página. Registra uma assinatura dos links visíveis para impedir
            # que a paginação entre em ciclo.
            $pageSignature = (([regex]::Matches($html, '(?i)(?:ItemID|FAQID)=\d+') | ForEach-Object { $_.Value }) -join '|')
            if ($pageSignature -and !$pageSignatures.Add($pageSignature)) {
                continue
            }
            $pageLinks = @()
            # O nome oficial está na primeira célula das linhas de subcategoria.
            # Essas linhas têm prioridade sobre links técnicos sem texto.
            $pageLinks += @([regex]::Matches($html, '(?is)<tr\b[^>]*>(?<row>.*?)</tr>') | ForEach-Object {
                $rowHtml = $_.Groups['row'].Value
                $categoryLink = [regex]::Match($rowHtml, '(?is)<a\b[^>]*href\s*=\s*["''](?<href>[^"'']*AgentFAQExplorer[^"'']*)["''][^>]*>')
                if ($categoryLink.Success) {
                    $cells = [regex]::Matches($rowHtml, '(?is)<td\b[^>]*>(?<cell>.*?)</td>')
                    $categoryText = ''
                    if ($cells.Count -gt 0) {
                        $categoryText = ([Net.WebUtility]::HtmlDecode(($cells[0].Groups['cell'].Value -replace '(?is)<[^>]+>', ' ')) -replace '\s+', ' ').Trim()
                    }
                    [PSCustomObject]@{ href = $categoryLink.Groups['href'].Value; innerText = $categoryText }
                }
            })
            # Em alguns temas do Capri o link do artigo é apenas um ícone.
            # Usa o texto completo da célula/linha para obter o título real.
            $pageLinks += @([regex]::Matches($html, '(?is)<tr\b[^>]*>(?<row>.*?)</tr>') | ForEach-Object {
                $rowHtml = $_.Groups['row'].Value
                $faqLink = [regex]::Match($rowHtml, '(?is)<a\b[^>]*href\s*=\s*["''](?<href>[^"'']*AgentFAQZoom[^"'']*)["''][^>]*>')
                if ($faqLink.Success) {
                    $titleText = ''
                    $rowCells = [regex]::Matches($rowHtml, '(?is)<td\b[^>]*>(?<cell>.*?)</td>')
                    foreach ($cell in $rowCells) {
                        if ($cell.Groups['cell'].Value -match 'AgentFAQZoom') {
                            $titleText = ([Net.WebUtility]::HtmlDecode(($cell.Groups['cell'].Value -replace '(?is)<[^>]+>', ' ')) -replace '\s+', ' ').Trim()
                            if ($titleText) { break }
                        }
                    }
                    if ($titleText -match '^(?i:FAQ#?\s*:?)?\s*\d+\s*$') { $titleText = '' }
                    if ([string]::IsNullOrWhiteSpace($titleText)) {
                        foreach ($cell in $rowCells) {
                            $candidate = ([Net.WebUtility]::HtmlDecode(($cell.Groups['cell'].Value -replace '(?is)<[^>]+>', ' ')) -replace '\s+', ' ').Trim()
                            if ($candidate -and $candidate -notmatch '^\d+$|^(pt|en|de|fr|v[aá]lido|inv[aá]lido|publicado)$') {
                                $titleText = $candidate
                                break
                            }
                        }
                    }
                    [PSCustomObject]@{ href = $faqLink.Groups['href'].Value; innerText = $titleText }
                }
            })
            # Depois vêm os anchors visíveis, que preservam títulos de artigos.
            $pageLinks += @([regex]::Matches($html, '(?is)<a\b[^>]*href\s*=\s*["''](?<href>[^"'']+)["''][^>]*>(?<text>.*?)</a>') | ForEach-Object {
                [PSCustomObject]@{
                    href = $_.Groups['href'].Value
                    innerText = ($_.Groups['text'].Value -replace '(?is)<[^>]+>', ' ')
                }
            })
            $pageLinks += @($response.Links)
            $pageLinks += @([regex]::Matches($html, '(?is)(?:data-url|value|data-href)\s*=\s*["''](?<href>[^"'']*(?:AgentFAQExplorer|AgentFAQZoom)[^"'']*)["'']') | ForEach-Object {
                [PSCustomObject]@{ href = $_.Groups['href'].Value; innerText = '' }
            })
            # Algumas versões do OTRS guardam a navegação em JavaScript/JSON,
            # sem href. Captura também qualquer URL citada no HTML.
            $pageLinks += @([regex]::Matches($html, '(?is)(?<href>(?:https?://capri\.senado\.leg\.br)?/?otrs/index\.pl\?[^"''<>\s]*(?:AgentFAQExplorer|AgentFAQZoom)[^"''<>\s]*)') | ForEach-Object {
                [PSCustomObject]@{ href = $_.Groups['href'].Value; innerText = '' }
            })
            $newFaqsOnPage = 0
            $faqLinksOnPage = 0
            $cachedBeforePage = $cachedOnResult
            foreach ($link in $pageLinks) {
                $href = [Net.WebUtility]::HtmlDecode([string]$link.href)
                if ([string]::IsNullOrWhiteSpace($href)) { continue }
                try { $href = [uri]::UnescapeDataString($href) } catch {}
                try { $absolute = ([uri]::new([uri]$origin, $href)).AbsoluteUri } catch { continue }
                if ($absolute -notlike "$origin/*") { continue }
                $text = ([Net.WebUtility]::HtmlDecode([string]$link.innerText) -replace '\s+', ' ').Trim()
                $categoryMatch = [regex]::Match($href, '(?i)(?:[?;&]|^)CategoryID=(?<id>\d+)')
                if ($href -match '(?i)(?:[?;&]|^)Action=AgentFAQExplorer(?:[;&]|$)' -and $categoryMatch.Success) {
                    $categoryId = $categoryMatch.Groups['id'].Value
                    if ($categoryId -eq $categoryKey) {
                        # Link de paginação/ordenação da categoria atual:
                        # mantém o caminho, sem criar falsos nós "2", "3" etc.
                        $queue.Enqueue([PSCustomObject]@{ Url = $absolute; Path = [string]$node.Path })
                    } elseif ($categoryId -ne '21') {
                        $categoryName = if ($text) { $text } else { "Categoria $categoryId" }
                        $queue.Enqueue([PSCustomObject]@{ Url = $absolute; Path = "$($node.Path) > $categoryName" })
                    }
                    continue
                }
                $faqMatch = [regex]::Match($href, '(?i)(?:[?;&]|^)(?:ItemID|FAQID)=(?<id>\d+)')
                if ($href -notmatch '(?i)(?:[?;&]|^)Action=AgentFAQZoom(?:[;&]|$)' -or !$faqMatch.Success) { continue }
                $faqId = $faqMatch.Groups['id'].Value
                $faqLinksOnPage++
                $canonicalFaqUrl = ($absolute -replace '(?i);(?:Nav|SessionID)=[^;]+', '')
                if ($cachedFaqUrls.Contains($canonicalFaqUrl)) {
                    if ($cachedResultUrls.Add($canonicalFaqUrl)) { $cachedOnResult++ }
                    continue
                }
                $officialFaqId = Resolve-CapriPublishedFaqId -Url $absolute -ItemId $faqId -Candidate $text
                if (!$faqIds.Add($faqId)) { continue }
                $newFaqsOnPage++
                $title = Resolve-CapriFaqTitle -Url $absolute -FaqId $officialFaqId -Candidate $text
                $categoryPath = ([string]$node.Path -replace '^Capri\s*>\s*', '').Trim()
                if ([string]::IsNullOrWhiteSpace($categoryPath) -or $categoryPath -eq 'Capri') {
                    $categoryPath = 'CENTRAL DE ATENDIMENTO'
                }
                $classification = Get-FaqClassification "$title $categoryPath"
                $items.Add([ordered]@{
                    id = $officialFaqId
                    title = $title
                    tool = [string]$classification.Tool
                    procedure = [string]$classification.Procedure
                    knowledge_category = [string]$classification.Category
                    knowledge_subcategory = [string]$classification.Subcategory
                    knowledge_procedure = [string]$classification.Procedure
                    original_category = $categoryPath
                    category_parts = @($categoryPath -split '\s*>\s*')
                    url = $absolute
                })
            }
            # Nem todo tema do OTRS inclui os links de paginação no HTML.
            # Enquanto uma página trouxer artigos inéditos, tenta a próxima.
            $cachedFaqsOnPage = $cachedOnResult - $cachedBeforePage
            if ($faqLinksOnPage -gt 0 -and ($newFaqsOnPage -gt 0 -or $cachedFaqsOnPage -gt 0) -and $categoryKeyMatch.Success) {
                $currentPage = 1
                if ($pageKeyMatch.Success) { $currentPage = [int]$pageKeyMatch.Groups['page'].Value }
                $nextPage = $currentPage + 1
                $nextUrl = [string]$node.Url
                if ($nextUrl -match '(?i)([;&])(?:StartHit|Page|PageNumber)=\d+') {
                    $nextUrl = $nextUrl -replace '(?i)([;&])(?:StartHit|Page|PageNumber)=\d+', "`${1}StartHit=$nextPage"
                } else {
                    $nextUrl = "$nextUrl;StartHit=$nextPage"
                }
                $queue.Enqueue([PSCustomObject]@{ Url = $nextUrl; Path = [string]$node.Path })
            }
            if ($expectedTotal -gt 0) {
                $processedTotal = $items.Count + $cachedOnResult
                $progressPercent = [Math]::Min(99, [Math]::Floor(($processedTotal * 100.0) / $expectedTotal))
                Write-Output ("@@FAQ_PROGRESS@@{0}" -f $progressPercent)
            }
        }
        if ($queue.Count -gt 0) {
            throw 'A árvore do Capri ultrapassou o limite ampliado de 4.000 páginas. A coleta foi interrompida para evitar um ciclo de navegação.'
        }
        if ($pageCount -le 1 -and $items.Count -eq 0) {
            $titleMatch = [regex]::Match([string]$firstResponse.Content, '(?is)<title[^>]*>(?<title>.*?)</title>')
            $pageTitle = if ($titleMatch.Success) { ($titleMatch.Groups['title'].Value -replace '\s+', ' ').Trim() } else { 'sem título identificado' }
            throw "O Capri respondeu, mas não devolveu categorias nem FAQs. Página recebida: $pageTitle. Atualize a autenticação pelo cadeado e tente novamente."
        }
        $ordered = @($items | Sort-Object original_category, title)
        $data = [ordered]@{
            source = $rootUrl
            count = $ordered.Count
            expected_count = $expectedTotal
            complete = ($expectedTotal -eq 0 -or ($ordered.Count + $cachedOnResult) -ge $expectedTotal)
            categories_scanned = $pageCount
            updated_at = (Get-Date).ToString('s')
            items = $ordered
            new_count = $ordered.Count
            cached_count = $cachedOnResult
        }
        Save-CapriWebSession $webSession
        Write-Output ('@@FAQS@@' + ($data | ConvertTo-Json -Depth 6 -Compress))
        Write-Output "$($ordered.Count) FAQs foram indexadas em $pageCount categoria(s)."
    }
    "faq_single" {
        try { $request = $Value | ConvertFrom-Json -ErrorAction Stop } catch { throw 'Informe uma FAQ válida para atualização.' }
        $faqId = [string]$request.id
        $articleUrl = [string]$request.url
        if ($faqId -notmatch '^\d{1,12}$' -or $articleUrl -notlike 'https://capri.senado.leg.br/*') {
            throw 'O número ou o endereço da FAQ é inválido.'
        }
        $rootUrl = 'https://capri.senado.leg.br/otrs/index.pl?Action=AgentFAQExplorer;CategoryID=21;Nav='
        $origin = 'https://capri.senado.leg.br'
        $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
        [void](Restore-CapriWebSession $webSession)
        function Test-CapriSingleLogin([string]$Html) {
            if ([string]::IsNullOrWhiteSpace($Html)) { return $true }
            return ($Html -match '(?is)<form[^>]+(?:Action=["'']?Login|id=["''][^"'']*Login)' -or
                    $Html -match '(?is)<input[^>]+name=["''](?:User|Password)["'']')
        }
        function Invoke-CapriSingleGet([string]$Url) {
            Invoke-WebRequest -Uri $Url -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 30 -ErrorAction Stop
        }
        function Convert-CapriSingleText([string]$Html) {
            $bodyMatch = [regex]::Match($Html, '(?is)<body\b[^>]*>(?<body>.*)</body>')
            $content = if ($bodyMatch.Success) { $bodyMatch.Groups['body'].Value } else { $Html }
            $content = $content -replace '(?is)<(script|style|noscript|svg|nav|header|footer|form)\b[^>]*>.*?</\1>', ' '
            $content = $content -replace '(?i)<br\s*/?>', "`n"
            $content = $content -replace '(?i)</(p|div|li|tr|h[1-6]|section|article)>', "`n"
            $content = [Net.WebUtility]::HtmlDecode(($content -replace '(?is)<[^>]+>', ' '))
            $content = $content -replace '(?i)<br\s*/?>', "`n"
            $content = $content -replace '(?i)</(p|div|li|tr|h[1-6]|section|article)>', "`n"
            $content = [Net.WebUtility]::HtmlDecode(($content -replace '(?is)<[^>]+>', ' '))
            return (@($content -split '[\r\n]+' | ForEach-Object { ($_ -replace '\s+', ' ').Trim() } | Where-Object { $_ }) -join "`n")
        }
        function Get-CapriSingleContent([string]$Html) {
            $blocks = [System.Collections.Generic.List[string]]::new()
            $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
            $pattern = '(?is)<(?:div|section|article)\b[^>]+(?:class|id)=["''][^"'']*(?:RichText|FAQContent|ArticleContent|ArticleBody|FieldValue)[^"'']*["''][^>]*>(?<value>.*?)</(?:div|section|article)>'
            foreach ($match in [regex]::Matches($Html, $pattern)) {
                $text = Convert-CapriSingleText ([string]$match.Groups['value'].Value)
                if ($text.Length -ge 40 -and $seen.Add($text)) { $blocks.Add($text) }
            }
            if (($blocks -join "`n`n").Length -ge 80) { return ($blocks -join "`n`n") }
            return Convert-CapriSingleText $Html
        }
        $firstResponse = Invoke-CapriSingleGet $rootUrl
        if (Test-CapriSingleLogin ([string]$firstResponse.Content)) {
            $capriUser = Get-AtlasCredentialText 'GERENCIADOR_CAPRI_USER_B64' 'GERENCIADOR_CAPRI_USER'
            $capriPassword = Get-AtlasCredentialText 'GERENCIADOR_CAPRI_PASSWORD_B64' 'GERENCIADOR_CAPRI_PASSWORD'
            if (!$capriUser -or !$capriPassword) { throw 'O Capri solicitou autenticação.' }
            $challenge = ''
            $challengeMatch = [regex]::Match([string]$firstResponse.Content, '(?is)<input[^>]+name=["'']ChallengeToken["''][^>]+value=["''](?<value>[^"'']*)')
            if ($challengeMatch.Success) { $challenge = [Net.WebUtility]::HtmlDecode($challengeMatch.Groups['value'].Value) }
            $loginBody = @{ Action='Login'; RequestedURL='Action=AgentFAQExplorer;CategoryID=21;Nav='; User=$capriUser; Password=$capriPassword }
            if ($challenge) { $loginBody['ChallengeToken'] = $challenge }
            $null = Invoke-WebRequest -Uri "$origin/otrs/index.pl" -Method Post -Body $loginBody -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 30 -ErrorAction Stop
        }
        Remove-Item Env:GERENCIADOR_CAPRI_PASSWORD, Env:GERENCIADOR_CAPRI_PASSWORD_B64 -ErrorAction SilentlyContinue
        $article = Invoke-CapriSingleGet $articleUrl
        if (Test-CapriSingleLogin ([string]$article.Content)) { throw 'A autenticação do Capri expirou ou foi recusada.' }
        $html = [string]$article.Content
        $content = Get-CapriSingleContent $html
        if ([string]::IsNullOrWhiteSpace($content) -or $content.Length -lt 40) { throw 'O conteúdo escrito da FAQ não foi localizado.' }
        $title = [string]$request.title
        $titleMatch = [regex]::Match($html, "(?is)FAQ#?\s*:?\s*$([regex]::Escape($faqId))\s*(?:&mdash;|&#8212;|—|–|-)\s*(?<title>[^<\r\n]+)")
        if ($titleMatch.Success) { $title = ([Net.WebUtility]::HtmlDecode($titleMatch.Groups['title'].Value) -replace '\s+', ' ').Trim() }
        $record = [ordered]@{ id=$faqId; title=$title; url=$articleUrl; updated=(Get-Date).ToString('s'); content=$content }
        Save-CapriWebSession $webSession
        Write-Output ('@@FAQ_SINGLE@@' + ($record | ConvertTo-Json -Depth 5 -Compress))
        Write-Output "FAQ $faqId atualizada individualmente."
    }
    "faq_export" {
        $destination = [string]$Value
        if ([string]::IsNullOrWhiteSpace($destination)) { throw 'Selecione o arquivo TXT de destino.' }
        if ([IO.Path]::GetExtension($destination) -notmatch '(?i)^\.txt$') { throw 'A extração deve ser salva em um arquivo TXT.' }
        $cachePath = Join-Path $env:LOCALAPPDATA 'AtlasSuporteAvancado\cache\faq_catalog.json'
        $contentCachePath = Join-Path $env:LOCALAPPDATA 'AtlasSuporteAvancado\cache\faq_contents.json'
        $legacyCacheRoot = Join-Path $env:LOCALAPPDATA 'AtlasSuporteAvancado\v5.0\cache'
        if (!(Test-Path -LiteralPath $cachePath) -and (Test-Path -LiteralPath (Join-Path $legacyCacheRoot 'faq_catalog.json'))) {
            New-Item -ItemType Directory -Path (Split-Path -Parent $cachePath) -Force | Out-Null
            Copy-Item -LiteralPath (Join-Path $legacyCacheRoot 'faq_catalog.json') -Destination $cachePath -Force
        }
        if (!(Test-Path -LiteralPath $contentCachePath) -and (Test-Path -LiteralPath (Join-Path $legacyCacheRoot 'faq_contents.json'))) {
            New-Item -ItemType Directory -Path (Split-Path -Parent $contentCachePath) -Force | Out-Null
            Copy-Item -LiteralPath (Join-Path $legacyCacheRoot 'faq_contents.json') -Destination $contentCachePath -Force
        }
        if (!(Test-Path -LiteralPath $cachePath -PathType Leaf)) {
            throw 'O catálogo local das FAQs não foi localizado. Faça primeiro o mapeamento pelo botão de atualizar.'
        }
        try {
            $catalog = Get-Content -LiteralPath $cachePath -Raw -Encoding UTF8 | ConvertFrom-Json
        } catch {
            throw "O catálogo salvo não pôde ser lido: $($_.Exception.Message)"
        }
        $faqItems = @($catalog.items)
        if (!$faqItems.Count) { throw 'O catálogo salvo não contém FAQs para exportação.' }
        $contentCache = @{}
        if (Test-Path -LiteralPath $contentCachePath -PathType Leaf) {
            try {
                $savedContents = Get-Content -LiteralPath $contentCachePath -Raw -Encoding UTF8 | ConvertFrom-Json
                if ([int]$savedContents.cache_version -eq 3) {
                    foreach ($saved in @($savedContents.items)) {
                        if ($saved.id -and $saved.content -and ([string]$saved.content).Length -ge 80) {
                            $contentCache[[string]$saved.id] = $saved
                        }
                    }
                }
            } catch {
                # Cache inválido não bloqueia uma nova coleta completa.
                $contentCache = @{}
            }
        }

        $rootUrl = 'https://capri.senado.leg.br/otrs/index.pl?Action=AgentFAQExplorer;CategoryID=21;Nav='
        $origin = 'https://capri.senado.leg.br'
        $webSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
        [void](Restore-CapriWebSession $webSession)
        function Test-CapriExportLogin([string]$Html) {
            if ([string]::IsNullOrWhiteSpace($Html)) { return $true }
            return ($Html -match '(?is)<form[^>]+(?:Action=["'']?Login|id=["''][^"'']*Login)' -or
                    $Html -match '(?is)<input[^>]+name=["''](?:User|Password)["'']')
        }
        function Invoke-CapriExportGet([string]$Url) {
            Invoke-WebRequest -Uri $Url -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 30 -ErrorAction Stop
        }
        function Convert-CapriArticleText([string]$Html) {
            # Usa o corpo integral. O Capri pode guardar o artigo em blocos
            # RichText aninhados ou como HTML codificado; limitar ao primeiro
            # DIV truncava justamente o conteúdo escrito da FAQ.
            $bodyMatch = [regex]::Match($Html, '(?is)<body\b[^>]*>(?<body>.*)</body>')
            $content = if ($bodyMatch.Success) { $bodyMatch.Groups['body'].Value } else { $Html }
            $content = $content -replace '(?is)<(script|style|noscript|svg)\b[^>]*>.*?</\1>', ' '
            $content = $content -replace '(?is)<(nav|header|footer|form)\b[^>]*>.*?</\1>', ' '
            $content = $content -replace '(?i)<br\s*/?>', "`n"
            $content = $content -replace '(?i)</(p|div|li|tr|h[1-6]|section|article)>', "`n"
            $content = $content -replace '(?is)<[^>]+>', ' '
            $content = [Net.WebUtility]::HtmlDecode($content)
            # Uma segunda passagem revela textos armazenados como &lt;p&gt;...,
            # preservando suas quebras antes de retirar as marcações restantes.
            $content = $content -replace '(?i)<br\s*/?>', "`n"
            $content = $content -replace '(?i)</(p|div|li|tr|h[1-6]|section|article)>', "`n"
            $content = $content -replace '(?is)<[^>]+>', ' '
            $content = [Net.WebUtility]::HtmlDecode($content)
            $lines = @($content -split '[\r\n]+' | ForEach-Object { ($_ -replace '\s+', ' ').Trim() } | Where-Object { $_ })
            return ($lines -join "`n")
        }
        function Get-CapriWrittenContent([string]$Html) {
            $blocks = [System.Collections.Generic.List[string]]::new()
            $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
            $blockPattern = '(?is)<(?:div|section|article)\b[^>]+(?:class|id)=["''][^"'']*(?:RichText|FAQContent|ArticleContent|ArticleBody|FieldValue)[^"'']*["''][^>]*>(?<value>.*?)</(?:div|section|article)>'
            foreach ($match in [regex]::Matches($Html, $blockPattern)) {
                $text = Convert-CapriArticleText ([string]$match.Groups['value'].Value)
                if ($text.Length -lt 40) { continue }
                if ($text -match '(?i)^(voltar|histórico|anexos|central de atendimento)$') { continue }
                if ($seen.Add($text)) { $blocks.Add($text) }
            }
            if (($blocks -join "`n`n").Length -ge 80) { return ($blocks -join "`n`n") }

            # Alguns artigos antigos não usam a classe RichText. Neles, todo o
            # texto visível da página é preservado, incluindo orientações,
            # listas e subtítulos escritos pelos autores da FAQ.
            return Convert-CapriArticleText $Html
        }
        function Get-CapriTextField([string]$Text, [string]$Label) {
            $lines = @($Text -split '[\r\n]+' | ForEach-Object { ($_ -replace '\s+', ' ').Trim() } | Where-Object { $_ })
            for ($index = 0; $index -lt $lines.Count; $index++) {
                if ($lines[$index] -match "(?i)^$([regex]::Escape($Label))\s*:?\s*(?<value>.*)$") {
                    $value = [string]$matches['value']
                    if ($value) { return $value.Trim() }
                    if ($index + 1 -lt $lines.Count) { return [string]$lines[$index + 1] }
                }
            }
            return 'Não informado'
        }
        function Get-CapriHtmlField([string]$Html, [string]$PlainText, [string]$Label) {
            $escaped = [regex]::Escape($Label)
            $patterns = @(
                "(?is)<t[dh][^>]*>\s*(?:<[^>]+>\s*)*$escaped\s*:?(?:\s*</[^>]+>)*\s*</t[dh]>\s*<td[^>]*>(?<value>.*?)</td>",
                "(?is)<label[^>]*>\s*$escaped\s*:?[\s\S]*?</label>\s*(?:<[^>]+>)*\s*(?<value>[^<]+)",
                "(?is)>\s*$escaped\s*:?\s*<[^>]+>\s*(?<value>[^<]{1,500})"
            )
            foreach ($pattern in $patterns) {
                $fieldMatch = [regex]::Match($Html, $pattern)
                if (!$fieldMatch.Success) { continue }
                $value = ([Net.WebUtility]::HtmlDecode(($fieldMatch.Groups['value'].Value -replace '(?is)<[^>]+>', ' ')) -replace '\s+', ' ').Trim()
                if ($value) { return $value }
            }
            return Get-CapriTextField -Text $PlainText -Label $Label
        }
        $missingCount = @($faqItems | Where-Object { !$contentCache.ContainsKey([string]$_.id) }).Count
        if ($missingCount -gt 0) {
            try {
                $firstResponse = Invoke-CapriExportGet $rootUrl
            } catch {
                throw "Não foi possível acessar o Capri para a extração: $($_.Exception.Message)"
            }
            if (Test-CapriExportLogin ([string]$firstResponse.Content)) {
                $capriUser = Get-AtlasCredentialText 'GERENCIADOR_CAPRI_USER_B64' 'GERENCIADOR_CAPRI_USER'
                $capriPassword = Get-AtlasCredentialText 'GERENCIADOR_CAPRI_PASSWORD_B64' 'GERENCIADOR_CAPRI_PASSWORD'
                if ([string]::IsNullOrWhiteSpace($capriUser) -or [string]::IsNullOrWhiteSpace($capriPassword)) {
                    throw 'O Capri solicitou autenticação. Atualize a conta pelo cadeado da área FAQs.'
                }
                $challenge = ''
                $challengeMatch = [regex]::Match([string]$firstResponse.Content, '(?is)<input[^>]+name=["'']ChallengeToken["''][^>]+value=["''](?<value>[^"'']*)')
                if ($challengeMatch.Success) { $challenge = [Net.WebUtility]::HtmlDecode($challengeMatch.Groups['value'].Value) }
                $loginBody = @{ Action='Login'; RequestedURL='Action=AgentFAQExplorer;CategoryID=21;Nav='; User=$capriUser; Password=$capriPassword }
                if ($challenge) { $loginBody['ChallengeToken'] = $challenge }
                $null = Invoke-WebRequest -Uri "$origin/otrs/index.pl" -Method Post -Body $loginBody -WebSession $webSession -UseDefaultCredentials -UseBasicParsing -TimeoutSec 30 -ErrorAction Stop
                $firstResponse = Invoke-CapriExportGet $rootUrl
                if (Test-CapriExportLogin ([string]$firstResponse.Content)) { throw 'O Capri recusou a autenticação informada.' }
            }
        }

        $parent = Split-Path -Parent $destination
        if ($parent -and !(Test-Path -LiteralPath $parent)) { [IO.Directory]::CreateDirectory($parent) | Out-Null }
        $encoding = New-Object System.Text.UTF8Encoding($false)
        $writer = New-Object System.IO.StreamWriter($destination, $false, $encoding)
        $exported = 0
        $failed = 0
        $reused = 0
        try {
            $writer.WriteLine('FAQs DO CAPRI — CENTRAL DE CONHECIMENTO')
            $writer.WriteLine("Extraído em: $(Get-Date -Format 'dd/MM/yyyy HH:mm')")
            $writer.WriteLine("Total catalogado: $($faqItems.Count)")
            $writer.WriteLine(('=' * 96))
            $writer.WriteLine('')
            foreach ($faq in @($faqItems | Sort-Object knowledge_category, knowledge_subcategory, knowledge_procedure, title)) {
                $faqId = [string]$faq.id
                $title = [string]$faq.title
                $url = [string]$faq.url
                $record = $null
                $errorText = ''
                if ($contentCache.ContainsKey($faqId)) {
                    $record = $contentCache[$faqId]
                    $reused++
                    $exported++
                } else {
                    try {
                        if ($url -notlike "$origin/*") { throw 'URL fora do domínio oficial.' }
                        $article = Invoke-CapriExportGet $url
                        if (Test-CapriExportLogin ([string]$article.Content)) { throw 'Sessão expirada durante a leitura.' }
                        $articleText = Get-CapriWrittenContent ([string]$article.Content)
                        if ([string]::IsNullOrWhiteSpace($articleText) -or $articleText.Length -lt 80) {
                            throw 'O artigo não devolveu conteúdo escrito suficiente para uma exportação válida.'
                        }
                        $record = [PSCustomObject]@{
                            id = $faqId
                            content = $articleText
                            type = Get-CapriHtmlField -Html ([string]$article.Content) -PlainText $articleText -Label 'Tipo'
                            service = Get-CapriHtmlField -Html ([string]$article.Content) -PlainText $articleText -Label 'Serviço'
                            subject = Get-CapriHtmlField -Html ([string]$article.Content) -PlainText $articleText -Label 'Assunto'
                            updated = Get-CapriHtmlField -Html ([string]$article.Content) -PlainText $articleText -Label 'Atualizado em'
                            cached_at = (Get-Date).ToString('s')
                        }
                        $contentCache[$faqId] = $record
                        $exported++
                    } catch {
                        $failed++
                        $errorText = [string]$_.Exception.Message
                    }
                }
                $writer.WriteLine("FAQ#: $faqId")
                $writer.WriteLine("Título: $title")
                $writer.WriteLine('')
                $writer.WriteLine('Caminho:')
                $writer.WriteLine([string]$faq.original_category)
                $writer.WriteLine('')
                $writer.WriteLine('Categoria organizada:')
                $writer.WriteLine("$($faq.knowledge_category) > $($faq.knowledge_subcategory) > $($faq.knowledge_procedure)")
                $writer.WriteLine('')
                if ($record) {
                    $writer.WriteLine('Tipo:')
                    $writer.WriteLine([string]$record.type)
                    $writer.WriteLine('')
                    $writer.WriteLine('Serviço:')
                    $writer.WriteLine([string]$record.service)
                    $writer.WriteLine('')
                    $writer.WriteLine('Assunto:')
                    $writer.WriteLine([string]$record.subject)
                    $writer.WriteLine('')
                    $writer.WriteLine('Atualizado em:')
                    $writer.WriteLine([string]$record.updated)
                    $writer.WriteLine('')
                    $writer.WriteLine('CONTEÚDO')
                    $writer.WriteLine('')
                    $writer.WriteLine([string]$record.content)
                } else {
                    $writer.WriteLine('CONTEÚDO')
                    $writer.WriteLine('')
                    $writer.WriteLine("Não foi possível extrair esta FAQ: $errorText")
                }
                $writer.WriteLine('')
                $writer.WriteLine("Fonte: $url")
                $writer.WriteLine('')
                $writer.WriteLine(('=' * 96))
                $writer.WriteLine('')
                $writer.Flush()
            }
        } finally {
            $writer.Dispose()
        Remove-Item Env:GERENCIADOR_CAPRI_PASSWORD, Env:GERENCIADOR_CAPRI_PASSWORD_B64 -ErrorAction SilentlyContinue
        }
        try {
            $cacheItems = @($contentCache.GetEnumerator() | ForEach-Object { $_.Value })
            [PSCustomObject]@{
                cache_version = 3
                updated_at = (Get-Date).ToString('s')
                count = $cacheItems.Count
                items = $cacheItems
            } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $contentCachePath -Encoding UTF8
        } catch {
            Write-Output "Aviso: o TXT foi criado, mas o cache do conteúdo não pôde ser atualizado: $($_.Exception.Message)"
        }
        Save-CapriWebSession $webSession
        Write-Output "Extração TXT concluída: $exported conteúdo(s), $reused reutilizado(s) do cache e $failed falha(s). Arquivo: $destination"
    }
    "authorized_software_run" {
        Require-Computer
        $path = $Value.Trim()
        if ($path -notmatch '(?i)^X:\\.+\.exe$') { throw 'O caminho solicitado não pertence ao catálogo autorizado do drive X:.' }
        $leaf = [IO.Path]::GetFileName($path)
        if ($leaf -ieq 'Driver Impressoras HP (Prodasen).exe' -or
            $leaf -ieq 'Remove Driver Impressoras HP (Prodasen).exe') {
            throw 'Os assistentes de driver HP devem ser executados exclusivamente pela área Impressoras.'
        }
        $logged = (Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
        $root = Get-RemoteMappedDrivePath -Letter 'X' -LoggedUser $logged
        if ([string]::IsNullOrWhiteSpace($root)) { throw 'O drive X: não está disponível para o usuário conectado.' }
        $relative = $path.Substring(3)
        $uncPath = Join-Path $root $relative
        if ((Test-Path -LiteralPath $root) -and !(Test-Path -LiteralPath $uncPath -PathType Leaf)) {
            throw 'O executável não foi localizado no catálogo autorizado.'
        }
        $taskName = 'Suporte_SoftwareAutorizado_' + [guid]::NewGuid().ToString('N').Substring(0, 8)
        Invoke-InteractiveTask -TaskName $taskName -Command $path -Arguments '' -RunLevel 'HighestAvailable'
        Write-Output "$leaf foi iniciado na sessão de $logged."
    }
    "ad" { Start-Process dsa.msc; Write-Output "Active Directory aberto." }
    "inetcpl" {
        Require-Computer
        try {
            Invoke-InteractiveTask -TaskName 'Suporte_OpcoesInternet' -Command 'control.exe' -Arguments 'inetcpl.cpl,,3'
            Write-Output 'Opcoes da Internet abertas na aba Conteudo da sessao remota.'
        } catch {
            Start-Process certlm.msc -ArgumentList "/computer:$Computer"
            Write-Output 'Console de certificados remoto aberto como alternativa.'
        }
    }
    "browser_open_chrome_cleanup" { Open-RemoteBrowserClearPage -Browser 'chrome' }
    "browser_open_edge_cleanup" { Open-RemoteBrowserClearPage -Browser 'edge' }
    "browser_close_chrome" { Close-RemoteBrowser -Browser 'chrome' }
    "browser_close_edge" { Close-RemoteBrowser -Browser 'edge' }
    "cert_list" {
        Require-Computer
        $loggedUser = ''
        $isLocalComputer = Test-LocalComputer
        if ($isLocalComputer) { $loggedUser = "$env:USERDOMAIN\$env:USERNAME" }
        else { try { $loggedUser = [string](Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName } catch {} }
        $certificates = if ($isLocalComputer) { @(Get-LocalProfileCertificates) } else {
            Require-RemoteComputer
            @(Get-CurrentUserProfileCertificates -computerName $Computer -storeFilter 'ALL')
        }
        $items = @($certificates | Sort-Object NotAfter, Subject | ForEach-Object {
            $certificate = $_
            $validFrom = [datetime]::MinValue
            $validTo = [datetime]::MinValue
            try { $validFrom = [datetime]$certificate.NotBefore } catch {}
            try { $validTo = [datetime]$certificate.NotAfter } catch {}
            $displayName = [string]$certificate.FriendlyName
            if ([string]::IsNullOrWhiteSpace($displayName)) { $displayName = Get-CertificateCleanName ([string]$certificate.Subject) }
            if ([string]::IsNullOrWhiteSpace($displayName)) { $displayName = [string]$certificate.Thumbprint }
            $status = if ([bool]$certificate.IsExpired -or ($validTo -ne [datetime]::MinValue -and $validTo -lt (Get-Date))) {
                'Expirado'
            } elseif ($validFrom -ne [datetime]::MinValue -and $validFrom -gt (Get-Date)) {
                'Ainda não válido'
            } else { 'Válido' }
            $isMachine = ([string]$certificate.StoreType) -like 'LocalMachine*'
            [ordered]@{
                display_name = $displayName
                subject = [string]$certificate.Subject
                issuer = [string]$certificate.Issuer
                valid_from = $(if ($validFrom -ne [datetime]::MinValue) { $validFrom.ToString('dd/MM/yyyy HH:mm') } else { [string]$certificate.NotBefore })
                valid_to = $(if ($validTo -ne [datetime]::MinValue) { $validTo.ToString('dd/MM/yyyy HH:mm') } else { [string]$certificate.NotAfter })
                status = $status
                thumbprint = (([string]$certificate.Thumbprint) -replace '[^0-9A-Fa-f]', '').ToUpperInvariant()
                serial = [string]$certificate.SerialNumber
                scope = $(if ($isLocalComputer) { if ($isMachine) { 'Computador local' } else { "Usuário local: $([string]$certificate.UserAccount)" } } elseif ($isMachine) { 'Computador remoto' } else { "Usuário remoto: $([string]$certificate.UserAccount)" })
                store_type = [string]$certificate.StoreType
                user_sid = [string]$certificate.UserSid
                user_account = [string]$certificate.UserAccount
                has_private_key = [bool]$certificate.HasPrivateKey
                is_sigad = [bool]$certificate.IsSigad
                storage_source = [string]$certificate.StorageSource
            }
        })
        $result = [ordered]@{
            station = $Computer
            logged_user = $(if ($loggedUser) { $loggedUser } else { 'Nenhum usuário conectado' })
            count = $items.Count
            session_status = [string]$script:CERT_REMOTE_SESSION_STATUS
            items = @($items)
        }
        Write-Output ("@@CERTIFICATES@@" + ($result | ConvertTo-Json -Depth 5 -Compress))
        Write-Output "$($result.count) certificado(s) pessoal(is) localizado(s) em $Computer."
    }
    "cert_delete" {
        Require-Computer
        if ([string]::IsNullOrWhiteSpace($Value)) { throw 'Nenhum certificado foi informado para exclusão.' }
        try { $request = $Value | ConvertFrom-Json -ErrorAction Stop } catch { throw 'Os dados do certificado selecionado são inválidos.' }
        $thumbprint = (([string]$request.thumbprint) -replace '[^0-9A-Fa-f]', '').ToUpperInvariant()
        if ($thumbprint -notmatch '^[0-9A-F]{40,128}$') { throw 'Impressão digital de certificado inválida.' }
        $storeType = ([string]$request.store_type).Trim()
        if ($storeType -notlike 'CurrentUser*' -and $storeType -notlike 'LocalMachine*') { throw 'Repositório de certificado não autorizado.' }
        if (Test-LocalComputer) {
            $providerRoot = if ($storeType -like 'LocalMachine*') { 'Cert:\LocalMachine\My' } else { 'Cert:\CurrentUser\My' }
            $certificatePath = Join-Path $providerRoot $thumbprint
            if (!(Test-Path -LiteralPath $certificatePath)) { throw 'O certificado selecionado não existe mais no repositório local.' }
            Remove-Item -LiteralPath $certificatePath -Force -ErrorAction Stop
            $removed = !(Test-Path -LiteralPath $certificatePath)
        } else {
            Require-RemoteComputer
            $removed = Remove-RemoteUserCertificate -computerName $Computer -thumbprint $thumbprint `
                -userSid ([string]$request.user_sid) -userAccount ([string]$request.user_account) -storeType $storeType
        }
        if (!$removed) { throw 'A estação não confirmou a exclusão do certificado selecionado.' }
        $displayName = ([string]$request.display_name).Trim()
        if (!$displayName) { $displayName = $thumbprint }
        Write-Output "Certificado '$displayName' excluído com sucesso somente do computador remoto $Computer."
    }
    "local_users" {
        Require-Computer
        Start-Process lusrmgr.msc -ArgumentList "/computer:\\$Computer"
        Write-Output "Gerenciamento de usuários e grupos locais aberto para $Computer."
    }
    "ad_user_info" {
        Require-Computer
        $logged = (Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
        if (!$logged) { throw "Nenhum usuário conectado foi identificado." }
        $userOnly = ($logged -split '\\')[-1]
        try {
            $data = Get-AtlasAdUserData $userOnly
            Write-Output ("@@ADUSER@@" + ($data | ConvertTo-Json -Depth 5 -Compress))
            Write-Output "Informações do usuário SENADO\\$userOnly consultadas com sucesso."
        } catch { throw "Falha ao consultar informações do usuário: $($_.Exception.Message)" }
    }
    "ad_user_info_login" {
        try {
            $userOnly = Normalize-AtlasNetworkLogin $Value
            $data = Get-AtlasAdUserData $userOnly
            Write-Output ("@@ADUSER@@" + ($data | ConvertTo-Json -Depth 5 -Compress))
            Write-Output "Informações complementares de SENADO\$userOnly consultadas com sucesso."
        } catch { throw "Falha ao consultar informações do usuário informado: $($_.Exception.Message)" }
    }
    "user_control_lookup" {
        try {
            $userOnly = Normalize-AtlasNetworkLogin $Value
            Write-Output "[USUÁRIO] Consultando SENADO\\$userOnly no Active Directory..."
            $data = Get-AtlasAdUserData $userOnly
            Write-Output ("@@USERCONTROL@@" + ($data | ConvertTo-Json -Depth 6 -Compress))
            Write-Output "[USUÁRIO] Dados do Active Directory carregados para SENADO\\$userOnly."
        } catch { throw "Falha ao consultar o usuário informado: $($_.Exception.Message)" }
    }
    "ad_groups" {
        Require-Computer
        $logged = (Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
        if (!$logged) { throw "Nenhum usuário conectado foi identificado." }
        $userOnly = ($logged -split '\\')[-1]
        try {
            $searcher = New-Object DirectoryServices.DirectorySearcher
            $searcher.Filter = "(&(objectCategory=person)(objectClass=user)(sAMAccountName=$userOnly))"
            $result = $searcher.FindOne()
            if (!$result) { throw "Usuário $userOnly não localizado no Active Directory." }
            $entry = $result.GetDirectoryEntry()
            Write-Output "Usuário: $($entry.displayName) ($userOnly)"
            Write-Output "Grupos do Active Directory:"
            @($entry.memberOf) | ForEach-Object {
                if ($_ -match '^CN=([^,]+)') { Write-Output " - $($matches[1])" }
            }
        } catch { throw "Falha ao consultar grupos: $($_.Exception.Message)" }
    }
    "disk_profiles" {
        Require-Computer
        $diskItems = @()
        Write-Output "UNIDADES LOCAIS E DE REDE — $Computer"

        # Mesma estratégia comprovada da ferramenta Legada: discos lógicos,
        # mapeamentos WMI e chaves Network dos perfis carregados no HKU.
        $disks = @()
        try {
            $disks = @(Get-WmiObject -Class Win32_LogicalDisk -ComputerName $Computer -ErrorAction SilentlyContinue)
        } catch {}

        $netDrives = @()
        try {
            $mappedWmi = Get-WmiObject -Class Win32_MappedLogicalDisk -ComputerName $Computer -ErrorAction SilentlyContinue
            foreach ($mapped in @($mappedWmi)) {
                if ($mapped.Name -and !($disks | Where-Object { $_.DeviceID -ieq $mapped.Name })) {
                    $netDrives += [PSCustomObject]@{
                        DeviceID = $mapped.Name
                        DriveType = 4
                        ProviderName = $mapped.ProviderName
                        Size = [int64]$mapped.Size
                        FreeSpace = [int64]$mapped.FreeSpace
                        VolumeName = $mapped.VolumeName
                        FileSystem = $mapped.FileSystem
                    }
                }
            }
        } catch {}

        try {
            foreach ($connection in @(Get-WmiObject -Class Win32_NetworkConnection -ComputerName $Computer -ErrorAction SilentlyContinue)) {
                $driveID = ([string]$connection.LocalName).Trim().ToUpperInvariant()
                $remotePath = ([string]$connection.RemoteName).Trim()
                if ($driveID -match '^[A-Z]:$' -and $remotePath -and
                    !($disks | Where-Object { $_.DeviceID -ieq $driveID }) -and
                    !($netDrives | Where-Object { $_.DeviceID -ieq $driveID })) {
                    $networkLabel = ''
                    try { $networkLabel = Split-Path $remotePath.TrimEnd('\') -Leaf } catch {}
                    $netDrives += [PSCustomObject]@{
                        DeviceID = $driveID
                        DriveType = 4
                        ProviderName = $remotePath
                        Size = [int64]0
                        FreeSpace = [int64]0
                        VolumeName = $networkLabel
                        FileSystem = ''
                    }
                }
            }
        } catch {}

        try {
            $regBase = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::Users, $Computer)
            if ($regBase) {
                foreach ($sidKey in @($regBase.GetSubKeyNames())) {
                    if ($sidKey -like 'S-1-5-21-*' -and $sidKey -notlike '*_Classes') {
                        $netKeyPath = "$sidKey\Network"
                        try {
                            $netSubKey = $regBase.OpenSubKey($netKeyPath)
                            if ($netSubKey) {
                                foreach ($driveLetter in @($netSubKey.GetSubKeyNames())) {
                                    $driveID = "$($driveLetter.ToUpper()):"
                                    if (!($disks | Where-Object { $_.DeviceID -ieq $driveID }) -and
                                        !($netDrives | Where-Object { $_.DeviceID -ieq $driveID })) {
                                        $driveKey = $regBase.OpenSubKey("$netKeyPath\$driveLetter")
                                        $remotePath = if ($driveKey) { [string]$driveKey.GetValue('RemotePath', '') } else { '' }
                                        if ($driveKey) { $driveKey.Close() }
                                        if ($remotePath) {
                                            $netDrives += [PSCustomObject]@{
                                                DeviceID = $driveID
                                                DriveType = 4
                                                ProviderName = $remotePath
                                                Size = [int64]0
                                                FreeSpace = [int64]0
                                                VolumeName = 'Mapeamento de Rede'
                                                FileSystem = ''
                                            }
                                        }
                                    }
                                }
                                $netSubKey.Close()
                            }
                        } catch {}
                    }
                }
                $regBase.Close()
            }
        } catch {}

        # Unidades mapeadas pertencem ao token da sessao interativa e podem nao
        # aparecer para o administrador que executa WMI. A consulta abaixo roda
        # no contexto do usuario conectado, exatamente como o Explorador.
        $sessionMapped = @()
        $registryMapped = @()
        $interactiveUsers = @()
        $collectionReports = [System.Collections.Generic.List[string]]::new()
        try { $interactiveUsers = @(Get-RemoteInteractiveUsers) } catch {}
        if ($interactiveUsers.Count -eq 0) {
            try {
                $fallbackUser = [string](Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction SilentlyContinue).UserName
                if ($fallbackUser) { $interactiveUsers = @($fallbackUser) }
            } catch {}
        }
        $registryUser = if ($interactiveUsers.Count) { [string]$interactiveUsers[0] } else { '' }
        try { $registryMapped = @(Get-RemoteRegistryMappedDrives -LoggedUser $registryUser) } catch {}
        try {
            $networkCollector = Join-Path $PSScriptRoot 'network_drives.ps1'
            $explorerMapped = if (Test-Path -LiteralPath $networkCollector) {
                @(& $networkCollector -Computer $Computer -LoggedUser $registryUser)
            } else { @() }
            foreach ($mapped in $explorerMapped) {
                $driveId = ([string]$mapped.drive).Trim().ToUpperInvariant()
                $existing = @($registryMapped | Where-Object { ([string]$_.drive).Trim().ToUpperInvariant() -eq $driveId })
                if ($driveId -match '^[A-Z]:$' -and $existing.Count -eq 0) { $registryMapped += $mapped }
            }
            $collectionReports.Add("Coleta multi-método do Explorer: $($explorerMapped.Count) unidade(s) localizada(s).")
        } catch {
            $collectionReports.Add("Coleta multi-método do Explorer indisponível: $($_.Exception.Message)")
        }

        # Caminho principal: uma tarefa SYSTEM obtém os tokens WTS já existentes
        # e consulta os mapeamentos sob impersonação. Diferente de criar um novo
        # logon com o mesmo nome, isto preserva o LUID que contém os drives.
        $wtsMapped = @()
        try {
            $wtsRaw = @(Get-RemoteWtsMappedDrives)
            $preferredWts = @()
            if ($interactiveUsers.Count -gt 0) {
                $preferredName = ([string]$interactiveUsers[0]).Trim()
                $preferredWts = @($wtsRaw | Where-Object { ([string]$_.Owner).Trim() -ieq $preferredName })
            }
            $selectedWts = if ($preferredWts.Count -gt 0) { @($preferredWts) } else { @($wtsRaw) }
            foreach ($record in @($selectedWts)) {
                $wtsMapped += [PSCustomObject]@{
                    drive = [string]$record.Drive
                    provider = [string]$record.Remote
                    size = [int64]$record.Total
                    free = [int64]$record.Free
                    label = [string]$record.Label
                    filesystem = [string]$record.FileSystem
                    owner = [string]$record.Owner
                    session_id = [int]$record.SessionId
                }
            }
            $collectionReports.Add([string]$script:WtsDriveDiagnostic)
        } catch {
            $collectionReports.Add("Falha WTS: $($_.Exception.Message)")
        }

        if ($wtsMapped.Count -gt 0) {
            $sessionMapped = @($wtsMapped)
        } else {
            # Compatibilidade para ambientes que bloqueiam criação de tarefa
            # SYSTEM: mantém a coleta interativa anterior como contingência.
            foreach ($interactiveUser in @($interactiveUsers)) {
                try {
                    $candidateMapped = @(Get-RemoteSessionMappedDrives -LoggedUser ([string]$interactiveUser))
                    $candidateNetwork = @($candidateMapped | Where-Object { ![string]::IsNullOrWhiteSpace([string]$_.provider) })
                    $collectionReports.Add("$interactiveUser — $script:MappedDriveDiagnostic")
                    if ($candidateMapped.Count -gt $sessionMapped.Count -or $candidateNetwork.Count -gt 0) {
                        $sessionMapped = @($candidateMapped)
                    }
                    if ($candidateNetwork.Count -gt 0) { break }
                } catch {
                    $collectionReports.Add("$interactiveUser — falha: $($_.Exception.Message)")
                }
            }
        }
        $script:MappedDriveDiagnostic = if ($collectionReports.Count) { $collectionReports -join ' | ' } else { 'Nenhuma sessão interativa foi identificada.' }

        # Consolida por letra. A sessao interativa tem prioridade para unidades
        # de rede; assim evitamos duplicatas e preservamos C:, D: e removiveis.
        $diskById = @{}
        foreach ($disk in @($disks)) {
            $diskId = ([string]$disk.DeviceID).Trim().ToUpperInvariant()
            if ($diskId) { $diskById[$diskId] = $disk }
        }
        foreach ($disk in @($netDrives)) {
            $diskId = ([string]$disk.DeviceID).Trim().ToUpperInvariant()
            if ($diskId -and (!$diskById.ContainsKey($diskId) -or [int]$diskById[$diskId].DriveType -eq 4)) {
                $diskById[$diskId] = $disk
            }
        }
        foreach ($mapped in @($registryMapped)) {
            $driveId = ([string]$mapped.drive).Trim().ToUpperInvariant()
            $provider = ([string]$mapped.provider).Trim()
            if ($driveId -match '^[A-Z]:$' -and $provider) {
                $diskById[$driveId] = [PSCustomObject]@{
                    DeviceID = $driveId
                    DriveType = 4
                    ProviderName = $provider
                    Size = [int64]$mapped.size
                    FreeSpace = [int64]$mapped.free
                    VolumeName = [string]$mapped.label
                    FileSystem = [string]$mapped.filesystem
                }
            }
        }
        foreach ($mapped in @($sessionMapped)) {
            $driveId = ([string]$mapped.drive).Trim().ToUpperInvariant()
            $provider = ([string]$mapped.provider).Trim()
            if ($driveId -match '^[A-Z]:$' -and $provider) {
                $diskById[$driveId] = [PSCustomObject]@{
                    DeviceID = $driveId
                    DriveType = 4
                    ProviderName = $provider
                    Size = [int64]$mapped.size
                    FreeSpace = [int64]$mapped.free
                    VolumeName = [string]$mapped.label
                    FileSystem = [string]$mapped.filesystem
                }
            } elseif ($driveId -match '^[A-Z]:$' -and $diskById.ContainsKey($driveId) -and $mapped.label) {
                $existingDisk = $diskById[$driveId]
                $diskById[$driveId] = [PSCustomObject]@{
                    DeviceID = $driveId
                    DriveType = [int]$existingDisk.DriveType
                    ProviderName = [string]$existingDisk.ProviderName
                    Size = [int64]$existingDisk.Size
                    FreeSpace = [int64]$existingDisk.FreeSpace
                    VolumeName = [string]$mapped.label
                    FileSystem = [string]$existingDisk.FileSystem
                }
            }
        }

        $allDisks = @($diskById.Values | Sort-Object DeviceID)
        Write-Output ("Mapeamentos no registro do usuario: {0} | Na sessao interativa: {1}" -f @($registryMapped).Count, @($sessionMapped).Count)
        $allDisks | ForEach-Object {
            if ($_.Size) {
                $total = [math]::Round($_.Size / 1GB, 2)
                $free = [math]::Round($_.FreeSpace / 1GB, 2)
                $usedPercent = if ($_.Size -gt 0) { [math]::Round((($_.Size - $_.FreeSpace) / $_.Size) * 100, 1) } else { 0 }
                $sizeAvailable = $true
            } else {
                $total = 0; $free = 0; $usedPercent = 0; $sizeAvailable = $false
            }
            $kind = switch ([int]$_.DriveType) { 3 { 'Disco local' } 4 { 'Unidade de rede' } 2 { 'Removível' } 5 { 'Unidade óptica' } default { 'Unidade' } }
            $driveId = [string]$_.DeviceID
            $volumeLabel = ([string]$_.VolumeName).Trim()
            if ([int]$_.DriveType -eq 4) {
                $displayName = $volumeLabel
                if (!$displayName -and $_.ProviderName) {
                    try { $displayName = Split-Path ([string]$_.ProviderName).TrimEnd('\') -Leaf } catch {}
                }
                if (!$displayName) { $displayName = 'Unidade de rede' }
                $providerText = ([string]$_.ProviderName).ToLowerInvariant()
                if ($providerText -match '\\scanserver(\.[^\\]+)?\\(scandrive|scanfolders?)$' -or
                    $displayName -match '^(?i:scandrive|scanfolders?)$') {
                    $displayName = 'Scanfolders'
                }
            } elseif ($driveId -ieq 'C:' -and (!$volumeLabel -or $volumeLabel -match '^(?i:OS|Windows|Sistema)$')) {
                $displayName = 'Disco local'
            } elseif ($driveId -ieq 'D:' -and (!$volumeLabel -or $volumeLabel -match '^(?i:DATA|Dados)$')) {
                $displayName = 'Dados'
            } else {
                $displayName = if ($volumeLabel) { $volumeLabel } else { $kind }
            }
            $diskItems += [ordered]@{
                drive = $driveId
                display_name = $displayName
                kind = $kind
                provider = [string]$_.ProviderName
                label = [string]$_.VolumeName
                filesystem = [string]$_.FileSystem
                total_gb = $total
                free_gb = $free
                used_percent = $usedPercent
                size_available = $sizeAvailable
            }
            $destination = if ($_.ProviderName) { " -> $($_.ProviderName)" } else { '' }
            $capacity = if ($sizeAvailable) { "Total: $total GB | Livre: $free GB" } else { 'Mapeamento localizado; tamanho não reportado' }
            Write-Output " $($_.DeviceID)$destination | $kind | $capacity"
        }
        $profileItems = @()
        Write-Output "PERFIS REGISTRADOS"
        $profiles = @(Get-WmiObject Win32_UserProfile -ComputerName $Computer -ErrorAction Stop |
            Where-Object { !$_.Special -and ![string]::IsNullOrWhiteSpace($_.LocalPath) } |
            Sort-Object LocalPath)

        $profileSizes = @{}
        # Caminho principal otimizado: calcula uma única vez na estação e mede
        # até três perfis em paralelo para reduzir o tempo sem saturar o disco.
        if ($profiles.Count -gt 0) {
            $scanToken = [guid]::NewGuid().ToString('N')
            $registryPath = "SOFTWARE\SuporteProfSizes_$scanToken"
            $remoteScript = @'
$registryPath = '__REGISTRY_PATH__'
New-Item -Path ("HKLM:\" + $registryPath) -Force -ErrorAction SilentlyContinue | Out-Null
$profiles = Get-WmiObject Win32_UserProfile | Where-Object { !$_.Special -and $_.LocalPath }
$measureProfile = {
    param([string]$path, [string]$sid)
    $size = [int64]0
    if ($path -and (Test-Path -LiteralPath $path)) {
        # Robocopy /L conta bytes sem copiar e evita junction loops com /XJ.
        try {
            $dummy = Join-Path $env:TEMP "profile_measure_$([guid]::NewGuid().ToString('N'))"
            $result = robocopy "$path" "$dummy" /L /S /NFL /NDL /NJH /BYTES /XJ /R:0 /W:0 2>$null
            foreach ($line in $result) {
                if ($line -match 'Bytes\s*:\s*(\d+)') { $size = [int64]$matches[1]; break }
            }
        } catch {}
        if ($size -eq 0) {
            try {
                $fso = New-Object -ComObject Scripting.FileSystemObject
                if ($fso.FolderExists($path)) { $size = [int64]$fso.GetFolder($path).Size }
            } catch {}
        }
        if ($size -eq 0) {
            try {
                $measure = Get-ChildItem -LiteralPath $path -Recurse -Force -File -Attributes !ReparsePoint -ErrorAction SilentlyContinue |
                    Measure-Object -Property Length -Sum
                if ($measure.Sum) { $size = [int64]$measure.Sum }
            } catch {}
        }
    }
    [PSCustomObject]@{ SID = $sid; Size = $size }
}
$jobs = @()
foreach ($profile in $profiles) {
    $running = @($jobs | Where-Object { $_.State -eq 'Running' })
    while ($running.Count -ge 3) {
        Wait-Job -Job $running -Any -Timeout 2 | Out-Null
        $running = @($jobs | Where-Object { $_.State -eq 'Running' })
    }
    $jobs += Start-Job -ScriptBlock $measureProfile -ArgumentList ([string]$profile.LocalPath), ([string]$profile.SID)
}
if ($jobs.Count) {
    Wait-Job -Job $jobs -Timeout 240 | Out-Null
    foreach ($item in @($jobs | Receive-Job -ErrorAction SilentlyContinue)) {
        if ($item.SID) {
            New-ItemProperty -Path ("HKLM:\" + $registryPath) -Name ([string]$item.SID) -Value ([string][int64]$item.Size) -PropertyType String -Force | Out-Null
        }
    }
    $jobs | Stop-Job -ErrorAction SilentlyContinue
    $jobs | Remove-Job -Force -ErrorAction SilentlyContinue
}
New-ItemProperty -Path ("HKLM:\" + $registryPath) -Name 'Done' -Value '1' -PropertyType String -Force | Out-Null
'@
            $remoteScript = $remoteScript.Replace('__REGISTRY_PATH__', $registryPath)
            try {
                $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($remoteScript))
                $remoteProcess = [WMICLASS]"\\$Computer\root\cimv2:Win32_Process"
                $created = $remoteProcess.Create("powershell.exe -NoProfile -ExecutionPolicy Bypass -EncodedCommand $encoded")
                if ($created.ReturnValue -eq 0) {
                    $stdReg = [WMICLASS]"\\$Computer\root\default:StdRegProv"
                    for ($wait = 0; $wait -lt 250; $wait++) {
                        $done = $stdReg.GetStringValue(2147483650, $registryPath, 'Done')
                        if ($done.ReturnValue -eq 0 -and $done.sValue -eq '1') { break }
                        Start-Sleep -Seconds 1
                    }
                    foreach ($profile in $profiles) {
                        $sid = [string]$profile.SID
                        $sizeResult = $stdReg.GetStringValue(2147483650, $registryPath, $sid)
                        if ($sizeResult.ReturnValue -eq 0 -and [int64]$sizeResult.sValue -gt 0) {
                            $profileSizes[$sid] = [int64]$sizeResult.sValue
                        }
                    }
                    $stdReg.DeleteKey(2147483650, $registryPath) | Out-Null
                }
            } catch { Write-Output " Aviso: cálculo remoto complementar indisponível: $($_.Exception.Message)" }
        }

        # Mantém a qualidade da busca: somente perfis sem resposta do cálculo
        # paralelo são medidos novamente pelas rotas UNC C$/D$.
        foreach ($profile in @($profiles | Where-Object { [int64]$profileSizes[[string]$_.SID] -eq 0 })) {
            $profileSizes[[string]$profile.SID] = Get-RemoteFolderSizeBytes -ComputerName $Computer -LocalPath ([string]$profile.LocalPath)
        }

        foreach ($profile in $profiles) {
                $profilePath = [string]$profile.LocalPath
                $lastUse = 'Não informado'
                try {
                    if ($profile.LastUseTime) { $lastUse = $profile.ConvertToDateTime($profile.LastUseTime).ToString('dd/MM/yyyy HH:mm') }
                } catch {}
                $sizeBytes = [double]$profileSizes[[string]$profile.SID]
                $sizeAvailable = $sizeBytes -gt 0
                if ($profilePath -match '^([A-Za-z]):\\(.+)$') {
                    $driveName = "$($matches[1]):"
                } else { $driveName = '' }
                $sizeGb = [math]::Round($sizeBytes / 1GB, 2)
                $diskPercent = 0
                if ($sizeAvailable -and $driveName) {
                    $profileDisk = $diskItems | Where-Object { $_.drive -eq $driveName } | Select-Object -First 1
                    if ($profileDisk -and [double]$profileDisk.total_gb -gt 0) {
                        $diskPercent = [math]::Round(($sizeGb / [double]$profileDisk.total_gb) * 100, 1)
                    }
                }
                $profileUser = if ($profilePath) { Split-Path -Leaf $profilePath } else { [string]$_.SID }
                $profileItems += [ordered]@{
                    user = $profileUser
                    path = $profilePath
                    loaded = [bool]$profile.Loaded
                    sid = [string]$profile.SID
                    last_use = $lastUse
                    size_gb = $sizeGb
                    size_bytes = [int64]$sizeBytes
                    disk_percent = $diskPercent
                    size_available = $sizeAvailable
                }
                $sizeOutput = if ($sizeAvailable) { "$sizeGb GB" } else { 'Não calculado (perfil inacessível)' }
                Write-Output " $profilePath | Tamanho: $sizeOutput | Carregado: $($profile.Loaded) | SID: $($profile.SID)"
        }
        $diagnostic = [ordered]@{
            station = $Computer
            disks = @($diskItems)
            profiles = @($profileItems)
            drive_collection = [string]$script:MappedDriveDiagnostic
            network_drive_count = @($diskItems | Where-Object { $_.kind -eq 'Unidade de rede' }).Count
            interactive_users = @($interactiveUsers)
        }
        Write-Output ("@@DISKPROFILE@@" + ($diagnostic | ConvertTo-Json -Depth 5 -Compress))
    }
    "admin" {
        Require-Computer
        $user = (Get-WmiObject Win32_ComputerSystem -ComputerName $Computer).UserName
        if (!$user) { throw "Não foi possível identificar o usuário conectado." }
        $group = [ADSI]"WinNT://$Computer/Administradores,group"
        $members = @($group.psbase.Invoke('Members')) | ForEach-Object { $_.GetType().InvokeMember('Name','GetProperty',$null,$_,$null) }
        $name = ($user -split '\\')[-1]
        if ($members -contains $name) {
            $group.Remove("WinNT://SENADO/$name,user")
            Write-Output "$user removido dos Administradores locais."
        } else {
            $group.Add("WinNT://SENADO/$name,user")
            Write-Output "$user adicionado aos Administradores locais."
        }
    }
    "admin_set" {
        Require-Computer
        $operation = $Value.Trim().ToLowerInvariant()
        if ($operation -notin @('add','remove')) { throw "Operação administrativa inválida: $Value" }
        $user = (Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
        if (!$user) { throw "Não foi possível identificar o usuário conectado." }
        $group = [ADSI]"WinNT://$Computer/Administradores,group"
        $members = @($group.psbase.Invoke('Members')) | ForEach-Object { $_.GetType().InvokeMember('Name','GetProperty',$null,$_,$null) }
        $name = ($user -split '\\')[-1]
        $isMember = $members -contains $name
        if ($operation -eq 'add') {
            if ($isMember) { Write-Output "$user já pertence aos Administradores locais." }
            else {
                $group.Add("WinNT://SENADO/$name,user")
                Write-Output "$user adicionado aos Administradores locais."
            }
        } else {
            if (!$isMember) { Write-Output "$user já não pertence aos Administradores locais." }
            else {
                $group.Remove("WinNT://SENADO/$name,user")
                Write-Output "$user removido dos Administradores locais."
            }
        }
    }
    default { throw "Ação desconhecida: $Action" }
}
