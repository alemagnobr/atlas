@echo off
setlocal EnableExtensions EnableDelayedExpansion

:: ========================================================
:: CONFIGURACAO DE PERFIL
:: ========================================================
set "DOM=SENADO"
set "LOGIN=%USERNAME%"

:RUN_PS
:: Extrai o codigo PowerShell abaixo do marcador e executa
powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=[System.IO.File]::ReadAllText('%~f0', [System.Text.Encoding]::UTF8); $m='#---'+'PS1---'; $s=[scriptblock]::Create($c.Substring($c.IndexOf($m)+10)); $env:ScriptPath='%~f0'; & $s" %*
if %errorlevel% neq 0 (
    echo.
    echo ========================================================
    echo    O script PowerShell foi encerrado com erro.
    echo ========================================================
    pause
)
exit

#---PS1---
$ErrorActionPreference = "Continue"
$PSCommandPath = $env:ScriptPath
try { $OutputEncoding = [System.Text.Encoding]::UTF8; [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
try { $host.UI.RawUI.WindowTitle = "Atlas - Suporte Avancado - Legada" } catch {}

# Posiciona e redimensiona a janela do console automaticamente no canto direito da tela
try {
    Add-Type -TypeDefinition @"
    using System;
    using System.Runtime.InteropServices;
    public class Win32Helper {
        [DllImport("user32.dll")] public static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);
        [DllImport("user32.dll")] public static extern int GetSystemMetrics(int nIndex);
    }
"@ -ErrorAction SilentlyContinue

    $hwnd = [Win32Helper]::GetConsoleWindow()
    if ($hwnd -ne [IntPtr]::Zero) {
        $screenWidth  = [Win32Helper]::GetSystemMetrics(0)
        $screenHeight = [Win32Helper]::GetSystemMetrics(1)
        $width  = [math]::Floor($screenWidth * 0.48)
        $height = $screenHeight - 40
        $x      = $screenWidth - $width
        $y      = 0
        [Win32Helper]::MoveWindow($hwnd, $x, $y, $width, $height, $true)
    }
} catch {}
$DOM = "SENADO"
$LOGIN = $env:USERNAME
$WINDOWS_IDENTITY = try { [Security.Principal.WindowsIdentity]::GetCurrent().Name } catch { "$DOM\$LOGIN" }

# Modos de inicializacao:
# - abertura normal: sempre inicia como Usuario Padrao
# - /ins: libera o menu administrativo somente se a sessao for realmente INS/Admin
# - /noadmin: forca o perfil padrao
$forceNoAdmin = ($args -contains "/noadmin") -or ($env:FORCENOADMIN -eq "1")
$requestedIns = ($args -contains "/ins")

# Verifica se o usuario atual ja e do perfil INS ou possui Privilegios de Administrador
$isInsAccount = ($LOGIN -match '_ins')
$isAdminRole  = try { ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch { $false }

if ($forceNoAdmin) {
    $NoAdmin = $true
} elseif ($requestedIns -and ($isInsAccount -or $isAdminRole)) {
    # O acesso completo so ocorre apos escolher "Logar como INS" no menu.
    $NoAdmin = $false
} else {
    # Mesmo que o BAT seja aberto por uma conta INS/Admin, a primeira tela
    # sera sempre a de Usuario Padrao.
    $NoAdmin = $true
}

$INS = "$DOM\$LOGIN"
$CONECTADO_COMP = $null
$CONECTADO_STATUS = $null
$CONECTADO_USER = $null
$CONECTADO_UPTIME = $null
$CONECTADO_SERIAL = $null
$CONECTADO_SCCM = $null
$CONECTADO_PRINTERS = $null
$CONECTADO_AD_PRINTERS = $null
$CMRC_LOCAL_STATUS = $null

function Get-LocalCmRcViewerStatus {
    if ($script:CMRC_LOCAL_STATUS -ne $null) {
        return $script:CMRC_LOCAL_STATUS
    }
    
    $paths = @("CmRcViewer.exe")
    if (![string]::IsNullOrWhiteSpace($env:SMS_ADMIN_UI_PATH)) {
        $paths += Join-Path $env:SMS_ADMIN_UI_PATH "i386\CmRcViewer.exe"
        $paths += Join-Path $env:SMS_ADMIN_UI_PATH "CmRcViewer.exe"
    }
    
    $baseDirs = @(
        "C:\Program Files (x86)\Microsoft Endpoint Manager\AdminConsole\bin",
        "C:\Program Files\Microsoft Endpoint Manager\AdminConsole\bin",
        "C:\Program Files (x86)\Microsoft Configuration Manager\AdminConsole\bin",
        "C:\Program Files\Microsoft Configuration Manager\bin"
    )
    
    foreach ($dir in $baseDirs) {
        if (Test-Path $dir) {
            $paths += Join-Path $dir "i386\CmRcViewer.exe"
            $paths += Join-Path $dir "CmRcViewer.exe"
        }
    }
    
    if (![string]::IsNullOrWhiteSpace($PSCommandPath)) {
        $scriptDir = Split-Path $PSCommandPath
        $paths += Join-Path $scriptDir "CmRcViewer.exe"
    }
    
    foreach ($p in $paths) {
        if ($p -eq "CmRcViewer.exe") {
            $resolved = Get-Command "CmRcViewer.exe" -ErrorAction SilentlyContinue
            if ($resolved) {
                $script:CMRC_LOCAL_STATUS = "Instalado (Disponivel no PATH)"
                return $script:CMRC_LOCAL_STATUS
            }
        } elseif (Test-Path $p) {
            $script:CMRC_LOCAL_STATUS = "Instalado ($p)"
            return $script:CMRC_LOCAL_STATUS
        }
    }
    
    $progFiles = @($env:ProgramFiles, "$env:SystemDrive\Program Files (x86)")
    foreach ($pf in $progFiles) {
        if ([string]::IsNullOrWhiteSpace($pf)) { continue }
        if (Test-Path "$pf\Microsoft Endpoint Manager") {
            $found = Get-ChildItem -Path "$pf\Microsoft Endpoint Manager" -Filter "CmRcViewer.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
            if ($found) {
                $script:CMRC_LOCAL_STATUS = "Instalado ($found)"
                return $script:CMRC_LOCAL_STATUS
            }
        }
        if (Test-Path "$pf\Microsoft Configuration Manager") {
            $found = Get-ChildItem -Path "$pf\Microsoft Configuration Manager" -Filter "CmRcViewer.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
            if ($found) {
                $script:CMRC_LOCAL_STATUS = "Instalado ($found)"
                return $script:CMRC_LOCAL_STATUS
            }
        }
    }
    
    try {
        $downloadsFound = Get-ChildItem -Path "$HOME\Downloads" -Filter "CmRcViewer.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
        if ($downloadsFound) {
            $script:CMRC_LOCAL_STATUS = "Instalado ($downloadsFound)"
            return $script:CMRC_LOCAL_STATUS
        }
    } catch {}

    $script:CMRC_LOCAL_STATUS = "Nao Instalado"
    return $script:CMRC_LOCAL_STATUS
}

function Test-UserIsLocalAdmin {
    param(
        [string]$computerName,
        [string]$targetUser
    )
    if ([string]::IsNullOrWhiteSpace($computerName) -or [string]::IsNullOrWhiteSpace($targetUser) -or $targetUser -eq "Nenhum usuario logado" -or $targetUser -eq "Nao foi possivel consultar" -or $targetUser -eq "-") {
        return $false
    }
    
    $cleanComp = $computerName.Trim().Replace('\', '')
    $cleanUser = $targetUser.Trim()
    
    $userDomain = "SENADO"
    $userNameOnly = $cleanUser
    if ($cleanUser -match '\\') {
        $parts = $cleanUser -split '\\', 2
        $userDomain = $parts[0]
        $userNameOnly = $parts[1]
    }

    $adminGroup = "Administradores"
    try {
        $sid = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-544")
        $translated = $sid.Translate([System.Security.Principal.NTAccount]).Value
        if ($translated -match '\\') {
            $adminGroup = $translated.Split('\')[-1]
        } else {
            $adminGroup = $translated
        }
    } catch {}

    # Metodo 1: ADSI WinNT Provider
    try {
        $groupObj = [ADSI]"WinNT://$cleanComp/$adminGroup,group"
        $mList = $groupObj.psbase.Invoke('Members')
        foreach ($m in $mList) {
            $mPath = $m.GetType().InvokeMember('ADSPath', 'GetProperty', $null, $m, $null)
            $mName = $m.GetType().InvokeMember('Name', 'GetProperty', $null, $m, $null)
            if ($mName -eq $userNameOnly -or $mPath -like "*$userDomain/$userNameOnly*" -or $mPath -like "*$userNameOnly*") {
                return $true
            }
        }
    } catch {}

    # Metodo 2: net localgroup via cmd/WMI
    try {
        $cmdOut = cmd.exe /c "net localgroup ""$adminGroup"" 2>&1"
        foreach ($line in $cmdOut) {
            if ($line -like "*$userNameOnly*") {
                return $true
            }
        }
    } catch {}

    return $false
}

function Test-UserIsRdpUser {
    param(
        [string]$computerName,
        [string]$targetUser
    )
    if ([string]::IsNullOrWhiteSpace($computerName) -or [string]::IsNullOrWhiteSpace($targetUser) -or $targetUser -eq "Nenhum usuario logado" -or $targetUser -eq "Nao foi possivel consultar" -or $targetUser -eq "-") {
        return $false
    }
    
    $cleanComp = $computerName.Trim().Replace('\', '')
    $cleanUser = $targetUser.Trim()
    
    $userDomain = "SENADO"
    $userNameOnly = $cleanUser
    if ($cleanUser -match '\\') {
        $parts = $cleanUser -split '\\', 2
        $userDomain = $parts[0]
        $userNameOnly = $parts[1]
    }

    $rdpGroup = "Usuarios da area de trabalho remota"
    try {
        $sid = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-555")
        $translated = $sid.Translate([System.Security.Principal.NTAccount]).Value
        if ($translated -match '\\') {
            $rdpGroup = $translated.Split('\')[-1]
        } else {
            $rdpGroup = $translated
        }
    } catch {}

    # Metodo 1: ADSI WinNT Provider
    try {
        $groupObj = [ADSI]"WinNT://$cleanComp/$rdpGroup,group"
        $mList = $groupObj.psbase.Invoke('Members')
        foreach ($m in $mList) {
            $mPath = $m.GetType().InvokeMember('ADSPath', 'GetProperty', $null, $m, $null)
            $mName = $m.GetType().InvokeMember('Name', 'GetProperty', $null, $m, $null)
            if ($mName -eq $userNameOnly -or $mPath -like "*$userDomain/$userNameOnly*" -or $mPath -like "*$userNameOnly*") {
                return $true
            }
        }
    } catch {}

    # Metodo 2: net localgroup via cmd/WMI
    try {
        $cmdOut = cmd.exe /c "net localgroup ""$rdpGroup"" 2>&1"
        foreach ($line in $cmdOut) {
            if ($line -like "*$userNameOnly*") {
                return $true
            }
        }
    } catch {}

    # Metodo 3: Variacoes do nome do grupo
    $groupVariations = @("Remote Desktop Users", "Usuarios da area de trabalho remota", "Usuarios do Trabalho Remoto")
    foreach ($gVar in $groupVariations) {
        if ($gVar -ne $rdpGroup) {
            try {
                $groupObj = [ADSI]"WinNT://$cleanComp/$gVar,group"
                $mList = $groupObj.psbase.Invoke('Members')
                foreach ($m in $mList) {
                    $mPath = $m.GetType().InvokeMember('ADSPath', 'GetProperty', $null, $m, $null)
                    $mName = $m.GetType().InvokeMember('Name', 'GetProperty', $null, $m, $null)
                    if ($mName -eq $userNameOnly -or $mPath -like "*$userDomain/$userNameOnly*" -or $mPath -like "*$userNameOnly*") {
                        return $true
                    }
                }
            } catch {}
        }
    }

    return $false
}

function Convert-PrinterNameToUNC {
    param([string]$raw)
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    $str = $raw.Trim()

    # Ignora se for puramente GUID
    if ($str -match '^\{[0-9a-fA-F\-]{32,38}\}$') { return $null }

    if ($str -like "\\*\*") {
        $cleanUNC = $str -replace ",", "\"
        # Se contem GUID no caminho: \\server\{GUID}\share -> \\server\share
        if ($cleanUNC -match '^\\\\([^\\]+)\\\{[0-9a-fA-F\-]{32,38}\}\\(.+)$') {
            $cleanUNC = "\\$($Matches[1])\$($Matches[2])"
        }
        return $cleanUNC
    }

    if ($str -match "^,") {
        $clean = $str -replace "^,+s,", "" -replace "^,+p,", "" -replace "^,+", ""
        if ($clean -match ",") {
            $parts = @($clean -split "," | Where-Object { ![string]::IsNullOrWhiteSpace($_) })
            if ($parts.Count -ge 2) {
                $server = $parts[0].Trim()
                # Pega a ultima parte que nao seja GUID
                $printerName = ""
                for ($i = $parts.Count - 1; $i -ge 1; $i--) {
                    $p = $parts[$i].Trim()
                    if ($p -notmatch '^\{[0-9a-fA-F\-]{32,38}\}$') {
                        $printerName = $p
                        break
                    }
                }
                if (![string]::IsNullOrWhiteSpace($server) -and ![string]::IsNullOrWhiteSpace($printerName)) {
                    return "\\$server\$printerName"
                }
            }
        }
    }

    if ($str -match "^[a-zA-Z0-9\.\-]+,[a-zA-Z0-9\.\-_]+$") {
        $parts = $str -split ","
        return "\\$($parts[0].Trim())\$($parts[1].Trim())"
    }

    return $null
}

function Get-RemoteInstalledPrinters {
    param([string]$computerName)

    $printerList = [System.Collections.Generic.List[string]]::new()
    if ([string]::IsNullOrWhiteSpace($computerName)) { return @() }
    $cleanComp = $computerName.Replace('\', '').Trim()
    if ([string]::IsNullOrWhiteSpace($cleanComp)) { return @() }

    $virtualFilter = "(?i)PDF|OneNote|XPS|Fax|Microsoft|Send To|Root|CutePDF|Virtual|Generic|Document Writer"

    $addPrinter = {
        param([string]$pStr)
        if ([string]::IsNullOrWhiteSpace($pStr)) { return }
        $unc = Convert-PrinterNameToUNC $pStr
        $target = if ($unc) { $unc } else { $pStr.Trim() }
        
        # Filtra impressoras virtuais e GUIDs
        if ($target -match $virtualFilter) { return }
        if ($target -match '\{[0-9a-fA-F\-]{32,38}\}') { return }
        if ($target -match '^\\+\s*$') { return }
        
        # Se for formato \\servidor\compartilhamento
        if ($target -match '^\\\\([^\\]+)\\(.+)$') {
            $srv = $Matches[1]
            $prt = $Matches[2]
            if ($prt -match '\{[0-9a-fA-F\-]{32,38}\}') { return }
            $target = "\\$srv\$prt"
        }

        if (![string]::IsNullOrWhiteSpace($target) -and !$printerList.Contains($target)) {
            [void]$printerList.Add($target)
        }
    }

    # 1. HKLM e HKU via RemoteRegistry (se servico RemoteRegistry estiver ativo)
    try {
        $regLM = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $cleanComp)
        if ($regLM) {
            # A) HKLM Connections
            try {
                $connKey = $regLM.OpenSubKey("SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Connections")
                if ($connKey) {
                    foreach ($sub in $connKey.GetSubKeyNames()) { &$addPrinter $sub }
                    $connKey.Close()
                }
            } catch {}

            # B) HKLM Client Side Rendering (CSR) Cache
            try {
                $csrServersKey = $regLM.OpenSubKey("SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Providers\Client Side Rendering Print Provider\Servers")
                if ($csrServersKey) {
                    foreach ($srv in $csrServersKey.GetSubKeyNames()) {
                        try {
                            $prtsKey = $csrServersKey.OpenSubKey("$srv\Printers")
                            if ($prtsKey) {
                                foreach ($pSub in $prtsKey.GetSubKeyNames()) {
                                    if ($pSub -match '^\{[0-9a-fA-F\-]{32,38}\}$') {
                                        try {
                                            $guidKey = $prtsKey.OpenSubKey($pSub)
                                            if ($guidKey) {
                                                $realName = $guidKey.GetValue("PrinterName")
                                                if ([string]::IsNullOrWhiteSpace($realName)) {
                                                    $realName = $guidKey.GetValue("ShareName")
                                                }
                                                if (![string]::IsNullOrWhiteSpace($realName)) {
                                                    &$addPrinter "\\$srv\$realName"
                                                }
                                                $guidKey.Close()
                                            }
                                        } catch {}
                                    } else {
                                        &$addPrinter "\\$srv\$pSub"
                                    }
                                }
                                $prtsKey.Close()
                            }
                        } catch {}
                    }
                    $csrServersKey.Close()
                }
            } catch {}

            # C) HKLM LanMan Print Services
            try {
                $lanmanKey = $regLM.OpenSubKey("SYSTEM\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers")
                if ($lanmanKey) {
                    foreach ($srv in $lanmanKey.GetSubKeyNames()) {
                        try {
                            $prtsKey = $lanmanKey.OpenSubKey("$srv\Printers")
                            if ($prtsKey) {
                                foreach ($pShare in $prtsKey.GetSubKeyNames()) {
                                    &$addPrinter "\\$srv\$pShare"
                                }
                                $prtsKey.Close()
                            }
                        } catch {}
                    }
                    $lanmanKey.Close()
                }
            } catch {}

            # D) HKLM Printers Locais
            try {
                $printKey = $regLM.OpenSubKey("SYSTEM\CurrentControlSet\Control\Print\Printers")
                if ($printKey) {
                    foreach ($pSubName in $printKey.GetSubKeyNames()) { &$addPrinter $pSubName }
                    $printKey.Close()
                }
            } catch {}

            $regLM.Close()
        }
    } catch {}

    try {
        $regUsers = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::Users, $cleanComp)
        if ($regUsers) {
            foreach ($sid in $regUsers.GetSubKeyNames()) {
                if ($sid -match "Classes$|^\.DEFAULT$|^S-1-5-18$|^S-1-5-19$|^S-1-5-20$") { continue }
                
                # HKU\<SID>\Printers\Connections
                try {
                    $connKey = $regUsers.OpenSubKey("$sid\Printers\Connections")
                    if ($connKey) {
                        foreach ($sub in $connKey.GetSubKeyNames()) { &$addPrinter $sub }
                        $connKey.Close()
                    }
                } catch {}

                # HKU\<SID>\Software\Microsoft\Windows NT\CurrentVersion\PrinterPorts
                try {
                    $portsKey = $regUsers.OpenSubKey("$sid\Software\Microsoft\Windows NT\CurrentVersion\PrinterPorts")
                    if ($portsKey) {
                        foreach ($vName in $portsKey.GetValueNames()) { &$addPrinter $vName }
                        $portsKey.Close()
                    }
                } catch {}

                # HKU\<SID>\Software\Microsoft\Windows NT\CurrentVersion\Devices
                try {
                    $devKey = $regUsers.OpenSubKey("$sid\Software\Microsoft\Windows NT\CurrentVersion\Devices")
                    if ($devKey) {
                        foreach ($vName in $devKey.GetValueNames()) { &$addPrinter $vName }
                        $devKey.Close()
                    }
                } catch {}
            }
            $regUsers.Close()
        }
    } catch {}

    # 2. WMI StdRegProv Fallback (Garante consulta no registro remoto mesmo com o servico RemoteRegistry desativado)
    try {
        $stdReg = [WMICLASS]"\\$cleanComp\root\default:StdRegProv"
        if ($stdReg) {
            $HKEY_LOCAL_MACHINE = 2147483650
            $HKEY_USERS         = 2147483651

            # A) HKLM Connections
            $resConn = $stdReg.EnumKey($HKEY_LOCAL_MACHINE, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Connections")
            if ($resConn -and $resConn.ReturnValue -eq 0 -and $resConn.sNames) {
                foreach ($sub in $resConn.sNames) { &$addPrinter $sub }
            }

            # B) HKLM CSR Servers
            $resCsr = $stdReg.EnumKey($HKEY_LOCAL_MACHINE, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Providers\Client Side Rendering Print Provider\Servers")
            if ($resCsr -and $resCsr.ReturnValue -eq 0 -and $resCsr.sNames) {
                foreach ($srv in $resCsr.sNames) {
                    $resPrts = $stdReg.EnumKey($HKEY_LOCAL_MACHINE, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Providers\Client Side Rendering Print Provider\Servers\$srv\Printers")
                    if ($resPrts -and $resPrts.ReturnValue -eq 0 -and $resPrts.sNames) {
                        foreach ($pSub in $resPrts.sNames) {
                            if ($pSub -match '^\{[0-9a-fA-F\-]{32,38}\}$') {
                                $resVal = $stdReg.GetStringValue($HKEY_LOCAL_MACHINE, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Providers\Client Side Rendering Print Provider\Servers\$srv\Printers\$pSub", "PrinterName")
                                $realName = if ($resVal -and $resVal.ReturnValue -eq 0) { $resVal.sValue } else { "" }
                                if ([string]::IsNullOrWhiteSpace($realName)) {
                                    $resValShare = $stdReg.GetStringValue($HKEY_LOCAL_MACHINE, "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Providers\Client Side Rendering Print Provider\Servers\$srv\Printers\$pSub", "ShareName")
                                    $realName = if ($resValShare -and $resValShare.ReturnValue -eq 0) { $resValShare.sValue } else { "" }
                                }
                                if (![string]::IsNullOrWhiteSpace($realName)) {
                                    &$addPrinter "\\$srv\$realName"
                                }
                            } else {
                                &$addPrinter "\\$srv\$pSub"
                            }
                        }
                    }
                }
            }

            # C) HKLM LanMan Servers
            $resLan = $stdReg.EnumKey($HKEY_LOCAL_MACHINE, "SYSTEM\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers")
            if ($resLan -and $resLan.ReturnValue -eq 0 -and $resLan.sNames) {
                foreach ($srv in $resLan.sNames) {
                    $resPrts = $stdReg.EnumKey($HKEY_LOCAL_MACHINE, "SYSTEM\CurrentControlSet\Control\Print\Providers\LanMan Print Services\Servers\$srv\Printers")
                    if ($resPrts -and $resPrts.ReturnValue -eq 0 -and $resPrts.sNames) {
                        foreach ($pShare in $resPrts.sNames) {
                            &$addPrinter "\\$srv\$pShare"
                        }
                    }
                }
            }

            # D) HKU Users
            $resUsers = $stdReg.EnumKey($HKEY_USERS, "")
            if ($resUsers -and $resUsers.ReturnValue -eq 0 -and $resUsers.sNames) {
                foreach ($sid in $resUsers.sNames) {
                    if ($sid -match "Classes$|^\.DEFAULT$|^S-1-5-18$|^S-1-5-19$|^S-1-5-20$") { continue }

                    # HKU\<SID>\Printers\Connections
                    $resUserConn = $stdReg.EnumKey($HKEY_USERS, "$sid\Printers\Connections")
                    if ($resUserConn -and $resUserConn.ReturnValue -eq 0 -and $resUserConn.sNames) {
                        foreach ($sub in $resUserConn.sNames) { &$addPrinter $sub }
                    }

                    # HKU\<SID>\Software\Microsoft\Windows NT\CurrentVersion\PrinterPorts
                    $resUserPorts = $stdReg.EnumValues($HKEY_USERS, "$sid\Software\Microsoft\Windows NT\CurrentVersion\PrinterPorts")
                    if ($resUserPorts -and $resUserPorts.ReturnValue -eq 0 -and $resUserPorts.sNames) {
                        foreach ($vName in $resUserPorts.sNames) { &$addPrinter $vName }
                    }

                    # HKU\<SID>\Software\Microsoft\Windows NT\CurrentVersion\Devices
                    $resUserDevs = $stdReg.EnumValues($HKEY_USERS, "$sid\Software\Microsoft\Windows NT\CurrentVersion\Devices")
                    if ($resUserDevs -and $resUserDevs.ReturnValue -eq 0 -and $resUserDevs.sNames) {
                        foreach ($vName in $resUserDevs.sNames) { &$addPrinter $vName }
                    }
                }
            }
        }
    } catch {}

    # 3. WMI Win32_Printer
    try {
        $wmiPrinters = Get-WmiObject -Class Win32_Printer -ComputerName $cleanComp -ErrorAction SilentlyContinue
        if ($wmiPrinters) {
            foreach ($p in $wmiPrinters) {
                if (![string]::IsNullOrWhiteSpace($p.Name)) { &$addPrinter $p.Name }
                if (![string]::IsNullOrWhiteSpace($p.PortName) -and $p.PortName -like "\\*") { &$addPrinter $p.PortName }
                if (![string]::IsNullOrWhiteSpace($p.ServerName) -and ![string]::IsNullOrWhiteSpace($p.ShareName)) {
                    $sClean = $p.ServerName.TrimStart('\')
                    &$addPrinter "\\$sClean\$($p.ShareName)"
                }
            }
        }
    } catch {}

    return [string[]]$printerList.ToArray()
}

function Get-RemoteDefaultPrinter {
    param([string]$computerName, [string]$loggedUser)

    if ([string]::IsNullOrWhiteSpace($computerName)) { return $null }
    $cleanComp = $computerName.Replace('\', '').Trim()
    if ([string]::IsNullOrWhiteSpace($cleanComp)) { return $null }

    # 1. Tentar via HKU (Registry remoto) nos perfis de usuarios carregados
    try {
        $regUsers = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::Users, $cleanComp)
        if ($regUsers) {
            foreach ($sid in $regUsers.GetSubKeyNames()) {
                if ($sid -match "Classes$|^\.DEFAULT$|^S-1-5-18$|^S-1-5-19$|^S-1-5-20$") { continue }
                
                try {
                    $winKey = $regUsers.OpenSubKey("$sid\Software\Microsoft\Windows NT\CurrentVersion\Windows")
                    if ($winKey) {
                        $devVal = $winKey.GetValue("Device")
                        if (![string]::IsNullOrWhiteSpace($devVal)) {
                            $defName = ($devVal -split ',')[0].Trim()
                            if (![string]::IsNullOrWhiteSpace($defName) -and $defName -notmatch '^\{[0-9a-fA-F\-]{32,38}\}') {
                                $unc = Convert-PrinterNameToUNC $defName
                                $res = if ($unc) { $unc } else { $defName }
                                $winKey.Close()
                                $regUsers.Close()
                                return $res
                            }
                        }
                        $winKey.Close()
                    }
                } catch {}
            }
            $regUsers.Close()
        }
    } catch {}

    # 2. WMI StdRegProv Fallback (HKU Device)
    try {
        $stdReg = [WMICLASS]"\\$cleanComp\root\default:StdRegProv"
        if ($stdReg) {
            $HKEY_USERS = 2147483651
            $resUsers = $stdReg.EnumKey($HKEY_USERS, "")
            if ($resUsers -and $resUsers.ReturnValue -eq 0 -and $resUsers.sNames) {
                foreach ($sid in $resUsers.sNames) {
                    if ($sid -match "Classes$|^\.DEFAULT$|^S-1-5-18$|^S-1-5-19$|^S-1-5-20$") { continue }
                    $resVal = $stdReg.GetStringValue($HKEY_USERS, "$sid\Software\Microsoft\Windows NT\CurrentVersion\Windows", "Device")
                    if ($resVal -and $resVal.ReturnValue -eq 0 -and ![string]::IsNullOrWhiteSpace($resVal.sValue)) {
                        $defName = ($resVal.sValue -split ',')[0].Trim()
                        if (![string]::IsNullOrWhiteSpace($defName) -and $defName -notmatch '^\{[0-9a-fA-F\-]{32,38}\}') {
                            $unc = Convert-PrinterNameToUNC $defName
                            return (if ($unc) { $unc } else { $defName })
                        }
                    }
                }
            }
        }
    } catch {}

    # 3. WMI Win32_Printer Default = True
    try {
        $wmiDef = Get-WmiObject -Class Win32_Printer -ComputerName $cleanComp -Filter "Default=True" -ErrorAction SilentlyContinue
        if ($wmiDef) {
            $pName = if (![string]::IsNullOrWhiteSpace($wmiDef.Name)) { $wmiDef.Name } else { $wmiDef.ShareName }
            if (![string]::IsNullOrWhiteSpace($pName)) {
                $unc = Convert-PrinterNameToUNC $pName
                return (if ($unc) { $unc } else { $pName.Trim() })
            }
        }
    } catch {}

    return $null
}

function Get-RemoteWinVersion {
    param([string]$computerName)
    if ([string]::IsNullOrWhiteSpace($computerName)) { return "-" }
    $cleanComp = $computerName.Replace('\', '').Trim()

    try {
        $os = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $cleanComp -ErrorAction Stop
        $caption = $os.Caption -replace "Microsoft\s*", "" -replace "[^a-zA-Z0-9\s\.\-]", ""
        $caption = $caption.Trim()
        $build = $os.BuildNumber

        # Se Build >= 22000, eh Windows 11 mesmo que WMI Caption Diga Windows 10
        if ([int]$build -ge 22000 -and $caption -match "Windows 10") {
            $caption = $caption -replace "Windows 10", "Windows 11"
        }

        # Obter DisplayVersion / ReleaseId e UBR do Registro do PC Remoto
        $displayVer = ""
        $ubr = ""
        try {
            $regLM = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $cleanComp)
            if ($regLM) {
                $cvKey = $regLM.OpenSubKey("SOFTWARE\Microsoft\Windows NT\CurrentVersion")
                if ($cvKey) {
                    $disp = $cvKey.GetValue("DisplayVersion")
                    if ([string]::IsNullOrWhiteSpace($disp)) {
                        $disp = $cvKey.GetValue("ReleaseId")
                    }
                    if (![string]::IsNullOrWhiteSpace($disp)) {
                        $displayVer = $disp
                    }

                    $u = $cvKey.GetValue("UBR")
                    if ($null -ne $u) {
                        $ubr = $u
                    }
                    $cvKey.Close()
                }
                $regLM.Close()
            }
        } catch {}

        # Montar a versao detalhada (Ex: Windows 11 Pro 23H2 (Build 22631.3880))
        $fullVer = $caption
        if (![string]::IsNullOrWhiteSpace($displayVer)) {
            $fullVer += " $displayVer"
        }

        if (![string]::IsNullOrWhiteSpace($ubr)) {
            $fullVer += " (Build $build.$ubr)"
        } elseif (![string]::IsNullOrWhiteSpace($build)) {
            $fullVer += " (Build $build)"
        }

        return $fullVer.Trim()
    } catch {
        return "Nao foi possivel consultar"
    }
}

function Set-ConnectedComputer {
    param($compName)
    if ([string]::IsNullOrWhiteSpace($compName)) {
        return
    }
    $cleanComp = $compName.Trim().Replace('\', '')
    $script:CONECTADO_COMP = $cleanComp
    $script:CONECTADO_TIME = Get-Date
    
    Write-Host ""
    Write-Host "Conectando e consultando informacoes de $cleanComp..." -ForegroundColor Cyan
    
    $pingResult = Test-Connection -ComputerName $cleanComp -Count 1 -ErrorAction SilentlyContinue
    if ($pingResult) {
        $ms = $pingResult.ResponseTime
        if ($null -eq $ms -or $ms -eq "") { $ms = $pingResult.Latency }
        if ($null -ne $ms -and $ms -ne "") {
            $script:CONECTADO_STATUS = "Conectado (Ping $($ms)ms)"
        } else {
            $script:CONECTADO_STATUS = "Conectado (Ping OK)"
        }
        
        # Consultar Usuario Logado via WMI
        try {
            $cs = Get-WmiObject -ComputerName $cleanComp -Class Win32_ComputerSystem -ErrorAction Stop
            if (![string]::IsNullOrWhiteSpace($cs.UserName)) {
                $script:CONECTADO_USER = $cs.UserName
            } else {
                $script:CONECTADO_USER = "Nenhum usuario logado"
            }
        } catch {
            $script:CONECTADO_USER = "Nao foi possivel consultar"
        }

        # Consultar Versao Completa do Windows Remoto
        try {
            $script:CONECTADO_WIN_VER = Get-RemoteWinVersion -computerName $cleanComp
        } catch {
            $script:CONECTADO_WIN_VER = "Nao foi possivel consultar"
        }

        # Consultar Status de Admin Local do Usuario Logado
        try {
            if (![string]::IsNullOrWhiteSpace($script:CONECTADO_USER) -and $script:CONECTADO_USER -ne "Nenhum usuario logado" -and $script:CONECTADO_USER -ne "Nao foi possivel consultar") {
                $isLocalAdmin = Test-UserIsLocalAdmin -computerName $cleanComp -targetUser $script:CONECTADO_USER
                if ($isLocalAdmin) {
                    $script:CONECTADO_IS_ADMIN = "SIM ($script:CONECTADO_USER)"
                } else {
                    $script:CONECTADO_IS_ADMIN = "NAO ($script:CONECTADO_USER)"
                }
            } else {
                $script:CONECTADO_IS_ADMIN = "-"
            }
        } catch {
            $script:CONECTADO_IS_ADMIN = "Nao foi possivel consultar"
        }

        # Consultar Status de Area de Trabalho Remota (RDP) do Usuario Logado
        try {
            if (![string]::IsNullOrWhiteSpace($script:CONECTADO_USER) -and $script:CONECTADO_USER -ne "Nenhum usuario logado" -and $script:CONECTADO_USER -ne "Nao foi possivel consultar") {
                $isRdpUser = Test-UserIsRdpUser -computerName $cleanComp -targetUser $script:CONECTADO_USER
                if ($isRdpUser) {
                    $script:CONECTADO_IS_RDP = "SIM ($script:CONECTADO_USER)"
                } else {
                    $script:CONECTADO_IS_RDP = "NAO ($script:CONECTADO_USER)"
                }
            } else {
                $script:CONECTADO_IS_RDP = "-"
            }
        } catch {
            $script:CONECTADO_IS_RDP = "Nao foi possivel consultar"
        }

        # Consultar Tempo de Atividade (Boot/Uptime) via WMI
        try {
            $os = Get-WmiObject -ComputerName $cleanComp -Class Win32_OperatingSystem -ErrorAction Stop
            $lastBootTime = $os.ConvertToDateTime($os.LastBootUpTime)
            $uptime = (Get-Date) - $lastBootTime
            $script:CONECTADO_UPTIME = "$($uptime.Days)d $($uptime.Hours)h $($uptime.Minutes)m (Boot: $($lastBootTime.ToString('dd/MM HH:mm')))"
        } catch {
            $script:CONECTADO_UPTIME = "Nao foi possivel consultar"
        }

        # Consultar Service Tag / Serial da BIOS via WMI
        try {
            $bios = Get-WmiObject win32_bios -ComputerName $cleanComp -ErrorAction Stop
            if (![string]::IsNullOrWhiteSpace($bios.SerialNumber)) {
                $script:CONECTADO_SERIAL = $bios.SerialNumber.Trim()
            } else {
                $script:CONECTADO_SERIAL = "Nao identificado"
            }
        } catch {
            $script:CONECTADO_SERIAL = "Nao foi possivel consultar"
        }

        # Consultar Agente SCCM Remoto (CcmExec) via WMI
        try {
            $sccmSvc = Get-WmiObject -ComputerName $cleanComp -Class Win32_Service -Filter "Name='CcmExec'" -ErrorAction Stop
            if ($sccmSvc) {
                if ($sccmSvc.State -eq "Running") {
                    $script:CONECTADO_SCCM = "Instalado (Em execucao)"
                } else {
                    $script:CONECTADO_SCCM = "Instalado ($($sccmSvc.State))"
                }
            } else {
                $script:CONECTADO_SCCM = "Nao Instalado"
            }
        } catch {
            $script:CONECTADO_SCCM = "Nao foi possivel consultar"
        }

        # Consultar Impressoras de Rede Remotas (HKLM, HKU e WMI)
        try {
            $printerList = Get-RemoteInstalledPrinters -computerName $cleanComp
            if ($printerList.Count -gt 0) {
                $script:CONECTADO_PRINTERS = ($printerList -join ", ")
            } else {
                $script:CONECTADO_PRINTERS = "Nenhuma impressora de rede encontrada"
            }
        } catch {
            $script:CONECTADO_PRINTERS = "Nao foi possivel consultar"
        }

        # Consultar Impressora Padrao Remota
        try {
            $defP = Get-RemoteDefaultPrinter -computerName $cleanComp -loggedUser $script:CONECTADO_USER
            if (![string]::IsNullOrWhiteSpace($defP)) {
                $script:CONECTADO_DEFAULT_PRINTER = $defP
            } else {
                $script:CONECTADO_DEFAULT_PRINTER = "Nenhuma definida"
            }
        } catch {
            $script:CONECTADO_DEFAULT_PRINTER = "Nao foi possivel consultar"
        }

        # Consultar Grupos de Impressora no AD (OU=Impressoras_OU) para o Usuario Logado
        try {
            if (![string]::IsNullOrWhiteSpace($script:CONECTADO_USER) -and $script:CONECTADO_USER -ne "Nenhum usuario logado" -and $script:CONECTADO_USER -ne "Nao foi possivel consultar") {
                $cleanUser = $script:CONECTADO_USER
                if ($cleanUser -match '\\') {
                    $cleanUser = ($cleanUser -split '\\')[-1]
                }
                
                $uSearcher = [adsisearcher]"(&(objectCategory=user)(sAMAccountName=$cleanUser))"
                $uResult = $uSearcher.FindOne()
                
                if ($uResult) {
                    $uDN = $uResult.Properties["distinguishedname"][0]
                    $userGroupsDNs = [System.Collections.Generic.List[string]]::new()
                    $userGroupsDNs.Add($uDN)
                    
                    if ($uResult.Properties["memberof"]) {
                        foreach ($mIn in $uResult.Properties["memberof"]) {
                            if (!$userGroupsDNs.Contains($mIn)) {
                                $userGroupsDNs.Add($mIn)
                            }
                        }
                    }
                    
                    $domainDN = ([ADSI]"LDAP://RootDSE").defaultNamingContext
                    $pSearcher = [adsisearcher]"(&(objectCategory=group)(sAMAccountName=*-ImprimirDoc))"
                    try {
                        $pSearcher.SearchRoot = [ADSI]"LDAP://OU=Impressoras_OU,$domainDN"
                    } catch {}
                    
                    $pResults = $pSearcher.FindAll()
                    $foundADPrinters = [System.Collections.Generic.List[string]]::new()
                    
                    foreach ($pRes in $pResults) {
                        $pGroupName = $pRes.Properties["samaccountname"][0]
                        $pGroupObj = $pRes.GetDirectoryEntry()
                        $members = $pGroupObj.Properties["member"]
                        
                        $hasPerm = $false
                        foreach ($mDN in $members) {
                            if ($userGroupsDNs.Contains($mDN)) {
                                $hasPerm = $true
                                break
                            }
                        }
                        
                        if ($hasPerm) {
                            $code = $pGroupName -replace "-ImprimirDoc$", ""
                            if (!$foundADPrinters.Contains($code)) {
                                $foundADPrinters.Add($code)
                            }
                        }
                    }
                    
                    if ($foundADPrinters.Count -gt 0) {
                        $script:CONECTADO_AD_PRINTERS = ($foundADPrinters -join ", ")
                    } else {
                        $script:CONECTADO_AD_PRINTERS = "Nenhum grupo localizado no AD"
                    }
                } else {
                    $script:CONECTADO_AD_PRINTERS = "Usuario nao encontrado no AD"
                }
            } else {
                $script:CONECTADO_AD_PRINTERS = "-"
            }
        } catch {
            $script:CONECTADO_AD_PRINTERS = "Nao foi possivel consultar AD"
        }
    } else {
        $script:CONECTADO_STATUS = "Offline (Sem resposta ao Ping)"
        $script:CONECTADO_WIN_VER = "-"
        $script:CONECTADO_USER = "-"
        $script:CONECTADO_IS_ADMIN = "-"
        $script:CONECTADO_IS_RDP = "-"
        $script:CONECTADO_UPTIME = "-"
        $script:CONECTADO_SERIAL = "-"
        $script:CONECTADO_SCCM = "-"
        $script:CONECTADO_PRINTERS = "-"
        $script:CONECTADO_DEFAULT_PRINTER = "-"
        $script:CONECTADO_AD_PRINTERS = "-"
    }
}

function Disconnect-ConnectedComputer {
    $script:CONECTADO_COMP = $null
    $script:CONECTADO_STATUS = $null
    $script:CONECTADO_WIN_VER = $null
    $script:CONECTADO_USER = $null
    $script:CONECTADO_IS_ADMIN = $null
    $script:CONECTADO_IS_RDP = $null
    $script:CONECTADO_UPTIME = $null
    $script:CONECTADO_SERIAL = $null
    $script:CONECTADO_SCCM = $null
    $script:CONECTADO_PRINTERS = $null
    $script:CONECTADO_DEFAULT_PRINTER = $null
    $script:CONECTADO_AD_PRINTERS = $null
    $script:CONECTADO_TARGET_PRINTER = $null
    $script:CONECTADO_TIME = $null
}

function Get-ConnectionDisconnectTime {
    return "-"
}

function Test-ConnectionTimeout {
    return $false
}

function Get-ADPrinterGroupMembers {
    param($groupFilter)
    
    Show-ToolHeader "CONSULTAR GRUPOS E MEMBROS DE IMPRESSORA NO AD"
    
    try {
        $domainDN = ([ADSI]"LDAP://RootDSE").defaultNamingContext
        
        if ([string]::IsNullOrWhiteSpace($groupFilter)) {
            $groupFilter = Read-Host "Digite o codigo/grupo da impressora (ex: IS0432 ou ENTER para listar todas)"
        }
        
        $ldapFilter = "(&(objectCategory=group)(sAMAccountName=*-ImprimirDoc))"
        if (![string]::IsNullOrWhiteSpace($groupFilter)) {
            $cleanFilter = $groupFilter.Trim() -replace "-ImprimirDoc$", ""
            $ldapFilter = "(&(objectCategory=group)(sAMAccountName=*$cleanFilter*))"
        }
        
        Write-Host "Consultando Active Directory (OU=Impressoras_OU,$domainDN)..." -ForegroundColor Cyan
        Write-Host ""
        
        $searcher = [adsisearcher]$ldapFilter
        try {
            $searcher.SearchRoot = [ADSI]"LDAP://OU=Impressoras_OU,$domainDN"
        } catch {}
        
        $results = $searcher.FindAll()
        
        if ($results.Count -eq 0) {
            Write-Host "Nenhum grupo de impressora encontrado com o termo '$groupFilter'." -ForegroundColor Yellow
        } else {
            Write-Host "Grupos encontrados no AD ($($results.Count)):" -ForegroundColor Green
            Write-Host ""
            
            foreach ($res in $results) {
                $gName = $res.Properties["samaccountname"][0]
                $gDesc = if ($res.Properties["description"]) { $res.Properties["description"][0] } else { "Sem descricao" }
                $gEntry = $res.GetDirectoryEntry()
                $membersDN = $gEntry.Properties["member"]
                
                Write-Host "--------------------------------------------------------" -ForegroundColor DarkGray
                Write-Host " Grupo AD     : $gName" -ForegroundColor Yellow
                Write-Host " Descricao    : $gDesc" -ForegroundColor White
                Write-Host " Membros ($($membersDN.Count)):" -ForegroundColor Cyan
                
                if ($membersDN.Count -gt 0) {
                    foreach ($mDN in $membersDN) {
                        try {
                            $cn = ($mDN -split ',')[0] -replace "^CN=", ""
                            $ouPath = ($mDN -split ',',2)[1]
                            $ouClean = $ouPath -replace "DC=", "" -replace "OU=", "" -replace ",", "/"
                            Write-Host "   - $cn" -NoNewline -ForegroundColor Green
                            Write-Host "  ($ouClean)" -ForegroundColor Gray
                        } catch {
                            Write-Host "   - $mDN" -ForegroundColor Gray
                        }
                    }
                } else {
                    Write-Host "   (Nenhum membro cadastrado)" -ForegroundColor DarkGray
                }
            }
            Write-Host "--------------------------------------------------------" -ForegroundColor DarkGray
        }
    } catch {
        Write-Host "Erro ao consultar o Active Directory: $_" -ForegroundColor Red
    }
    
    Write-Host ""
    Read-Host "Pressione ENTER para continuar..."
}

function Get-RemoteUserADGroups {
    Show-ToolHeader "CONSULTAR GRUPOS DO AD (USUARIO REMOTO)"

    $targetUser = $null
    if (![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) {
        Write-Host "Computador Conectado: $script:CONECTADO_COMP" -ForegroundColor Cyan
        if (![string]::IsNullOrWhiteSpace($script:CONECTADO_USER) -and $script:CONECTADO_USER -ne "Nenhum usuario logado" -and $script:CONECTADO_USER -ne "Nao foi possivel consultar") {
            $targetUser = $script:CONECTADO_USER -ireplace '(?i)_INS$', '' -ireplace '(?i)_INS(?=\\|$|@)', ''
            Write-Host "Usuario Logado Detectado: $targetUser" -ForegroundColor Yellow
        }
    }

    if ([string]::IsNullOrWhiteSpace($targetUser) -and ![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) {
        try {
            $cs = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $script:CONECTADO_COMP -ErrorAction SilentlyContinue
            if ($cs -and ![string]::IsNullOrWhiteSpace($cs.UserName)) {
                $targetUser = $cs.UserName -ireplace '(?i)_INS$', '' -ireplace '(?i)_INS(?=\\|$|@)', ''
            }
        } catch {}
    }

    if (![string]::IsNullOrWhiteSpace($targetUser)) {
        Write-Host "Pressione [ENTER] para consultar '$targetUser' ou digite outro usuario (ex: 02826800124 ou SENADO\02826800124):" -ForegroundColor Yellow
        $inputUser = Read-Host "Usuario"
        if (![string]::IsNullOrWhiteSpace($inputUser)) {
            $targetUser = $inputUser.Trim()
        }
    } else {
        $targetUser = Read-Host "Digite o usuario ou matricula (ex: 02826800124 ou SENADO\02826800124)"
    }

    if ([string]::IsNullOrWhiteSpace($targetUser)) {
        Write-Host "Nenhum usuario informado." -ForegroundColor Red
        Write-Host ""
        Read-Host "Pressione ENTER para continuar..."
        return
    }

    $userOnly = $targetUser.Trim()
    if ($userOnly -match '\\') {
        $userOnly = ($userOnly -split '\\', 2)[1]
    }
    # Remover sufixo ou marca _INS para consultar a conta principal do usuario no AD
    $userOnly = $userOnly -ireplace '(?i)_INS$', '' -ireplace '(?i)_INS(?=\\|$|@)', ''

    Write-Host ""
    Write-Host "Consultando Active Directory para '$userOnly'..." -ForegroundColor Cyan
    Write-Host ""

    try {
        $found = $false
        
        # Metodo 1: ADSI Searcher (LDAP)
        try {
            $domainDN = ([ADSI]"LDAP://RootDSE").defaultNamingContext
            $searcher = [adsisearcher]""
            if ($domainDN) {
                $searcher.SearchRoot = [ADSI]"LDAP://$domainDN"
            }
            $searcher.PropertiesToLoad.AddRange(@("samaccountname", "displayname", "memberof", "distinguishedname")) | Out-Null
            
            # Buscar exato sAMAccountName primeiro sem _INS
            $searcher.Filter = "(sAMAccountName=$userOnly)"
            $userResult = $searcher.FindOne()

            if ($null -eq $userResult) {
                # Filtrar desconsiderando contas _INS
                $searcher.Filter = "(&(sAMAccountName=*$userOnly*)(!(sAMAccountName=*_INS*)))"
                $userResult = $searcher.FindOne()
            }

            if ($null -eq $userResult) {
                $searcher.Filter = "(|(sAMAccountName=$userOnly)(cn=*$userOnly*)(displayName=*$userOnly*))"
                $allResults = $searcher.FindAll()
                if ($allResults) {
                    foreach ($res in $allResults) {
                        $samName = $res.Properties["samaccountname"][0]
                        if ($samName -notmatch '(?i)_INS$') {
                            $userResult = $res
                            break
                        }
                    }
                    if ($null -eq $userResult -and $allResults.Count -gt 0) {
                        $userResult = $allResults[0]
                    }
                }
            }

            if ($null -ne $userResult) {
                $found = $true
                $sam = $userResult.Properties["samaccountname"][0]
                $dispName = if ($userResult.Properties["displayname"]) { $userResult.Properties["displayname"][0] } else { $sam }
                $dn = $userResult.Properties["distinguishedname"][0]
                $memberOf = $userResult.Properties["memberof"]

                Write-Host "--------------------------------------------------------" -ForegroundColor DarkGray
                Write-Host " Usuario Encontrado : $dispName ($sam)" -ForegroundColor Green
                Write-Host " Caminho (DN)       : $dn" -ForegroundColor Gray
                Write-Host "--------------------------------------------------------" -ForegroundColor DarkGray
                
                $totalCount = 1
                if ($memberOf) { $totalCount += $memberOf.Count }
                
                Write-Host " GRUPOS DO ACTIVE DIRECTORY ($totalCount):" -ForegroundColor Cyan
                Write-Host ""
                Write-Host "  [Grupo Primario] Domain Users" -ForegroundColor Yellow

                if ($memberOf -and $memberOf.Count -gt 0) {
                    $groupList = @()
                    foreach ($gDN in $memberOf) {
                        $cn = ($gDN -split ',')[0] -replace "^CN=", ""
                        $ouPath = ($gDN -split ',', 2)[1]
                        $ouClean = $ouPath -replace "DC=", "" -replace "OU=", "" -replace ",", "/"
                        $groupList += [PSCustomObject]@{
                            CN = $cn
                            OU = $ouClean
                        }
                    }
                    $sorted = $groupList | Sort-Object CN
                    foreach ($g in $sorted) {
                        Write-Host "  - $($g.CN)" -NoNewline -ForegroundColor Green
                        Write-Host "  ($($g.OU))" -ForegroundColor Gray
                    }
                } else {
                    Write-Host "  (Nenhum grupo adicional retornado)" -ForegroundColor DarkGray
                }
                Write-Host "--------------------------------------------------------" -ForegroundColor DarkGray
            }
        } catch {
            Write-Host "Tentativa ADSI: $_" -ForegroundColor Gray
        }

        # Metodo 2: Get-ADUser / Get-ADPrincipalGroupMembership (Modulo Active Directory)
        if (!$found) {
            try {
                $adUsers = Get-ADUser -Filter "sAMAccountName -eq '$userOnly' -or Name -like '*$userOnly*'" -ErrorAction SilentlyContinue
                $adUser = $adUsers | Where-Object { $_.SamAccountName -notmatch '(?i)_INS$' } | Select-Object -First 1
                if (!$adUser) { $adUser = $adUsers | Select-Object -First 1 }

                if ($adUser) {
                    $found = $true
                    Write-Host "--------------------------------------------------------" -ForegroundColor DarkGray
                    Write-Host " Usuario Encontrado : $($adUser.Name) ($($adUser.SamAccountName))" -ForegroundColor Green
                    Write-Host "--------------------------------------------------------" -ForegroundColor DarkGray
                    $groups = Get-ADPrincipalGroupMembership -Identity $adUser.SamAccountName -ErrorAction SilentlyContinue
                    if ($groups) {
                        Write-Host " GRUPOS DO ACTIVE DIRECTORY ($($groups.Count)):" -ForegroundColor Cyan
                        Write-Host ""
                        foreach ($g in ($groups | Sort-Object Name)) {
                            Write-Host "  - $($g.Name)" -ForegroundColor Green
                        }
                    } else {
                        Write-Host " Nenhum grupo retornado pelo modulo ActiveDirectory." -ForegroundColor Yellow
                    }
                    Write-Host "--------------------------------------------------------" -ForegroundColor DarkGray
                }
            } catch {}
        }

        if (!$found) {
            Write-Host "Usuario '$userOnly' nao foi localizado no Active Directory." -ForegroundColor Red
        }

    } catch {
        Write-Host "Erro ao consultar o Active Directory: $_" -ForegroundColor Red
    }

    Write-Host ""
    Read-Host "Pressione ENTER para continuar..."
}

function Get-TargetComputer {
    param($promptText)
    if (Test-ConnectionTimeout) {
        return $null
    }
    if (![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) {
        Write-Host "Usando computador conectado: $script:CONECTADO_COMP" -ForegroundColor Cyan
        return $script:CONECTADO_COMP
    }
    $inputVal = Read-Host $promptText
    if (![string]::IsNullOrWhiteSpace($inputVal)) {
        Set-ConnectedComputer -compName $inputVal
        return $script:CONECTADO_COMP
    }
    return $null
}

function Invoke-RemoteSessionTempCleanup {
    param(
        [string]$computerName,
        [string]$loggedUser
    )

    $cleanComp = $computerName.Trim().Replace('\', '')
    $token = [guid]::NewGuid().ToString('N')
    $taskName = "Suporte_CapturaTemp_$token"
    $localXml = Join-Path $env:TEMP "$taskName.xml"

    try {
        # A exclusao ocorre dentro da sessao interativa do usuario. O proprio
        # Windows resolve $env:TEMP, inclusive caminhos no D: e nomes 8.3.
        $cleanupCommand = "`$tempReal=`$env:TEMP; Get-ChildItem -LiteralPath `$tempReal -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue"
        $encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($cleanupCommand))
        $safeUser = [Security.SecurityElement]::Escape($loggedUser)
        $taskXml = @(
            '<?xml version="1.0" encoding="UTF-16"?>',
            '<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">',
            '  <Principals>',
            '    <Principal id="Author">',
            "      <UserId>$safeUser</UserId>",
            '      <LogonType>InteractiveToken</LogonType>',
            '      <RunLevel>LeastPrivilege</RunLevel>',
            '    </Principal>',
            '  </Principals>',
            '  <Settings>',
            '    <AllowStartOnDemand>true</AllowStartOnDemand>',
            '    <Enabled>true</Enabled>',
            '    <Hidden>true</Hidden>',
            '    <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>',
            '  </Settings>',
            '  <Actions Context="Author">',
            '    <Exec>',
            '      <Command>powershell.exe</Command>',
            "      <Arguments>-NoProfile -WindowStyle Hidden -EncodedCommand $encodedCommand</Arguments>",
            '    </Exec>',
            '  </Actions>',
            '</Task>'
        ) -join "`r`n"

        [IO.File]::WriteAllText($localXml, $taskXml, [Text.Encoding]::Unicode)
        $createOutput = schtasks /create /s $cleanComp /tn $taskName /xml $localXml /f 2>&1
        if ($LASTEXITCODE -ne 0) { return $null }

        schtasks /run /s $cleanComp /tn $taskName > $null 2>&1
        if ($LASTEXITCODE -ne 0) { return $false }
        Start-Sleep -Seconds 3
        return $true
    } catch {
        return $null
    } finally {
        schtasks /delete /s $cleanComp /tn $taskName /f > $null 2>&1
        Remove-Item -LiteralPath $localXml -Force -ErrorAction SilentlyContinue
    }
    return $false
}

function Clear-RemoteTemporaryFiles {
    param([string]$computerName)

    $cleanComp = $computerName.Trim().Replace('\', '')
    Clear-Host
    Write-Host "========================================================"
    Write-Host "   LIMPEZA DO %TEMP% DO USUARIO - $cleanComp"
    Write-Host "========================================================"
    $loggedUser = $script:CONECTADO_USER
    if ([string]::IsNullOrWhiteSpace($loggedUser) -or $loggedUser -like "Nenhum usuario*" -or $loggedUser -eq "Nao foi possivel consultar" -or $loggedUser -eq "-") {
        try {
            $loggedUser = (Get-WmiObject -Class Win32_ComputerSystem -ComputerName $cleanComp -ErrorAction Stop).UserName
        } catch {}
    }

    if ([string]::IsNullOrWhiteSpace($loggedUser)) {
        Write-Host "Nao foi possivel identificar o usuario logado." -ForegroundColor Red
        Read-Host "Pressione ENTER para retornar ao menu..."
        return
    }

    Write-Host "Executando a limpeza dentro da sessao de $loggedUser..." -ForegroundColor Cyan
    $cleanupStarted = Invoke-RemoteSessionTempCleanup -computerName $cleanComp -loggedUser $loggedUser
    if ($cleanupStarted) {
        Write-Host ""
        Write-Host "========================================================"
        Write-Host "Comando de limpeza executado na sessao do usuario." -ForegroundColor Green
        Write-Host "O Windows utilizou diretamente o caminho de %TEMP%." -ForegroundColor Green
        Write-Host "Arquivos que estavam em uso foram mantidos." -ForegroundColor Gray
        Write-Host "========================================================"
        Write-Host ""
        Read-Host "Pressione ENTER para retornar ao menu..."
        return
    }

    Write-Host "Nao foi possivel executar a tarefa na sessao. Tentando acesso direto..." -ForegroundColor Yellow
    $sessionTempPath = $null
    $tempPaths = New-Object System.Collections.Generic.List[string]
    if ($sessionTempPath -match '^([A-Za-z]):\\(.+)$') {
        $tempDrive = $matches[1]
        $tempRelativePath = $matches[2]
        $exactRemoteTemp = "\\$cleanComp\$tempDrive`$\$tempRelativePath"
        if (Test-Path -LiteralPath $exactRemoteTemp) {
            $tempPaths.Add($exactRemoteTemp)
        }
    }

    $userOnly = ($loggedUser -split '\\')[-1]
    $profilePath = $null
    $userSid = $null
    try {
        $userSid = (New-Object System.Security.Principal.NTAccount($loggedUser)).Translate(
            [System.Security.Principal.SecurityIdentifier]
        ).Value
    } catch {}

    # Consulta todos os perfis carregados no computador. Isso cobre nomes de
    # pasta como usuario.SENADO, usuario.000 e outras variacoes do Windows.
    try {
        $loadedProfiles = @(Get-WmiObject -Class Win32_UserProfile -ComputerName $cleanComp -ErrorAction Stop |
            Where-Object { $_.Loaded -eq $true -and $_.Special -ne $true -and ![string]::IsNullOrWhiteSpace($_.LocalPath) })

        $profile = $null
        if (![string]::IsNullOrWhiteSpace($userSid)) {
            $profile = $loadedProfiles | Where-Object { $_.SID -eq $userSid } | Select-Object -First 1
        }
        if (!$profile) {
            $profile = $loadedProfiles | Where-Object {
                $leaf = Split-Path $_.LocalPath -Leaf
                $leaf -eq $userOnly -or $leaf -like "$userOnly.*" -or $leaf -like "$userOnly-*"
            } | Select-Object -First 1
        }
        if (!$profile -and $loadedProfiles.Count -eq 1) {
            $profile = $loadedProfiles[0]
        }
        if ($profile) { $profilePath = $profile.LocalPath }
    } catch {}

    if ($tempPaths.Count -eq 0 -and $profilePath -match '^([A-Za-z]):\\(.+)$') {
        $drive = $matches[1]
        $relativeProfile = $matches[2]
        $candidate = "\\$cleanComp\$drive`$\$relativeProfile\AppData\Local\Temp"
        if (Test-Path -LiteralPath $candidate) { $tempPaths.Add($candidate) }
    }

    # Fallback por compartilhamento administrativo quando a consulta WMI de
    # perfis estiver bloqueada. Localiza o nome real da pasta do usuario.
    if ($tempPaths.Count -eq 0) {
        foreach ($drive in @("C", "D")) {
            $usersRoot = "\\$cleanComp\$drive`$\Users"
            if (!(Test-Path -LiteralPath $usersRoot)) { continue }
            $profileDirs = @(Get-ChildItem -LiteralPath $usersRoot -Directory -Force -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -eq $userOnly -or $_.Name -like "$userOnly.*" -or $_.Name -like "$userOnly-*" })
            foreach ($profileDir in $profileDirs) {
                $candidate = Join-Path $profileDir.FullName "AppData\Local\Temp"
                if (Test-Path -LiteralPath $candidate) { $tempPaths.Add($candidate) }
            }
        }
    }

    if ($tempPaths.Count -eq 0) {
        Write-Host "A pasta %TEMP% do usuario $loggedUser nao foi encontrada ou esta sem acesso." -ForegroundColor Red
        Read-Host "Pressione ENTER para retornar ao menu..."
        return
    }

    Write-Host "Usuario logado: $loggedUser" -ForegroundColor Cyan
    Write-Host "Limpando o mesmo local aberto pelo comando %TEMP%..." -ForegroundColor Yellow
    Write-Host "Arquivos em uso serao ignorados automaticamente." -ForegroundColor Gray

    $totalBytes = [int64]0
    $removedItems = 0
    $failedItems = 0

    foreach ($tempPath in ($tempPaths | Select-Object -Unique)) {
        Write-Host "Pasta: $tempPath" -ForegroundColor Gray
        $items = @(Get-ChildItem -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue)
        foreach ($item in $items) {
            try {
                $itemBytes = [int64]0
                if ($item.PSIsContainer) {
                    $measure = Get-ChildItem -LiteralPath $item.FullName -File -Recurse -Force -ErrorAction SilentlyContinue |
                        Measure-Object -Property Length -Sum
                    if ($measure.Sum) { $itemBytes = [int64]$measure.Sum }
                } else {
                    $itemBytes = [int64]$item.Length
                }
                Remove-Item -LiteralPath $item.FullName -Recurse -Force -ErrorAction Stop
                $totalBytes += $itemBytes
                $removedItems++
            } catch {
                $failedItems++
            }
        }
    }

    Write-Host ""
    Write-Host "========================================================"
    $released = if ($totalBytes -ge 1GB) {
        "{0:N2} GB" -f ($totalBytes / 1GB)
    } elseif ($totalBytes -ge 1MB) {
        "{0:N2} MB" -f ($totalBytes / 1MB)
    } else {
        "{0:N2} KB" -f ($totalBytes / 1KB)
    }
    Write-Host "Limpeza do %TEMP% concluida. Espaco estimado liberado: $released" -ForegroundColor Green
    Write-Host "Itens removidos: $removedItems | Itens em uso/sem acesso: $failedItems" -ForegroundColor White
    Write-Host "========================================================"
    Write-Host ""
    Read-Host "Pressione ENTER para retornar ao menu..."
}

function Get-FolderSizeInBytes {
    param(
        [string]$computerName,
        [string]$localPath
    )

    if ([string]::IsNullOrWhiteSpace($localPath)) { return [int64]0 }
    $cleanComp = $computerName.Replace('\', '').Trim()
    $isLocal = ($cleanComp -eq "127.0.0.1" -or $cleanComp -ieq "localhost" -or $cleanComp -ieq $env:COMPUTERNAME)

    $candidates = New-Object System.Collections.Generic.List[string]

    if ($isLocal) {
        $candidates.Add($localPath)
    } else {
        if ($localPath -match '^([A-Za-z]):\\(.+)$') {
            $driveLet = $matches[1]
            $relPath = $matches[2]
            $unc1 = "\\$cleanComp\" + $driveLet + "`$\" + $relPath
            $candidates.Add($unc1)
        }
        $userFolder = Split-Path $localPath -Leaf
        foreach ($d in @("D", "C")) {
            foreach ($uFolder in @("Users", "Usuários", "Usuarios")) {
                $uncAlt = "\\$cleanComp\" + $d + "`$\" + $uFolder + "\" + $userFolder
                if (!$candidates.Contains($uncAlt)) { $candidates.Add($uncAlt) }
            }
        }
        foreach ($uFolder in @("Users", "Usuários", "Usuarios")) {
            $uncShare = "\\$cleanComp\" + $uFolder + "\" + $userFolder
            if (!$candidates.Contains($uncShare)) { $candidates.Add($uncShare) }
        }
    }

    foreach ($targetPath in $candidates) {
        if ([string]::IsNullOrWhiteSpace($targetPath)) { continue }
        if (!(Test-Path -LiteralPath $targetPath -ErrorAction SilentlyContinue)) { continue }

        # 1. Scripting.FileSystemObject (Nativo e instantaneo no Windows local/UNC)
        try {
            $fso = New-Object -ComObject Scripting.FileSystemObject
            if ($fso.FolderExists($targetPath)) {
                $fObj = $fso.GetFolder($targetPath)
                $sz = [int64]$fObj.Size
                if ($sz -gt 0) { return $sz }
            }
        } catch {}

        # 2. Robocopy (Preciso, ignora junction loops /XJ e le permissoes restritas)
        # NOTA: NAO usar /NJS pois /NJS oculta a tabela 'Bytes : ...' do resumo do Robocopy!
        try {
            $dummyDst = Join-Path $env:TEMP "robodummy_$([guid]::NewGuid().ToString('N'))"
            $robo = robocopy "$targetPath" "$dummyDst" /L /S /NFL /NDL /NJH /BYTES /XJ /R:0 /W:0 2>$null
            if (Test-Path -Path $dummyDst) { Remove-Item -Path $dummyDst -Force -Recurse -ErrorAction SilentlyContinue }
            foreach ($line in $robo) {
                if ($line -match 'Bytes\s*:\s*(\d+)') {
                    $sz = [int64]$matches[1]
                    if ($sz -gt 0) { return $sz }
                }
            }
        } catch {}

        # 3. cmd.exe dir /s /a /-c (Busca linha exata de total de arquivos 'File(s)' ou 'Arquivo(s)')
        try {
            $dirOut = cmd.exe /c "dir `"$targetPath`" /s /a /-c 2>nul"
            foreach ($line in $dirOut) {
                if ($line -match '^\s*\d+\s+(?:Arquivo\(s\)|File\(s\))\s+(\d+)\s+bytes') {
                    $sz = [int64]$matches[1]
                    if ($sz -gt 0) { return $sz }
                }
            }
        } catch {}

        # 4. Get-ChildItem Measure-Object
        try {
            $files = Get-ChildItem -LiteralPath $targetPath -Recurse -Force -ErrorAction SilentlyContinue
            if ($files) {
                $measure = $files | Where-Object { !$_.PSIsContainer } | Measure-Object -Property Length -Sum
                if ($measure -and $measure.Sum -gt 0) { return [int64]$measure.Sum }
            }
        } catch {}
    }

    return [int64]0
}

function Get-RemoteDiskAndProfilesSpace {
    $COMP = Get-TargetComputer "Digite o nome ou IP do computador remoto"
    if ([string]::IsNullOrWhiteSpace($COMP)) { return }
    $cleanComp = $COMP.Replace('\', '').Trim()
    $isLocal = ($cleanComp -eq "127.0.0.1" -or $cleanComp -ieq "localhost" -or $cleanComp -ieq $env:COMPUTERNAME)

    while ($true) {
        Clear-Host
        Write-Host "========================================================"
        Write-Host "   ANALISE DE ESPACO EM DISCO E PERFIS - $cleanComp"
        Write-Host "========================================================"
        Write-Host ""
        Write-Host "Consultando unidades de disco (locais e de rede)..." -ForegroundColor Cyan

        # Busca Discos Locais e de Rede via WMI
        $disks = @()
        try {
            $disks = @(Get-WmiObject -Class Win32_LogicalDisk -ComputerName $cleanComp -ErrorAction SilentlyContinue)
        } catch {}

        # Busca Mapeamentos de Rede adicionais via Win32_MappedLogicalDisk
        $netDrives = @()
        try {
            $mappedWmi = Get-WmiObject -Class Win32_MappedLogicalDisk -ComputerName $cleanComp -ErrorAction SilentlyContinue
            foreach ($m in $mappedWmi) {
                if ($m.Name -and !($disks | Where-Object { $_.DeviceID -ieq $m.Name })) {
                    $netDrives += [PSCustomObject]@{
                        DeviceID     = $m.Name
                        DriveType    = 4
                        ProviderName = $m.ProviderName
                        Size         = [int64]$m.Size
                        FreeSpace    = [int64]$m.FreeSpace
                        VolumeName   = $m.VolumeName
                    }
                }
            }
        } catch {}

        # HKU Registry fallback para Mapeamentos de Rede de Usuarios
        try {
            $regBase = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::Users, $cleanComp)
            if ($regBase) {
                foreach ($sidKey in $regBase.GetSubKeyNames()) {
                    if ($sidKey -like 'S-1-5-21-*' -and $sidKey -notlike '*_Classes') {
                        $netKeyPath = "$sidKey\Network"
                        try {
                            $netSubKey = $regBase.OpenSubKey($netKeyPath)
                            if ($netSubKey) {
                                foreach ($driveLet in $netSubKey.GetSubKeyNames()) {
                                    $driveID = "$($driveLet.ToUpper()):"
                                    if (!($disks | Where-Object { $_.DeviceID -ieq $driveID }) -and !($netDrives | Where-Object { $_.DeviceID -ieq $driveID })) {
                                        $dKey = $regBase.OpenSubKey("$netKeyPath\$driveLet")
                                        $remPath = $dKey.GetValue("RemotePath")
                                        if ($remPath) {
                                            $netDrives += [PSCustomObject]@{
                                                DeviceID     = $driveID
                                                DriveType    = 4
                                                ProviderName = $remPath
                                                Size         = [int64]0
                                                FreeSpace    = [int64]0
                                                VolumeName   = "Mapeamento de Rede"
                                            }
                                        }
                                    }
                                }
                            }
                        } catch {}
                    }
                }
            }
        } catch {}

        $allDisks = @($disks) + @($netDrives) | Sort-Object DeviceID

        # Busca Perfis de Usuario
        Write-Host "Consultando perfis de usuario e tamanhos de pasta..." -ForegroundColor Cyan
        $profiles = @()
        try {
            $profiles = @(Get-WmiObject -Class Win32_UserProfile -ComputerName $cleanComp -ErrorAction Stop |
                Where-Object { $_.Special -ne $true -and ![string]::IsNullOrWhiteSpace($_.LocalPath) } |
                Sort-Object LocalPath)
        } catch {
            Write-Host "Erro ao consultar perfis de usuario via WMI: $_" -ForegroundColor Red
        }

        # Calcula o tamanho das pastas de perfis via UNC
        if ($profiles.Count -gt 0) {
            foreach ($p in $profiles) {
                $profBytes = Get-FolderSizeInBytes -computerName $cleanComp -localPath $p.LocalPath
                $p | Add-Member -NotePropertyName "CalculatedBytes" -NotePropertyValue $profBytes -Force
            }
        }

        # Fallback via Processo WMI Remoto se os tamanhos via UNC vieram zerados (ex: C$/D$ bloqueados)
        $hasZeroes = ($profiles | Where-Object { [int64]$_.CalculatedBytes -eq 0 }).Count -gt 0
        if (!$isLocal -and $hasZeroes -and $profiles.Count -gt 0) {
            try {
                Write-Host "Calculando tamanhos de pasta diretamente no computador remoto via WMI..." -ForegroundColor Yellow
                $remoteScript = @'
$profs = Get-WmiObject Win32_UserProfile | Where-Object { !$_.Special -and $_.LocalPath };
New-Item -Path 'HKLM:\SOFTWARE\SuporteProfSizes' -Force -ErrorAction SilentlyContinue | Out-Null;
foreach($p in $profs){
    $lp = $p.LocalPath;
    $sid = $p.SID;
    $sz = [int64]0;
    if($lp -and (Test-Path -LiteralPath $lp)){
        try {
            $fso = New-Object -ComObject Scripting.FileSystemObject;
            if($fso.FolderExists($lp)){ $sz = [int64]$fso.GetFolder($lp).Size }
        } catch {}
        if($sz -eq 0){
            try {
                $r = robocopy $lp "$env:TEMP\null_dummy" /L /S /NFL /NDL /NJH /BYTES /XJ /R:0 /W:0 2>$null;
                foreach($l in $r){
                    if($l -match 'Bytes\s*:\s*(\d+)'){ $sz = [int64]$matches[1]; break }
                }
            } catch {}
        }
        if($sz -eq 0){
            try {
                $files = Get-ChildItem -LiteralPath $lp -Recurse -Force -ErrorAction SilentlyContinue;
                if($files){ $m = $files | Where-Object{!$_.PSIsContainer} | Measure-Object -Property Length -Sum; if($m.Sum){ $sz = [int64]$m.Sum } }
            } catch {}
        }
    };
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\SuporteProfSizes' -Name $sid -Value ([string]$sz) -Type String -ErrorAction SilentlyContinue;
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\SuporteProfSizes' -Name ($sid + '_qw') -Value $sz -Type QWord -ErrorAction SilentlyContinue;
}
'@
                $encodedCommand = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($remoteScript))
                $wmiProcess = [WMICLASS]"\\$cleanComp\root\cimv2:Win32_Process"
                $null = $wmiProcess.Create("powershell.exe -NoProfile -ExecutionPolicy Bypass -EncodedCommand $encodedCommand")

                # Aguarda conclusao do processo remoto (ate 12 segundos)
                $waited = 0
                while ($waited -lt 12) {
                    Start-Sleep -Seconds 1
                    $waited++
                    try {
                        $regBase = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $cleanComp)
                        $szKey = $regBase.OpenSubKey("SOFTWARE\SuporteProfSizes")
                        if ($szKey -and $szKey.ValueCount -gt 0) { break }
                    } catch {}
                }

                # Le os tamanhos calculados do Registro remoto
                try {
                    $stdReg = [WMICLASS]"\\$cleanComp\root\default:StdRegProv"
                    foreach ($p in $profiles) {
                        $sidVal = $p.SID
                        $outVal = $null

                        # 1. Tenta via WMI StdRegProv GetStringValue
                        try {
                            $regResStr = $stdReg.GetStringValue(2147483650, "SOFTWARE\SuporteProfSizes", $sidVal)
                            if ($regResStr -and $regResStr.ReturnValue -eq 0 -and $regResStr.sValue) {
                                $outVal = [int64]$regResStr.sValue
                            }
                        } catch {}

                        # 2. Tenta via WMI StdRegProv GetQValue
                        if ($outVal -eq $null -or $outVal -eq 0) {
                            try {
                                $regResQw = $stdReg.GetQValue(2147483650, "SOFTWARE\SuporteProfSizes", ($sidVal + "_qw"))
                                if ($regResQw -and $regResQw.ReturnValue -eq 0 -and $regResQw.uValue) {
                                    $outVal = [int64]$regResQw.uValue
                                }
                            } catch {}
                        }

                        # 3. Fallback via RemoteRegistry.OpenRemoteBaseKey
                        if ($outVal -eq $null -or $outVal -eq 0) {
                            try {
                                $regBase = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $cleanComp)
                                $szKey = $regBase.OpenSubKey("SOFTWARE\SuporteProfSizes")
                                if ($szKey) {
                                    $v = $szKey.GetValue($sidVal)
                                    if ($v -ne $null -and [int64]$v -gt 0) { $outVal = [int64]$v }
                                    $szKey.Close()
                                }
                            } catch {}
                        }

                        if ($outVal -and $outVal -gt 0) {
                            $p.CalculatedBytes = [int64]$outVal
                        }
                    }

                    try { $stdReg.DeleteKey(2147483650, "SOFTWARE\SuporteProfSizes") } catch {}
                } catch {}
            } catch {}
        }

        Clear-Host
        Write-Host "========================================================"
        Write-Host "   SELECAO DE DRIVES E PERFIS PARA ANALISE - $cleanComp"
        Write-Host "========================================================"
        Write-Host ""

        $itemIndex = 1
        $driveMap = @{}
        $profileMap = @{}

        Write-Host " UNIDADES DE DISCO DISPONIVEIS (LOCAIS E DE REDE):" -ForegroundColor Yellow
        if ($allDisks.Count -gt 0) {
            foreach ($d in $allDisks) {
                $drive = $d.DeviceID
                $typeStr = switch ($d.DriveType) {
                    2 { "Removivel" }
                    3 { "Disco Local" }
                    4 { "Unidade de Rede" }
                    5 { "CD/DVD" }
                    default { "Outro" }
                }
                $provStr = if (![string]::IsNullOrWhiteSpace($d.ProviderName)) { " -> $($d.ProviderName)" } else { "" }
                $sizeInfo = ""
                if ($d.Size -gt 0) {
                    $totalGB = [math]::Round($d.Size / 1GB, 2)
                    $freeGB  = [math]::Round($d.FreeSpace / 1GB, 2)
                    $sizeInfo = " - Total: $totalGB GB | Livre: $freeGB GB"
                } else {
                    $sizeInfo = " - (Mapeamento / Sem tamanho reportado)"
                }
                Write-Host "   [$itemIndex] - Drive $drive ($typeStr$provStr)$sizeInfo" -ForegroundColor White
                $driveMap[$itemIndex] = $d
                $itemIndex++
            }
        } else {
            Write-Host "   (Nenhuma unidade de disco localizada)" -ForegroundColor DarkGray
        }

        Write-Host ""
        Write-Host " PERFIS DE USUARIOS REGISTRADOS:" -ForegroundColor Yellow
        if ($profiles.Count -gt 0) {
            foreach ($p in $profiles) {
                $localPath = $p.LocalPath
                $userFolder = Split-Path $localPath -Leaf
                $userName = $userFolder
                try {
                    $ntAcc = (New-Object System.Security.Principal.SecurityIdentifier($p.SID)).Translate([System.Security.Principal.NTAccount]).Value
                    if (![string]::IsNullOrWhiteSpace($ntAcc)) { $userName = "$ntAcc ($userFolder)" }
                } catch {}

                Write-Host "   [$itemIndex] - $userName" -ForegroundColor White
                $profileMap[$itemIndex] = $p
                $itemIndex++
            }
        } else {
            Write-Host "   (Nenhum perfil registrado localizado)" -ForegroundColor DarkGray
        }

        Write-Host ""
        Write-Host " OPCOES GERAIS:" -ForegroundColor Yellow
        Write-Host "   [T] - Analisar TODOS os Drives e Perfis de uma vez" -ForegroundColor Cyan
        Write-Host "   [0] - Voltar ao Menu Principal" -ForegroundColor Red
        Write-Host "========================================================"
        Write-Host ""
        $choice = Read-Host "Digite o numero ou opcao desejada"
        if ([string]::IsNullOrWhiteSpace($choice)) { continue }
        $choice = $choice.Trim()

        if ($choice -eq "0") {
            return
        } elseif ($choice -ieq "T") {
            # Exibir relatorio de TODOS
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   RELATORIO COMPLETO DE DRIVES E PERFIS - $cleanComp"
            Write-Host "========================================================"
            Write-Host ""

            Write-Host "--- 1. UNIDADES DE DISCO ---" -ForegroundColor Yellow
            foreach ($d in $allDisks) {
                $drive = $d.DeviceID
                $typeStr = switch ($d.DriveType) { 2{"Removivel"} 3{"Disco Local"} 4{"Unidade de Rede"} 5{"CD/DVD"} default{"Outro"} }
                $provider = if (![string]::IsNullOrWhiteSpace($d.ProviderName)) { " -> $($d.ProviderName)" } elseif (![string]::IsNullOrWhiteSpace($d.VolumeName)) { " [$($d.VolumeName)]" } else { "" }
                if ($d.Size -gt 0) {
                    $totalGB = [math]::Round($d.Size / 1GB, 2)
                    $freeGB  = [math]::Round($d.FreeSpace / 1GB, 2)
                    $usedGB  = [math]::Round(($d.Size - $d.FreeSpace) / 1GB, 2)
                    $pctFree = [math]::Round(($d.FreeSpace / $d.Size) * 100, 1)
                    Write-Host " [$drive] $typeStr$provider" -ForegroundColor White
                    Write-Host "       Tamanho Total : $totalGB GB" -ForegroundColor Gray
                    Write-Host "       Espaco Usado  : $usedGB GB" -ForegroundColor Gray
                    Write-Host "       Espaco Livre  : $freeGB GB ($pctFree% livre)" -ForegroundColor Green
                } else {
                    Write-Host " [$drive] $typeStr$provider" -ForegroundColor DarkGray
                }
                Write-Host ""
            }

            Write-Host "--- 2. PERFIS DE USUARIOS ---" -ForegroundColor Yellow
            $totalAllBytes = [int64]0
            foreach ($p in $profiles) {
                $localPath = $p.LocalPath
                $userFolder = Split-Path $localPath -Leaf
                $userName = $userFolder
                try {
                    $ntAcc = (New-Object System.Security.Principal.SecurityIdentifier($p.SID)).Translate([System.Security.Principal.NTAccount]).Value
                    if (![string]::IsNullOrWhiteSpace($ntAcc)) { $userName = "$ntAcc ($userFolder)" }
                } catch {}

                $statusStr = if ($p.Loaded -eq $true) { "Logado / Ativo" } else { "Deslogado" }
                $lastUseStr = "-"
                try {
                    if ($p.LastUseTime) { $lastUseStr = ($p.ConvertToDateTime($p.LastUseTime)).ToString("dd/MM/yyyy HH:mm") }
                } catch {}

                $profBytes = [int64]$p.CalculatedBytes
                if ($profBytes -eq 0) {
                    $profBytes = Get-FolderSizeInBytes -computerName $cleanComp -localPath $localPath
                }
                $totalAllBytes += $profBytes

                $sizeFormatted = if ($profBytes -ge 1GB) { "{0:N2} GB" -f ($profBytes / 1GB) } elseif ($profBytes -ge 1MB) { "{0:N2} MB" -f ($profBytes / 1MB) } else { "{0:N2} KB" -f ($profBytes / 1KB) }

                Write-Host " User/Pasta    : $userName" -ForegroundColor White
                Write-Host " Caminho Local : $localPath" -ForegroundColor Gray
                Write-Host " Status Sessao : $statusStr" -ForegroundColor Cyan
                Write-Host " Ultimo Acesso : $lastUseStr" -ForegroundColor Gray
                Write-Host " Espaco Usado  : $sizeFormatted" -ForegroundColor Green
                Write-Host ""
            }

            $allProfFormatted = if ($totalAllBytes -ge 1GB) { "{0:N2} GB" -f ($totalAllBytes / 1GB) } else { "{0:N2} MB" -f ($totalAllBytes / 1MB) }
            Write-Host "--------------------------------------------------------" -ForegroundColor DarkGray
            Write-Host " Espaco Total dos Perfis: $allProfFormatted" -ForegroundColor Green
            Write-Host "========================================================"
            Write-Host ""
            Read-Host "Pressione ENTER para retornar ao menu de selecao..."
        } elseif ([int]::TryParse($choice, [ref]$null)) {
            $selNum = [int]$choice
            if ($driveMap.ContainsKey($selNum)) {
                $d = $driveMap[$selNum]
                Clear-Host
                Write-Host "========================================================"
                Write-Host "   DETALHES DA UNIDADE DE DISCO - $($d.DeviceID)"
                Write-Host "========================================================"
                Write-Host ""
                $typeStr = switch ($d.DriveType) { 2{"Removivel"} 3{"Disco Local"} 4{"Unidade de Rede"} 5{"CD/DVD"} default{"Outro"} }
                Write-Host " Unidade       : $($d.DeviceID)" -ForegroundColor White
                Write-Host " Tipo          : $typeStr" -ForegroundColor Cyan
                if (![string]::IsNullOrWhiteSpace($d.VolumeName)) { Write-Host " Rotulo/Volume : $($d.VolumeName)" -ForegroundColor Gray }
                if (![string]::IsNullOrWhiteSpace($d.ProviderName)) { Write-Host " Servidor Rede : $($d.ProviderName)" -ForegroundColor Yellow }

                if ($d.Size -gt 0) {
                    $totalGB = [math]::Round($d.Size / 1GB, 2)
                    $freeGB  = [math]::Round($d.FreeSpace / 1GB, 2)
                    $usedGB  = [math]::Round(($d.Size - $d.FreeSpace) / 1GB, 2)
                    $pctFree = [math]::Round(($d.FreeSpace / $d.Size) * 100, 1)

                    Write-Host " Tamanho Total : $totalGB GB" -ForegroundColor White
                    Write-Host " Espaco Usado  : $usedGB GB" -ForegroundColor White
                    Write-Host " Espaco Livre  : $freeGB GB ($pctFree% livre)" -ForegroundColor Green
                    if (![string]::IsNullOrWhiteSpace($d.FileSystem)) { Write-Host " Sistema Arquiv: $($d.FileSystem)" -ForegroundColor Gray }
                } else {
                    Write-Host " Status        : Mapeamento de Rede / Sem tamanho reportado" -ForegroundColor Yellow
                }
                Write-Host ""
                Write-Host "========================================================"
                Read-Host "Pressione ENTER para retornar ao menu de selecao..."
            } elseif ($profileMap.ContainsKey($selNum)) {
                $p = $profileMap[$selNum]
                $localPath = $p.LocalPath
                $userFolder = Split-Path $localPath -Leaf
                $userName = $userFolder
                try {
                    $ntAcc = (New-Object System.Security.Principal.SecurityIdentifier($p.SID)).Translate([System.Security.Principal.NTAccount]).Value
                    if (![string]::IsNullOrWhiteSpace($ntAcc)) { $userName = "$ntAcc ($userFolder)" }
                } catch {}

                $statusStr = if ($p.Loaded -eq $true) { "Logado / Ativo" } else { "Deslogado" }
                $lastUseStr = "-"
                try {
                    if ($p.LastUseTime) { $lastUseStr = ($p.ConvertToDateTime($p.LastUseTime)).ToString("dd/MM/yyyy HH:mm") }
                } catch {}

                Clear-Host
                Write-Host "========================================================"
                Write-Host "   DETALHES DO PERFIL DE USUARIO - $userFolder"
                Write-Host "========================================================"
                Write-Host ""
                Write-Host " Usuario / Conta : $userName" -ForegroundColor White
                Write-Host " Caminho Local   : $localPath" -ForegroundColor Gray
                Write-Host " Status Sessao   : $statusStr" -ForegroundColor Cyan
                Write-Host " Ultimo Acesso   : $lastUseStr" -ForegroundColor Gray
                Write-Host " SID             : $($p.SID)" -ForegroundColor DarkGray
                Write-Host ""

                $profBytes = [int64]$p.CalculatedBytes
                if ($profBytes -eq 0) {
                    $profBytes = Get-FolderSizeInBytes -computerName $cleanComp -localPath $localPath
                }

                $sizeFormatted = if ($profBytes -ge 1GB) {
                    "{0:N2} GB ({1:N0} Bytes)" -f ($profBytes / 1GB), $profBytes
                } elseif ($profBytes -ge 1MB) {
                    "{0:N2} MB ({1:N0} Bytes)" -f ($profBytes / 1MB), $profBytes
                } else {
                    "{0:N2} KB ({1:N0} Bytes)" -f ($profBytes / 1KB), $profBytes
                }

                Write-Host " Espaco Ocupado  : $sizeFormatted" -ForegroundColor Green
                Write-Host ""
                Write-Host "========================================================"
                Read-Host "Pressione ENTER para retornar ao menu de selecao..."
            } else {
                Write-Host "Opcao invalida. Tente novamente." -ForegroundColor Red
                Start-Sleep -Seconds 1
            }
        } else {
            Write-Host "Opcao invalida. Tente novamente." -ForegroundColor Red
            Start-Sleep -Seconds 1
        }
    }
}

function Show-ToolHeader {
    param([string]$title)
    Clear-Host
    Write-Host "  $title" -ForegroundColor Cyan
    Write-Host ""
}

function Show-SasLogo {
    # Mantido sem impressao extra para evitar poluicao visual e rolagem no console
}

function Show-HeaderPanel {
    param([string]$title)
    $now = Get-Date -Format "dd/MM/yyyy  HH:mm"
    Write-Host "╭──────────────────────────────────────────────────────────────────────╮" -ForegroundColor DarkCyan
    Write-Host "│  " -NoNewline -ForegroundColor DarkCyan
    Write-Host ("{0,-57}{1,11}" -f $title, "v2.3") -NoNewline -ForegroundColor White
    Write-Host "│" -ForegroundColor DarkCyan
    Write-Host "│  " -NoNewline -ForegroundColor DarkCyan
    Write-Host ("{0,-48}{1,20}" -f "SENADO FEDERAL  ·  OPERACOES TECNICAS", $now) -NoNewline -ForegroundColor Gray
    Write-Host "│" -ForegroundColor DarkCyan
    Write-Host "╰──────────────────────────────────────────────────────────────────────╯" -ForegroundColor DarkCyan

    if ($NoAdmin) {
        if ($isInsAccount -or $isAdminRole) {
            Write-Host "  ●  INTERFACE PADRAO" -NoNewline -ForegroundColor Yellow
            Write-Host "   Identidade administrativa ainda ativa" -ForegroundColor Red
        } else {
            Write-Host "  ●  SESSAO PADRAO" -NoNewline -ForegroundColor Green
            Write-Host "   Navegacao e ambiente do usuario normal" -ForegroundColor DarkGray
        }
    } else {
        Write-Host "  ●  SESSAO INS" -NoNewline -ForegroundColor Yellow
        Write-Host "      Ferramentas administrativas habilitadas" -ForegroundColor DarkGray
    }
    Write-Host "  Identidade Windows  " -NoNewline -ForegroundColor DarkGray
    Write-Host $WINDOWS_IDENTITY -ForegroundColor White
    Write-Host "  Desenvolvido por Alexandre Linhares  ·  @alemagnobr" -ForegroundColor DarkCyan
    Write-Host ""
}

function Write-MenuItem {
    param(
        [string]$Key,
        [string]$Text,
        [string]$Color = "White"
    )
    if ($Key -match '^\d+$') {
        $displayKey = "{0:D2}" -f [int]$Key
    } else {
        $displayKey = $Key
    }
    Write-Host ("    {0}  ›  " -f $displayKey) -NoNewline -ForegroundColor Cyan
    Write-Host $Text -ForegroundColor $Color
}

function Write-MenuSection {
    param([string]$Text)
    Write-Host ""
    Write-Host "  " -NoNewline
    Write-Host $Text -NoNewline -ForegroundColor DarkCyan
    Write-Host ("  " + ("─" * [Math]::Max(1, 66 - $Text.Length))) -ForegroundColor DarkGray
}

function Write-MenuFooter {
    Write-Host ""
    Write-Host "  ────────────────────────────────────────────────────────────────────" -ForegroundColor DarkGray
    Write-Host "  Digite o numero da acao" -NoNewline -ForegroundColor DarkGray
    Write-Host "  ›  " -NoNewline -ForegroundColor Cyan
}

function Write-Breadcrumb {
    param([string]$Current)
    Write-Host "  PAINEL" -NoNewline -ForegroundColor DarkGray
    Write-Host "  /  " -NoNewline -ForegroundColor DarkCyan
    Write-Host $Current -ForegroundColor Cyan
}

function Show-ConnectedComputerPanel {
    if (![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) {
        Write-MenuSection "STATUS DA CONEXAO"
        Write-Host "  ●  CONECTADO" -ForegroundColor Green
        
        Write-Host "  Estacao          " -NoNewline -ForegroundColor DarkGray
        Write-Host "$script:CONECTADO_COMP " -NoNewline -ForegroundColor Green
        Write-Host "[$script:CONECTADO_STATUS]" -ForegroundColor DarkGreen

        Write-Host "  Windows          " -NoNewline -ForegroundColor DarkGray
        Write-Host "$script:CONECTADO_WIN_VER" -ForegroundColor White

        Write-Host "  Usuario remoto   " -NoNewline -ForegroundColor DarkGray
        Write-Host "$script:CONECTADO_USER" -ForegroundColor Yellow

        Write-Host "  Admin local      " -NoNewline -ForegroundColor DarkGray
        if ($script:CONECTADO_IS_ADMIN -like "SIM*") {
            Write-Host "$script:CONECTADO_IS_ADMIN" -ForegroundColor Green
        } elseif ($script:CONECTADO_IS_ADMIN -like "NAO*") {
            Write-Host "$script:CONECTADO_IS_ADMIN" -ForegroundColor Red
        } else {
            Write-Host "$script:CONECTADO_IS_ADMIN" -ForegroundColor Gray
        }

        Write-Host "  Acesso RDP       " -NoNewline -ForegroundColor DarkGray
        if ($script:CONECTADO_IS_RDP -like "SIM*") {
            Write-Host "$script:CONECTADO_IS_RDP" -ForegroundColor Green
        } elseif ($script:CONECTADO_IS_RDP -like "NAO*") {
            Write-Host "$script:CONECTADO_IS_RDP" -ForegroundColor Red
        } else {
            Write-Host "$script:CONECTADO_IS_RDP" -ForegroundColor Gray
        }

        Write-Host "  Ultimo boot      " -NoNewline -ForegroundColor DarkGray
        Write-Host "$script:CONECTADO_UPTIME" -ForegroundColor Cyan

        Write-Host "  Serial / BIOS    " -NoNewline -ForegroundColor DarkGray
        Write-Host "$script:CONECTADO_SERIAL" -ForegroundColor Magenta

        Write-Host "  Agente SCCM      " -NoNewline -ForegroundColor DarkGray
        Write-Host "$script:CONECTADO_SCCM" -ForegroundColor DarkYellow

        # Impressora Padrao
        $defShort = ""
        if (![string]::IsNullOrWhiteSpace($script:CONECTADO_DEFAULT_PRINTER) -and $script:CONECTADO_DEFAULT_PRINTER -ne "Nenhuma definida" -and $script:CONECTADO_DEFAULT_PRINTER -ne "Nao foi possivel consultar" -and $script:CONECTADO_DEFAULT_PRINTER -ne "-") {
            $defShort = $script:CONECTADO_DEFAULT_PRINTER
            if ($defShort -match '\\') {
                $defShort = $defShort.Split('\')[-1].Trim()
            }
        }

        # Impressoras de Rede (Exibe apenas o nome da impressora, sem caminho \\servidor\ nem GUIDs)
        if (![string]::IsNullOrWhiteSpace($script:CONECTADO_PRINTERS)) {
            $printers = $script:CONECTADO_PRINTERS -split ',\s*'
            $cleanPrinters = [System.Collections.Generic.List[string]]::new()
            foreach ($p in $printers) {
                $pClean = $p
                if ($pClean -match '\\') {
                    $pClean = $pClean.Split('\')[-1].Trim()
                }
                if ($pClean -notmatch '^\{[0-9a-fA-F\-]+\}$' -and ![string]::IsNullOrWhiteSpace($pClean) -and !$cleanPrinters.Contains($pClean)) {
                    $cleanPrinters.Add($pClean)
                }
            }
            if ($cleanPrinters.Count -gt 0) {
                $formattedPrinters = [System.Collections.Generic.List[string]]::new()
                foreach ($cp in $cleanPrinters) {
                    if (![string]::IsNullOrWhiteSpace($defShort) -and $cp -ieq $defShort) {
                        $formattedPrinters.Add("$cp (Padrao)")
                    } else {
                        $formattedPrinters.Add($cp)
                    }
                }
                $pStr = ($formattedPrinters -join ", ")
                $pLines = [System.Collections.Generic.List[string]]::new()
                $curL = ""
                foreach ($item in ($pStr -split ',\s*')) {
                    if (($curL + $item).Length -gt 50) {
                        $pLines.Add($curL.TrimEnd(', '))
                        $curL = "$item, "
                    } else {
                        $curL += "$item, "
                    }
                }
                if ($curL.Length -gt 0) { $pLines.Add($curL.TrimEnd(', ')) }

                $pFirst = $true
                foreach ($pl in $pLines) {
                    if ($pFirst) {
                        Write-Host "  Impressoras Rede : " -NoNewline -ForegroundColor Gray
                        Write-Host $pl -ForegroundColor White
                        $pFirst = $false
                    } else {
                        Write-Host "                     " -NoNewline
                        Write-Host $pl -ForegroundColor White
                    }
                }
            } else {
                Write-Host "  Impressoras Rede : " -NoNewline -ForegroundColor Gray
                Write-Host "Nenhuma" -ForegroundColor Gray
            }
        } else {
            Write-Host "  Impressoras Rede : " -NoNewline -ForegroundColor Gray
            Write-Host "Nenhuma" -ForegroundColor Gray
        }

        # Impressora Padrao (Linha dedicada abaixo de Impressoras e antes de Grupos AD)
        Write-Host "  Impressora Padrao: " -NoNewline -ForegroundColor Gray
        if (![string]::IsNullOrWhiteSpace($defShort)) {
            Write-Host "$defShort" -ForegroundColor Yellow
        } elseif ($script:CONECTADO_DEFAULT_PRINTER -eq "Nao foi possivel consultar") {
            Write-Host "Nao foi possivel consultar" -ForegroundColor DarkGray
        } else {
            Write-Host "Nenhuma definida" -ForegroundColor DarkGray
        }

        # Grupos AD
        if (![string]::IsNullOrWhiteSpace($script:CONECTADO_AD_PRINTERS)) {
            $adGroups = $script:CONECTADO_AD_PRINTERS -split ',\s*'
            $gLines = [System.Collections.Generic.List[string]]::new()
            $curG = ""
            foreach ($g in $adGroups) {
                if (($curG + $g).Length -gt 50) {
                    $gLines.Add($curG.TrimEnd(', '))
                    $curG = "$g, "
                } else {
                    $curG += "$g, "
                }
            }
            if ($curG.Length -gt 0) { $gLines.Add($curG.TrimEnd(', ')) }

            $gFirst = $true
            foreach ($gl in $gLines) {
                if ($gFirst) {
                    Write-Host "  Grupos AD Impr.  : " -NoNewline -ForegroundColor Gray
                    Write-Host $gl -ForegroundColor DarkCyan
                    $gFirst = $false
                } else {
                    Write-Host "                     " -NoNewline
                    Write-Host $gl -ForegroundColor DarkCyan
                }
            }
        } else {
            Write-Host "  Grupos AD Impr.  : " -NoNewline -ForegroundColor Gray
            Write-Host "Nenhum" -ForegroundColor DarkCyan
        }
    } else {
        Write-MenuSection "STATUS DA CONEXAO"
        Write-Host "  ○  Nenhum computador conectado" -ForegroundColor DarkGray
        Write-Host "     Use a opcao 01 para iniciar uma conexao remota." -ForegroundColor DarkGray
    }
}

function Show-Menu {
    if (Test-ConnectionTimeout) {
        return
    }
    Clear-Host
    Show-HeaderPanel "GERENCIADOR DE SUPORTE AVANCADO"
    Write-Breadcrumb $(if ($NoAdmin) { "ACESSO" } else { "MENU PRINCIPAL" })

    if ($NoAdmin) {
        Write-Host "  INICIO RAPIDO" -ForegroundColor White
        Write-Host "  Selecione o perfil de acesso para iniciar o atendimento." -ForegroundColor Gray
        Write-MenuSection "ACESSO"
        Write-MenuItem "1" "Entrar com usuario INS" "Green"
        Write-Host "          Acesso completo as ferramentas administrativas" -ForegroundColor DarkGray
        Write-MenuItem "0" "Fechar o gerenciador" "Red"
        Write-MenuFooter
        return
    }

    Show-ConnectedComputerPanel

    Write-MenuSection "CONEXAO E CONTROLE"
    if (![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) {
        Write-MenuItem "1" "Desconectar computador remoto" "Red"
    } else {
        Write-MenuItem "1" "Conectar a um computador remoto" "Green"
    }
    Write-MenuItem "2" "Abrir Controle Remoto SCCM" "White"
    Write-MenuItem "3" "Executar ping continuo" "White"
    Write-Host ""
    Write-MenuItem "4" "Abrir central de suporte remoto" "Yellow"

    Write-MenuSection "USUARIOS E DIRETORIO"
    if ($script:CONECTADO_IS_ADMIN -like "SIM*") {
        Write-MenuItem "5" "Remover $script:CONECTADO_USER de Admin Local" "Red"
    } elseif ($script:CONECTADO_IS_ADMIN -like "NAO*") {
        Write-MenuItem "5" "Adicionar $script:CONECTADO_USER como Admin Local" "Yellow"
    } else {
        Write-MenuItem "5" "Gerenciar usuario como Admin Local" "Yellow"
    }
    Write-MenuItem "6" "Gerenciar usuarios e grupos locais" "White"
    Write-MenuItem "7" "Abrir Active Directory" "White"
    Write-MenuItem "8" "Consultar grupos do usuario no AD" "Yellow"

    Write-MenuSection "DIAGNOSTICO E FERRAMENTAS"
    Write-MenuItem "9" "Analisar disco e perfis de usuario" "Cyan"
    Write-MenuItem "10" "Abrir Opcoes da Internet e certificados" "White"
    Write-MenuItem "11" "Atualizar informacoes do painel" "Green"

    Write-MenuSection "SESSAO"
    Write-MenuItem "12" "Voltar ao perfil padrao" "DarkGray"
    Write-MenuItem "0" "Fechar o gerenciador" "Red"
    Write-MenuFooter
}

function Show-RemoteMenu {
    if (Test-ConnectionTimeout) {
        return
    }
    Clear-Host
    Show-HeaderPanel "SUPORTE REMOTO (CONEXAO E COMANDOS)"
    Write-Breadcrumb "MENU PRINCIPAL  /  SUPORTE REMOTO"

    Show-ConnectedComputerPanel

    Write-MenuSection "SUPORTE AO COMPUTADOR"
    Write-MenuItem "1" "Fechar Outlook remotamente" "White"
    Write-MenuItem "2" "Limpar cache DNS (FlushDNS)" "White"
    Write-MenuItem "3" "Forcar atualizacao de politicas (GPUpdate)" "White"
    Write-MenuItem "4" "Realizar logoff remoto" "Yellow"
    Write-MenuItem "5" "Reiniciar computador remoto" "Red"
    Write-MenuItem "6" "Limpar pasta TEMP remota" "White"

    Write-MenuSection "SUPORTE A IMPRESSORAS"
    Write-MenuItem "7" "Instalar impressora remota" "White"
    Write-MenuItem "8" "Remover driver HP (Prodasen)" "White"
    Write-MenuItem "9" "Instalar driver HP (Prodasen)" "White"
    Write-MenuItem "10" "Imprimir pagina de teste" "White"
    Write-MenuItem "11" "Definir impressora padrao" "White"
    Write-MenuItem "12" "Limpar fila de impressao (Spooler)" "Yellow"

    Write-MenuSection "NAVEGACAO"
    Write-MenuItem "0" "Voltar ao menu principal" "Red"
    Write-MenuFooter
}

$menuMode = "main"

while ($true) {
    if ($menuMode -eq "main") {
        Show-Menu
        $RAW_OPCAO = Read-Host
        if ($RAW_OPCAO -match '^\d+$') {
            $RAW_OPCAO = ([int]$RAW_OPCAO).ToString()
        }
        $OPCAO = $RAW_OPCAO
        if ($NoAdmin) {
            if ($RAW_OPCAO -eq "1") {
                $OPCAO = "2"
            } elseif ($RAW_OPCAO -eq "0") {
                $OPCAO = "0"
            } else {
                $OPCAO = "invalid"
            }
        } else {
            if ($RAW_OPCAO -eq "1") {
                if (![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) {
                    $OPCAO = "desconectar"
                } else {
                    $OPCAO = "conectar"
                }
            } elseif ($RAW_OPCAO -eq "2") {
                $OPCAO = "cmrcviewer"
            } elseif ($RAW_OPCAO -eq "3") {
                $OPCAO = "13"
            } elseif ($RAW_OPCAO -eq "4") {
                $menuMode = "remote"
                continue
            } elseif ($RAW_OPCAO -eq "5") {
                $OPCAO = "add_local_admin"
            } elseif ($RAW_OPCAO -eq "6") {
                $OPCAO = "6"
            } elseif ($RAW_OPCAO -eq "7") {
                $OPCAO = "7"
            } elseif ($RAW_OPCAO -eq "8") {
                $OPCAO = "check_ad_groups"
            } elseif ($RAW_OPCAO -eq "9") {
                $OPCAO = "check_disk_profiles"
            } elseif ($RAW_OPCAO -eq "10") {
                $OPCAO = "manage_certs"
            } elseif ($RAW_OPCAO -eq "11") {
                $OPCAO = "refresh_panel"
            } elseif ($RAW_OPCAO -eq "12") {
                $OPCAO = "return_standard"
            } elseif ($RAW_OPCAO -eq "0") {
                $OPCAO = "0"
            } else {
                $OPCAO = "invalid"
            }
        }
    } else {
        Show-RemoteMenu
        $RAW_OPCAO = Read-Host
        if ($RAW_OPCAO -match '^\d+$') {
            $RAW_OPCAO = ([int]$RAW_OPCAO).ToString()
        }
        if ($RAW_OPCAO -eq "1") {
            $OPCAO = "8"
        } elseif ($RAW_OPCAO -eq "2") {
            $OPCAO = "9"
        } elseif ($RAW_OPCAO -eq "3") {
            $OPCAO = "10"
        } elseif ($RAW_OPCAO -eq "4") {
            $OPCAO = "11"
        } elseif ($RAW_OPCAO -eq "5") {
            $OPCAO = "12"
        } elseif ($RAW_OPCAO -eq "6") {
            $OPCAO = "clear_temp_remote"
        } elseif ($RAW_OPCAO -eq "7") {
            $OPCAO = "14"
        } elseif ($RAW_OPCAO -eq "8") {
            $OPCAO = "15"
        } elseif ($RAW_OPCAO -eq "9") {
            $OPCAO = "16"
        } elseif ($RAW_OPCAO -eq "10") {
            $OPCAO = "test_print_page"
        } elseif ($RAW_OPCAO -eq "11") {
            $OPCAO = "set_default_printer"
        } elseif ($RAW_OPCAO -eq "12") {
            $OPCAO = "clear_spooler_remote"
        } elseif ($RAW_OPCAO -eq "0") {
            $menuMode = "main"
            continue
        } else {
            $OPCAO = "invalid"
        }
    }

    switch ($OPCAO) {
        "check_disk_profiles" {
            Get-RemoteDiskAndProfilesSpace
        }
        "clear_temp_remote" {
            $COMP = Get-TargetComputer "Digite o nome ou IP do computador remoto"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                Clear-RemoteTemporaryFiles -computerName $COMP
            }
        }
        "refresh_panel" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   ATUALIZANDO INFORMACOES DO PAINEL..."
            Write-Host "========================================================"
            if (![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) {
                Write-Host "Re-consultando dados do computador '$script:CONECTADO_COMP'..." -ForegroundColor Cyan
                Set-ConnectedComputer -compName $script:CONECTADO_COMP
            } else {
                Write-Host "Painel atualizado!" -ForegroundColor Green
            }
            Start-Sleep -Seconds 1
        }
        "check_ad_groups" {
            Get-RemoteUserADGroups
        }
        "add_local_admin" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   GERENCIAR ADMINISTRADOR LOCAL REMOTO (ADICIONAR/REMOVER)"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP do computador remoto"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                $cleanComp = $COMP.Replace('\', '').Trim()
                Write-Host ""
                
                # Tenta detectar usuario logado ou usar o conectado
                $targetUser = $null
                if ($cleanComp -eq $script:CONECTADO_COMP -and ![string]::IsNullOrWhiteSpace($script:CONECTADO_USER)) {
                    $targetUser = $script:CONECTADO_USER
                } else {
                    try {
                        $cs = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $cleanComp -ErrorAction SilentlyContinue
                        if ($cs -and ![string]::IsNullOrWhiteSpace($cs.UserName)) {
                            $targetUser = $cs.UserName
                        }
                    } catch {}
                }

                if (![string]::IsNullOrWhiteSpace($targetUser)) {
                    Write-Host "Usuario detectado no computador $($cleanComp): $targetUser" -ForegroundColor Cyan
                    Write-Host "Pressione [ENTER] para usar '$targetUser' ou digite o login do usuario desejado (ex: SENADO\nome.usuario):" -ForegroundColor Yellow
                    $inputUser = Read-Host "Usuario"
                    if (![string]::IsNullOrWhiteSpace($inputUser)) {
                        $targetUser = $inputUser.Trim()
                    }
                } else {
                    $targetUser = Read-Host "Digite o usuario que deseja alterar (ex: SENADO\nome.usuario ou nome.usuario)"
                }

                if (![string]::IsNullOrWhiteSpace($targetUser)) {
                    # Trata o formato DOMINIO\usuario
                    $userDomain = $DOM
                    $userNameOnly = $targetUser
                    if ($targetUser -match '\\') {
                        $parts = $targetUser -split '\\', 2
                        $userDomain = $parts[0]
                        $userNameOnly = $parts[1]
                    }
                    $fullUser = "$userDomain\$userNameOnly"

                    # Identifica nome do grupo de Administradores Locais (Administradores vs Administrators)
                    $adminGroup = "Administradores"
                    try {
                        $sid = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-544")
                        $translated = $sid.Translate([System.Security.Principal.NTAccount]).Value
                        if ($translated -match '\\') {
                            $adminGroup = $translated.Split('\')[-1]
                        } else {
                            $adminGroup = $translated
                        }
                    } catch {}

                    # Checar se o usuario JA e Administrador Local
                    $currentlyAdmin = Test-UserIsLocalAdmin -computerName $cleanComp -targetUser $fullUser

                    $success = $false

                    if ($currentlyAdmin) {
                        # ACAO: REMOVER ADMINISTRADOR
                        Write-Host ""
                        Write-Host "O usuario '$fullUser' ATUALMENTE E ADMINISTRADOR LOCAL em '$cleanComp'." -ForegroundColor Red
                        Write-Host "Iniciando REMOCAO do grupo '$adminGroup'..." -ForegroundColor Red

                        # Estrategia 1: ADSI WinNT Provider Remove
                        try {
                            $groupObj = [ADSI]"WinNT://$cleanComp/$adminGroup,group"
                            if ($groupObj) {
                                $groupObj.Remove("WinNT://$userDomain/$userNameOnly")
                                $success = $true
                                Write-Host "Usuario '$fullUser' REMOVIDO do grupo '$adminGroup' via ADSI com sucesso!" -ForegroundColor Green
                            }
                        } catch {
                            $adsiErr = $_.Exception.Message
                            Write-Host "Tentativa via ADSI: $adsiErr" -ForegroundColor Gray
                        }

                        # Estrategia 2: net localgroup via WMI (Win32_Process) /delete
                        if (!$success) {
                            try {
                                $cmd = "cmd.exe /c net localgroup ""$adminGroup"" ""$fullUser"" /delete"
                                $wmiRes = Invoke-WmiMethod -Class Win32_Process -ComputerName $cleanComp -Name Create -ArgumentList $cmd -ErrorAction Stop
                                if ($wmiRes.ReturnValue -eq 0) {
                                    $success = $true
                                    Write-Host "Comando 'net localgroup /delete' executado com sucesso em $cleanComp via WMI!" -ForegroundColor Green
                                } else {
                                    Write-Host "WMI Win32_Process retornou codigo: $($wmiRes.ReturnValue)" -ForegroundColor Yellow
                                }
                            } catch {
                                Write-Host "Tentativa via WMI: $_" -ForegroundColor Gray
                            }
                        }

                        # Estrategia 3: Execucao direta com net localgroup /delete
                        if (!$success) {
                            try {
                                $netOut = cmd.exe /c "net localgroup ""$adminGroup"" ""$fullUser"" /delete" 2>&1
                                if ($LASTEXITCODE -eq 0) {
                                    $success = $true
                                    Write-Host "Removido com sucesso via net localgroup!" -ForegroundColor Green
                                } else {
                                    Write-Host "Resultado do net localgroup: $netOut" -ForegroundColor Yellow
                                }
                            } catch {}
                        }

                    } else {
                        # ACAO: ADICIONAR ADMINISTRADOR
                        Write-Host ""
                        Write-Host "O usuario '$fullUser' NAO E ADMINISTRADOR LOCAL em '$cleanComp'." -ForegroundColor Yellow
                        Write-Host "Iniciando ADICAO ao grupo '$adminGroup'..." -ForegroundColor Green

                        # Estrategia 1: ADSI WinNT Provider Add
                        try {
                            $groupObj = [ADSI]"WinNT://$cleanComp/$adminGroup,group"
                            if ($groupObj) {
                                $groupObj.Add("WinNT://$userDomain/$userNameOnly")
                                $success = $true
                                Write-Host "Usuario '$fullUser' ADICIONADO ao grupo '$adminGroup' via ADSI com sucesso!" -ForegroundColor Green
                            }
                        } catch {
                            $adsiErr = $_.Exception.Message
                            Write-Host "Tentativa via ADSI: $adsiErr" -ForegroundColor Gray
                        }

                        # Estrategia 2: net localgroup via WMI (Win32_Process) /add
                        if (!$success) {
                            try {
                                $cmd = "cmd.exe /c net localgroup ""$adminGroup"" ""$fullUser"" /add"
                                $wmiRes = Invoke-WmiMethod -Class Win32_Process -ComputerName $cleanComp -Name Create -ArgumentList $cmd -ErrorAction Stop
                                if ($wmiRes.ReturnValue -eq 0) {
                                    $success = $true
                                    Write-Host "Comando 'net localgroup /add' executado com sucesso em $cleanComp via WMI!" -ForegroundColor Green
                                } else {
                                    Write-Host "WMI Win32_Process retornou codigo: $($wmiRes.ReturnValue)" -ForegroundColor Yellow
                                }
                            } catch {
                                Write-Host "Tentativa via WMI: $_" -ForegroundColor Gray
                            }
                        }

                        # Estrategia 3: Execucao direta com net localgroup /add
                        if (!$success) {
                            try {
                                $netOut = cmd.exe /c "net localgroup ""$adminGroup"" ""$fullUser"" /add /domain" 2>&1
                                if ($LASTEXITCODE -eq 0) {
                                    $success = $true
                                    Write-Host "Adicionado com sucesso via net localgroup!" -ForegroundColor Green
                                } else {
                                    Write-Host "Resultado do net localgroup: $netOut" -ForegroundColor Yellow
                                }
                            } catch {}
                        }
                    }

                    # Atualiza status no cabecalho se for o computador conectado
                    if ($cleanComp -eq $script:CONECTADO_COMP) {
                        $nowAdmin = Test-UserIsLocalAdmin -computerName $cleanComp -targetUser $fullUser
                        if ($nowAdmin) {
                            $script:CONECTADO_IS_ADMIN = "SIM ($fullUser)"
                        } else {
                            $script:CONECTADO_IS_ADMIN = "NAO ($fullUser)"
                        }
                    }

                    # Lista de Verificacao dos Membros Atuais
                    Write-Host ""
                    Write-Host "--------------------------------------------------------" -ForegroundColor Gray
                    Write-Host "Membros atuais do grupo '$adminGroup' em $($cleanComp):" -ForegroundColor Cyan
                    try {
                        $gObj = [ADSI]"WinNT://$cleanComp/$adminGroup,group"
                        $mList = $gObj.psbase.Invoke('Members')
                        foreach ($m in $mList) {
                            $mName = $m.GetType().InvokeMember('Name', 'GetProperty', $null, $m, $null)
                            $mPath = $m.GetType().InvokeMember('ADSPath', 'GetProperty', $null, $m, $null)
                            $cleanM = $mPath -replace "WinNT://", "" -replace "/", "\"
                            Write-Host "  - $cleanM ($mName)" -ForegroundColor Yellow
                        }
                    } catch {
                        Write-Host "  (Consulte 'Gerenciar Usuarios e Grupos Locais' para visualizar a lista completa)" -ForegroundColor Gray
                    }
                    Write-Host "--------------------------------------------------------" -ForegroundColor Gray

                } else {
                    Write-Host "Nenhum usuario informado. Operacao cancelada." -ForegroundColor Yellow
                }

                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "cmrcviewer" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   CONTROLE REMOTO (CmRcViewer.exe)"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP do computador remoto"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                Write-Host ""
                Write-Host "Procurando executavel do Controle Remoto (CmRcViewer.exe)..." -ForegroundColor Cyan
                
                # Lista de caminhos para busca
                $paths = @("CmRcViewer.exe")
                
                if (![string]::IsNullOrWhiteSpace($env:SMS_ADMIN_UI_PATH)) {
                    $paths += Join-Path $env:SMS_ADMIN_UI_PATH "i386\CmRcViewer.exe"
                    $paths += Join-Path $env:SMS_ADMIN_UI_PATH "CmRcViewer.exe"
                }
                
                $baseDirs = @(
                    "C:\Program Files (x86)\Microsoft Endpoint Manager\AdminConsole\bin",
                    "C:\Program Files\Microsoft Endpoint Manager\AdminConsole\bin",
                    "C:\Program Files (x86)\Microsoft Configuration Manager\AdminConsole\bin",
                    "C:\Program Files\Microsoft Configuration Manager\bin"
                )
                
                foreach ($dir in $baseDirs) {
                    if (Test-Path $dir) {
                        $paths += Join-Path $dir "i386\CmRcViewer.exe"
                        $paths += Join-Path $dir "CmRcViewer.exe"
                    }
                }
                
                $progFiles = @($env:ProgramFiles, "$env:SystemDrive\Program Files (x86)")
                foreach ($pf in $progFiles) {
                    if ([string]::IsNullOrWhiteSpace($pf)) { continue }
                    $searchDirs = @()
                    if (Test-Path "$pf\Microsoft Endpoint Manager") { $searchDirs += "$pf\Microsoft Endpoint Manager" }
                    if (Test-Path "$pf\Microsoft Configuration Manager") { $searchDirs += "$pf\Microsoft Configuration Manager" }
                    if (Test-Path "$pf\Microsoft System Center") { $searchDirs += "$pf\Microsoft System Center" }
                    
                    foreach ($sd in $searchDirs) {
                        try {
                            $found = Get-ChildItem -Path $sd -Filter "CmRcViewer.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName
                            if ($found) { $paths += $found }
                        } catch {}
                    }
                }
                
                try {
                    $downloadsFound = Get-ChildItem -Path "$HOME\Downloads" -Filter "CmRcViewer.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName
                    if ($downloadsFound) { $paths += $downloadsFound }
                } catch {}

                if (![string]::IsNullOrWhiteSpace($PSCommandPath)) {
                    $scriptDir = Split-Path $PSCommandPath
                    $paths += Join-Path $scriptDir "CmRcViewer.exe"
                }
                
                $exePath = $null
                foreach ($p in $paths) {
                    if ($p -eq "CmRcViewer.exe") {
                        $resolved = Get-Command "CmRcViewer.exe" -ErrorAction SilentlyContinue
                        if ($resolved) {
                            $exePath = "CmRcViewer.exe"
                            break
                        }
                    } elseif (Test-Path $p) {
                        $exePath = $p
                        break
                    }
                }
                
                if ($exePath) {
                    Write-Host "Iniciando Controle Remoto ($exePath) para $COMP..." -ForegroundColor Cyan
                    try {
                        Start-Process $exePath -ArgumentList $COMP
                        Write-Host "CmRcViewer.exe iniciado com sucesso para $COMP!" -ForegroundColor Green
                    } catch {
                        Write-Host "Erro ao iniciar CmRcViewer.exe: $_" -ForegroundColor Red
                    }
                } else {
                    Write-Host "Erro: O executavel 'CmRcViewer.exe' nao foi localizado nas pastas padrao do SCCM," -ForegroundColor Red
                    Write-Host "na pasta Downloads, ou no mesmo diretorio deste script." -ForegroundColor Red
                    Write-Host ""
                    Write-Host "Por favor, coloque o CmRcViewer.exe na mesma pasta deste script ou em Downloads" -ForegroundColor Yellow
                    Write-Host "para que ele possa ser detectado e executado automaticamente." -ForegroundColor Yellow
                }
                Start-Sleep -Seconds 4
            }
        }
        "check_cmrcviewer" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   VERIFICAR INSTALACAO DO CmRcViewer.exe"
            Write-Host "========================================================"
            Write-Host ""
            Write-Host "Como deseja realizar a verificacao?" -ForegroundColor Cyan
            Write-Host "   1 - No computador LOCAL (onde o script esta rodando)"
            Write-Host "   2 - Em um computador REMOTO"
            Write-Host ""
            $TIPO = Read-Host "Selecione uma opcao"
            
            if ($TIPO -eq "1") {
                Clear-Host
                Write-Host "========================================================"
                Write-Host "   BUSCANDO CmRcViewer.exe LOCALMENTE"
                Write-Host "========================================================"
                Write-Host ""
                Write-Host "Procurando nas pastas padrao..." -ForegroundColor Cyan
                
                $paths = @("CmRcViewer.exe")
                if (![string]::IsNullOrWhiteSpace($env:SMS_ADMIN_UI_PATH)) {
                    $paths += Join-Path $env:SMS_ADMIN_UI_PATH "i386\CmRcViewer.exe"
                    $paths += Join-Path $env:SMS_ADMIN_UI_PATH "CmRcViewer.exe"
                }
                
                $baseDirs = @(
                    "C:\Program Files (x86)\Microsoft Endpoint Manager\AdminConsole\bin",
                    "C:\Program Files\Microsoft Endpoint Manager\AdminConsole\bin",
                    "C:\Program Files (x86)\Microsoft Configuration Manager\AdminConsole\bin",
                    "C:\Program Files\Microsoft Configuration Manager\bin"
                )
                
                foreach ($dir in $baseDirs) {
                    if (Test-Path $dir) {
                        $paths += Join-Path $dir "i386\CmRcViewer.exe"
                        $paths += Join-Path $dir "CmRcViewer.exe"
                    }
                }
                
                $progFiles = @($env:ProgramFiles, "$env:SystemDrive\Program Files (x86)")
                foreach ($pf in $progFiles) {
                    if ([string]::IsNullOrWhiteSpace($pf)) { continue }
                    $searchDirs = @()
                    if (Test-Path "$pf\Microsoft Endpoint Manager") { $searchDirs += "$pf\Microsoft Endpoint Manager" }
                    if (Test-Path "$pf\Microsoft Configuration Manager") { $searchDirs += "$pf\Microsoft Configuration Manager" }
                    if (Test-Path "$pf\Microsoft System Center") { $searchDirs += "$pf\Microsoft System Center" }
                    
                    foreach ($sd in $searchDirs) {
                        try {
                            $found = Get-ChildItem -Path $sd -Filter "CmRcViewer.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName
                            if ($found) { $paths += $found }
                        } catch {}
                    }
                }
                
                try {
                    $downloadsFound = Get-ChildItem -Path "$HOME\Downloads" -Filter "CmRcViewer.exe" -Recurse -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName
                    if ($downloadsFound) { $paths += $downloadsFound }
                } catch {}

                if (![string]::IsNullOrWhiteSpace($PSCommandPath)) {
                    $scriptDir = Split-Path $PSCommandPath
                    $paths += Join-Path $scriptDir "CmRcViewer.exe"
                }
                
                $encontrados = @()
                foreach ($p in $paths) {
                    if ($p -eq "CmRcViewer.exe") {
                        $resolved = Get-Command "CmRcViewer.exe" -ErrorAction SilentlyContinue
                        if ($resolved) {
                            $encontrados += "CmRcViewer.exe (Disponivel no PATH de variaveis de ambiente)"
                        }
                    } elseif (Test-Path $p) {
                        if ($encontrados -notcontains $p) {
                            $encontrados += $p
                        }
                    }
                }
                
                if ($encontrados.Count -gt 0) {
                    Write-Host "CmRcViewer.exe ENCONTRADO!" -ForegroundColor Green
                    Write-Host "Locais localizados:" -ForegroundColor White
                    foreach ($enc in $encontrados) {
                        Write-Host " - $enc" -ForegroundColor Gray
                    }
                } else {
                    Write-Host "CmRcViewer.exe NAO ENCONTRADO no computador local." -ForegroundColor Red
                    Write-Host ""
                    Write-Host "Dicas para resolver:" -ForegroundColor Yellow
                    Write-Host "1. Instale o Admin Console do SCCM / MECM no seu computador."
                    Write-Host "2. Baixe apenas o 'CmRcViewer.exe' (com seus arquivos de dependencia, como 'rdpcoresec.dll') e cole em Downloads ou na mesma pasta deste script."
                }
            } elseif ($TIPO -eq "2") {
                Clear-Host
                Write-Host "========================================================"
                Write-Host "   VERIFICANDO REMOTAMENTE SE CmRcViewer / AGENTE ESTAO INSTALADOS"
                Write-Host "========================================================"
                $COMP = Get-TargetComputer "Digite o nome ou IP do computador remoto"
                if (![string]::IsNullOrWhiteSpace($COMP)) {
                    Write-Host ""
                    Write-Host "Testando conectividade (Ping) com $COMP..." -ForegroundColor Cyan
                    $pingOk = $false
                    try {
                        $pingOk = Test-Connection -ComputerName $COMP -Count 1 -Quiet -ErrorAction SilentlyContinue
                    } catch {}
                    
                    if ($pingOk) {
                        Write-Host "Computador $COMP esta ONLINE." -ForegroundColor Green
                    } else {
                        Write-Host "Aviso: Computador $COMP nao respondeu ao ping. Tentando acesso assim mesmo..." -ForegroundColor Yellow
                    }
                    
                    Write-Host ""
                    Write-Host "1. Verificando Servico de Controle Remoto (CmRcService)..." -ForegroundColor Cyan
                    try {
                        $service = Get-Service -ComputerName $COMP -Name CmRcService -ErrorAction Stop
                        Write-Host "   Servico 'CmRcService' detectado!" -ForegroundColor Green
                        Write-Host "   Status: $($service.Status)" -ForegroundColor White
                        Write-Host "   Tipo de Inicializacao: $($service.StartType)" -ForegroundColor White
                    } catch {
                        try {
                            $wmiService = Get-WmiObject -ComputerName $COMP -Class Win32_Service -Filter "Name='CmRcService'" -ErrorAction Stop
                            if ($wmiService) {
                                Write-Host "   Servico 'CmRcService' detectado via WMI!" -ForegroundColor Green
                                Write-Host "   Status: $($wmiService.State)" -ForegroundColor White
                                Write-Host "   Modo de Inicializacao: $($wmiService.StartMode)" -ForegroundColor White
                            } else {
                                Write-Host "   Servico 'CmRcService' NAO esta instalado nesta maquina remota." -ForegroundColor Yellow
                            }
                        } catch {
                            Write-Host "   Nao foi possivel consultar o servico remoto. Erro: $_" -ForegroundColor Red
                        }
                    }
                    
                    Write-Host ""
                    Write-Host "2. Verificando CmRcViewer.exe nas pastas compartilhadas administrativas (C$)..." -ForegroundColor Cyan
                    try {
                        $remotePaths = @()
                        $baseDirs = @(
                            "Program Files (x86)\Microsoft Endpoint Manager\AdminConsole\bin",
                            "Program Files\Microsoft Endpoint Manager\AdminConsole\bin",
                            "Program Files (x86)\Microsoft Configuration Manager\AdminConsole\bin",
                            "Program Files\Microsoft Configuration Manager\bin"
                        )
                        foreach ($bd in $baseDirs) {
                            $remotePaths += "\\$COMP\C$$\$bd\i386\CmRcViewer.exe"
                            $remotePaths += "\\$COMP\C$$\$bd\CmRcViewer.exe"
                        }
                        
                        $remEncontrados = @()
                        foreach ($rp in $remotePaths) {
                            if (Test-Path $rp) {
                                $remEncontrados += $rp
                            }
                        }
                        
                        if ($remEncontrados.Count -gt 0) {
                            Write-Host "   CmRcViewer.exe (Viewer do Admin Console) ENCONTRADO na maquina remota!" -ForegroundColor Green
                            foreach ($renc in $remEncontrados) {
                                Write-Host "    - $renc" -ForegroundColor Gray
                            }
                        } else {
                            Write-Host "   Nenhum CmRcViewer.exe (Viewer) localizado nas pastas padrao de C$ na maquina remota." -ForegroundColor Yellow
                            Write-Host "   (Isso e comum se a maquina remota for apenas um cliente comum e nao um computador de tecnico)" -ForegroundColor Gray
                        }
                    } catch {
                        Write-Host "   Sem acesso de rede para verificar arquivos administrativos (C$)." -ForegroundColor Yellow
                    }
                }
            } else {
                Write-Host "Opcao invalida." -ForegroundColor Yellow
            }
            Write-Host ""
            Read-Host "Pressione ENTER para retornar ao menu..."
        }
        "conectar" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   CONECTAR COMPUTADOR REMOTO"
            Write-Host "========================================================"
            $DIGITADO = Read-Host "Digite o nome ou IP do computador para manter conectado"
            if (![string]::IsNullOrWhiteSpace($DIGITADO)) {
                Set-ConnectedComputer -compName $DIGITADO
                Write-Host ""
                Write-Host "Computador '$script:CONECTADO_COMP' conectado com sucesso!" -ForegroundColor Green
            } else {
                Write-Host "Nenhum computador digitado." -ForegroundColor Yellow
            }
            Start-Sleep -Seconds 2
        }
        "desconectar" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   DESCONECTAR COMPUTADOR REMOTO"
            Write-Host "========================================================"
            Write-Host "Desconectando computador '$script:CONECTADO_COMP'..." -ForegroundColor Yellow
            Disconnect-ConnectedComputer
            Write-Host "Desconectado com sucesso!" -ForegroundColor Green
            Start-Sleep -Seconds 2
        }
        "return_standard" {
            Clear-Host
            if ($NoAdmin) {
                Show-HeaderPanel "SESSAO PADRAO"
                Write-Host "  Voce ja esta utilizando a identidade padrao do Windows." -ForegroundColor Green
                Read-Host "Pressione ENTER para retornar..."
            } else {
                Show-HeaderPanel "ENCERRANDO SESSAO INS"
                $STD_LOGIN = $LOGIN -replace '(?i)_ins',''
                Write-Host "  Retornando com a conta  " -NoNewline -ForegroundColor DarkGray
                Write-Host "$DOM\$STD_LOGIN" -ForegroundColor Green
                Write-Host ""
                Write-Host "  Abrindo o menu inicial com a identidade padrao..." -ForegroundColor Cyan
                $ArgumentList = "/user:$DOM\$STD_LOGIN /savecred `"cmd.exe /c \`"$PSCommandPath\`" /noadmin`""
                try {
                    Start-Process runas -ArgumentList $ArgumentList -ErrorAction Stop
                    Write-Host "  ✓ Sessao padrao solicitada. Encerrando a janela INS." -ForegroundColor Green
                    Start-Sleep -Milliseconds 900
                    exit
                } catch {
                    Write-Host "  Nao foi possivel abrir o usuario padrao." -ForegroundColor Red
                    Write-Host "  $($_.Exception.Message)" -ForegroundColor DarkGray
                    Write-Host ""
                    Read-Host "  Pressione ENTER para retornar"
                }
            }
        }
        "2" {
            Clear-Host
            if ($NoAdmin) {
                Show-HeaderPanel "ABRIR SESSAO ADMINISTRATIVA"
                $INS_LOGIN = "$($LOGIN -replace '_ins','')_ins"
                Write-Host "  Conta solicitada  " -NoNewline -ForegroundColor DarkGray
                Write-Host "$DOM\$INS_LOGIN" -ForegroundColor Yellow
                Write-Host ""
                Write-Host "  Abrindo o ambiente INS em uma nova janela..." -ForegroundColor Cyan
                Write-Host "  A janela padrao sera encerrada apos iniciar o INS." -ForegroundColor Gray
                $ArgumentList = "/user:$DOM\$INS_LOGIN /savecred `"cmd.exe /c \`"$PSCommandPath\`" /ins`""
                try {
                    Start-Process runas -ArgumentList $ArgumentList -ErrorAction Stop
                    Write-Host ""
                    Write-Host "  ✓ Sessao INS solicitada. Encerrando a janela padrao." -ForegroundColor Green
                    Start-Sleep -Milliseconds 900
                    exit
                } catch {
                    Write-Host ""
                    Write-Host "  Nao foi possivel abrir a sessao INS." -ForegroundColor Red
                    Write-Host "  $($_.Exception.Message)" -ForegroundColor DarkGray
                }
                Write-Host ""
                Read-Host "  Pressione ENTER para voltar ao menu"
            } else {
                Write-Host "Voce ja esta logado como INS (Com Admin)."
                Read-Host "Pressione ENTER para retornar..."
            }
        }
        "3" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   VERIFICAR LOGIN CONECTADO (QWINSTA)"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                Write-Host ""
                qwinsta /server:$COMP
                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "4" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   VERIFICAR TEMPO DE ATIVIDADE (UPTIME)"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                Write-Host ""
                Write-Host "Consultando tempo de atividade de $COMP..."
                try {
                    $os = Get-WmiObject -ComputerName $COMP -Class Win32_OperatingSystem -ErrorAction Stop
                    $lastBootTime = $os.ConvertToDateTime($os.LastBootUpTime)
                    $uptime = (Get-Date) - $lastBootTime
                    Write-Host "O computador '$COMP' foi iniciado em:" -ForegroundColor Cyan
                    Write-Host "$lastBootTime" -ForegroundColor White
                    Write-Host ""
                    Write-Host "Tempo de atividade:" -ForegroundColor Cyan
                    Write-Host "$($uptime.Days) dias, $($uptime.Hours) horas, $($uptime.Minutes) minutos e $($uptime.Seconds) segundos" -ForegroundColor Green
                } catch {
                    Write-Host "Erro ao consultar tempo de atividade em $($COMP): $_" -ForegroundColor Red
                }
                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "5" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   CONSULTAR SERIAL NUMBER (BIOS)"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                try {
                    $bios = Get-WmiObject win32_bios -ComputerName $COMP -ErrorAction Stop
                    Write-Host ""
                    Write-Host "SerialNumber"
                    Write-Host $bios.SerialNumber
                    Write-Host ""
                } catch {
                    Write-Host "Erro ao consultar $($COMP): $_" -ForegroundColor Red
                }
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "6" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   ABRIR USUARIOS E GRUPOS LOCAIS REMOTO"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                Write-Host "Conectando a \\$COMP..."
                Start-Process "lusrmgr.msc" -ArgumentList "/computer:\\$COMP"
            }
        }
        "7" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   ABRINDO ACTIVE DIRECTORY"
            Write-Host "========================================================"
            Start-Process "dsa.msc"
        }
        "8" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   FORCAR FECHAMENTO DO OUTLOOK REMOTO"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                Write-Host ""
                Write-Host "Finalizando processos do Outlook em $COMP..."
                taskkill /S $COMP /IM outlook.exe /F 2> $null
                taskkill /S $COMP /IM olk.exe /F 2> $null
                Write-Host "Comandos de fechamento enviados."
                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "9" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   LIMPAR DNS REMOTO (FLUSHDNS) (INTERATIVO)"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                Write-Host ""
                try {
                    Write-Host "Verificando usuario logado em $COMP..."
                    $computerSystem = Get-WmiObject -ComputerName $COMP -Class Win32_ComputerSystem -ErrorAction Stop
                    $user = $computerSystem.UserName

                    if (![string]::IsNullOrWhiteSpace($user)) {
                        Write-Host "Usuario '$user' detectado. Criando tarefa interativa via XML..."
                        $xmlPath = "$env:TEMP\FlushDNSTask_$($COMP).xml"
                        $taskXml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Principals>
    <Principal id="Author">
      <UserId>$user</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>cmd.exe</Command>
      <Arguments>/c "mode con: cols=70 lines=15 &amp; title Limpar DNS Remoto &amp; color 1f &amp; echo ======================================== &amp; echo Limpando Cache DNS (FlushDNS) &amp; echo Solicitado pelo Suporte Avancado &amp; echo ======================================== &amp; echo. &amp; ipconfig /flushdns &amp; echo. &amp; echo Janela sera fechada em instantes... &amp; timeout /t 10"</Arguments>
    </Exec>
  </Actions>
</Task>
"@
                        [System.IO.File]::WriteAllText($xmlPath, $taskXml, [System.Text.Encoding]::Unicode)
                        
                        $schOutput = schtasks /create /s $COMP /tn "Suporte_FlushDNS" /xml $xmlPath /f 2>&1
                        if ($LASTEXITCODE -eq 0) {
                            schtasks /run /s $COMP /tn "Suporte_FlushDNS" > $null 2>&1
                            Write-Host "Comando executado com sucesso e visivel na tela do usuario!" -ForegroundColor Green
                            Start-Sleep -Seconds 2
                            schtasks /delete /s $COMP /tn "Suporte_FlushDNS" /f > $null 2>&1
                        } else {
                            Write-Host "Falha ao criar tarefa interativa. O erro foi:" -ForegroundColor Yellow
                            Write-Host $schOutput -ForegroundColor Gray
                            Write-Host "Executando via WMI (oculto)..." -ForegroundColor Yellow
                            Invoke-WmiMethod -ComputerName $COMP -Class Win32_Process -Name Create -ArgumentList "cmd.exe /c ipconfig /flushdns" | Out-Null
                            Write-Host "Comando enviado em segundo plano." -ForegroundColor Green
                        }
                        Remove-Item -Path $xmlPath -Force -ErrorAction SilentlyContinue
                    } else {
                        Write-Host "Nenhum usuario logado no momento. Executando em segundo plano..."
                        Invoke-WmiMethod -ComputerName $COMP -Class Win32_Process -Name Create -ArgumentList "cmd.exe /c ipconfig /flushdns" | Out-Null
                        Write-Host "Comando enviado em segundo plano." -ForegroundColor Green
                    }
                } catch {
                    Write-Host "Erro ao conectar em $($COMP): $_" -ForegroundColor Red
                }
                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "10" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   FORCAR GPUPDATE REMOTO (INTERATIVO)"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                Write-Host ""
                try {
                    Write-Host "Verificando usuario logado em $COMP..."
                    $computerSystem = Get-WmiObject -ComputerName $COMP -Class Win32_ComputerSystem -ErrorAction Stop
                    $user = $computerSystem.UserName

                    if (![string]::IsNullOrWhiteSpace($user)) {
                        Write-Host "Usuario '$user' detectado. Criando tarefa interativa via XML..."
                        $xmlPath = "$env:TEMP\GPUpdateTask_$($COMP).xml"
                        $taskXml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Principals>
    <Principal id="Author">
      <UserId>$user</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>cmd.exe</Command>
      <Arguments>/c "mode con: cols=70 lines=15 &amp; title GPUpdate Remoto &amp; color 1f &amp; echo ======================================== &amp; echo Atualizando Politicas de Grupo (GPUpdate) &amp; echo Solicitado pelo Suporte Avancado &amp; echo ======================================== &amp; echo. &amp; gpupdate /force &amp; echo. &amp; echo Janela sera fechada em instantes... &amp; timeout /t 10"</Arguments>
    </Exec>
  </Actions>
</Task>
"@
                        [System.IO.File]::WriteAllText($xmlPath, $taskXml, [System.Text.Encoding]::Unicode)
                        
                        $schOutput = schtasks /create /s $COMP /tn "Suporte_GPUpdate" /xml $xmlPath /f 2>&1
                        if ($LASTEXITCODE -eq 0) {
                            schtasks /run /s $COMP /tn "Suporte_GPUpdate" > $null 2>&1
                            Write-Host "Comando executado com sucesso e visivel na tela do usuario!" -ForegroundColor Green
                            Start-Sleep -Seconds 2
                            schtasks /delete /s $COMP /tn "Suporte_GPUpdate" /f > $null 2>&1
                        } else {
                            Write-Host "Falha ao criar tarefa interativa. O erro foi:" -ForegroundColor Yellow
                            Write-Host $schOutput -ForegroundColor Gray
                            Write-Host "Executando via WMI (oculto)..." -ForegroundColor Yellow
                            Invoke-WmiMethod -ComputerName $COMP -Class Win32_Process -Name Create -ArgumentList "cmd.exe /c echo N | gpupdate /force" | Out-Null
                            Write-Host "Comando enviado em segundo plano." -ForegroundColor Green
                        }
                        Remove-Item -Path $xmlPath -Force -ErrorAction SilentlyContinue
                    } else {
                        Write-Host "Nenhum usuario logado no momento. Executando em segundo plano..."
                        Invoke-WmiMethod -ComputerName $COMP -Class Win32_Process -Name Create -ArgumentList "cmd.exe /c echo N | gpupdate /force" | Out-Null
                        Write-Host "Comando enviado em segundo plano." -ForegroundColor Green
                    }
                } catch {
                    Write-Host "Erro ao conectar em $($COMP): $_" -ForegroundColor Red
                }
                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "11" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   REALIZAR LOGOFF REMOTO"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                Write-Host ""
                Write-Host "Verificando se ha alguem logado em $COMP..."
                try {
                    $computerSystem = Get-WmiObject -ComputerName $COMP -Class Win32_ComputerSystem -ErrorAction Stop
                    $user = $computerSystem.UserName

                    if (![string]::IsNullOrWhiteSpace($user)) {
                        Write-Host "Usuario '$user' detectado." -ForegroundColor Yellow
                        $CONFIRMAR = Read-Host "Deseja realmente derrubar a sessao desse usuario? (S/N)"
                        if ($CONFIRMAR -eq "S" -or $CONFIRMAR -eq "s") {
                            Write-Host "Enviando comando de logoff forcado via WMI..."
                            $os = Get-WmiObject -ComputerName $COMP -Class Win32_OperatingSystem -ErrorAction Stop
                            $result = $os.Win32Shutdown(4) # 4 = Forcar Logoff
                            if ($result.ReturnValue -eq 0) {
                                Write-Host "Comando de logoff executado com sucesso." -ForegroundColor Green
                            } else {
                                Write-Host "Falha ao enviar comando de logoff. Codigo: $($result.ReturnValue)" -ForegroundColor Yellow
                            }
                        } else {
                            Write-Host "Operacao cancelada." -ForegroundColor Cyan
                        }
                    } else {
                        Write-Host "Nenhum usuario logado no momento. Nao e necessario fazer logoff." -ForegroundColor Cyan
                    }
                } catch {
                    Write-Host "Erro ao conectar em $($COMP): $_" -ForegroundColor Red
                }
                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "12" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   REINICIAR COMPUTADOR REMOTO"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                Write-Host ""
                $CONFIRM = Read-Host "Confirmar reinicio da maquina $COMP? (S/N)"
                if ($CONFIRM -match "^[sS]$") {
                    shutdown -r -f -t 00 -m \\$COMP
                    Write-Host "Comando de reinicializacao enviado."
                } else {
                    Write-Host "Operacao cancelada."
                }
                Start-Sleep -Seconds 3
            }
        }
        "13" {
            Show-ToolHeader "PING CONTINUO (PING -T)"
            $defaultTarget = if (![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) { $script:CONECTADO_COMP } else { $env:COMPUTERNAME }
            Write-Host "Pressione [ENTER] para pingar a maquina atual ($defaultTarget) ou digite outro IP/nome:" -ForegroundColor Yellow
            $inputTarget = Read-Host "Endereco / IP"
            if ([string]::IsNullOrWhiteSpace($inputTarget)) {
                $TARGET = $defaultTarget
            } else {
                $TARGET = $inputTarget.Replace('\', '').Trim()
            }

            if (![string]::IsNullOrWhiteSpace($TARGET)) {
                Write-Host ""
                Write-Host "Iniciando ping continuo para $TARGET..." -ForegroundColor Cyan
                Write-Host "-> Pressione ESC para retornar ao menu." -ForegroundColor Yellow
                Write-Host ""
                
                # Limpa o buffer de teclas
                while ([Console]::KeyAvailable) { $null = [Console]::ReadKey($true) }
                
                $first = $true
                & {
                    trap {
                        continue
                    }
                    while ($true) {
                        if ([Console]::KeyAvailable) {
                            $key = [Console]::ReadKey($true)
                            if ($key.Key -eq 'Escape') {
                                break
                            }
                        }
                        
                        $timeStr = (Get-Date).ToString("HH:mm:ss")
                        $pingOut = ping $TARGET -n 1
                        
                        if ($first) {
                            $firstLine = $pingOut | Where-Object { $_ -match "Disparando|Pinging" }
                            if ($firstLine) { Write-Host $firstLine -ForegroundColor Gray }
                            $first = $false
                        }
                        
                        $replyLine = $pingOut | Where-Object { $_ -match "Resposta de|Reply from" }
                        if ($replyLine) {
                            $cleanReply = ($replyLine -replace '\s+', ' ').Trim()
                            Write-Host "[$timeStr] $cleanReply" -ForegroundColor Green
                        } else {
                            $failLine = $pingOut | Where-Object { $_ -match "Esgotado|timed out|inacess|unreach|Falha|failure|Perda" }
                            if ($failLine) {
                                $cleanFail = ($failLine -replace '\s+', ' ').Trim()
                                Write-Host "[$timeStr] [PERDA DE PACOTE] $cleanFail" -ForegroundColor Red
                            } else {
                                Write-Host "[$timeStr] [PERDA DE PACOTE] Esgotado o tempo limite da solicitacao." -ForegroundColor Red
                            }
                        }
                        
                        Start-Sleep -Milliseconds 1000
                    }
                }
            }
        }
        "14" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   INSTALACAO DE IMPRESSORA REMOTA"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina remota"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                Write-Host ""
                Write-Host "Tentando estabelecer conexao com $COMP..." -ForegroundColor Cyan
                
                $connected = $false
                $pingOk = $false
                try {
                    $pingOk = Test-Connection -ComputerName $COMP -Count 1 -Quiet -ErrorAction SilentlyContinue
                } catch {}

                try {
                    # Tenta obter informacoes basicas via WMI para validar o acesso administrativo completo
                    $os = Get-WmiObject -ComputerName $COMP -Class Win32_OperatingSystem -ErrorAction Stop
                    $connected = $true
                    Write-Host "Conectado com sucesso a $COMP!" -ForegroundColor Green
                    Write-Host "Sistema Operacional: $($os.Caption)" -ForegroundColor Gray
                } catch {
                    if ($pingOk) {
                        Write-Host "O computador responde ao Ping, mas o acesso administrativo (WMI/WinRM) falhou." -ForegroundColor Yellow
                        Write-Host "Detalhe do erro: $_" -ForegroundColor Gray
                        Write-Host ""
                        $ans = Read-Host "Deseja prosseguir com a tentativa de instalacao mesmo assim? (S/N)"
                        if ($ans -match "^[sS]") {
                            $connected = $true
                        }
                    } else {
                        Write-Host "Erro: O computador remoto $COMP nao esta acessivel na rede (Offline ou bloqueado por Firewall)." -ForegroundColor Red
                        Write-Host "Detalhe do erro: $_" -ForegroundColor Gray
                        Write-Host ""
                        $ans = Read-Host "Deseja forcar e tentar prosseguir mesmo assim? (S/N)"
                        if ($ans -match "^[sS]") {
                            $connected = $true
                        }
                    }
                }

                if ($connected) {
                    Write-Host ""
                    
                    $PRINTER = $null

                    # Tenta extrair lista de impressoras autorizadas no AD obtidas no cabecalho
                    $adPrintersList = @()
                    if (![string]::IsNullOrWhiteSpace($script:CONECTADO_AD_PRINTERS) -and 
                        $script:CONECTADO_AD_PRINTERS -ne "Nenhum grupo localizado no AD" -and 
                        $script:CONECTADO_AD_PRINTERS -ne "Usuario nao encontrado no AD" -and 
                        $script:CONECTADO_AD_PRINTERS -ne "Nao foi possivel consultar AD" -and 
                        $script:CONECTADO_AD_PRINTERS -ne "-") {
                        
                        $adPrintersList = $script:CONECTADO_AD_PRINTERS -split ',\s*'
                    }

                    if ($adPrintersList.Count -gt 0) {
                        Write-Host "Impressoras autorizadas encontradas para o usuario no AD:" -ForegroundColor Green
                        for ($i = 0; $i -lt $adPrintersList.Count; $i++) {
                            Write-Host "   [$($i+1)] $($adPrintersList[$i])" -ForegroundColor Yellow
                        }
                        Write-Host "   [M] Digitar outro codigo de impressora manualmente" -ForegroundColor Cyan
                        Write-Host ""
                        
                        $choice = Read-Host "Selecione o numero da impressora ou 'M' para manual"
                        if ($choice -match '^\d+$') {
                            $idx = [int]$choice - 1
                            if ($idx -ge 0 -and $idx -lt $adPrintersList.Count) {
                                $PRINTER = $adPrintersList[$idx]
                            }
                        }
                        
                        if ([string]::IsNullOrWhiteSpace($PRINTER)) {
                            $PRINTER = Read-Host "Digite o Endereco Logico da Impressora (ex: IS0432)"
                        }
                    } else {
                        $PRINTER = Read-Host "Digite o Endereco Logico da Impressora (ex: IS0432)"
                    }

                    if (![string]::IsNullOrWhiteSpace($PRINTER)) {
                        $cleanPrinterCode = $PRINTER.Trim() -replace "^\\\\", "" -replace "^printserver\\", ""
                        $script:CONECTADO_TARGET_PRINTER = "\\printserver\$cleanPrinterCode"
                        $PRINTER = $cleanPrinterCode
                        
                        Write-Host ""
                        Write-Host "Verificando usuario ativo em $COMP..." -ForegroundColor Gray
                        
                        $user = $null
                        try {
                            $computerSystem = Get-WmiObject -ComputerName $COMP -Class Win32_ComputerSystem -ErrorAction Stop
                            $user = $computerSystem.UserName
                        } catch {
                            Write-Host "Nao foi possivel consultar o usuario logado via WMI: $_" -ForegroundColor Yellow
                        }

                        Write-Host ""
                        Write-Host "Iniciando instalacao para \\printserver\$PRINTER em $COMP..." -ForegroundColor Green
                        if (![string]::IsNullOrWhiteSpace($user)) {
                            Write-Host "Usuario ativo detectado: $user (instalacao via Sessao Interativa)" -ForegroundColor Cyan
                        } else {
                            Write-Host "Nenhum usuario logado (instalacao Global na Maquina)" -ForegroundColor Cyan
                        }
                        Write-Host ""

                        if (![string]::IsNullOrWhiteSpace($user)) {
                            Write-Host "Criando tarefa interativa para abrir o instalador na sessao do usuario $user..." -ForegroundColor Gray
                                
                                $xmlPath = "$env:TEMP\PrinterTask_$($COMP).xml"
                                $taskXml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Principals>
    <Principal id="Author">
      <UserId>$user</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>rundll32.exe</Command>
      <Arguments>printui.dll,PrintUIEntry /in /n"\\printserver\$PRINTER"</Arguments>
    </Exec>
  </Actions>
</Task>
"@
                                try {
                                    [System.IO.File]::WriteAllText($xmlPath, $taskXml, [System.Text.Encoding]::Unicode)
                                    $schOutput = schtasks /create /s $COMP /tn "Suporte_InstalarImpressora" /xml $xmlPath /f 2>&1
                                    if ($LASTEXITCODE -eq 0) {
                                        schtasks /run /s $COMP /tn "Suporte_InstalarImpressora" > $null 2>&1
                                        Write-Host "Comando enviado com sucesso para a tela do usuario!" -ForegroundColor Green
                                        Write-Host "O assistente de conexao da impressora foi disparado na sessao de $user." -ForegroundColor Green
                                        Start-Sleep -Seconds 3
                                        schtasks /delete /s $COMP /tn "Suporte_InstalarImpressora" /f > $null 2>&1
                                    } else {
                                        throw $schOutput
                                    }
                                } catch {
                                    Write-Host "Falha ao criar tarefa interativa: $_" -ForegroundColor Yellow
                                    Write-Host "Tentando metodo global via WMI..." -ForegroundColor Gray
                                    
                                    $cmd = "cmd.exe /c rundll32.exe printui.dll,PrintUIEntry /ga /n""\\printserver\\$PRINTER"" /q & net stop spooler & net start spooler"
                                    try {
                                        $wmiResult = Invoke-WmiMethod -ComputerName $COMP -Class Win32_Process -Name Create -ArgumentList $cmd -ErrorAction Stop
                                        if ($wmiResult.ReturnValue -eq 0) {
                                            Write-Host "Instalacao global enviada com sucesso via WMI!" -ForegroundColor Green
                                        } else {
                                            Write-Host "O WMI retornou o codigo de retorno: $($wmiResult.ReturnValue)" -ForegroundColor Red
                                        }
                                    } catch {
                                        Write-Host "Erro ao tentar via WMI: $_" -ForegroundColor Red
                                    }
                                }
                                Remove-Item -Path $xmlPath -Force -ErrorAction SilentlyContinue
                            } else {
                                Write-Host "Iniciando instalacao global via WMI (Maquina)..." -ForegroundColor Gray
                                
                                $cmd = "cmd.exe /c rundll32.exe printui.dll,PrintUIEntry /ga /n""\\printserver\\$PRINTER"" /q & net stop spooler & net start spooler"
                                try {
                                    $wmiResult = Invoke-WmiMethod -ComputerName $COMP -Class Win32_Process -Name Create -ArgumentList $cmd -ErrorAction Stop
                                    if ($wmiResult.ReturnValue -eq 0) {
                                        Write-Host "Instalacao global enviada com sucesso via WMI!" -ForegroundColor Green
                                        Write-Host "A impressora foi adicionada globalmente no computador." -ForegroundColor Green
                                    } else {
                                        Write-Host "Erro via WMI. Codigo de retorno: $($wmiResult.ReturnValue)" -ForegroundColor Red
                                        Write-Host "Tentando via Invoke-Command (WinRM)..." -ForegroundColor Gray
                                        Invoke-Command -ComputerName $COMP -ScriptBlock {
                                            param($printerName)
                                            rundll32.exe printui.dll,PrintUIEntry /ga /n"\\printserver\\$printerName" /q
                                            Restart-Service -Name Spooler -Force -ErrorAction SilentlyContinue
                                        } -ArgumentList $PRINTER -ErrorAction Stop
                                        Write-Host "Instalacao feita com sucesso via Invoke-Command!" -ForegroundColor Green
                                    }
                                } catch {
                                    Write-Host "Nao foi possivel instalar de forma remota: $_" -ForegroundColor Red
                                    Write-Host "Certifique-se de que a maquina esteja acessivel na rede e que voce tenha privilegios administrativos." -ForegroundColor Yellow
                                }
                            }
                    }
                }
                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "15" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   REMOVER DRIVER IMPRESSORAS HP (PRODASEN)"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP do computador remoto"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                $cleanComp = $COMP.Replace('\', '')
                Write-Host ""
                Write-Host "Verificando conexao e procurando sessao de usuario ativo em $cleanComp..." -ForegroundColor Gray
                
                $user = $null
                $pingOk = Test-Connection -ComputerName $cleanComp -Count 1 -Quiet -ErrorAction SilentlyContinue
                
                if ($pingOk) {
                    try {
                        $computerSystem = Get-WmiObject -ComputerName $cleanComp -Class Win32_ComputerSystem -ErrorAction Stop
                        $user = $computerSystem.UserName
                    } catch {
                        Write-Host "Nao foi possivel consultar o usuario logado via WMI: $_" -ForegroundColor Yellow
                    }

                    $exeRemotePath = "X:\Driver Impressoras (Prodasen)\Remove Driver Impressoras HP (Prodasen).exe"
                    Write-Host "Caminho do arquivo no computador remoto: $exeRemotePath" -ForegroundColor Cyan
                    Write-Host ""

                    if (![string]::IsNullOrWhiteSpace($user)) {
                        Write-Host "Usuario ativo '$user' detectado em $cleanComp." -ForegroundColor Yellow
                        Write-Host "Criando tarefa interativa para executar o assistente na sessao do usuario..." -ForegroundColor Gray
                        
                        $xmlPath = "$env:TEMP\RemovePrinterTask_$($cleanComp).xml"
                        $taskXml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Principals>
    <Principal id="Author">
      <UserId>$user</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>cmd.exe</Command>
      <Arguments>/c "X:\Driver Impressoras (Prodasen)\Remove Driver Impressoras HP (Prodasen).exe"</Arguments>
    </Exec>
  </Actions>
</Task>
"@
                        try {
                            [System.IO.File]::WriteAllText($xmlPath, $taskXml, [System.Text.Encoding]::Unicode)
                            $schOutput = schtasks /create /s $cleanComp /tn "Suporte_RemoveDriverHP" /xml $xmlPath /f 2>&1
                            if ($LASTEXITCODE -eq 0) {
                                schtasks /run /s $cleanComp /tn "Suporte_RemoveDriverHP" > $null 2>&1
                                Write-Host "Comando enviado com sucesso para a tela de $user!" -ForegroundColor Green
                                Write-Host "O assistente de remocao de driver de impressora HP foi iniciado." -ForegroundColor Green
                                Start-Sleep -Seconds 3
                                schtasks /delete /s $cleanComp /tn "Suporte_RemoveDriverHP" /f > $null 2>&1
                            } else {
                                throw $schOutput
                            }
                        } catch {
                            Write-Host "Falha ao criar tarefa interativa: $_" -ForegroundColor Yellow
                            Write-Host "Tentando metodo global via WMI (Oculto)..." -ForegroundColor Gray
                            
                            $cmd = "cmd.exe /c `"$exeRemotePath`""
                            try {
                                $wmiResult = Invoke-WmiMethod -ComputerName $cleanComp -Class Win32_Process -Name Create -ArgumentList $cmd -ErrorAction Stop
                                if ($wmiResult.ReturnValue -eq 0) {
                                    Write-Host "Comando de remocao enviado com sucesso via WMI!" -ForegroundColor Green
                                } else {
                                    Write-Host "O WMI retornou o codigo de erro: $($wmiResult.ReturnValue)" -ForegroundColor Red
                                }
                            } catch {
                                Write-Host "Erro ao tentar via WMI: $_" -ForegroundColor Red
                            }
                        }
                        if (Test-Path $xmlPath) {
                            Remove-Item -Path $xmlPath -Force -ErrorAction SilentlyContinue
                        }
                    } else {
                        Write-Host "Nenhum usuario logado no momento em $cleanComp." -ForegroundColor Yellow
                        Write-Host "Executando via WMI..." -ForegroundColor Gray
                        
                        $cmd = "cmd.exe /c `"$exeRemotePath`""
                        try {
                            $wmiResult = Invoke-WmiMethod -ComputerName $cleanComp -Class Win32_Process -Name Create -ArgumentList $cmd -ErrorAction Stop
                            if ($wmiResult.ReturnValue -eq 0) {
                                Write-Host "Comando de remocao enviado com sucesso via WMI!" -ForegroundColor Green
                            } else {
                                Write-Host "O WMI retornou o codigo de erro: $($wmiResult.ReturnValue)" -ForegroundColor Red
                            }
                        } catch {
                            Write-Host "Erro ao tentar via WMI: $_" -ForegroundColor Red
                        }
                    }
                } else {
                    Write-Host "Erro: O computador remoto $cleanComp nao esta respondendo ao Ping (Offline)." -ForegroundColor Red
                }
                
                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "16" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   INSTALAR DRIVER IMPRESSORAS HP (PRODASEN)"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP do computador remoto"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                $cleanComp = $COMP.Replace('\', '')
                Write-Host ""
                Write-Host "Verificando conexao e procurando sessao de usuario ativo em $cleanComp..." -ForegroundColor Gray
                
                $user = $null
                $pingOk = Test-Connection -ComputerName $cleanComp -Count 1 -Quiet -ErrorAction SilentlyContinue
                
                if ($pingOk) {
                    try {
                        $computerSystem = Get-WmiObject -ComputerName $cleanComp -Class Win32_ComputerSystem -ErrorAction Stop
                        $user = $computerSystem.UserName
                    } catch {
                        Write-Host "Nao foi possivel consultar o usuario logado via WMI: $_" -ForegroundColor Yellow
                    }

                    $exeRemotePath = "X:\Driver Impressoras (Prodasen)\Driver Impressoras HP (Prodasen).exe"
                    Write-Host "Caminho do arquivo no computador remoto: $exeRemotePath" -ForegroundColor Cyan
                    Write-Host ""

                    if (![string]::IsNullOrWhiteSpace($user)) {
                        Write-Host "Usuario ativo '$user' detectado em $cleanComp." -ForegroundColor Yellow
                        Write-Host "Criando tarefa interativa para executar o assistente na sessao do usuario..." -ForegroundColor Gray
                        
                        $xmlPath = "$env:TEMP\InstallPrinterTask_$($cleanComp).xml"
                        $taskXml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Principals>
    <Principal id="Author">
      <UserId>$user</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>cmd.exe</Command>
      <Arguments>/c "X:\Driver Impressoras (Prodasen)\Driver Impressoras HP (Prodasen).exe"</Arguments>
    </Exec>
  </Actions>
</Task>
"@
                        try {
                            [System.IO.File]::WriteAllText($xmlPath, $taskXml, [System.Text.Encoding]::Unicode)
                            $schOutput = schtasks /create /s $cleanComp /tn "Suporte_InstallDriverHP" /xml $xmlPath /f 2>&1
                            if ($LASTEXITCODE -eq 0) {
                                schtasks /run /s $cleanComp /tn "Suporte_InstallDriverHP" > $null 2>&1
                                Write-Host "Comando enviado com sucesso para a tela de $user!" -ForegroundColor Green
                                Write-Host "O assistente de instalacao de driver de impressora HP foi iniciado." -ForegroundColor Green
                                Start-Sleep -Seconds 3
                                schtasks /delete /s $cleanComp /tn "Suporte_InstallDriverHP" /f > $null 2>&1
                            } else {
                                throw $schOutput
                            }
                        } catch {
                            Write-Host "Falha ao criar tarefa interativa: $_" -ForegroundColor Yellow
                            Write-Host "Tentando metodo global via WMI (Oculto)..." -ForegroundColor Gray
                            
                            $cmd = "cmd.exe /c `"$exeRemotePath`""
                            try {
                                $wmiResult = Invoke-WmiMethod -ComputerName $cleanComp -Class Win32_Process -Name Create -ArgumentList $cmd -ErrorAction Stop
                                if ($wmiResult.ReturnValue -eq 0) {
                                    Write-Host "Comando de instalacao enviado com sucesso via WMI!" -ForegroundColor Green
                                } else {
                                    Write-Host "O WMI retornou o codigo de erro: $($wmiResult.ReturnValue)" -ForegroundColor Red
                                }
                            } catch {
                                Write-Host "Erro ao tentar via WMI: $_" -ForegroundColor Red
                            }
                        }
                        if (Test-Path $xmlPath) {
                            Remove-Item -Path $xmlPath -Force -ErrorAction SilentlyContinue
                        }
                    } else {
                        Write-Host "Nenhum usuario logado no momento em $cleanComp." -ForegroundColor Yellow
                        Write-Host "Executando via WMI..." -ForegroundColor Gray
                        
                        $cmd = "cmd.exe /c `"$exeRemotePath`""
                        try {
                            $wmiResult = Invoke-WmiMethod -ComputerName $cleanComp -Class Win32_Process -Name Create -ArgumentList $cmd -ErrorAction Stop
                            if ($wmiResult.ReturnValue -eq 0) {
                                Write-Host "Comando de instalacao enviado com sucesso via WMI!" -ForegroundColor Green
                            } else {
                                Write-Host "O WMI retornou o codigo de erro: $($wmiResult.ReturnValue)" -ForegroundColor Red
                            }
                        } catch {
                            Write-Host "Erro ao tentar via WMI: $_" -ForegroundColor Red
                        }
                    }
                } else {
                    Write-Host "Erro: O computador remoto $cleanComp nao esta respondendo ao Ping (Offline)." -ForegroundColor Red
                }
                
                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "test_print_page" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   IMPRIMIR PAGINA DE TESTE REMOTA"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina remota"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                $cleanComp = $COMP.Replace('\', '').Trim()
                Write-Host ""
                Write-Host "Consultando impressoras de rede instaladas em $cleanComp..." -ForegroundColor Cyan

                $rawPrinters = @(Get-RemoteInstalledPrinters -computerName $cleanComp)
                $installedPrinters = [System.Collections.Generic.List[string]]::new()
                foreach ($rp in $rawPrinters) {
                    if ($null -ne $rp) {
                        $rpStr = "$rp".Trim()
                        if (![string]::IsNullOrWhiteSpace($rpStr) -and !$installedPrinters.Contains($rpStr)) {
                            [void]$installedPrinters.Add($rpStr)
                        }
                    }
                }

                # Fallback se for o computador ja conectado no cabecalho
                if ($installedPrinters.Count -eq 0 -and $cleanComp -eq $script:CONECTADO_COMP -and ![string]::IsNullOrWhiteSpace($script:CONECTADO_PRINTERS)) {
                    if ($script:CONECTADO_PRINTERS -ne "Nenhuma impressora de rede encontrada" -and $script:CONECTADO_PRINTERS -ne "Nao foi possivel consultar" -and $script:CONECTADO_PRINTERS -ne "-") {
                        $splitP = $script:CONECTADO_PRINTERS -split ',\s*'
                        foreach ($sp in $splitP) {
                            $spStr = "$sp".Trim()
                            if (![string]::IsNullOrWhiteSpace($spStr) -and !$installedPrinters.Contains($spStr)) {
                                [void]$installedPrinters.Add($spStr)
                            }
                        }
                    }
                }

                $PRINTER = $null

                if ($installedPrinters.Count -gt 0) {
                    Write-Host ""
                    Write-Host "Impressoras de rede instaladas encontradas em $($cleanComp):" -ForegroundColor Green
                    for ($i = 0; $i -lt $installedPrinters.Count; $i++) {
                        Write-Host "   [$($i+1)] $($installedPrinters[$i])" -ForegroundColor Yellow
                    }
                    Write-Host "   [M] Digitar outro nome ou codigo manualmente" -ForegroundColor Cyan
                    Write-Host ""
                    
                    $choice = Read-Host "Selecione o numero da impressora ou 'M' para manual"
                    if ($choice -match '^\d+$') {
                        $idx = [int]$choice - 1
                        if ($idx -ge 0 -and $idx -lt $installedPrinters.Count) {
                            $PRINTER = [string]$installedPrinters[$idx]
                        }
                    }
                }

                if ([string]::IsNullOrWhiteSpace($PRINTER)) {
                    $PRINTER = Read-Host "Digite o Endereco Logico ou nome da Impressora (ex: IS0432 ou \\printserver\IS0432)"
                }

                if (![string]::IsNullOrWhiteSpace($PRINTER)) {
                    $cleanP = ("$PRINTER").Trim()
                    if ($cleanP -notlike "\\*") {
                        $cleanP = "\\printserver\$cleanP"
                    }

                    Write-Host ""
                    Write-Host "Enviando comando para imprimir pagina de teste em '$cleanP' no computador $cleanComp..." -ForegroundColor Green

                    $printed = $false

                    # Tenta via WMI PrintTestPage()
                    try {
                        $escapedP = $cleanP -replace "\\", "\\"
                        $wmiP = Get-WmiObject -Class Win32_Printer -ComputerName $cleanComp -Filter "Name='$escapedP'" -ErrorAction SilentlyContinue
                        if ($wmiP) {
                            $res = $wmiP.PrintTestPage()
                            if ($res.ReturnValue -eq 0) {
                                Write-Host "Pagina de teste solicitada com sucesso via WMI (PrintTestPage)!" -ForegroundColor Green
                                $printed = $true
                            }
                        }
                    } catch {}

                    if (!$printed) {
                        $user = $null
                        try {
                            $computerSystem = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $cleanComp -ErrorAction SilentlyContinue
                            $user = $computerSystem.UserName
                        } catch {}

                        if (![string]::IsNullOrWhiteSpace($user)) {
                            Write-Host "Usuario ativo '$user' detectado em $cleanComp. Enviando para a sessao..." -ForegroundColor Gray
                            $xmlPath = "$env:TEMP\TestPrintTask_$($cleanComp).xml"
                            $taskXml = @(
                                '<?xml version="1.0" encoding="UTF-16"?>',
                                '<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">',
                                '  <Principals>',
                                '    <Principal id="Author">',
                                "      <UserId>$user</UserId>",
                                '      <LogonType>InteractiveToken</LogonType>',
                                '      <RunLevel>LeastPrivilege</RunLevel>',
                                '    </Principal>',
                                '  </Principals>',
                                '  <Settings>',
                                '    <AllowStartOnDemand>true</AllowStartOnDemand>',
                                '    <Enabled>true</Enabled>',
                                '    <Hidden>false</Hidden>',
                                '    <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>',
                                '  </Settings>',
                                '  <Actions Context="Author">',
                                '    <Exec>',
                                '      <Command>rundll32.exe</Command>',
                                "      <Arguments>printui.dll,PrintUIEntry /k /n&quot;$cleanP&quot;</Arguments>",
                                '    </Exec>',
                                '  </Actions>',
                                '</Task>'
                            ) -join "`r`n"
                            try {
                                [System.IO.File]::WriteAllText($xmlPath, $taskXml, [System.Text.Encoding]::Unicode)
                                $schOutput = schtasks /create /s $cleanComp /tn "Suporte_ImprimirTeste" /xml $xmlPath /f 2>&1
                                if ($LASTEXITCODE -eq 0) {
                                    schtasks /run /s $cleanComp /tn "Suporte_ImprimirTeste" > $null 2>&1
                                    Write-Host "Comando de pagina de teste enviado para a tela do usuario com sucesso!" -ForegroundColor Green
                                    Start-Sleep -Seconds 2
                                    schtasks /delete /s $cleanComp /tn "Suporte_ImprimirTeste" /f > $null 2>&1
                                    $printed = $true
                                } else {
                                    throw $schOutput
                                }
                            } catch {
                                Write-Host "Falha na tarefa interativa: $_" -ForegroundColor Yellow
                            }
                            if (Test-Path $xmlPath) { Remove-Item -Path $xmlPath -Force -ErrorAction SilentlyContinue }
                        }

                        if (!$printed) {
                            Write-Host "Tentando disparo via WMI..." -ForegroundColor Gray
                            $cmd = "cmd.exe /c rundll32.exe printui.dll,PrintUIEntry /k /n""$cleanP"""
                            try {
                                $wmiResult = Invoke-WmiMethod -Class Win32_Process -ComputerName $cleanComp -Name Create -ArgumentList $cmd -ErrorAction Stop
                                if ($wmiResult.ReturnValue -eq 0) {
                                    Write-Host "Comando de pagina de teste enviado via WMI com sucesso!" -ForegroundColor Green
                                    $printed = $true
                                } else {
                                    Write-Host "O WMI retornou o codigo: $($wmiResult.ReturnValue)" -ForegroundColor Red
                                }
                            } catch {
                                Write-Host "Erro ao enviar via WMI: $_" -ForegroundColor Red
                            }
                        }
                    }
                } else {
                    Write-Host "Nenhuma impressora informada. Operacao cancelada." -ForegroundColor Yellow
                }

                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "set_default_printer" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   DEFINIR IMPRESSORA PADRAO REMOTA"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina remota"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                $cleanComp = $COMP.Replace('\', '').Trim()
                Write-Host ""
                Write-Host "Consultando impressoras instaladas em $cleanComp..." -ForegroundColor Cyan

                $rawPrinters = @(Get-RemoteInstalledPrinters -computerName $cleanComp)
                $installedPrinters = [System.Collections.Generic.List[string]]::new()
                foreach ($rp in $rawPrinters) {
                    if ($null -ne $rp) {
                        $rpStr = "$rp".Trim()
                        if (![string]::IsNullOrWhiteSpace($rpStr) -and !$installedPrinters.Contains($rpStr)) {
                            [void]$installedPrinters.Add($rpStr)
                        }
                    }
                }

                # Fallback se for o computador ja conectado no cabecalho
                if ($installedPrinters.Count -eq 0 -and $cleanComp -eq $script:CONECTADO_COMP -and ![string]::IsNullOrWhiteSpace($script:CONECTADO_PRINTERS)) {
                    if ($script:CONECTADO_PRINTERS -ne "Nenhuma impressora de rede encontrada" -and $script:CONECTADO_PRINTERS -ne "Nao foi possivel consultar" -and $script:CONECTADO_PRINTERS -ne "-") {
                        $splitP = $script:CONECTADO_PRINTERS -split ',\s*'
                        foreach ($sp in $splitP) {
                            $spStr = "$sp".Trim()
                            if (![string]::IsNullOrWhiteSpace($spStr) -and !$installedPrinters.Contains($spStr)) {
                                [void]$installedPrinters.Add($spStr)
                            }
                        }
                    }
                }

                $PRINTER = $null

                if ($installedPrinters.Count -gt 0) {
                    Write-Host ""
                    Write-Host "Impressoras instaladas encontradas em $($cleanComp):" -ForegroundColor Green
                    for ($i = 0; $i -lt $installedPrinters.Count; $i++) {
                        Write-Host "   [$($i+1)] $($installedPrinters[$i])" -ForegroundColor Yellow
                    }
                    Write-Host "   [M] Digitar outro nome de impressora manualmente" -ForegroundColor Cyan
                    Write-Host ""
                    
                    $choice = Read-Host "Selecione o numero da impressora para definir como PADRAO ou 'M' para manual"
                    if ($choice -match '^\d+$') {
                        $idx = [int]$choice - 1
                        if ($idx -ge 0 -and $idx -lt $installedPrinters.Count) {
                            $PRINTER = [string]$installedPrinters[$idx]
                        }
                    }
                }

                if ([string]::IsNullOrWhiteSpace($PRINTER)) {
                    $PRINTER = Read-Host "Digite o Nome da Impressora que deseja definir como padrao (ex: \\printserver\IS0432 ou NomeImpressora)"
                }

                if (![string]::IsNullOrWhiteSpace($PRINTER)) {
                    $cleanP = ("$PRINTER").Trim()
                    Write-Host ""
                    Write-Host "Definindo '$cleanP' como impressora padrao no computador $cleanComp..." -ForegroundColor Green

                    $setSuccess = $false

                    # Tenta via WMI SetDefaultPrinter()
                    try {
                        $escapedP = $cleanP -replace "\\", "\\"
                        $wmiP = Get-WmiObject -Class Win32_Printer -ComputerName $cleanComp -Filter "Name='$escapedP'" -ErrorAction SilentlyContinue
                        if ($wmiP) {
                            $res = $wmiP.SetDefaultPrinter()
                            if ($res.ReturnValue -eq 0) {
                                Write-Host "Impressora '$cleanP' definida como padrao com sucesso via WMI!" -ForegroundColor Green
                                $setSuccess = $true
                            }
                        }
                    } catch {}

                    # Se nao funcionou via WMI direto, tenta na sessao interativa do usuario via agendador de tarefas
                    if (!$setSuccess) {
                        $user = $null
                        try {
                            $computerSystem = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $cleanComp -ErrorAction SilentlyContinue
                            $user = $computerSystem.UserName
                        } catch {}

                        if (![string]::IsNullOrWhiteSpace($user)) {
                            Write-Host "Usuario ativo '$user' detectado. Executando alteracao na sessao do usuario..." -ForegroundColor Cyan
                            
                            $xmlPath = "$env:TEMP\SetDefPrinterTask_$($cleanComp).xml"
                            $psScript = "`$p = '$cleanP'; `$shortP = if (`$p -match '\\') { (`$p -split '\\')[-1] } else { `$p }; `$done = `$false; try { (New-Object -ComObject WScript.Network).SetDefaultPrinter(`$p); `$done = `$true } catch {}; if (!`$done -and `$shortP -ne `$p) { try { (New-Object -ComObject WScript.Network).SetDefaultPrinter(`$shortP); `$done = `$true } catch {} }; if (!`$done -and `$p -notlike '\\*') { try { (New-Object -ComObject WScript.Network).SetDefaultPrinter('\\printserver\' + `$p); `$done = `$true } catch {} }; try { Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows' -Name 'LegacyDefaultPrinterMode' -Value 1 -Force -ErrorAction SilentlyContinue } catch {}"
                            $encodedArgs = [System.Security.SecurityElement]::Escape("-WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -Command `"$psScript`"")
                            $taskXml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Principals>
    <Principal id="Author">
      <UserId>$user</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>powershell.exe</Command>
      <Arguments>$encodedArgs</Arguments>
    </Exec>
  </Actions>
</Task>
"@
                            try {
                                [System.IO.File]::WriteAllText($xmlPath, $taskXml, [System.Text.Encoding]::Unicode)
                                $schOutput = schtasks /create /s $cleanComp /tn "Suporte_SetDefaultPrinter" /xml $xmlPath /f 2>&1
                                if ($LASTEXITCODE -eq 0) {
                                    schtasks /run /s $cleanComp /tn "Suporte_SetDefaultPrinter" > $null 2>&1
                                    Write-Host "Comando enviado com sucesso para a sessao de $user!" -ForegroundColor Green
                                    Write-Host "A impressora '$cleanP' foi definida como padrao." -ForegroundColor Green
                                    Start-Sleep -Seconds 2
                                    schtasks /delete /s $cleanComp /tn "Suporte_SetDefaultPrinter" /f > $null 2>&1
                                    $setSuccess = $true
                                } else {
                                    throw $schOutput
                                }
                            } catch {
                                Write-Host "Falha ao criar tarefa na sessao do usuario: $_" -ForegroundColor Yellow
                            }
                            if (Test-Path $xmlPath) {
                                Remove-Item -Path $xmlPath -Force -ErrorAction SilentlyContinue
                            }
                        }
                    }

                    # Fallback via Invoke-WmiMethod Win32_Process
                    if (!$setSuccess) {
                        try {
                            $cmd = "cmd.exe /c rundll32.exe printui.dll,PrintUIEntry /y /n""$cleanP"""
                            $wmiResult = Invoke-WmiMethod -ComputerName $cleanComp -Class Win32_Process -Name Create -ArgumentList $cmd -ErrorAction SilentlyContinue
                            if ($wmiResult.ReturnValue -eq 0) {
                                Write-Host "Comando executado no computador remoto via WMI Process!" -ForegroundColor Green
                                $setSuccess = $true
                            }
                        } catch {}
                    }

                    if ($setSuccess -and $cleanComp -eq $script:CONECTADO_COMP) {
                        $script:CONECTADO_DEFAULT_PRINTER = $cleanP
                    }

                    if (!$setSuccess) {
                        Write-Host "Nao foi possivel confirmar a definicao da impressora padrao remotamente." -ForegroundColor Yellow
                    }
                } else {
                    Write-Host "Nenhuma impressora informada. Operacao cancelada." -ForegroundColor Yellow
                }

                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "clear_spooler_remote" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   LIMPAR FILA DE IMPRESSAO REMOTA (SPOOLER)" -ForegroundColor Yellow
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP do computador remoto"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                $cleanComp = $COMP.Replace('\', '').Trim()
                Write-Host ""
                Write-Host "Iniciando limpeza do spooler de impressao em '$cleanComp'..." -ForegroundColor Cyan
                
                # 1. Parar Servico Spooler Remoto
                Write-Host "1. Parando servico Spooler de Impressao remoto..." -ForegroundColor Gray
                $serviceStopped = $false
                try {
                    $svc = Get-Service -ComputerName $cleanComp -Name Spooler -ErrorAction Stop
                    if ($svc.Status -ne "Stopped") {
                        try {
                            Stop-Service -InputObject $svc -Force -ErrorAction Stop
                        } catch {
                            (Get-WmiObject -ComputerName $cleanComp -Class Win32_Service -Filter "Name='Spooler'").StopService() | Out-Null
                        }
                    }
                    $serviceStopped = $true
                    Write-Host "   Servico Spooler parado com sucesso." -ForegroundColor Green
                } catch {
                    try {
                        $cmdStop = "cmd.exe /c net stop spooler"
                        $res = Invoke-WmiMethod -ComputerName $cleanComp -Class Win32_Process -Name Create -ArgumentList $cmdStop -ErrorAction Stop
                        if ($res.ReturnValue -eq 0) {
                            $serviceStopped = $true
                            Write-Host "   Comando de parada do Spooler enviado via WMI." -ForegroundColor Green
                        } else {
                            Write-Host "   Aviso ao parar Spooler: retorno $($res.ReturnValue)" -ForegroundColor Yellow
                        }
                    } catch {
                        Write-Host "   Falha ao parar Spooler remoto: $_" -ForegroundColor Yellow
                    }
                }

                # 2. Deletar arquivos da pasta PRINTERS do spooler
                Write-Host "2. Excluindo arquivos presos na fila (PRINTERS)..." -ForegroundColor Gray
                $spoolPath = "\\$cleanComp\C$\Windows\System32\spool\PRINTERS"
                try {
                    if (Test-Path $spoolPath) {
                        $files = Get-ChildItem -Path "$spoolPath\*" -Recurse -ErrorAction SilentlyContinue
                        foreach ($f in $files) {
                            try {
                                Remove-Item -Path $f.FullName -Force -Recurse -ErrorAction SilentlyContinue
                            } catch {}
                        }
                        Write-Host "   Fila de impressao limpa na pasta de spooler remota." -ForegroundColor Green
                    } else {
                        $cmdDel = "cmd.exe /c del /f /q /s %systemroot%\System32\spool\PRINTERS\*.*"
                        Invoke-WmiMethod -ComputerName $cleanComp -Class Win32_Process -Name Create -ArgumentList $cmdDel | Out-Null
                        Write-Host "   Comando de limpeza de arquivos enviado via WMI." -ForegroundColor Green
                    }
                } catch {
                    Write-Host "   Erro ao tentar apagar arquivos do spooler: $_" -ForegroundColor Yellow
                }

                # 3. Iniciar Servico Spooler Remoto
                Write-Host "3. Reiniciando servico Spooler de Impressao remoto..." -ForegroundColor Gray
                try {
                    $svc = Get-Service -ComputerName $cleanComp -Name Spooler -ErrorAction Stop
                    Start-Service -InputObject $svc -ErrorAction SilentlyContinue
                    (Get-WmiObject -ComputerName $cleanComp -Class Win32_Service -Filter "Name='Spooler'").StartService() | Out-Null
                } catch {
                    $cmdStart = "cmd.exe /c net start spooler"
                    Invoke-WmiMethod -ComputerName $cleanComp -Class Win32_Process -Name Create -ArgumentList $cmdStart | Out-Null
                }

                Start-Sleep -Seconds 2

                # 4. Confirmar Status do Spooler
                try {
                    $finalSvc = Get-Service -ComputerName $cleanComp -Name Spooler -ErrorAction SilentlyContinue
                    if ($finalSvc -and $finalSvc.Status -eq "Running") {
                        Write-Host "   Servico Spooler em EXECUCAO no computador $cleanComp!" -ForegroundColor Green
                    } else {
                        Write-Host "   Servico Spooler reiniciado." -ForegroundColor Green
                    }
                } catch {
                    Write-Host "   Operacao de reinicializacao do Spooler concluida." -ForegroundColor Green
                }

                Write-Host ""
                Write-Host "Fila de impressao do computador '$cleanComp' foi limpa com sucesso!" -ForegroundColor Green
                Write-Host ""
                Read-Host "Pressione ENTER para continuar..."
            }
        }
        "manage_certs" {
            Clear-Host
            Write-Host "========================================================"
            Write-Host "   ABRIR OPCOES DA INTERNET (ABA CONTEUDO/CERTIFICADOS)"
            Write-Host "========================================================"
            $COMP = Get-TargetComputer "Digite o nome ou IP da maquina remota"
            if (![string]::IsNullOrWhiteSpace($COMP)) {
                $cleanComp = $COMP.Replace('\', '')
                Write-Host ""
                Write-Host "Verificando conexao e procurando sessao de usuario ativo em $cleanComp..." -ForegroundColor Gray
                
                $user = $null
                $pingOk = Test-Connection -ComputerName $cleanComp -Count 1 -Quiet -ErrorAction SilentlyContinue
                
                if ($pingOk) {
                    try {
                        $computerSystem = Get-WmiObject -ComputerName $cleanComp -Class Win32_ComputerSystem -ErrorAction Stop
                        $user = $computerSystem.UserName
                    } catch {
                        Write-Host "Nao foi possivel consultar o usuario logado via WMI." -ForegroundColor Yellow
                    }

                    if (![string]::IsNullOrWhiteSpace($user)) {
                        Write-Host "Usuario ativo '$user' detectado em $cleanComp." -ForegroundColor Yellow
                        Write-Host "Disparando 'Opcoes da Internet (Conteudo)' na tela do usuario remoto..." -ForegroundColor Cyan
                        
                        $xmlPath = "$env:TEMP\InternetOptionsTask_$($cleanComp).xml"
                        $taskXml = @(
                            '<?xml version="1.0" encoding="UTF-16"?>',
                            '<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">',
                            '  <Principals>',
                            '    <Principal id="Author">',
                            "      <UserId>$user</UserId>",
                            '      <LogonType>InteractiveToken</LogonType>',
                            '      <RunLevel>LeastPrivilege</RunLevel>',
                            '    </Principal>',
                            '  </Principals>',
                            '  <Settings>',
                            '    <AllowStartOnDemand>true</AllowStartOnDemand>',
                            '    <Enabled>true</Enabled>',
                            '    <Hidden>false</Hidden>',
                            '    <ExecutionTimeLimit>PT1H</ExecutionTimeLimit>',
                            '  </Settings>',
                            '  <Actions Context="Author">',
                            '    <Exec>',
                            '      <Command>powershell.exe</Command>',
                            '      <Arguments>-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command "Start-Process control.exe -ArgumentList ''inetcpl.cpl,,3''; Start-Sleep -Milliseconds 1000; `$w = New-Object -ComObject Wscript.Shell; `$w.AppActivate(''Propriedades de Internet'') | Out-Null"</Arguments>',
                            '    </Exec>',
                            '  </Actions>',
                            '</Task>'
                        ) -join "`r`n"
                        try {
                            [System.IO.File]::WriteAllText($xmlPath, $taskXml, [System.Text.Encoding]::Unicode)
                            $schOutput = schtasks /create /s $cleanComp /tn "Suporte_OpcoesInternet" /xml $xmlPath /f 2>&1
                            if ($LASTEXITCODE -eq 0) {
                                schtasks /run /s $cleanComp /tn "Suporte_OpcoesInternet" > $null 2>&1
                                Write-Host "Painel enviado com sucesso para a tela de $user!" -ForegroundColor Green
                                Start-Sleep -Seconds 3
                                schtasks /delete /s $cleanComp /tn "Suporte_OpcoesInternet" /f > $null 2>&1
                            } else {
                                throw $schOutput
                            }
                        } catch {
                            Write-Host "Nao foi possivel abrir na sessao do usuario remoto: $_" -ForegroundColor Red
                            Write-Host "Tentando abrir o console de certificados da maquina remota localmente..." -ForegroundColor Yellow
                            Start-Process "certlm.msc" -ArgumentList "/computer:$cleanComp"
                        }
                        if (Test-Path $xmlPath) {
                            Remove-Item -Path $xmlPath -Force -ErrorAction SilentlyContinue
                        }
                    } else {
                        Write-Host "Nenhum usuario ativo detectado na maquina remota." -ForegroundColor Yellow
                        Write-Host "Abrindo console de certificados do computador remoto $cleanComp em sua tela..." -ForegroundColor Cyan
                        Start-Process "certlm.msc" -ArgumentList "/computer:$cleanComp"
                    }
                } else {
                    Write-Host "Erro: O computador remoto $cleanComp nao esta respondendo ao Ping (Offline)." -ForegroundColor Red
                }
                
                Write-Host ""
                Read-Host "Pressione ENTER para retornar ao menu..."
            }
        }
        "0" {
            exit
        }
        default {
            Write-Host "Opcao invalida." -ForegroundColor Yellow
            Start-Sleep -Seconds 2
        }
    }
}
