param(
    [Parameter(Mandatory=$true)][string]$Script,
    [Parameter(Mandatory=$true)][string]$Action,
    [string]$Computer = "",
    [string]$Value = ""
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)

try {
    $scriptDirectory = Split-Path -Parent $Script
    $source = Get-Content -LiteralPath $Script -Raw -Encoding UTF8
    $block = [scriptblock]::Create($source)
    & $block -Action $Action -Computer $Computer -Value $Value -ModuleRoot $scriptDirectory
} catch {
    # Write-Error com ErrorActionPreference=Stop substitui a exceção original
    # pela localização desta linha. Escreva a causa para o painel do Atlas.
    $failure = [string]$_.Exception.Message
    if ([string]::IsNullOrWhiteSpace($failure)) { $failure = [string]$_ }
    [Console]::Out.WriteLine("[ERRO REMOTO] $failure")
    exit 1
}
