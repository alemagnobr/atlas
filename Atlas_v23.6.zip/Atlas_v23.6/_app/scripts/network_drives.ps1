param(
    [Parameter(Mandatory=$true)][string]$Computer,
    [string]$LoggedUser = ''
)

$ErrorActionPreference = 'SilentlyContinue'

function Normalize-Unc {
    param([string]$RemotePath)
    if ([string]::IsNullOrWhiteSpace($RemotePath)) { return '' }
    $clean = $RemotePath.Trim().TrimEnd([char]92, [char]47)
    $parts = @($clean -split '[\\/]+' | Where-Object { $_ })
    if ($parts.Count -lt 2) { return $clean }
    $server = ([string]$parts[0]).ToLowerInvariant()
    $share = [string]$parts[1]
    $key = $share.ToLowerInvariant() -replace '[\s_]+', ''
    if ($server -eq 'fs' -or $server -eq 'dru' -or $server -like 'fs.*' -or $server -like 'dru.*') {
        if ($key -match '^biblioteca(setorial)?$') { return '\\DRU\BIBLIOTECA_SETORIAL' }
        if ($key -match '^central(de)?atendimento$') { return '\\DRU\CENTRAL_ATENDIMENTO' }
        return ('\\DRU\' + $share.ToUpperInvariant())
    }
    if (($server -eq 'scanserver' -or $server -like 'scanserver.*') -and $key -match '^(scandrive|scanfolders?)$') {
        return '\\scanserver\scanfolders'
    }
    return $clean
}

function Get-CorporateLetter {
    param([string]$RemotePath, [string]$Sector)
    $canonical = Normalize-Unc $RemotePath
    $parts = @($canonical -split '[\\/]+' | Where-Object { $_ })
    if ($parts.Count -lt 2) { return '' }
    $server = ([string]$parts[0]).ToLowerInvariant()
    $share = ([string]$parts[1]).ToLowerInvariant() -replace '[\s_]+', '' -replace '^centralde', 'central'
    if ($server -like 'scanserver*' -or $share -match '^(scandrive|scanfolders?)$') { return 'R:' }
    if ($share -eq 'share') { return 'V:' }
    if ($share -match '^biblioteca(setorial)?$') { return 'W:' }
    if ($share -eq 'centralatendimento') { return 'X:' }
    $sectorKey = ([string]$Sector).ToLowerInvariant() -replace '[\s_]+', ''
    if ($server -eq 'dru' -and (($sectorKey -and $share -eq $sectorKey) -or $share -notmatch '^(share|biblioteca(setorial)?|centralatendimento)$')) { return 'U:' }
    return ''
}

$sector = ''
try {
    $userOnly = (($LoggedUser -split '\\')[-1]) -replace '(?i)_INS$', ''
    if ($userOnly) {
        $searcher = New-Object DirectoryServices.DirectorySearcher
        $searcher.Filter = "(&(objectCategory=person)(objectClass=user)(sAMAccountName=$userOnly))"
        [void]$searcher.PropertiesToLoad.Add('scriptpath')
        [void]$searcher.PropertiesToLoad.Add('department')
        $entry = $searcher.FindOne()
        if ($entry -and $entry.Properties['scriptpath'].Count -gt 0) {
            $sector = [IO.Path]::GetFileNameWithoutExtension([string]$entry.Properties['scriptpath'][0])
        } elseif ($entry -and $entry.Properties['department'].Count -gt 0) {
            $sector = [string]$entry.Properties['department'][0]
        }
    }
} catch {}

$items = [System.Collections.Generic.List[object]]::new()
$letters = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)

function Add-NetworkDrive {
    param([string]$Letter, [string]$RemotePath, [bool]$InferLetter, [string]$Source)
    if ([string]::IsNullOrWhiteSpace($RemotePath)) { return }
    $drive = ([string]$Letter).Trim().ToUpperInvariant()
    if ($drive -and $drive -notmatch ':$') { $drive = $drive + ':' }
    $remote = Normalize-Unc $RemotePath
    if ($drive -notmatch '^[A-Z]:$' -and $InferLetter) { $drive = Get-CorporateLetter $remote $sector }
    if ($drive -notmatch '^[A-Z]:$' -or $letters.Contains($drive)) { return }
    [void]$letters.Add($drive)
    $labelParts = @($remote -split '[\\/]+' | Where-Object { $_ })
    $label = if ($labelParts.Count -gt 0) { [string]$labelParts[-1] } else { 'Unidade de rede' }
    $items.Add([PSCustomObject]@{
        drive = $drive
        provider = $remote
        size = [int64]0
        free = [int64]0
        label = $label
        filesystem = ''
        source = $Source
    })
}

# Registro do usuário: fonte mais fiel e rápida para letras persistentes.
try {
    $users = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::Users, $Computer)
    foreach ($sid in @($users.GetSubKeyNames())) {
        if ($sid -notlike 'S-1-5-21-*' -or $sid -like '*_Classes') { continue }
        $network = $users.OpenSubKey("$sid\Network")
        if ($network) {
            foreach ($letter in @($network.GetSubKeyNames())) {
                $driveKey = $network.OpenSubKey($letter)
                $remote = if ($driveKey) { [string]$driveKey.GetValue('RemotePath', '') } else { '' }
                if ($driveKey) { $driveKey.Close() }
                Add-NetworkDrive $letter $remote $false 'HKU\Network'
            }
            $network.Close()
        }
        $mounts = $users.OpenSubKey("$sid\Software\Microsoft\Windows\CurrentVersion\Explorer\MountPoints2")
        if ($mounts) {
            foreach ($mount in @($mounts.GetSubKeyNames())) {
                if ($mount -like '##*') {
                    $remote = '\\' + ($mount.Substring(2) -replace '#', '\')
                    Add-NetworkDrive '' $remote $true 'Explorer\MountPoints2'
                }
            }
            $mounts.Close()
        }
    }
    $users.Close()
} catch {}

# WMI preserva capacidade e espaço livre quando o provedor os publica.
foreach ($mapped in @(Get-WmiObject Win32_MappedLogicalDisk -ComputerName $Computer -ErrorAction SilentlyContinue)) {
    $drive = ([string]$mapped.Name).Trim().ToUpperInvariant()
    if ($drive -match '^[A-Z]:$') {
        $existing = $items | Where-Object { $_.drive -ieq $drive } | Select-Object -First 1
        if ($existing) {
            if ($mapped.ProviderName) { $existing.provider = Normalize-Unc ([string]$mapped.ProviderName) }
            if ($mapped.Size) { $existing.size = [int64]$mapped.Size; $existing.free = [int64]$mapped.FreeSpace }
            if ($mapped.VolumeName) { $existing.label = [string]$mapped.VolumeName }
            if ($mapped.FileSystem) { $existing.filesystem = [string]$mapped.FileSystem }
        } else {
            Add-NetworkDrive $drive ([string]$mapped.ProviderName) $false 'Win32_MappedLogicalDisk'
        }
    }
}

# WinRM é complementar; se estiver bloqueado, as fontes anteriores permanecem.
try {
    $remoteItems = @(Invoke-Command -ComputerName $Computer -ErrorAction Stop -ScriptBlock {
        $output = @()
        foreach ($drive in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
            if ($drive.DisplayRoot) { $output += [PSCustomObject]@{ drive = "$($drive.Name):"; provider = [string]$drive.DisplayRoot } }
        }
        try {
            $network = New-Object -ComObject WScript.Network
            $mapped = $network.EnumNetworkDrives()
            for ($index = 0; $index -lt $mapped.Count; $index += 2) {
                $output += [PSCustomObject]@{ drive = [string]$mapped.Item($index); provider = [string]$mapped.Item($index + 1) }
            }
        } catch {}
        $output
    })
    foreach ($item in $remoteItems) { Add-NetworkDrive ([string]$item.drive) ([string]$item.provider) $false 'WinRM' }
} catch {}

@($items)
