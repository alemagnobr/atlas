function Invoke-AtlasRemoteMessage {
    param([ValidateSet('evaluation','orientation','escalation')][string]$Kind)
    Require-Computer
    try { $payload = $Value | ConvertFrom-Json -ErrorAction Stop }
    catch { throw 'A mensagem remota está em formato inválido.' }
    if ($Kind -eq 'orientation' -and
        [string]::IsNullOrWhiteSpace([string]$payload.guidance) -and
        [string]::IsNullOrWhiteSpace([string]$payload.path) -and
        [string]::IsNullOrWhiteSpace([string]$payload.contact)) {
        throw 'A orientação não possui conteúdo.'
    }
    $sessionUser = [string](Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
    if ([string]::IsNullOrWhiteSpace($sessionUser)) { throw 'Nenhum usuário conectado foi identificado.' }
    $account = ($sessionUser -split '\\')[-1]
    if ($Kind -ne 'escalation' -and
        ([string]::IsNullOrWhiteSpace([string]$payload.expected_user) -or
         $account -ine [string]$payload.expected_user)) {
        throw 'O usuário conectado mudou. Atualize a estação antes de enviar a mensagem.'
    }
    if ([string]::IsNullOrWhiteSpace([string]$payload.display_name)) {
        $payload | Add-Member -NotePropertyName display_name -NotePropertyValue $account -Force
    }
    if ([string]::IsNullOrWhiteSpace([string]$payload.operator_name)) {
        $payload | Add-Member -NotePropertyName operator_name -NotePropertyValue 'Equipe de Suporte do Prodasen' -Force
    }
    $payload | Add-Member -NotePropertyName kind -NotePropertyValue $Kind -Force
    $payloadB64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(($payload | ConvertTo-Json -Depth 5 -Compress)))
    $remoteCode = @"
`$ErrorActionPreference = 'Stop'
try {
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase
Add-Type -Namespace Atlas -Name WindowNative -MemberDefinition '[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow(); [System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr hWnd, int nCmdShow);'
# A tarefa da v17 abre o PowerShell na sessão interativa. Esconda apenas o
# console desse processo, deixando a janela WPF visível e independente.
`$console = [Atlas.WindowNative]::GetConsoleWindow()
if (`$console -ne [IntPtr]::Zero) { [Atlas.WindowNative]::ShowWindow(`$console, 0) | Out-Null }
`$data = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('$payloadB64')) | ConvertFrom-Json
`$converter = New-Object System.Windows.Media.BrushConverter
`$window = New-Object System.Windows.Window
`$window.Title = if (`$data.kind -eq 'evaluation') { 'ATLAS — Avaliação do atendimento' } elseif (`$data.kind -eq 'escalation') { 'ATLAS — Apoio técnico' } else { 'ATLAS — Orientação ao usuário' }
if (`$data.kind -eq 'escalation') {
    `$window.Width = 520; `$window.MinHeight = 235; `$window.MaxHeight = 330
} else {
    `$window.Width = 640; `$window.MinHeight = 390; `$window.MaxHeight = 690
}
`$window.SizeToContent = 'Height'; `$window.WindowStartupLocation = 'CenterScreen'
`$window.Topmost = `$true; `$window.FontFamily = 'Segoe UI'
`$window.ShowActivated = `$true
`$window.Add_SourceInitialized({
    # O console foi ocultado; a janela WPF continua visível na sessão.
    try {
        `$helper = New-Object System.Windows.Interop.WindowInteropHelper -ArgumentList `$window
        `$handle = `$helper.Handle
        [Atlas.WindowNative]::ShowWindow(`$handle, 5) | Out-Null
        [void]`$window.Activate()
    } catch {}
})
`$window.Background = `$converter.ConvertFromString(`$(if (`$data.kind -eq 'escalation') { '#31141D' } else { '#082135' }))
`$scroll = New-Object System.Windows.Controls.ScrollViewer
`$scroll.VerticalScrollBarVisibility = 'Auto'
`$panel = New-Object System.Windows.Controls.StackPanel
`$panel.Margin = '32,25,32,28'
`$scroll.Content = `$panel
function Add-Text([string]`$value, [int]`$size, [string]`$color, [string]`$margin) {
    `$label = New-Object System.Windows.Controls.TextBlock
    `$label.Text = `$value; `$label.TextWrapping = 'Wrap'; `$label.FontSize = `$size
    `$label.Margin = `$margin; `$label.Foreground = `$converter.ConvertFromString(`$color)
    [void]`$panel.Children.Add(`$label)
}
function Add-Action([string]`$caption, [scriptblock]`$handler) {
    `$button = New-Object System.Windows.Controls.Button
    `$button.Content = `$caption; `$button.Margin = '0,3,0,7'; `$button.Padding = '12,9'
    `$button.Cursor = 'Hand'; `$button.Background = `$converter.ConvertFromString('#12694F')
    `$button.Foreground = `$converter.ConvertFromString('#F3F7FA')
    `$button.BorderBrush = `$converter.ConvertFromString('#2F9F72')
    `$button.Add_Click(`$handler)
    [void]`$panel.Children.Add(`$button)
}
`$name = [string]`$data.display_name
`$operator = [string]`$data.operator_name
if (`$data.kind -eq 'escalation') {
    Add-Text 'SOLICITAÇÃO DE APOIO TÉCNICO' 14 '#FF8692' '0,0,0,19'
    Add-Text "Analista `$operator solicita apoio técnico." 22 '#FFF1F2' '0,0,0,12'
    if (![string]::IsNullOrWhiteSpace([string]`$data.source_computer)) {
        Add-Text "Micro: `$(`$data.source_computer)" 15 '#FFB8C0' '0,0,0,12'
    }
    `$duration = 3
} elseif (`$data.kind -eq 'evaluation') {
    Add-Text "Olá, Sr. `$name" 21 '#54D7A7' '0,0,0,18'
    Add-Text 'Sua opinião é importante!' 16 '#F3F7FA' '0,0,0,12'
    Add-Text 'Após o fechamento deste chamado, você receberá um novo e-mail com um link para a pesquisa de satisfação. Sua participação é muito importante para melhorarmos continuamente nosso atendimento.' 15 '#F3F7FA' '0,0,0,15'
    Add-Text 'Muito obrigado!' 15 '#F3F7FA' '0,0,0,15'
    Add-Text 'A avaliação chegará em seu e-mail e poderá ser acessada pelo:' 15 '#F3F7FA' '0,0,0,10'
    Add-Action '🌐 Acessar Outlook Web' { Start-Process 'https://outlook.office.com/mail/' }
    Add-Action '💻 Acessar Outlook Desktop' {
        try { Start-Process 'outlook.exe' -ErrorAction Stop }
        catch {
            try { Start-Process 'outlook:' -ErrorAction Stop }
            catch { [System.Windows.MessageBox]::Show('Não foi possível abrir o Outlook Desktop nesta estação.','ATLAS') | Out-Null }
        }
    }
    `$duration = 3
} else {
    Add-Text "Olá, `$name" 21 '#54D7A7' '0,0,0,8'
    `$heading = if ([string]`$data.title -eq 'Orientação livre') { 'MENSAGEM DO SUPORTE' } else { 'ORIENTAÇÃO DO SUPORTE' }
    Add-Text `$heading 13 '#F3F7FA' '0,0,0,15'
    if (![string]::IsNullOrWhiteSpace([string]`$data.guidance)) {
        Add-Text ([string]`$data.guidance) 15 '#F3F7FA' '0,0,0,15'
    }
    if (![string]::IsNullOrWhiteSpace([string]`$data.path)) {
        if (`$data.include_chief_notice -ne `$false) {
            Add-Text 'IMPORTANTE: O chamado deve ser aberto pelo chefe do setor.' 13 '#F3D68A' '0,3,0,12'
        }
        Add-Text 'CAMINHO NA INTRANET' 12 '#54D7A7' '0,2,0,5'
        Add-Text ([string]`$data.path) 15 '#F3F7FA' '0,0,0,15'
    }
    if (![string]::IsNullOrWhiteSpace([string]`$data.contact)) {
        Add-Text 'CONTATO / SETOR RESPONSÁVEL' 12 '#54D7A7' '0,2,0,5'
        Add-Text ([string]`$data.contact) 15 '#F3F7FA' '0,0,0,15'
    }
    Add-Text 'Agradecemos por entrar em contato com o Prodasen.' 14 '#F3F7FA' '0,7,0,15'
    `$duration = 10
}
if (`$data.kind -eq 'escalation') {
    # A mensagem usa exatamente a identificação do analista, sem assinatura adicional.
} elseif (`$data.kind -eq 'evaluation') {
    `$signature = "Atenciosamente,`n`n--`n`$operator"
    if (![string]::IsNullOrWhiteSpace([string]`$data.operator_title)) {
        `$signature += "`n" + [string]`$data.operator_title
    }
    Add-Text `$signature 15 '#54D7A7' '0,10,0,10'
} else {
    Add-Text "Atenciosamente,`n`$operator" 15 '#54D7A7' '0,0,0,10'
}
`$close = New-Object System.Windows.Controls.Button
`$close.Content = 'Fechar'; `$close.Width = 90; `$close.Margin = '0,10,0,0'
`$close.HorizontalAlignment = 'Right'
if (`$data.kind -eq 'escalation') {
    `$close.Background = `$converter.ConvertFromString('#A82E42')
    `$close.Foreground = `$converter.ConvertFromString('#FFFFFF')
    `$close.BorderBrush = `$converter.ConvertFromString('#DE6274')
}
`$close.Add_Click({ `$window.Close() })
[void]`$panel.Children.Add(`$close)
`$window.Content = `$scroll
`$timer = New-Object System.Windows.Threading.DispatcherTimer
`$timer.Interval = [TimeSpan]::FromMinutes(`$duration)
`$timer.Add_Tick({ `$timer.Stop(); `$window.Close() })
`$timer.Start()
[void]`$window.ShowDialog()
} catch {
    # Uma falha após o despacho não pode ser observada pela máquina de suporte.
    # Não abra uma janela de erro na sessão do usuário.
    exit 1
}
"@
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($remoteCode))
    $taskName = 'Atlas_Mensagem_' + [guid]::NewGuid().ToString('N').Substring(0, 10)
    # Mesmo percurso comprovado na avaliação da v17: tarefa interativa
    # executando diretamente o comando codificado, sem WSH nem arquivos temporários.
    Invoke-InteractiveTask -TaskName $taskName -Command 'powershell.exe' -Arguments "-NoProfile -STA -WindowStyle Hidden -EncodedCommand $encoded" -InteractiveUser $sessionUser -PostStartDelayMilliseconds 2500
    Write-Output "Mensagem despachada para a sessão de $sessionUser em $Computer. A abertura e a leitura da janela não podem ser confirmadas remotamente."
}
