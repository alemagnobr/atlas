function Normalize-AtlasEscalationName([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name)) { return '' }
    $builder = New-Object Text.StringBuilder
    foreach ($character in $Name.Normalize([Text.NormalizationForm]::FormD).ToCharArray()) {
        if ([Globalization.CharUnicodeInfo]::GetUnicodeCategory($character) -ne [Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$builder.Append($character)
        }
    }
    return (($builder.ToString() -replace '\s+', ' ').Trim().ToUpperInvariant())
}

function Get-AtlasEscalationPresence {
    $catalogPath = Join-Path (Split-Path -Parent $ModuleRoot) 'data\escalation_targets.json'
    $targets = @(Get-Content -LiteralPath $catalogPath -Raw -Encoding UTF8 | ConvertFrom-Json)
    $items = foreach ($target in $targets) {
        $record = [ordered]@{
            key = [string]$target.key
            computer = [string]$target.computer
            available = $false
            expected_user = ''
            status = 'Sem usuário logado'
        }
        try {
            $computerSystem = @(Get-BoundedWmiObject -ComputerName $record.computer -ClassName 'Win32_ComputerSystem' -TimeoutSeconds 5)[0]
            $logged = if ($computerSystem) { ([string]$computerSystem.UserName).Trim() } else { '' }
            if (!$logged) {
                $record.status = 'Sem usuário logado'
            } else {
                $account = ($logged -split '\\')[-1]
                if ($account -notmatch '^[A-Za-z0-9_.-]+$') {
                    $record.status = 'Identidade do usuário não confirmada'
                } else {
                    $searcher = New-Object DirectoryServices.DirectorySearcher
                    $searcher.Filter = "(&(objectCategory=person)(objectClass=user)(sAMAccountName=$account))"
                    $searcher.ClientTimeout = [TimeSpan]::FromSeconds(5)
                    $searcher.ServerTimeLimit = [TimeSpan]::FromSeconds(5)
                    [void]$searcher.PropertiesToLoad.Add('displayName')
                    $result = $searcher.FindOne()
                    $actual = if ($result) { ([string]$result.Properties['displayname'][0]).Trim() } else { '' }
                    $expected = ([string]$target.name).Trim()
                    if ($actual -and (Normalize-AtlasEscalationName $actual) -eq (Normalize-AtlasEscalationName $expected)) {
                        $record.available = $true
                        $record.expected_user = $account
                        $record.status = 'Disponível'
                    } else {
                        $record.status = if ($actual) { 'Outra pessoa conectada' } else { 'Identidade no AD não confirmada' }
                    }
                }
            }
        } catch {
            $record.status = 'Estação ou AD indisponível'
        }
        [pscustomobject]$record
    }
    Write-Output ('@@ESCALATION_PRESENCE@@' + (@{ items=@($items) } | ConvertTo-Json -Depth 4 -Compress))
}
