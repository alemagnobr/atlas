# ==============================================================================
# GERENCIAMENTO AVANCADO DE CERTIFICADOS DIGITAIS REMOTOS (ICP-BRASIL / SIGAD)
# ==============================================================================

function Convert-BlobToCertificate {
    param([byte[]]$bytes)
    if ($null -eq $bytes -or $bytes.Length -lt 8) { return $null }

    # 1. Verifica se comeca diretamente com DER X.509 ASN.1 (0x30 0x82... ou 0x30 0x81...)
    if ($bytes[0] -eq 0x30 -and ($bytes[1] -eq 0x82 -or $bytes[1] -eq 0x81 -or $bytes[1] -gt 0)) {
        try {
            $x509 = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(,$bytes)
            if ($x509 -and ![string]::IsNullOrWhiteSpace($x509.Thumbprint)) {
                return [PSCustomObject]@{
                    Certificate   = $x509
                    HasPrivateKey = $x509.HasPrivateKey
                    FriendlyName  = $x509.FriendlyName
                }
            }
        } catch {}
    }

    # 2. Formato Serialized Property Store do CryptoAPI (SystemCertificates\...\Certificates\<Thumbprint>\Blob)
    # Sequencia TLV: DWORD dwPropId, DWORD dwFlags, DWORD cbData, BYTE pbData[cbData]
    $offset = 0
    $certBytes = $null
    $hasKey = $false
    $friendlyName = $null

    while ($offset + 12 -le $bytes.Length) {
        $propId = [System.BitConverter]::ToUInt32($bytes, $offset)
        $flags  = [System.BitConverter]::ToUInt32($bytes, $offset + 4)
        $cbData = [System.BitConverter]::ToUInt32($bytes, $offset + 8)
        $offset += 12
        if ($offset + $cbData -gt $bytes.Length) { break }

        if ($propId -eq 32) { # CERT_CERT_PROP_ID (0x20)
            $certBytes = New-Object byte[] $cbData
            [System.Buffer]::BlockCopy($bytes, $offset, $certBytes, 0, $cbData)
        } elseif ($propId -eq 2) { # CERT_KEY_PROV_INFO_PROP_ID (Chave privada / Token USB / SmartCard)
            $hasKey = $true
        } elseif ($propId -eq 11) { # CERT_FRIENDLY_NAME_PROP_ID
            try {
                $rawStr = [System.Text.Encoding]::Unicode.GetString($bytes, $offset, $cbData)
                $nullIdx = $rawStr.IndexOf([char]0)
                if ($nullIdx -ge 0) { $rawStr = $rawStr.Substring(0, $nullIdx) }
                $friendlyName = $rawStr.Trim()
            } catch {}
        }
        $offset += $cbData
    }

    if ($null -ne $certBytes) {
        try {
            $x509 = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(,$certBytes)
            if ($x509 -and ![string]::IsNullOrWhiteSpace($x509.Thumbprint)) {
                return [PSCustomObject]@{
                    Certificate   = $x509
                    HasPrivateKey = ($hasKey -or $x509.HasPrivateKey)
                    FriendlyName  = if (![string]::IsNullOrWhiteSpace($friendlyName)) { $friendlyName } else { $x509.FriendlyName }
                }
            }
        } catch {}
    }

    # 3. Scanner de fallback para sequencia DER X.509 embutida em qualquer offset
    try {
        $bLen = $bytes.Length
        for ($i = 0; $i -lt $bLen - 4; $i++) {
            if ($bytes[$i] -eq 0x30 -and $bytes[$i+1] -eq 0x82) {
                $asnLen = 4 + ($bytes[$i+2] -shl 8) + $bytes[$i+3]
                if ($i + $asnLen -le $bLen) {
                    $cand = New-Object byte[] $asnLen
                    [System.Buffer]::BlockCopy($bytes, $i, $cand, 0, $asnLen)
                    try {
                        $x509 = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(,$cand)
                        if ($x509 -and ![string]::IsNullOrWhiteSpace($x509.Thumbprint)) {
                            return [PSCustomObject]@{
                                Certificate   = $x509
                                HasPrivateKey = ($hasKey -or $x509.HasPrivateKey)
                                FriendlyName  = if (![string]::IsNullOrWhiteSpace($friendlyName)) { $friendlyName } else { $x509.FriendlyName }
                            }
                        }
                    } catch {}
                }
            } elseif ($bytes[$i] -eq 0x30 -and $bytes[$i+1] -eq 0x81) {
                $asnLen = 3 + $bytes[$i+2]
                if ($i + $asnLen -le $bLen) {
                    $cand = New-Object byte[] $asnLen
                    [System.Buffer]::BlockCopy($bytes, $i, $cand, 0, $asnLen)
                    try {
                        $x509 = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(,$cand)
                        if ($x509 -and ![string]::IsNullOrWhiteSpace($x509.Thumbprint)) {
                            return [PSCustomObject]@{
                                Certificate   = $x509
                                HasPrivateKey = ($hasKey -or $x509.HasPrivateKey)
                                FriendlyName  = if (![string]::IsNullOrWhiteSpace($friendlyName)) { $friendlyName } else { $x509.FriendlyName }
                            }
                        }
                    } catch {}
                }
            }
        }
    } catch {}

    return $null
}

function Test-IsSigadCertificate {
    param($certObj)
    if ($null -eq $certObj) { return $false }
    $sub = [string]$certObj.Subject
    $iss = [string]$certObj.Issuer
    $fn  = [string]$certObj.FriendlyName

    # 1. Padrao e-CPF ICP-Brasil (NOME:00000000000 com 11 digitos numericos apos dois pontos)
    if ($sub -match ':\d{11}' -or $sub -match 'OU=(e-CPF|Certificado PF|Pessoa Fisica)' -or $sub -match 'O=ICP-Brasil') {
        return $true
    }
    # 2. Emissores ICP-Brasil e do Senado Federal
    if ($iss -match 'ICP-Brasil|AC SERPRO|AC Certisign|AC Caixa|AC Soluti|AC Valid|AC DigitalSign|AC Imprensa Oficial|AC Notarial|AC Safeweb|AC SENADO|Senado Federal') {
        return $true
    }
    # 3. Referencias a SIGAD ou Assinatura Digital
    if ($fn -match 'SIGAD|Assinad|e-CPF|ICP-Brasil' -or $sub -match 'SIGAD|Assinad') {
        return $true
    }
    return $false
}

function Get-CertificateCleanName {
    param([string]$dn)
    if ([string]::IsNullOrWhiteSpace($dn)) { return "-" }
    if ($dn -match 'CN=([^,]+)') {
        return $matches[1].Trim()
    }
    return $dn.Trim()
}

function Enable-RemoteRegistryService {
    param([string]$computerName)
    if ([string]::IsNullOrWhiteSpace($computerName)) { return }
    $cleanComp = $computerName.Replace('\', '').Trim()
    $isLocal = ($cleanComp -ieq "localhost" -or $cleanComp -ieq "127.0.0.1" -or $cleanComp -ieq $env:COMPUTERNAME)
    if ($isLocal) { return }

    try {
        $rr = Get-WmiObject -Class Win32_Service -ComputerName $cleanComp -Filter "Name='RemoteRegistry'" -ErrorAction SilentlyContinue
        if ($rr -and $rr.State -ne "Running") {
            $null = $rr.ChangeStartMode("Manual")
            $null = $rr.StartService()
            Start-Sleep -Milliseconds 400
        }
    } catch {}
}

function Get-RemoteMachineCertificates {
    param([string]$computerName)
    if ([string]::IsNullOrWhiteSpace($computerName)) { return @() }
    $cleanComp = $computerName.Replace('\', '').Trim()
    $isLocal = ($cleanComp -ieq "localhost" -or $cleanComp -ieq "127.0.0.1" -or $cleanComp -ieq $env:COMPUTERNAME)

    # Evita falha de criacao da lista em hosts PowerShell 5.1 mais antigos.
    $results = New-Object 'System.Collections.Generic.List[object]'
    $seenMap = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)

    # 1. Se local, consulta direta via provedor Cert:\LocalMachine\My e .NET X509Store
    if ($isLocal) {
        try {
            $lmStore = New-Object System.Security.Cryptography.X509Certificates.X509Store("My", [System.Security.Cryptography.X509Certificates.StoreLocation]::LocalMachine)
            $lmStore.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadOnly)
            foreach ($c in $lmStore.Certificates) {
                $tb = $c.Thumbprint.Trim().ToUpper()
                if (!$seenMap.Contains($tb)) {
                    $seenMap.Add($tb) | Out-Null
                    $isSig = Test-IsSigadCertificate $c
                    $results.Add([PSCustomObject]@{
                        Subject       = $c.Subject
                        Issuer        = $c.Issuer
                        NotBefore     = $c.NotBefore.ToString("yyyy-MM-dd HH:mm:ss")
                        NotAfter      = $c.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                        IsExpired     = ($c.NotAfter -lt (Get-Date))
                        HasPrivateKey = $c.HasPrivateKey
                        Thumbprint    = $tb
                        FriendlyName  = $c.FriendlyName
                        SerialNumber  = $c.SerialNumber
                        UserAccount   = "Maquina Local ($cleanComp)"
                        UserSid       = $null
                        StoreType     = "LocalMachine\My"
                        IsSigad       = $isSig
                        StorageSource = "LocalMachine Store (.NET)"
                    })
                }
            }
            $lmStore.Close()
        } catch {}

        try {
            Get-ChildItem -Path Cert:\LocalMachine\My -ErrorAction SilentlyContinue | ForEach-Object {
                $tb = $_.Thumbprint.Trim().ToUpper()
                if (!$seenMap.Contains($tb)) {
                    $seenMap.Add($tb) | Out-Null
                    $isSig = Test-IsSigadCertificate $_
                    $results.Add([PSCustomObject]@{
                        Subject       = $_.Subject
                        Issuer        = $_.Issuer
                        NotBefore     = $_.NotBefore.ToString("yyyy-MM-dd HH:mm:ss")
                        NotAfter      = $_.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                        IsExpired     = ($_.NotAfter -lt (Get-Date))
                        HasPrivateKey = $_.HasPrivateKey
                        Thumbprint    = $tb
                        FriendlyName  = $_.FriendlyName
                        SerialNumber  = $_.SerialNumber
                        UserAccount   = "Maquina Local ($cleanComp)"
                        UserSid       = $null
                        StoreType     = "LocalMachine\My"
                        IsSigad       = $isSig
                        StorageSource = "Cert:\LocalMachine\My"
                    })
                }
            }
        } catch {}
    }

    # 2. WMI StdRegProv Fallback (Essencial para acesso remoto confiavel sem depender do servico RemoteRegistry)
    try {
        $stdReg = if ($isLocal) {
            [WMICLASS]"root\default:StdRegProv"
        } else {
            [WMICLASS]"\\$cleanComp\root\default:StdRegProv"
        }

        if ($stdReg) {
            $HKLM = 2147483650 # 0x80000002
            $mStores = @(
                "Software\Microsoft\SystemCertificates\My\Certificates",
                "Software\Microsoft\EnterpriseCertificates\My\Certificates",
                "Software\Policies\Microsoft\SystemCertificates\My\Certificates"
            )

            foreach ($stPath in $mStores) {
                try {
                    $enumRes = $stdReg.EnumKey($HKLM, $stPath)
                    if ($enumRes -and $enumRes.sNames) {
                        foreach ($cThumb in $enumRes.sNames) {
                            $tbUpper = $cThumb.Trim().ToUpper()
                            if ($seenMap.Contains($tbUpper)) { continue }

                            try {
                                $binRes = $stdReg.GetBinaryValue($HKLM, "$stPath\$cThumb", "Blob")
                                if ($binRes -and $binRes.uValue) {
                                    $blobBytes = [byte[]]$binRes.uValue
                                    $parsed = Convert-BlobToCertificate $blobBytes
                                    if ($parsed -and $parsed.Certificate) {
                                        $seenMap.Add($tbUpper) | Out-Null
                                        $cObj = $parsed.Certificate
                                        $isSig = Test-IsSigadCertificate $cObj
                                        $results.Add([PSCustomObject]@{
                                            Subject       = $cObj.Subject
                                            Issuer        = $cObj.Issuer
                                            NotBefore     = $cObj.NotBefore.ToString("yyyy-MM-dd HH:mm:ss")
                                            NotAfter      = $cObj.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                                            IsExpired     = ($cObj.NotAfter -lt (Get-Date))
                                            HasPrivateKey = $parsed.HasPrivateKey
                                            Thumbprint    = $tbUpper
                                            FriendlyName  = $parsed.FriendlyName
                                            SerialNumber  = $cObj.SerialNumber
                                            UserAccount   = "Maquina ($cleanComp)"
                                            UserSid       = $null
                                            StoreType     = "LocalMachine\My"
                                            IsSigad       = $isSig
                                            StorageSource = "WMI StdRegProv (HKLM)"
                                        })
                                    }
                                }
                            } catch {}
                        }
                    }
                } catch {}
            }
        }
    } catch {}

    # 3. Varredura via Registro Remoto / Local HKLM (.NET OpenRemoteBaseKey)
    try {
        if (!$isLocal) { Enable-RemoteRegistryService $cleanComp }

        $regLM = if ($isLocal) {
            [Microsoft.Win32.Registry]::LocalMachine
        } else {
            [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $cleanComp)
        }

        if ($regLM) {
            $mStores = @(
                "Software\Microsoft\SystemCertificates\My\Certificates",
                "Software\Microsoft\EnterpriseCertificates\My\Certificates"
            )

            foreach ($stPath in $mStores) {
                try {
                    $lmStoreKey = $regLM.OpenSubKey($stPath)
                    if ($lmStoreKey) {
                        foreach ($cThumb in $lmStoreKey.GetSubKeyNames()) {
                            $tbUpper = $cThumb.Trim().ToUpper()
                            if ($seenMap.Contains($tbUpper)) { continue }

                            try {
                                $cSubKey = $lmStoreKey.OpenSubKey($cThumb)
                                if ($cSubKey) {
                                    $blobBytes = $cSubKey.GetValue("Blob")
                                    if ($blobBytes -and $blobBytes -is [byte[]]) {
                                        $parsed = Convert-BlobToCertificate $blobBytes
                                        if ($parsed -and $parsed.Certificate) {
                                            $seenMap.Add($tbUpper) | Out-Null
                                            $cObj = $parsed.Certificate
                                            $isSig = Test-IsSigadCertificate $cObj
                                            $results.Add([PSCustomObject]@{
                                                Subject       = $cObj.Subject
                                                Issuer        = $cObj.Issuer
                                                NotBefore     = $cObj.NotBefore.ToString("yyyy-MM-dd HH:mm:ss")
                                                NotAfter      = $cObj.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                                                IsExpired     = ($cObj.NotAfter -lt (Get-Date))
                                                HasPrivateKey = $parsed.HasPrivateKey
                                                Thumbprint    = $tbUpper
                                                FriendlyName  = $parsed.FriendlyName
                                                SerialNumber  = $cObj.SerialNumber
                                                UserAccount   = "Maquina ($cleanComp)"
                                                UserSid       = $null
                                                StoreType     = "LocalMachine\My"
                                                IsSigad       = $isSig
                                                StorageSource = "Registro Remoto HKLM"
                                            })
                                        }
                                    }
                                    $cSubKey.Close()
                                }
                            } catch {}
                        }
                        $lmStoreKey.Close()
                    }
                } catch {}
            }
            $regLM.Close()
        }
    } catch {}

    # 4. Fallback via WinRM / Invoke-Command se remoto e nenhum certificado foi capturado
    if ($results.Count -eq 0 -and !$isLocal) {
        try {
            $certs = Invoke-Command -ComputerName $cleanComp -ScriptBlock {
                @(Get-ChildItem -Path Cert:\LocalMachine\My -ErrorAction SilentlyContinue | ForEach-Object {
                    [PSCustomObject]@{
                        Subject       = $_.Subject
                        Issuer        = $_.Issuer
                        NotBefore     = $_.NotBefore.ToString("yyyy-MM-dd HH:mm:ss")
                        NotAfter      = $_.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                        IsExpired     = ($_.NotAfter -lt (Get-Date))
                        HasPrivateKey = $_.HasPrivateKey
                        Thumbprint    = $_.Thumbprint
                        FriendlyName  = $_.FriendlyName
                        SerialNumber  = $_.SerialNumber
                    }
                })
            } -ErrorAction SilentlyContinue

            if ($null -ne $certs) {
                foreach ($c in $certs) {
                    $tb = $c.Thumbprint.ToUpper()
                    if (!$seenMap.Contains($tb)) {
                        $seenMap.Add($tb) | Out-Null
                        $isSig = Test-IsSigadCertificate $c
                        $results.Add([PSCustomObject]@{
                            Subject       = $c.Subject
                            Issuer        = $c.Issuer
                            NotBefore     = $c.NotBefore
                            NotAfter      = $c.NotAfter
                            IsExpired     = $c.IsExpired
                            HasPrivateKey = $c.HasPrivateKey
                            Thumbprint    = $tb
                            FriendlyName  = $c.FriendlyName
                            SerialNumber  = $c.SerialNumber
                            UserAccount   = "Maquina ($cleanComp)"
                            UserSid       = $null
                            StoreType     = "LocalMachine\My"
                            IsSigad       = $isSig
                            StorageSource = "WinRM Invoke-Command"
                        })
                    }
                }
            }
        } catch {}
    }

    # Evita "Argument types do not match" no PowerShell 5.1.
    return $results.ToArray()
}

function Remove-RemoteMachineCertificate {
    param(
        [string]$computerName,
        [string]$thumbprint
    )
    if ([string]::IsNullOrWhiteSpace($computerName) -or [string]::IsNullOrWhiteSpace($thumbprint)) { return $false }
    $cleanComp = $computerName.Replace('\', '').Trim()
    $tb = $thumbprint.Trim().ToUpper()
    $isLocal = ($cleanComp -ieq "localhost" -or $cleanComp -ieq "127.0.0.1" -or $cleanComp -ieq $env:COMPUTERNAME)
    $removed = $false

    if ($isLocal) {
        try {
            Remove-Item -Path "Cert:\LocalMachine\My\$tb" -Force -ErrorAction SilentlyContinue
            & certutil.exe -delstore My $tb > $null 2>&1
            $removed = $true
        } catch {}
    }

    # 1. Remocao via reg.exe delete remoto
    if (!$isLocal) {
        try {
            $delOut = & reg.exe delete "\\$cleanComp\HKLM\Software\Microsoft\SystemCertificates\My\Certificates\$tb" /f 2>&1
            if ($LASTEXITCODE -eq 0) { $removed = $true }
            & reg.exe delete "\\$cleanComp\HKLM\Software\Microsoft\EnterpriseCertificates\My\Certificates\$tb" /f > $null 2>&1
        } catch {}
    }

    # 2. Remocao via WMI StdRegProv
    try {
        $stdReg = if ($isLocal) { [WMICLASS]"root\default:StdRegProv" } else { [WMICLASS]"\\$cleanComp\root\default:StdRegProv" }
        if ($stdReg) {
            $HKLM = 2147483650
            $delRes1 = $stdReg.DeleteKey($HKLM, "Software\Microsoft\SystemCertificates\My\Certificates\$tb")
            if ($delRes1 -and $delRes1.ReturnValue -eq 0) { $removed = $true }
            $null = $stdReg.DeleteKey($HKLM, "Software\Microsoft\EnterpriseCertificates\My\Certificates\$tb")
        }
    } catch {}

    # 3. Remocao direta via Registro Remoto HKLM
    try {
        if (!$isLocal) { Enable-RemoteRegistryService $cleanComp }
        $regLM = if ($isLocal) { [Microsoft.Win32.Registry]::LocalMachine } else { [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $cleanComp) }
        if ($regLM) {
            $mKey = $regLM.OpenSubKey("Software\Microsoft\SystemCertificates\My\Certificates", $true)
            if ($mKey) {
                $hasSub = $mKey.GetSubKeyNames() | Where-Object { $_ -ieq $tb }
                if ($hasSub) {
                    $mKey.DeleteSubKeyTree($tb, $false)
                    $removed = $true
                }
                $mKey.Close()
            }
            $regLM.Close()
        }
    } catch {}

    # 4. Fallback via Invoke-Command (WinRM)
    if (!$removed -and !$isLocal) {
        try {
            $res = Invoke-Command -ComputerName $cleanComp -ScriptBlock {
                param($t)
                try {
                    Remove-Item -Path "Cert:\LocalMachine\My\$t" -Force -ErrorAction SilentlyContinue
                    & certutil.exe -delstore My $t > $null 2>&1
                    return $true
                } catch { return $false }
            } -ArgumentList $tb -ErrorAction SilentlyContinue
            if ($res -eq $true) { $removed = $true }
        } catch {}
    }

    return $removed
}

function Get-RemoteInteractiveUserCertificates {
    param(
        [string]$computerName,
        [string]$targetUser = $null
    )

    # Arrays simples evitam incompatibilidade com alguns hosts PowerShell 5.1.
    $script:CERT_REMOTE_SESSION_STATUS = "Iniciando consulta da sessao remota..."
    $results = @()

    if ([string]::IsNullOrWhiteSpace($computerName)) { return @() }
    $cleanComp = $computerName.Replace('\', '').Trim()
    if ([string]::IsNullOrWhiteSpace($cleanComp)) { return @() }

    # Certificados pessoais pertencem ao contexto do usuario. Uma consulta feita
    # como administrador/SYSTEM pode retornar uma loja vazia, principalmente com
    # certificados A3, token USB e smart card. Esta rotina executa a leitura na
    # sessao interativa que ja esta aberta no computador remoto.
    $interactiveUser = $targetUser
    if ([string]::IsNullOrWhiteSpace($interactiveUser) -or $interactiveUser -eq "TODOS") {
        try {
            $cs = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $cleanComp -ErrorAction Stop
            $interactiveUser = $cs.UserName
        } catch {
            $script:CERT_REMOTE_SESSION_STATUS = "Nao foi possivel identificar o usuario logado via WMI."
        }
    }

    if ([string]::IsNullOrWhiteSpace($interactiveUser)) {
        if ([string]::IsNullOrWhiteSpace($script:CERT_REMOTE_SESSION_STATUS)) {
            $script:CERT_REMOTE_SESSION_STATUS = "Nenhum usuario com sessao interativa foi localizado."
        }
        return @()
    }

    $jobId = [Guid]::NewGuid().ToString("N")
    $taskName = "SuporteSenado_ListarCert_$jobId"
    $remoteLocalPath = "C:\Windows\Temp\SuporteSenado_Cert_$jobId.json"
    $remoteUncPath = "\\$cleanComp\C$\Windows\Temp\SuporteSenado_Cert_$jobId.json"
    $taskXmlPath = Join-Path $env:TEMP "SuporteSenado_Cert_$jobId.xml"

    try {
        $collectorScript = @"
`$ErrorActionPreference = 'SilentlyContinue'
`$rows = @()
`$collectorErrors = @()
# O certutil nao e executado aqui porque alguns tokens A3 aguardam PIN e
# impedem a tarefa de chegar ate a gravacao do arquivo de retorno.
try {
    foreach (`$storePath in @('Cert:\CurrentUser\My', 'Cert:\LocalMachine\My')) {
        `$storeType = if (`$storePath -like '*LocalMachine*') { 'LocalMachine\My' } else { 'CurrentUser\My' }
        `$rows += @(Get-ChildItem -Path `$storePath -ErrorAction SilentlyContinue | ForEach-Object {
            [PSCustomObject]@{
                Subject       = [string]`$_.Subject
                Issuer        = [string]`$_.Issuer
                NotBefore     = `$_.NotBefore.ToString('o')
                NotAfter      = `$_.NotAfter.ToString('o')
                IsExpired     = (`$_.NotAfter -lt (Get-Date))
                HasPrivateKey = [bool]`$_.HasPrivateKey
                Thumbprint    = [string]`$_.Thumbprint
                FriendlyName  = [string]`$_.FriendlyName
                SerialNumber  = [string]`$_.SerialNumber
                StoreType     = `$storeType
            }
        })
    }
} catch { `$collectorErrors += "CertProvider: `$(`$_.Exception.Message)" }
try {
    `$payload = [PSCustomObject]@{
        Computer     = `$env:COMPUTERNAME
        User          = "`$env:USERDOMAIN\`$env:USERNAME"
        CertificateCount = @(`$rows).Count
        Errors        = @(`$collectorErrors)
        Certificates  = @(`$rows)
    }
    `$json = ConvertTo-Json -InputObject `$payload -Depth 5 -Compress
    [System.IO.File]::WriteAllText('$remoteLocalPath', `$json, (New-Object System.Text.UTF8Encoding(`$false)))
} catch {}
"@

        $encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($collectorScript))
        $xmlUser = [System.Security.SecurityElement]::Escape($interactiveUser)
        $taskXml = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Principals>
    <Principal id="Author">
      <UserId>$xmlUser</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>true</Hidden>
    <ExecutionTimeLimit>PT2M</ExecutionTimeLimit>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>powershell.exe</Command>
      <Arguments>-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand $encodedCommand</Arguments>
    </Exec>
  </Actions>
</Task>
"@

        [System.IO.File]::WriteAllText($taskXmlPath, $taskXml, [System.Text.Encoding]::Unicode)

        $createOutput = @(& schtasks.exe /Create /S $cleanComp /TN $taskName /XML $taskXmlPath /F 2>&1)
        if ($LASTEXITCODE -ne 0) {
            $createMsg = ($createOutput -join " ").Trim()
            $script:CERT_REMOTE_SESSION_STATUS = "Falha ao criar tarefa na sessao de ${interactiveUser}. Retorno: $createMsg"
            return @()
        }

        $runOutput = @(& schtasks.exe /Run /S $cleanComp /TN $taskName 2>&1)
        if ($LASTEXITCODE -ne 0) {
            $runMsg = ($runOutput -join " ").Trim()
            $script:CERT_REMOTE_SESSION_STATUS = "A tarefa foi criada, mas nao iniciou na sessao de ${interactiveUser}. Retorno: $runMsg"
            return @()
        }

        $foundOutput = $false
        for ($attempt = 0; $attempt -lt 40; $attempt++) {
            if (Test-Path -LiteralPath $remoteUncPath) {
                $foundOutput = $true
                break
            }
            Start-Sleep -Milliseconds 500
        }

        if (!$foundOutput) {
            $script:CERT_REMOTE_SESSION_STATUS = "A sessao de $interactiveUser nao retornou o arquivo de certificados no tempo esperado."
            return @()
        }

        $rawJson = Get-Content -LiteralPath $remoteUncPath -Raw -ErrorAction Stop
        if (![string]::IsNullOrWhiteSpace($rawJson)) {
            $payload = $rawJson | ConvertFrom-Json -ErrorAction Stop
            $items = @($payload.Certificates)
            foreach ($c in $items) {
                if ($null -eq $c -or [string]::IsNullOrWhiteSpace([string]$c.Thumbprint)) { continue }
                $results += [PSCustomObject]@{
                    Subject       = [string]$c.Subject
                    Issuer        = [string]$c.Issuer
                    NotBefore     = [string]$c.NotBefore
                    NotAfter      = [string]$c.NotAfter
                    IsExpired     = [bool]$c.IsExpired
                    HasPrivateKey = [bool]$c.HasPrivateKey
                    Thumbprint    = ([string]$c.Thumbprint).Trim().ToUpper()
                    FriendlyName  = [string]$c.FriendlyName
                    SerialNumber  = [string]$c.SerialNumber
                    UserAccount   = if (([string]$c.StoreType) -like "LocalMachine*") { "Maquina ($cleanComp)" } else { $interactiveUser }
                    UserSid       = $null
                    StoreType     = if (([string]$c.StoreType) -like "LocalMachine*") { "LocalMachine\My" } else { "CurrentUser\My" }
                    IsSigad       = (Test-IsSigadCertificate $c)
                    StorageSource = "Sessao interativa remota ($interactiveUser)"
                }
            }

            $collectorErrorText = @($payload.Errors) -join "; "
            if (![string]::IsNullOrWhiteSpace($collectorErrorText)) {
                $script:CERT_REMOTE_SESSION_STATUS = "Sessao consultada com avisos: $collectorErrorText"
            }
        }

        if ($script:CERT_REMOTE_SESSION_STATUS -notlike "*avisos*") {
            $script:CERT_REMOTE_SESSION_STATUS = "Sessao de $interactiveUser consultada: $($results.Count) certificado(s) da maquina e do perfil."
        }
    } catch {
        $script:CERT_REMOTE_SESSION_STATUS = "Falha na leitura pela sessao de ${interactiveUser}: $($_.Exception.Message)"
    } finally {
        try { & schtasks.exe /Delete /S $cleanComp /TN $taskName /F 2>&1 | Out-Null } catch {}
        try { Remove-Item -LiteralPath $remoteUncPath -Force -ErrorAction SilentlyContinue } catch {}
        try { Remove-Item -LiteralPath $taskXmlPath -Force -ErrorAction SilentlyContinue } catch {}
    }

    # Evita "Argument types do not match" no PowerShell 5.1.
    return $results
}

function Get-RemoteUserCertificates {
    param(
        [string]$computerName,
        [string]$targetUser = $null,
        [bool]$includeMachineFallback = $true
    )
    if ([string]::IsNullOrWhiteSpace($computerName)) { return @() }
    $cleanComp = $computerName.Replace('\', '').Trim()
    $isLocal = ($cleanComp -ieq "localhost" -or $cleanComp -ieq "127.0.0.1" -or $cleanComp -ieq $env:COMPUTERNAME)

    # Object e mais compativel que PSCustomObject como tipo generico no PowerShell 5.1.
    $results = New-Object 'System.Collections.Generic.List[object]'
    $seenMap = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)

    # 1. VARREDURA LOCAL DIRETA (se for maquina local)
    if ($isLocal) {
        try {
            $uStore = New-Object System.Security.Cryptography.X509Certificates.X509Store("My", [System.Security.Cryptography.X509Certificates.StoreLocation]::CurrentUser)
            $uStore.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadOnly)
            foreach ($c in $uStore.Certificates) {
                $tb = $c.Thumbprint.Trim().ToUpper()
                if (!$seenMap.Contains($tb)) {
                    $seenMap.Add($tb) | Out-Null
                    $isSig = Test-IsSigadCertificate $c
                    $results.Add([PSCustomObject]@{
                        Subject       = $c.Subject
                        Issuer        = $c.Issuer
                        NotBefore     = $c.NotBefore.ToString("yyyy-MM-dd HH:mm:ss")
                        NotAfter      = $c.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                        IsExpired     = ($c.NotAfter -lt (Get-Date))
                        HasPrivateKey = $c.HasPrivateKey
                        Thumbprint    = $tb
                        FriendlyName  = $c.FriendlyName
                        SerialNumber  = $c.SerialNumber
                        UserAccount   = "$env:USERDOMAIN\$env:USERNAME"
                        UserSid       = $null
                        StoreType     = "CurrentUser\My"
                        IsSigad       = $isSig
                        StorageSource = "Sessao Atual (.NET Store)"
                    })
                }
            }
            $uStore.Close()
        } catch {}

        try {
            Get-ChildItem -Path Cert:\CurrentUser\My -ErrorAction SilentlyContinue | ForEach-Object {
                $tb = $_.Thumbprint.Trim().ToUpper()
                if (!$seenMap.Contains($tb)) {
                    $seenMap.Add($tb) | Out-Null
                    $isSig = Test-IsSigadCertificate $_
                    $results.Add([PSCustomObject]@{
                        Subject       = $_.Subject
                        Issuer        = $_.Issuer
                        NotBefore     = $_.NotBefore.ToString("yyyy-MM-dd HH:mm:ss")
                        NotAfter      = $_.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                        IsExpired     = ($_.NotAfter -lt (Get-Date))
                        HasPrivateKey = $_.HasPrivateKey
                        Thumbprint    = $tb
                        FriendlyName  = $_.FriendlyName
                        SerialNumber  = $_.SerialNumber
                        UserAccount   = "$env:USERDOMAIN\$env:USERNAME"
                        UserSid       = $null
                        StoreType     = "CurrentUser\My"
                        IsSigad       = $isSig
                        StorageSource = "Cert:\CurrentUser\My"
                    })
                }
            }
        } catch {}

        # Disparo de leitura de Token USB / Smart Card conectado
        try {
            $null = & certutil.exe -user -silent -store My 2>&1
        } catch {}
    }

    # Em computador remoto, tenta primeiro a loja real do usuario logado. Esse
    # caminho cobre certificados que nao ficam visiveis em HKU/NTUSER.DAT.
    if (!$isLocal) {
        try {
            $interactiveCerts = @(Get-RemoteInteractiveUserCertificates -computerName $cleanComp -targetUser $targetUser)
            foreach ($ic in $interactiveCerts) {
                $tb = $ic.Thumbprint.Trim().ToUpper()
                if (!$seenMap.Contains($tb)) {
                    $seenMap.Add($tb) | Out-Null
                    $results.Add($ic)
                }
            }
        } catch {
            $script:CERT_REMOTE_SESSION_STATUS = "Falha ao chamar a consulta interativa: $($_.Exception.Message)"
        }
    }

    # 2. VARREDURA VIA WMI StdRegProv EM HKEY_USERS (0x80000003)
    # Funciona confiavelmente em maquinas remotas mesmo com o servico RemoteRegistry desativado
    try {
        $stdReg = if ($isLocal) {
            [WMICLASS]"root\default:StdRegProv"
        } else {
            [WMICLASS]"\\$cleanComp\root\default:StdRegProv"
        }

        if ($stdReg) {
            $HKU = 2147483651 # 0x80000003
            $enumSids = $stdReg.EnumKey($HKU, "")
            if ($enumSids -and $enumSids.sNames) {
                foreach ($sid in $enumSids.sNames) {
                    if ($sid -match "Classes$|^\.DEFAULT$|^S-1-5-18$|^S-1-5-19$|^S-1-5-20$") { continue }
                    if ($sid -notmatch '^S-1-5-[0-9\-]+$') { continue }

                    # Traduz SID para conta de usuario se possivel
                    $uAccount = $sid
                    try {
                        $sidObj = New-Object System.Security.Principal.SecurityIdentifier($sid)
                        $uAccount = $sidObj.Translate([System.Security.Principal.NTAccount]).Value
                    } catch {}

                    # Filtro por usuario alvo se especificado
                    if (![string]::IsNullOrWhiteSpace($targetUser) -and $targetUser -ne "TODOS") {
                        $cleanTarget = $targetUser.Trim().ToLower()
                        $cleanAcc = $uAccount.Trim().ToLower()
                        if (!$cleanAcc.EndsWith("\$cleanTarget") -and $cleanAcc -ne $cleanTarget -and !$cleanTarget.EndsWith("\$cleanAcc")) {
                            continue
                        }
                    }

                    $uStores = @(
                        "$sid\Software\Microsoft\SystemCertificates\My\Certificates",
                        "$sid\Software\Microsoft\EnterpriseCertificates\My\Certificates"
                    )

                    foreach ($ustPath in $uStores) {
                        try {
                            $enumC = $stdReg.EnumKey($HKU, $ustPath)
                            if ($enumC -and $enumC.sNames) {
                                foreach ($cThumb in $enumC.sNames) {
                                    $tbUpper = $cThumb.Trim().ToUpper()
                                    if ($seenMap.Contains($tbUpper)) { continue }

                                    try {
                                        $binRes = $stdReg.GetBinaryValue($HKU, "$ustPath\$cThumb", "Blob")
                                        if ($binRes -and $binRes.uValue) {
                                            $blobBytes = [byte[]]$binRes.uValue
                                            $parsed = Convert-BlobToCertificate $blobBytes
                                            if ($parsed -and $parsed.Certificate) {
                                                $seenMap.Add($tbUpper) | Out-Null
                                                $cObj = $parsed.Certificate
                                                $isSig = Test-IsSigadCertificate $cObj
                                                $results.Add([PSCustomObject]@{
                                                    Subject       = $cObj.Subject
                                                    Issuer        = $cObj.Issuer
                                                    NotBefore     = $cObj.NotBefore.ToString("yyyy-MM-dd HH:mm:ss")
                                                    NotAfter      = $cObj.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                                                    IsExpired     = ($cObj.NotAfter -lt (Get-Date))
                                                    HasPrivateKey = $parsed.HasPrivateKey
                                                    Thumbprint    = $tbUpper
                                                    FriendlyName  = $parsed.FriendlyName
                                                    SerialNumber  = $cObj.SerialNumber
                                                    UserAccount   = $uAccount
                                                    UserSid       = $sid
                                                    StoreType     = "CurrentUser\My"
                                                    IsSigad       = $isSig
                                                    StorageSource = "WMI StdRegProv (HKU\$uAccount)"
                                                })
                                            }
                                        }
                                    } catch {}
                                }
                            }
                        } catch {}
                    }
                }
            }
        }
    } catch {}

    # 3. VARREDURA VIA REGISTRO REMOTO / LOCAL HKU (.NET OpenRemoteBaseKey)
    try {
        if (!$isLocal) { Enable-RemoteRegistryService $cleanComp }

        $regUsers = if ($isLocal) {
            [Microsoft.Win32.Registry]::Users
        } else {
            [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::Users, $cleanComp)
        }

        if ($regUsers) {
            $subNames = $regUsers.GetSubKeyNames()
            foreach ($sid in $subNames) {
                if ($sid -match "Classes$|^\.DEFAULT$|^S-1-5-18$|^S-1-5-19$|^S-1-5-20$") { continue }
                if ($sid -notmatch '^S-1-5-[0-9\-]+$') { continue }

                $uAccount = $sid
                try {
                    $sidObj = New-Object System.Security.Principal.SecurityIdentifier($sid)
                    $uAccount = $sidObj.Translate([System.Security.Principal.NTAccount]).Value
                } catch {}

                if (![string]::IsNullOrWhiteSpace($targetUser) -and $targetUser -ne "TODOS") {
                    $cleanTarget = $targetUser.Trim().ToLower()
                    $cleanAccount = $uAccount.Trim().ToLower()
                    if (!$cleanAccount.EndsWith("\$cleanTarget") -and $cleanAccount -ne $cleanTarget -and !$cleanTarget.EndsWith("\$cleanAccount")) {
                        continue
                    }
                }

                $uStores = @(
                    "$sid\Software\Microsoft\SystemCertificates\My\Certificates",
                    "$sid\Software\Microsoft\EnterpriseCertificates\My\Certificates"
                )

                foreach ($ustPath in $uStores) {
                    try {
                        $certStoreKey = $regUsers.OpenSubKey($ustPath)
                        if ($certStoreKey) {
                            foreach ($cThumb in $certStoreKey.GetSubKeyNames()) {
                                $tbUpper = $cThumb.Trim().ToUpper()
                                if ($seenMap.Contains($tbUpper)) { continue }

                                try {
                                    $cSubKey = $certStoreKey.OpenSubKey($cThumb)
                                    if ($cSubKey) {
                                        $blobBytes = $cSubKey.GetValue("Blob")
                                        if ($blobBytes -and $blobBytes -is [byte[]]) {
                                            $parsed = Convert-BlobToCertificate $blobBytes
                                            if ($parsed -and $parsed.Certificate) {
                                                $seenMap.Add($tbUpper) | Out-Null
                                                $cObj = $parsed.Certificate
                                                $isSig = Test-IsSigadCertificate $cObj
                                                $results.Add([PSCustomObject]@{
                                                    Subject       = $cObj.Subject
                                                    Issuer        = $cObj.Issuer
                                                    NotBefore     = $cObj.NotBefore.ToString("yyyy-MM-dd HH:mm:ss")
                                                    NotAfter      = $cObj.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                                                    IsExpired     = ($cObj.NotAfter -lt (Get-Date))
                                                    HasPrivateKey = $parsed.HasPrivateKey
                                                    Thumbprint    = $tbUpper
                                                    FriendlyName  = $parsed.FriendlyName
                                                    SerialNumber  = $cObj.SerialNumber
                                                    UserAccount   = $uAccount
                                                    UserSid       = $sid
                                                    StoreType     = "CurrentUser\My"
                                                    IsSigad       = $isSig
                                                    StorageSource = "Registro HKU ($uAccount)"
                                                })
                                            }
                                        }
                                        $cSubKey.Close()
                                    }
                                } catch {}
                            }
                            $certStoreKey.Close()
                        }
                    } catch {}
                }
            }
            $regUsers.Close()
        }
    } catch {}

    # 4. VARREDURA EM PERFIS DE USUARIO OFFLINE (NTUSER.DAT montado sob demanda via reg.exe)
    # Permite encontrar certificados pessoais mesmo quando o usuario nao estiver com sessao ativa no momento
    try {
        $usersBaseDir = if ($isLocal) { "$env:SystemDrive\Users" } else { "\\$cleanComp\C$\Users" }
        if (Test-Path -LiteralPath $usersBaseDir) {
            $userDirs = Get-ChildItem -LiteralPath $usersBaseDir -Directory -ErrorAction SilentlyContinue | Where-Object {
                $_.Name -notmatch '^(Public|Default|Default User|All Users)$'
            }

            foreach ($uDir in $userDirs) {
                $folderUser = $uDir.Name
                if (![string]::IsNullOrWhiteSpace($targetUser) -and $targetUser -ne "TODOS") {
                    $cleanTarget = $targetUser.Trim().ToLower()
                    $simpleTarget = if ($cleanTarget.Contains('\')) { $cleanTarget.Split('\')[-1] } else { $cleanTarget }
                    if ($folderUser.ToLower() -ne $simpleTarget) {
                        continue
                    }
                }

                $ntUserDat = Join-Path $uDir.FullName "NTUSER.DAT"
                if (Test-Path -LiteralPath $ntUserDat) {
                    $tempHiveKey = "TempHive_Cert_$folderUser"
                    try {
                        $null = & reg.exe load "HKU\$tempHiveKey" "$ntUserDat" 2>&1
                        $certStoreKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$tempHiveKey\Software\Microsoft\SystemCertificates\My\Certificates")
                        if ($certStoreKey) {
                            foreach ($cThumb in $certStoreKey.GetSubKeyNames()) {
                                $tbUpper = $cThumb.Trim().ToUpper()
                                if ($seenMap.Contains($tbUpper)) { continue }

                                try {
                                    $cSubKey = $certStoreKey.OpenSubKey($cThumb)
                                    if ($cSubKey) {
                                        $blobBytes = $cSubKey.GetValue("Blob")
                                        if ($blobBytes -and $blobBytes -is [byte[]]) {
                                            $parsed = Convert-BlobToCertificate $blobBytes
                                            if ($parsed -and $parsed.Certificate) {
                                                $seenMap.Add($tbUpper) | Out-Null
                                                $cObj = $parsed.Certificate
                                                $isSig = Test-IsSigadCertificate $cObj
                                                $results.Add([PSCustomObject]@{
                                                    Subject       = $cObj.Subject
                                                    Issuer        = $cObj.Issuer
                                                    NotBefore     = $cObj.NotBefore.ToString("yyyy-MM-dd HH:mm:ss")
                                                    NotAfter      = $cObj.NotAfter.ToString("yyyy-MM-dd HH:mm:ss")
                                                    IsExpired     = ($cObj.NotAfter -lt (Get-Date))
                                                    HasPrivateKey = $parsed.HasPrivateKey
                                                    Thumbprint    = $tbUpper
                                                    FriendlyName  = $parsed.FriendlyName
                                                    SerialNumber  = $cObj.SerialNumber
                                                    UserAccount   = "Perfil: $folderUser (Offline)"
                                                    UserSid       = $null
                                                    StoreType     = "CurrentUser\My"
                                                    IsSigad       = $isSig
                                                    StorageSource = "NTUSER.DAT ($folderUser)"
                                                })
                                            }
                                        }
                                        $cSubKey.Close()
                                    }
                                } catch {}
                            }
                            $certStoreKey.Close()
                        }
                    } catch {} finally {
                        [GC]::Collect()
                        Start-Sleep -Milliseconds 50
                        $null = & reg.exe unload "HKU\$tempHiveKey" 2>&1
                    }
                }
            }
        }
    } catch {}

    # 5. INCLUSAO DE CERTIFICADOS DA MAQUINA (LocalMachine\My)
    # Garante que todos os certificados de maquina instalados no computador remoto sejam exibidos
    if ($includeMachineFallback) {
        try {
            $machCerts = Get-RemoteMachineCertificates -computerName $cleanComp
            foreach ($mc in $machCerts) {
                $tbUpper = $mc.Thumbprint.Trim().ToUpper()
                if (!$seenMap.Contains($tbUpper)) {
                    $seenMap.Add($tbUpper) | Out-Null
                    $results.Add($mc)
                }
            }
        } catch {}
    }

    # Evita "Argument types do not match" no PowerShell 5.1.
    return $results.ToArray()
}

function Remove-RemoteUserCertificate {
    param(
        [string]$computerName,
        [string]$thumbprint,
        [string]$userSid = $null,
        [string]$userAccount = $null,
        [string]$storeType = "CurrentUser\My"
    )
    if ([string]::IsNullOrWhiteSpace($computerName) -or [string]::IsNullOrWhiteSpace($thumbprint)) { return $false }
    $cleanComp = $computerName.Replace('\', '').Trim()
    $tb = $thumbprint.Trim().ToUpper()
    $isLocal = ($cleanComp -ieq "localhost" -or $cleanComp -ieq "127.0.0.1" -or $cleanComp -ieq $env:COMPUTERNAME)
    $removed = $false

    # 1. Se foi identificado como LocalMachine:
    if ($storeType -like "LocalMachine*") {
        return (Remove-RemoteMachineCertificate -computerName $cleanComp -thumbprint $tb)
    }

    # 2. Remocao local direta se estiver na maquina local
    if ($isLocal) {
        try {
            Remove-Item -Path "Cert:\CurrentUser\My\$tb" -Force -ErrorAction SilentlyContinue
            & certutil.exe -user -delstore My $tb > $null 2>&1
            $removed = $true
        } catch {}
    }

    # 3. Remocao remota via reg.exe delete
    if (!$isLocal -and ![string]::IsNullOrWhiteSpace($userSid)) {
        try {
            & reg.exe delete "\\$cleanComp\HKU\$userSid\Software\Microsoft\SystemCertificates\My\Certificates\$tb" /f > $null 2>&1
            & reg.exe delete "\\$cleanComp\HKU\$userSid\Software\Microsoft\EnterpriseCertificates\My\Certificates\$tb" /f > $null 2>&1
            $removed = $true
        } catch {}
    }

    # 4. Remocao via WMI StdRegProv
    try {
        $stdReg = if ($isLocal) { [WMICLASS]"root\default:StdRegProv" } else { [WMICLASS]"\\$cleanComp\root\default:StdRegProv" }
        if ($stdReg) {
            $HKU = 2147483651
            $sidsToTry = @()
            if (![string]::IsNullOrWhiteSpace($userSid)) {
                $sidsToTry += $userSid
            } else {
                $resS = $stdReg.EnumKey($HKU, "")
                if ($resS -and $resS.sNames) {
                    $sidsToTry += $resS.sNames | Where-Object { $_ -match '^S-1-5-[0-9\-]+$' -and $_ -notmatch 'Classes$' }
                }
            }

            foreach ($s in $sidsToTry) {
                try {
                    $delRes = $stdReg.DeleteKey($HKU, "$s\Software\Microsoft\SystemCertificates\My\Certificates\$tb")
                    if ($delRes -and $delRes.ReturnValue -eq 0) { $removed = $true }
                    $null = $stdReg.DeleteKey($HKU, "$s\Software\Microsoft\EnterpriseCertificates\My\Certificates\$tb")
                } catch {}
            }
        }
    } catch {}

    # 5. Remocao no Registro via .NET OpenRemoteBaseKey
    try {
        if (!$isLocal) { Enable-RemoteRegistryService $cleanComp }
        $regUsers = if ($isLocal) { [Microsoft.Win32.Registry]::Users } else { [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::Users, $cleanComp) }
        if ($regUsers) {
            $sidsToTry = @()
            if (![string]::IsNullOrWhiteSpace($userSid)) {
                $sidsToTry += $userSid
            } else {
                $sidsToTry += $regUsers.GetSubKeyNames() | Where-Object { $_ -match '^S-1-5-[0-9\-]+$' -and $_ -notmatch 'Classes$' }
            }

            foreach ($s in $sidsToTry) {
                try {
                    $keyPath = "$s\Software\Microsoft\SystemCertificates\My\Certificates"
                    $mKey = $regUsers.OpenSubKey($keyPath, $true)
                    if ($mKey) {
                        $hasSub = $mKey.GetSubKeyNames() | Where-Object { $_ -ieq $tb }
                        if ($hasSub) {
                            $mKey.DeleteSubKeyTree($tb, $false)
                            $removed = $true
                        }
                        $mKey.Close()
                    }
                } catch {}
            }
            $regUsers.Close()
        }
    } catch {}

    return $removed
}

function Get-CurrentUserProfileCertificates {
    param(
        [string]$computerName = $null,
        [string]$storeFilter = "ALL"
    )
    $cleanComp = if (![string]::IsNullOrWhiteSpace($computerName)) { $computerName.Replace('\', '').Trim() } else { $env:COMPUTERNAME }
    $isLocal = ($cleanComp -ieq "localhost" -or $cleanComp -ieq "127.0.0.1" -or $cleanComp -ieq $env:COMPUTERNAME)

    $allCerts = @()

    if ($isLocal) {
        # Maquina local: busca perfil do usuario atual e inclui certificados da maquina local
        $targetUser = "$env:USERNAME"
        $allCerts = Get-RemoteUserCertificates -computerName $cleanComp -targetUser $targetUser -includeMachineFallback $true
    } else {
        # Maquina remota: varredura completa da maquina conectada
        $allCerts = Get-RemoteUserCertificates -computerName $cleanComp -includeMachineFallback $true
    }

    # Aplica filtro de exibicao
    if ($storeFilter -ieq "MACHINE") {
        return @($allCerts | Where-Object { $_.StoreType -like "LocalMachine*" })
    } elseif ($storeFilter -ieq "USER") {
        return @($allCerts | Where-Object { $_.StoreType -like "CurrentUser*" })
    } else {
        return @($allCerts)
    }
}

function Confirm-And-Remove-Certificate {
    param(
        $certObj,
        [string]$compName
    )
    $subClean = Get-CertificateCleanName $certObj.Subject
    $issClean = Get-CertificateCleanName $certObj.Issuer

    $valD = ""
    try {
        $dtA = [datetime]$certObj.NotAfter
        $dtB = [datetime]$certObj.NotBefore
        $valD = "$($dtB.ToString('dd/MM/yyyy')) ate $($dtA.ToString('dd/MM/yyyy'))"
    } catch {
        $valD = "$($certObj.NotBefore) ate $($certObj.NotAfter)"
    }

    Clear-Host
    Write-Host "========================================================" -ForegroundColor Red
    Write-Host "   CONFIRMACAO DE EXCLUSAO DE CERTIFICADO DIGITAL" -ForegroundColor Yellow
    Write-Host "========================================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Voce selecionou para REMOCAO o seguinte certificado:" -ForegroundColor White
    Write-Host ""
    Write-Host "    Titular     : " -NoNewline -ForegroundColor Gray
    Write-Host "$subClean" -ForegroundColor White
    if ($certObj.IsSigad) {
        Write-Host "    Tipo        : " -NoNewline -ForegroundColor Gray
        Write-Host "CERTIFICADO SIGAD / ICP-BRASIL" -ForegroundColor Yellow
    }
    Write-Host "    Emissor     : " -NoNewline -ForegroundColor Gray
    Write-Host "$issClean" -ForegroundColor Yellow
    Write-Host "    Validade    : " -NoNewline -ForegroundColor Gray
    Write-Host "$valD" -ForegroundColor White
    Write-Host "    Repositorio : " -NoNewline -ForegroundColor Gray
    Write-Host "$($certObj.StoreType)" -ForegroundColor Cyan
    Write-Host "    Conta/Alvo  : " -NoNewline -ForegroundColor Gray
    Write-Host "$($certObj.UserAccount)" -ForegroundColor Yellow
    Write-Host "    Thumbprint  : " -NoNewline -ForegroundColor Gray
    Write-Host "$($certObj.Thumbprint)" -ForegroundColor Cyan
    Write-Host "    Origem      : " -NoNewline -ForegroundColor Gray
    Write-Host "$($certObj.StorageSource)" -ForegroundColor Magenta
    Write-Host ""
    Write-Host "  ATENCAO: Esta acao ira remover permanentemente o certificado da maquina." -ForegroundColor Yellow
    Write-Host ""

    $confirm = Read-Host "Deseja realmente EXCLUIR este certificado? (S/N)"
    if ($confirm -match '^[sS]$') {
        Write-Host ""
        Write-Host "Removendo certificado digital..." -ForegroundColor Cyan
        $delOk = Remove-RemoteUserCertificate -computerName $compName -thumbprint $certObj.Thumbprint -userSid $certObj.UserSid -userAccount $certObj.UserAccount -storeType $certObj.StoreType

        if ($delOk) {
            Write-Host "Certificado digital REMOVIDO com sucesso!" -ForegroundColor Green
        } else {
            # Tenta remocao direta local
            try {
                if ($certObj.StoreType -like "LocalMachine*") {
                    Remove-Item -Path "Cert:\LocalMachine\My\$($certObj.Thumbprint)" -Force -ErrorAction SilentlyContinue
                    & certutil.exe -delstore My $certObj.Thumbprint > $null 2>&1
                } else {
                    Remove-Item -Path "Cert:\CurrentUser\My\$($certObj.Thumbprint)" -Force -ErrorAction SilentlyContinue
                    & certutil.exe -user -delstore My $certObj.Thumbprint > $null 2>&1
                }
                Write-Host "Certificado digital REMOVIDO com sucesso!" -ForegroundColor Green
                $delOk = $true
            } catch {
                Write-Host "Aviso: Nao foi possivel confirmar a exclusao do certificado." -ForegroundColor Yellow
            }
        }
        Start-Sleep -Seconds 2
    } else {
        Write-Host "Operacao de exclusao cancelada." -ForegroundColor Cyan
        Start-Sleep -Seconds 1
    }
    return $delOk
}

function Manage-CurrentProfileCertificates {
    # Alvo padrao: computador conectado se houver, ou maquina local
    $targetComp = if (![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) { $script:CONECTADO_COMP } else { $env:COMPUTERNAME }
    $isLocal = ($targetComp -ieq "localhost" -or $targetComp -ieq "127.0.0.1" -or $targetComp -ieq $env:COMPUTERNAME)
    $storeFilter = "ALL" # "ALL", "MACHINE", "USER"

    while ($true) {
        Clear-Host
        Write-Host "========================================================" -ForegroundColor DarkCyan
        Write-Host "   CERTIFICADOS DIGITAIS - MAQUINA E PERFIS DE USUARIO" -ForegroundColor Cyan
        Write-Host "   Opcoes da Internet > Conteudo > Certificados / certlm" -ForegroundColor DarkGray
        Write-Host "========================================================" -ForegroundColor DarkCyan

        Write-Host "  ● Computador       : " -NoNewline -ForegroundColor Gray
        if ($isLocal) {
            Write-Host "Maquina Local ($env:COMPUTERNAME)" -ForegroundColor Green
            Write-Host "  ● Perfil / Usuario : " -NoNewline -ForegroundColor Gray
            Write-Host "$env:USERDOMAIN\$env:USERNAME" -ForegroundColor Yellow
        } else {
            Write-Host "$targetComp " -NoNewline -ForegroundColor Green
            Write-Host "[Conectado]" -ForegroundColor DarkGreen

            $targetUserDisp = if (![string]::IsNullOrWhiteSpace($script:CONECTADO_USER) -and $script:CONECTADO_USER -ne "Nenhum usuario logado" -and $script:CONECTADO_USER -ne "Nao foi possivel consultar") {
                "$script:CONECTADO_USER (Logado)"
            } else {
                "Todos os Perfis da Maquina Remota"
            }
            Write-Host "  ● Alvo / Perfil    : " -NoNewline -ForegroundColor Gray
            Write-Host "$targetUserDisp" -ForegroundColor Yellow
        }

        $storeLabel = switch ($storeFilter) {
            "MACHINE" { "Somente Maquina (LocalMachine\My)" }
            "USER"    { "Somente Pessoal / Perfis (CurrentUser\My)" }
            default   { "Todos (Maquina LocalMachine + Pessoal CurrentUser)" }
        }
        Write-Host "  ● Repositorio      : " -NoNewline -ForegroundColor Gray
        Write-Host "$storeLabel" -ForegroundColor Cyan

        Write-Host "  ● Finalidade       : " -NoNewline -ForegroundColor Gray
        Write-Host "<Todos>" -ForegroundColor White

        Write-Host ""
        Write-Host "Carregando certificados da maquina '$targetComp' (WMI / Registro / Perfis)..." -ForegroundColor Gray

        # Captura erros antes que o Clear-Host apague a mensagem exibida no console.
        $certCallErrors = @()
        $errorCountBeforeCertCall = $Error.Count
        $certComputerName = $null
        if (!$isLocal) {
            $certComputerName = $targetComp
        }
        try {
            $certList = @(Get-CurrentUserProfileCertificates -computerName $certComputerName -storeFilter $storeFilter)
        } catch {
            $certCallErrors += $_
            $certList = @()
        }
        $newErrorCount = [Math]::Max(0, ($Error.Count - $errorCountBeforeCertCall))
        if ($newErrorCount -gt 0) {
            $certCallErrors += @($Error | Select-Object -First ([Math]::Min($newErrorCount, 5)))
        }

        Clear-Host
        Write-Host "========================================================" -ForegroundColor DarkCyan
        Write-Host "   CERTIFICADOS DIGITAIS - MAQUINA E PERFIS DE USUARIO" -ForegroundColor Cyan
        Write-Host "   Opcoes da Internet > Conteudo > Certificados / certlm" -ForegroundColor DarkGray
        Write-Host "========================================================" -ForegroundColor DarkCyan

        Write-Host "  ● Computador       : " -NoNewline -ForegroundColor Gray
        if ($isLocal) {
            Write-Host "Maquina Local ($env:COMPUTERNAME)" -ForegroundColor Green
            Write-Host "  ● Perfil / Usuario : " -NoNewline -ForegroundColor Gray
            Write-Host "$env:USERDOMAIN\$env:USERNAME" -ForegroundColor Yellow
        } else {
            Write-Host "$targetComp " -NoNewline -ForegroundColor Green
            Write-Host "[Conectado]" -ForegroundColor DarkGreen

            $targetUserDisp = if (![string]::IsNullOrWhiteSpace($script:CONECTADO_USER) -and $script:CONECTADO_USER -ne "Nenhum usuario logado" -and $script:CONECTADO_USER -ne "Nao foi possivel consultar") {
                "$script:CONECTADO_USER (Logado)"
            } else {
                "Todos os Perfis da Maquina Remota"
            }
            Write-Host "  ● Alvo / Perfil    : " -NoNewline -ForegroundColor Gray
            Write-Host "$targetUserDisp" -ForegroundColor Yellow
        }

        Write-Host "  ● Repositorio      : " -NoNewline -ForegroundColor Gray
        Write-Host "$storeLabel" -ForegroundColor Cyan

        Write-Host "  ● Finalidade       : " -NoNewline -ForegroundColor Gray
        Write-Host "<Todos>" -ForegroundColor White
        Write-Host ""

        if ($certList.Count -eq 0) {
            Write-Host "  (Nenhum certificado digital localizado no repositorio selecionado)" -ForegroundColor DarkGray
            Write-Host ""
            if (!$isLocal) {
                if (@($certCallErrors).Count -gt 0) {
                    Write-Host "  Erro capturado durante a consulta:" -ForegroundColor Red
                    foreach ($certErr in @($certCallErrors | Select-Object -First 3)) {
                        $errText = if ($certErr.Exception) { $certErr.Exception.Message } else { [string]$certErr }
                        Write-Host "  - $errText" -ForegroundColor Yellow
                    }
                    Write-Host ""
                }
                if (![string]::IsNullOrWhiteSpace($script:CERT_REMOTE_SESSION_STATUS)) {
                    Write-Host "  Diagnostico da sessao remota:" -ForegroundColor DarkCyan
                    Write-Host "  $script:CERT_REMOTE_SESSION_STATUS" -ForegroundColor Yellow
                    Write-Host ""
                }
                Write-Host "  Dicas de Diagnostico para a Maquina Remota '$targetComp':" -ForegroundColor Gray
                Write-Host "  - Pressione [T] para garantir a exibicao de TODOS os repositorios (Maquina + Pessoal)." -ForegroundColor Gray
                Write-Host "  - Pressione [M] para alternar e focar no repositorio da Maquina (LocalMachine\My)." -ForegroundColor Gray
                Write-Host "  - Pressione [C] para abrir o Console Oficial do Windows (certlm.msc /computer:$targetComp)." -ForegroundColor Yellow
                Write-Host "  - Se o certificado for Token USB / Smart Card (A3), certifique-se de que" -ForegroundColor Gray
                Write-Host "    o dispositivo fisico esta plugado no computador remoto." -ForegroundColor Gray
            } else {
                Write-Host "  Dica: Se o certificado estiver em um Token USB / Smart Card (A3)," -ForegroundColor Gray
                Write-Host "        conecte o dispositivo na maquina e pressione [A] para atualizar." -ForegroundColor Gray
            }
            Write-Host ""
            Write-Host "────────────────────────────────────────────────────────" -ForegroundColor DarkGray
            Write-Host "  ACOES:" -ForegroundColor DarkCyan
            Write-Host "   [T]  Exibir TODOS os certificados (Maquina + Pessoal)" -ForegroundColor White
            Write-Host "   [M]  Filtrar: Somente Certificados da MAQUINA (LocalMachine\My)" -ForegroundColor Green
            Write-Host "   [P]  Filtrar: Somente Certificados PESSOAIS (CurrentUser\My)" -ForegroundColor Cyan
            if (!$isLocal) {
                Write-Host "   [C]  Abrir Console de Certificados da Maquina Remota (certlm.msc)" -ForegroundColor Yellow
            }
            Write-Host "   [W]  Abrir janela grafica do Windows (Opcoes da Internet / Certificados)" -ForegroundColor Cyan
            Write-Host "   [A]  Atualizar busca de certificados" -ForegroundColor White
            if (!$isLocal) {
                Write-Host "   [L]  Alternar para perfil da Maquina Local" -ForegroundColor White
            } elseif (![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) {
                Write-Host "   [R]  Alternar para computador conectado ($script:CONECTADO_COMP)" -ForegroundColor White
            }
            Write-Host "   [0]  Voltar ao menu principal" -ForegroundColor Red
            Write-Host "────────────────────────────────────────────────────────" -ForegroundColor DarkGray
            Write-Host ""
            $act = Read-Host "Opcao"
            if ($act -ieq "T") {
                $storeFilter = "ALL"
                continue
            } elseif ($act -ieq "M") {
                $storeFilter = "MACHINE"
                continue
            } elseif ($act -ieq "P") {
                $storeFilter = "USER"
                continue
            } elseif ($act -ieq "C" -and !$isLocal) {
                Write-Host "Abrindo Console de Certificados do Computador Remoto ($targetComp)..." -ForegroundColor Cyan
                try {
                    Start-Process "certlm.msc" -ArgumentList "/computer:$targetComp"
                } catch {
                    try {
                        Start-Process "mmc.exe" -ArgumentList "certmgr.msc -computer:$targetComp"
                    } catch {
                        Write-Host "Nao foi possivel abrir o snap-in MMC remoto." -ForegroundColor Yellow
                    }
                }
                Start-Sleep -Seconds 2
                continue
            } elseif ($act -ieq "W") {
                Write-Host "Abrindo tela de Certificados / Opcoes da Internet do Windows..." -ForegroundColor Cyan
                try {
                    Start-Process "rundll32.exe" -ArgumentList "cryptext.dll,CryptExtOpenSTR My"
                    Start-Process "control.exe" -ArgumentList "inetcpl.cpl,,2"
                } catch {
                    Start-Process "certmgr.msc"
                }
                Start-Sleep -Seconds 2
                continue
            } elseif ($act -ieq "A") {
                continue
            } elseif ($act -ieq "L") {
                $targetComp = $env:COMPUTERNAME
                $isLocal = $true
                continue
            } elseif ($act -ieq "R" -and ![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) {
                $targetComp = $script:CONECTADO_COMP
                $isLocal = $false
                continue
            }
            return
        }

        Write-Host " CERTIFICADOS LOCALIZADOS NA MAQUINA ($($certList.Count)): " -ForegroundColor Yellow
        Write-Host ""

        $certMap = @{}
        for ($i = 0; $i -lt $certList.Count; $i++) {
            $c = $certList[$i]
            $idx = $i + 1
            $certMap[$idx] = $c

            $subName = Get-CertificateCleanName $c.Subject
            $issName = Get-CertificateCleanName $c.Issuer

            $valStr = ""
            $isExp = $false
            try {
                $dtAfter = [datetime]$c.NotAfter
                $dtBefore = [datetime]$c.NotBefore
                $valStr = "$($dtBefore.ToString('dd/MM/yyyy')) ate $($dtAfter.ToString('dd/MM/yyyy'))"
                if ($dtAfter -lt (Get-Date)) { $isExp = $true }
            } catch {
                $valStr = "$($c.NotBefore) ate $($c.NotAfter)"
                if ($c.IsExpired -eq $true) { $isExp = $true }
            }

            $statusTag = if ($isExp) { " [EXPIRADO]" } else { " [VALIDO]" }
            $statusColor = if ($isExp) { "Red" } else { "Green" }
            $keyColor = if ($c.HasPrivateKey) { "Green" } else { "DarkGray" }
            $hasKeyStr = if ($c.HasPrivateKey) { "Sim" } else { "Nao" }

            $isMach = ($c.StoreType -like "LocalMachine*")
            $typeTag = if ($isMach) { "[MAQUINA]" } else { "[PESSOAL]" }
            $typeColor = if ($isMach) { "Green" } else { "Cyan" }

            Write-Host "   [$idx] " -NoNewline -ForegroundColor Cyan
            Write-Host "$subName" -NoNewline -ForegroundColor White
            Write-Host $statusTag -NoNewline -ForegroundColor $statusColor
            Write-Host " $typeTag" -NoNewline -ForegroundColor $typeColor
            if ($c.IsSigad -eq $true) {
                Write-Host " [SIGAD / ICP-BRASIL]" -ForegroundColor Yellow
            } else {
                Write-Host ""
            }

            Write-Host "        Emitido Para : " -NoNewline -ForegroundColor Gray
            Write-Host "$subName" -ForegroundColor White

            Write-Host "        Emitido Por  : " -NoNewline -ForegroundColor Gray
            Write-Host "$issName" -ForegroundColor DarkCyan

            Write-Host "        Validade     : " -NoNewline -ForegroundColor Gray
            Write-Host "$valStr" -NoNewline -ForegroundColor White
            if ($isExp) {
                Write-Host " (Vencido)" -ForegroundColor Red
            } else {
                Write-Host ""
            }

            Write-Host "        Repositorio  : " -NoNewline -ForegroundColor Gray
            Write-Host "$($c.StoreType)" -NoNewline -ForegroundColor $typeColor
            Write-Host "   |   Conta/Alvo: " -NoNewline -ForegroundColor Gray
            Write-Host "$($c.UserAccount)" -ForegroundColor Yellow

            Write-Host "        Chave Privada: " -NoNewline -ForegroundColor Gray
            Write-Host "$hasKeyStr" -NoNewline -ForegroundColor $keyColor
            Write-Host "   |   Thumbprint: " -NoNewline -ForegroundColor Gray
            Write-Host "$($c.Thumbprint)" -ForegroundColor DarkGray

            if (![string]::IsNullOrWhiteSpace($c.FriendlyName)) {
                Write-Host "        Nome Amigavel: " -NoNewline -ForegroundColor Gray
                Write-Host "$($c.FriendlyName)" -ForegroundColor DarkCyan
            }

            if (![string]::IsNullOrWhiteSpace($c.StorageSource)) {
                Write-Host "        Origem       : " -NoNewline -ForegroundColor Gray
                Write-Host "$($c.StorageSource)" -ForegroundColor Magenta
            }
            Write-Host ""
        }

        Write-Host "────────────────────────────────────────────────────────" -ForegroundColor DarkGray
        Write-Host "  ACOES DISPONIVEIS:" -ForegroundColor DarkCyan
        Write-Host "   [1-$($certList.Count)] Digite o numero para VER DETALHES COMPLETOS do certificado" -ForegroundColor White
        Write-Host "   [E]   Excluir / Remover um certificado da maquina" -ForegroundColor White
        Write-Host "   [T]   Exibir TODOS os certificados (Maquina + Pessoal)" -ForegroundColor White
        Write-Host "   [M]   Filtrar: Somente Certificados da MAQUINA (LocalMachine\My)" -ForegroundColor Green
        Write-Host "   [P]   Filtrar: Somente Certificados PESSOAIS (CurrentUser\My)" -ForegroundColor Cyan
        if (!$isLocal) {
            Write-Host "   [C]   Abrir Console Oficial do Windows (certlm.msc /computer:$targetComp)" -ForegroundColor Yellow
        }
        Write-Host "   [W]   Abrir janela grafica do Windows (Opcoes da Internet / Certificados)" -ForegroundColor Cyan
        Write-Host "   [A]   Atualizar lista de certificados" -ForegroundColor White
        if (!$isLocal) {
            Write-Host "   [L]   Alternar para perfil da Maquina Local" -ForegroundColor White
        } elseif (![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) {
            Write-Host "   [R]   Alternar para computador conectado ($script:CONECTADO_COMP)" -ForegroundColor White
        }
        Write-Host "   [0]   Voltar ao menu principal" -ForegroundColor Red
        Write-Host "────────────────────────────────────────────────────────" -ForegroundColor DarkGray
        Write-Host ""

        $choice = Read-Host "Digite sua escolha"
        if ($choice -eq "0" -or [string]::IsNullOrWhiteSpace($choice)) {
            return
        } elseif ($choice -ieq "T") {
            $storeFilter = "ALL"
            continue
        } elseif ($choice -ieq "M") {
            $storeFilter = "MACHINE"
            continue
        } elseif ($choice -ieq "P") {
            $storeFilter = "USER"
            continue
        } elseif ($choice -ieq "C" -and !$isLocal) {
            Write-Host "Abrindo Console de Certificados do Computador Remoto ($targetComp)..." -ForegroundColor Cyan
            try {
                Start-Process "certlm.msc" -ArgumentList "/computer:$targetComp"
            } catch {
                try {
                    Start-Process "mmc.exe" -ArgumentList "certmgr.msc -computer:$targetComp"
                } catch {
                    Write-Host "Nao foi possivel abrir o snap-in MMC remoto." -ForegroundColor Yellow
                }
            }
            Start-Sleep -Seconds 2
            continue
        } elseif ($choice -ieq "A") {
            continue
        } elseif ($choice -ieq "L") {
            $targetComp = $env:COMPUTERNAME
            $isLocal = $true
            continue
        } elseif ($choice -ieq "R" -and ![string]::IsNullOrWhiteSpace($script:CONECTADO_COMP)) {
            $targetComp = $script:CONECTADO_COMP
            $isLocal = $false
            continue
        } elseif ($choice -ieq "W") {
            Write-Host "Abrindo tela de Certificados / Opcoes da Internet do Windows..." -ForegroundColor Cyan
            try {
                Start-Process "rundll32.exe" -ArgumentList "cryptext.dll,CryptExtOpenSTR My"
                Start-Process "control.exe" -ArgumentList "inetcpl.cpl,,2"
            } catch {
                Start-Process "certmgr.msc"
            }
            Start-Sleep -Seconds 2
            continue
        } elseif ($choice -ieq "E") {
            $delNum = Read-Host "Digite o numero do certificado que deseja EXCLUIR [1-$($certList.Count)]"
            if ([int]::TryParse($delNum, [ref]$null)) {
                $dIdx = [int]$delNum
                if ($certMap.ContainsKey($dIdx)) {
                    $cToDel = $certMap[$dIdx]
                    $certRemovalComputer = if ($isLocal) { $env:COMPUTERNAME } else { $targetComp }
                    Confirm-And-Remove-Certificate -certObj $cToDel -compName $certRemovalComputer
                } else {
                    Write-Host "Numero de certificado invalido." -ForegroundColor Red
                    Start-Sleep -Seconds 1
                }
            }
        } elseif ([int]::TryParse($choice, [ref]$null)) {
            $selIdx = [int]$choice
            if ($certMap.ContainsKey($selIdx)) {
                $sc = $certMap[$selIdx]
                Clear-Host
                Write-Host "========================================================" -ForegroundColor DarkCyan
                Write-Host "   DETALHES COMPLETOS DO CERTIFICADO [$selIdx]" -ForegroundColor Cyan
                Write-Host "========================================================" -ForegroundColor DarkCyan
                Write-Host ""
                Write-Host " Emitido Para (Subject) : $($sc.Subject)" -ForegroundColor White
                Write-Host " Emitido Por (Issuer)   : $($sc.Issuer)" -ForegroundColor Yellow
                Write-Host " Valido a partir de     : $($sc.NotBefore)" -ForegroundColor White
                Write-Host " Valido ate             : $($sc.NotAfter)" -ForegroundColor White
                Write-Host " Status de Validade     : $(if ($sc.IsExpired) { 'EXPIRADO' } else { 'VALIDO' })" -ForegroundColor $(if ($sc.IsExpired) { 'Red' } else { 'Green' })
                Write-Host " Repositorio            : $($sc.StoreType)" -ForegroundColor Cyan
                Write-Host " Chave Privada Presente : $(if ($sc.HasPrivateKey) { 'Sim (Disponivel)' } else { 'Nao' })" -ForegroundColor $(if ($sc.HasPrivateKey) { 'Green' } else { 'DarkGray' })
                Write-Host " Numero de Serie        : $($sc.SerialNumber)" -ForegroundColor White
                Write-Host " Thumbprint (SHA1)      : $($sc.Thumbprint)" -ForegroundColor Cyan
                Write-Host " Nome Amigavel          : $($sc.FriendlyName)" -ForegroundColor DarkCyan
                Write-Host " Conta / Perfil Alvo    : $($sc.UserAccount)" -ForegroundColor Yellow
                Write-Host " Origem da Leitura      : $($sc.StorageSource)" -ForegroundColor Gray
                Write-Host " Tipo ICP / SIGAD       : $(if ($sc.IsSigad) { 'SIM (Certificado Digital ICP-Brasil)' } else { 'Certificado de Maquina / Outro' })" -ForegroundColor $(if ($sc.IsSigad) { 'Green' } else { 'Gray' })
                Write-Host ""
                Write-Host "========================================================" -ForegroundColor DarkCyan
                Write-Host "  [1] Excluir este certificado digital da maquina" -ForegroundColor Red
                Write-Host "  [W] Abrir janela grafica do Windows" -ForegroundColor Cyan
                Write-Host "  [0] Voltar a lista" -ForegroundColor White
                Write-Host "========================================================" -ForegroundColor DarkCyan
                Write-Host ""
                $subAct = Read-Host "Opcao"
                if ($subAct -eq "1") {
                    $certRemovalComputer = if ($isLocal) { $env:COMPUTERNAME } else { $targetComp }
                    Confirm-And-Remove-Certificate -certObj $sc -compName $certRemovalComputer
                } elseif ($subAct -ieq "W") {
                    try {
                        Start-Process "rundll32.exe" -ArgumentList "cryptext.dll,CryptExtOpenSTR My"
                        Start-Process "control.exe" -ArgumentList "inetcpl.cpl,,2"
                    } catch {
                        Start-Process "certmgr.msc"
                    }
                    Start-Sleep -Seconds 2
                }
            } else {
                Write-Host "Numero de certificado invalido." -ForegroundColor Red
                Start-Sleep -Seconds 1
            }
        }
    }
}

function Manage-RemoteCertificates {
    Manage-CurrentProfileCertificates
}

