﻿# Diagnóstico transitório da sessão interativa. Executado pelo bridge.ps1.
function Get-AtlasInteractiveAccount {
    $logged = [string](Get-WmiObject Win32_ComputerSystem -ComputerName $Computer -ErrorAction Stop).UserName
    if ([string]::IsNullOrWhiteSpace($logged)) { throw 'Nenhum usuário conectado foi identificado na estação.' }
    return $logged
}

function Get-AtlasUserProcesses {
    $logged = Get-AtlasInteractiveAccount
    $items = @()
    foreach ($process in @(Get-WmiObject Win32_Process -ComputerName $Computer -ErrorAction Stop)) {
        if ([int]$process.SessionId -eq 0) { continue }
        try {
            $owner = $process.GetOwner()
            if ([int]$owner.ReturnValue -ne 0) { continue }
            $account = "$($owner.Domain)\$($owner.User)"
            if ($account -ine $logged) { continue }
            $items += [PSCustomObject]@{
                pid = [int]$process.ProcessId
                name = [string]$process.Name
                memory_mb = [math]::Round(([double]$process.WorkingSetSize / 1MB), 1)
            }
        } catch { continue }
    }
    $ordered = @($items | Sort-Object name, pid)
    Write-Output ('@@REMOTE_PROCESSES@@' + (@{ user=$logged; items=$ordered } | ConvertTo-Json -Depth 5 -Compress))
}

function Stop-AtlasUserProcess {
    try { $request = $Value | ConvertFrom-Json -ErrorAction Stop }
    catch { throw 'A seleção do processo é inválida.' }
    $logged = Get-AtlasInteractiveAccount
    if ($logged -ine [string]$request.user) { throw 'O usuário conectado mudou. Atualize a consulta de processos.' }
    $pidNumber = 0
    if (![int]::TryParse([string]$request.pid, [ref]$pidNumber) -or $pidNumber -le 0) { throw 'PID inválido.' }
    $process = Get-WmiObject Win32_Process -ComputerName $Computer -Filter "ProcessId=$pidNumber" -ErrorAction Stop
    if (!$process -or [string]$process.Name -ine [string]$request.name -or [int]$process.SessionId -eq 0) {
        throw 'O processo mudou ou já foi encerrado. Atualize a consulta.'
    }
    $owner = $process.GetOwner()
    if ([int]$owner.ReturnValue -ne 0 -or "$($owner.Domain)\$($owner.User)" -ine $logged) {
        throw 'O processo não pertence ao usuário conectado.'
    }
    $result = $process.Terminate()
    if ([int]$result.ReturnValue -ne 0) { throw "A estação recusou o encerramento (código $($result.ReturnValue))." }
    Write-Output ('@@REMOTE_PROCESS_END@@' + (@{ pid=$pidNumber; name=[string]$process.Name; confirmed=$true } | ConvertTo-Json -Compress))
}

function Stop-AtlasUserProcessGroup {
    try { $request = $Value | ConvertFrom-Json -ErrorAction Stop }
    catch { throw 'A seleção do software é inválida.' }
    $logged = Get-AtlasInteractiveAccount
    if ($logged -ine [string]$request.user) { throw 'O usuário conectado mudou. Atualize os processos.' }
    $name = [string]$request.name
    $pids = @($request.pids | ForEach-Object {
        $number = 0
        if (![int]::TryParse([string]$_, [ref]$number) -or $number -le 0) { throw 'PID inválido na seleção.' }
        $number
    } | Sort-Object -Unique)
    if ([string]::IsNullOrWhiteSpace($name) -or !$pids.Count -or $pids.Count -gt 256) {
        throw 'Seleção de processos inválida. Atualize a consulta.'
    }
    # Verifica cada PID, nome e proprietário antes de encerrar qualquer um.
    # Novos processos com o mesmo nome não entram nesta seleção.
    $verified = @()
    foreach ($pidNumber in $pids) {
        $process = Get-WmiObject Win32_Process -ComputerName $Computer -Filter "ProcessId=$pidNumber" -ErrorAction Stop
        if (!$process -or [string]$process.Name -ine $name -or [int]$process.SessionId -eq 0) {
            throw 'A lista de processos mudou. Atualize a consulta antes de encerrar o software.'
        }
        $owner = $process.GetOwner()
        if ([int]$owner.ReturnValue -ne 0 -or "$($owner.Domain)\$($owner.User)" -ine $logged) {
            throw 'Um processo selecionado não pertence ao usuário conectado.'
        }
        $verified += $process
    }
    $ended = 0
    $failed = @()
    foreach ($process in $verified) {
        try {
            $result = $process.Terminate()
            if ([int]$result.ReturnValue -eq 0) { $ended++ }
            else { $failed += [int]$process.ProcessId }
        } catch { $failed += [int]$process.ProcessId }
    }
    Write-Output ('@@REMOTE_PROCESS_END@@' + (@{
        name=$name; count=$pids.Count; ended=$ended; failed=$failed;
        confirmed=($failed.Count -eq 0)
    } | ConvertTo-Json -Depth 4 -Compress))
}

function Get-AtlasUserSoftware {
    $logged = Get-AtlasInteractiveAccount
    try { $sid = (New-Object Security.Principal.NTAccount($logged)).Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { throw 'Não foi possível identificar o SID do perfil conectado.' }
    $registry = [WMICLASS]"\\$Computer\root\default:StdRegProv"
    $locations = @(
        @{ hive=[uint32]2147483651; path="$sid\Software\Microsoft\Windows\CurrentVersion\Uninstall"; scope='Perfil do usuário' },
        @{ hive=[uint32]2147483650; path='SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'; scope='Estação (64 bits)' },
        @{ hive=[uint32]2147483650; path='SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'; scope='Estação (32 bits)' }
    )
    $items = @()
    $seen = @{}
    foreach ($location in $locations) {
        $keys = $registry.EnumKey($location.hive, $location.path)
        foreach ($key in @($keys.sNames)) {
            if ([string]::IsNullOrWhiteSpace([string]$key)) { continue }
            $path = "$($location.path)\$key"
            $name = [string]$registry.GetStringValue($location.hive, $path, 'DisplayName').sValue
            if ([string]::IsNullOrWhiteSpace($name)) { continue }
            $version = [string]$registry.GetStringValue($location.hive, $path, 'DisplayVersion').sValue
            $identity = "$($location.scope)|$name|$version".ToLowerInvariant()
            if ($seen.ContainsKey($identity)) { continue }
            $seen[$identity] = $true
            $items += [PSCustomObject]@{ name=$name.Trim(); version=$version; scope=$location.scope }
        }
    }
    $ordered = @($items | Sort-Object scope, name)
    Write-Output ('@@USER_SOFTWARE@@' + (@{ user=$logged; items=$ordered } | ConvertTo-Json -Depth 5 -Compress))
}
