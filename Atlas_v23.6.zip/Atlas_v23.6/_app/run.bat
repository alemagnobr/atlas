@echo off
if /I not "%~1"=="--minimized" (
  start "" /min "%ComSpec%" /d /c call "%~f0" --minimized
  exit /b 0
)
setlocal
title Atlas - Suporte Avancado 23.6 - Inicializacao

rem Alguns terminais modernos ignoram o /min do comando START. Forca a
rem minimizacao da propria janela sem ocultar mensagens de diagnostico.
powershell.exe -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -Command ^
  "$q=[char]34;$src='[DllImport('+$q+'kernel32.dll'+$q+')]public static extern IntPtr GetConsoleWindow();[DllImport('+$q+'user32.dll'+$q+')]public static extern bool ShowWindow(IntPtr h,int n);'; Add-Type -MemberDefinition $src -Name ConsoleWindow -Namespace GSS; [GSS.ConsoleWindow]::ShowWindow([GSS.ConsoleWindow]::GetConsoleWindow(),6) ^| Out-Null" >nul 2>&1

rem O OneDrive e algumas politicas corporativas podem impedir que o Python
rem leia scripts diretamente da pasta Downloads. Por isso, o aplicativo e
rem preparado em uma pasta local confiavel antes da execucao.
pushd "%~dp0" >nul 2>&1
if errorlevel 1 goto SOURCE_ERROR
set "SOURCE_DIR=%CD%"
popd
set "APP_DIR=%LOCALAPPDATA%\AtlasSuporteAvancado\v23.6"
set "COPY_LOG=%TEMP%\AtlasSuporteAvancado_copia.log"

if not exist "%SOURCE_DIR%\main.py" (
  echo ============================================================
  echo O arquivo main.py nao foi encontrado ao lado do run.bat.
  echo Extraia todo o ZIP antes de iniciar o programa.
  echo ============================================================
  pause
  exit /b 1
)

if not exist "%APP_DIR%" mkdir "%APP_DIR%" >nul 2>&1

rem Copia apenas os componentes de execucao. Testes, documentacao e ferramentas
rem de empacotamento permanecem no pacote-fonte, mas nao atrasam a abertura.
robocopy "%SOURCE_DIR%" "%APP_DIR%" /E /R:2 /W:1 /COPY:DAT /DCOPY:DAT ^
  /XD "__pycache__" "tests" "docs" "tools" "installer" "build" "dist" "release" ^
  /XF "erro_inicializacao.txt" "*.md" /LOG:"%COPY_LOG%" >nul 2>&1
call :VALIDATE_COPY
if not errorlevel 1 goto PREPARED

rem Segunda tentativa: copia seletiva para ambientes que restringem robocopy.
copy /Y "%SOURCE_DIR%\main.py" "%APP_DIR%\main.py" >"%COPY_LOG%" 2>&1
copy /Y "%SOURCE_DIR%\fallback.py" "%APP_DIR%\fallback.py" >>"%COPY_LOG%" 2>&1
copy /Y "%SOURCE_DIR%\run.bat" "%APP_DIR%\run.bat" >>"%COPY_LOG%" 2>&1
copy /Y "%SOURCE_DIR%\requirements.txt" "%APP_DIR%\requirements.txt" >>"%COPY_LOG%" 2>&1
for %%D in (assets commands core data scripts services storage ui) do (
  if exist "%SOURCE_DIR%\%%D" xcopy "%SOURCE_DIR%\%%D\*" "%APP_DIR%\%%D\" /E /I /H /Y /R >>"%COPY_LOG%" 2>&1
)
call :VALIDATE_COPY
if not errorlevel 1 goto PREPARED

echo ============================================================
echo O Windows nao permitiu preparar todos os arquivos do aplicativo.
echo.
echo Tente mover a pasta Atlas_Suporte_Avancado para:
echo C:\Atlas_Suporte_Avancado
echo e execute o run.bat novamente.
echo.
echo Log da tentativa: %COPY_LOG%
echo ============================================================
if exist "%COPY_LOG%" type "%COPY_LOG%"
pause
exit /b 1

:PREPARED

cd /d "%APP_DIR%"

set "PYTHON_CMD="
where py >nul 2>&1 && set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD where python >nul 2>&1 && set "PYTHON_CMD=python"

if not defined PYTHON_CMD (
  echo ============================================================
  echo Python nao foi encontrado neste computador.
  echo Instale o Python 3.11 ou superior e marque Add Python to PATH.
  echo ============================================================
  pause
  exit /b 1
)

%PYTHON_CMD% -c "import PySide6" >nul 2>&1
if errorlevel 1 (
  echo Preparando a interface grafica profissional. Aguarde...
  %PYTHON_CMD% -m pip install --disable-pip-version-check -r requirements.txt
  %PYTHON_CMD% -c "import PySide6" >nul 2>&1
  if errorlevel 1 goto COMPATIVEL
)

%PYTHON_CMD% "%APP_DIR%\main.py" 2>"%APP_DIR%\erro_inicializacao.txt"
if errorlevel 1 goto ERRO
exit /b 0

:COMPATIVEL
echo PySide6 nao esta disponivel. Abrindo o modo compativel...
%PYTHON_CMD% "%APP_DIR%\fallback.py" 2>"%APP_DIR%\erro_inicializacao.txt"
if errorlevel 1 goto ERRO
exit /b 0

:ERRO
echo.
echo Nao foi possivel iniciar o programa.
echo O diagnostico foi salvo em:
echo %APP_DIR%\erro_inicializacao.txt
echo.
type "%APP_DIR%\erro_inicializacao.txt"
pause
exit /b 1

:VALIDATE_COPY
if not exist "%APP_DIR%\main.py" exit /b 1
if not exist "%APP_DIR%\fallback.py" exit /b 1
if not exist "%APP_DIR%\requirements.txt" exit /b 1
if not exist "%APP_DIR%\assets\logo_full_light.png" exit /b 1
if not exist "%APP_DIR%\assets\logo_full_dark.png" exit /b 1
if not exist "%APP_DIR%\assets\logo_compact_light.png" exit /b 1
if not exist "%APP_DIR%\assets\logo_compact_dark.png" exit /b 1
if not exist "%APP_DIR%\assets\app_icon.ico" exit /b 1
if not exist "%APP_DIR%\scripts\bridge.ps1" exit /b 1
if not exist "%APP_DIR%\scripts\bridge_launcher.ps1" exit /b 1
if not exist "%APP_DIR%\scripts\remote_message.ps1" exit /b 1
if not exist "%APP_DIR%\scripts\remote_inventory.ps1" exit /b 1
exit /b 0

:SOURCE_ERROR
echo ============================================================
echo Nao foi possivel acessar a pasta onde o run.bat esta localizado.
echo Extraia o ZIP para C:\Atlas_Suporte_Avancado e tente novamente.
echo ============================================================
pause
exit /b 1
