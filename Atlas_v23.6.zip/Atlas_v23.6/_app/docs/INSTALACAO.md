# Instalação e preparação do ambiente

## Para o usuário final

1. Instale o Python 3.11 ou superior pelo site oficial ou pela central corporativa.
2. Durante a instalação, marque **Add Python to PATH**.
3. Extraia todo o ZIP para uma pasta local, preferencialmente `C:\Atlas_Suporte_Avancado`.
4. Execute `run.bat`.

O inicializador procura `py -3` e depois `python`. Se PySide6 não estiver instalado, executa:

```powershell
python -m pip install -r requirements.txt
```

Se a instalação gráfica falhar, `fallback.py` abre o modo compatível.

## Para desenvolvimento no VS Code

Instale:

- Visual Studio Code;
- extensão oficial **Python**, da Microsoft;
- Git for Windows;
- Python 3.11 ou superior.

Abra a pasta do projeto e, no terminal do VS Code, execute:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Se o PowerShell impedir a ativação somente naquela janela:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Selecione o interpretador com `Ctrl+Shift+P`, **Python: Select Interpreter**, `.venv`.

## Dependências de infraestrutura

Conforme a rotina utilizada, podem ser necessários:

- resolução DNS e ping até a estação;
- WMI/DCOM permitido pelo firewall;
- compartilhamentos administrativos `C$` e `D$`;
- serviço de Agendador de Tarefas;
- acesso ao Active Directory;
- permissões no servidor de impressão;
- CmRcViewer instalado localmente.

Não habilite serviços ou regras de firewall sem aprovação da equipe responsável.
