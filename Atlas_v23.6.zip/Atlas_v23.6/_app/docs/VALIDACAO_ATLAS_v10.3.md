# Validação — Atlas 10.3

1. Entre em **Chamados** e aguarde a montagem inicial de **Todos**.
2. Digite no campo e clique em **Pesquisar**; confira a barra e os resultados do texto.
3. Escolha **Fechados com êxito** sem clicar em nada e confirme que os resultados ainda não mudam.
4. Clique no novo botão **Filtrar**, ao lado do seletor, e confira a barra e os chamados fechados.
5. Altere novamente o texto e pressione Enter; confirme que a pesquisa muda sem aplicar uma situação ainda não confirmada.
6. Altere somente a situação e clique em **Filtrar**; confirme que o texto anteriormente pesquisado é preservado.
7. Durante qualquer montagem, confira que campo, seletor, **Pesquisar** e **Filtrar** ficam bloqueados.
8. Teste **Todos** e **Fechados com êxito** nos modos claro, escuro, janela completa e modo lateral.
9. Confirme que nenhuma pesquisa local consulta o Capri e que as correções anteriores continuam funcionando.
