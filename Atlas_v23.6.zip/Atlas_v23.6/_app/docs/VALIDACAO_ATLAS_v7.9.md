# Validação — Atlas v7.9

## Escopo

- Barra de progresso animada durante a consulta da estação, mantendo a mensagem dentro do componente.
- Bloqueio Windows + L direto e sem confirmação.
- Orientação livre acessível pelo campo Usuário, com identificação e assinatura automáticas.

## Segurança funcional

A orientação livre utiliza a mesma ação remota das orientações vinculadas às FAQs. Não cria uma segunda forma de execução na estação.
