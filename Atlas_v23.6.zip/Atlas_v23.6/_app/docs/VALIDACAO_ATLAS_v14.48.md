# Validação ATLAS v14.48

## Cobertura desta versão

- Tema escuro uniforme no popup de chamados recentes, incluindo os cartões, área de rolagem e seletor de situação.
- Progresso e porcentagem exibidos somente durante a consulta; ao concluir, o indicador some sem permanecer em 100%.
- Atualização manual dos chamados recentes a partir do card ou do popup, com ícone de atualização girando durante a busca.
- Cópia do login de rede sem prefixo de domínio.
- Metadados e instalador atualizados para 14.48.

## Execução local

```text
python -m unittest discover -s tests -v
python -m compileall -q main.py services tests
```

A conferência visual e a consulta real ao Capri precisam ser verificadas em Windows com a sessão institucional ativa.
