# Validação — Atlas v7.0

## Escopo

- Base unificada entre FAQs e orientações ao usuário.
- Cache persistente independente para os dois catálogos.
- Classificação de caminho, contato e instruções seguras ao usuário.
- Atualização direta de uma FAQ no Capri sem novo rastreamento completo.
- Reindexação local e imediata depois de cada atualização.

## Fluxos recomendados

1. Mapear as FAQs e confirmar a geração automática das orientações.
2. Reiniciar o Atlas e validar que ambos os catálogos continuam disponíveis sem nova coleta.
3. Atualizar uma FAQ específica pelos dois campos e confirmar que somente ela foi substituída.
4. Pesquisar palavras do conteúdo atualizado em FAQs e orientações.
5. Confirmar que nenhuma janela de sugestão aparece durante a digitação.
6. Enviar uma orientação e validar que somente conteúdo permitido ao usuário é exibido.
