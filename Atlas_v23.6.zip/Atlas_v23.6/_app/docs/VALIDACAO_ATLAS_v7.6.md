# Validação — Atlas v7.6

- No modo lateral, os cartões de ações devem permanecer organizados em duas colunas.
- Cada cartão compacto deve exibir ícone, título e seta na parte superior.
- A descrição deve aparecer abaixo e utilizar a largura integral do cartão.
- Títulos como **Reiniciar computador** podem ocupar duas linhas sem comprimir a descrição lateralmente.
- Ícones compactos devem usar 36 px e os controles de ação 28 px.
- Os cartões da mesma linha devem permanecer visualmente alinhados.
- Ao retornar ao modo normal, o cartão deve recuperar o layout horizontal, ícone de 46 px e controle de 30 px.
- As ações, confirmações e indicadores de carregamento devem preservar o comportamento da v7.5.
