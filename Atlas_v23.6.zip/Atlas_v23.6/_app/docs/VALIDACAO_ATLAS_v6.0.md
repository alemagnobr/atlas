# Validação — Atlas v6.0

## Sintoma corrigido

> ERRO: O sistema não pode encontrar o arquivo especificado.

## Diagnóstico

O texto poderia ser emitido pelo `schtasks` ao tentar encerrar uma tarefa visual anterior que já não existia. Como a saída era herdada pelo processo principal, o erro genérico mascarava a etapa que realmente falhou.

## Correções

- Rotina `Remove-RemoteScheduledTaskQuiet` executa encerramento e exclusão sem herdar saída externa.
- A ausência de uma tarefa anterior deixa de ser considerada falha.
- Caminhos de `powershell.exe` e `msg.exe` são absolutos e derivados de `WindowsDirectory`.
- O script visual possui `try/catch` próprio.
- Falhas WPF são gravadas em marcador UTF-8 separado.
- O operador recebe diagnóstico da construção da janela, não apenas o retorno genérico da tarefa.

## Preservado

- Trellix permanece ativo.
- Popup continua aberto até **Entendi**.
- Aviso nativo continua disponível como fallback.
- Catálogo com 103 orientações permanece inalterado.
