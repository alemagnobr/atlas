# Validação — Atlas v6.7

## Conteúdo apresentado ao usuário remoto

- Saudação personalizada com o primeiro e o último nome do usuário remoto.
- Orientação resumida, caminho da Intranet e/ou contato responsável.
- Alerta fixo: o chamado deve ser aberto pelo chefe do setor.
- Agradecimento pelo contato com o Prodasen.
- Assinatura com o primeiro e o último nome do atendente autenticado no Atlas.

## Informações restritas à interface do atendente

- Número da FAQ.
- Referência ao Capri.
- Observações internas.
- Instruções técnicas de instalação, correção ou diagnóstico.

## Destaques

Na janela visual, título, alerta, rótulos e assinatura utilizam peso reforçado. Na rota CMD autorizada, que não oferece formatação tipográfica por trecho de forma portável, os destaques são apresentados em seções, caixa alta e espaçamento próprio.

## Verificações

- Payload remoto sem `faq_number` e `important_note`.
- Ausência de “Referência: FAQ” no bridge de orientação.
- Nome do atendente obtido pelo mesmo resolvedor AD da saudação principal do Atlas.
- Catálogo regenerado com textos voltados ao usuário final.
- Suíte de contratos e integridade do pacote.
