# Validação — Atlas 9.5

1. Inicie o Atlas diretamente no modo escuro.
2. Abra **Chamados** e selecione **Todos** com o catálogo completo de 594 itens.
3. Confirme que os cartões exibem número, situação, usuário, título, detalhes, etapa e botão já na primeira renderização.
4. Passe o mouse sobre vários cartões e confirme que nenhuma informação desaparece.
5. Alterne entre **Todos**, **Abertos**, **Pendentes** e **Fechados com êxito**.
6. Confirme que os resultados e contagens não mudaram em relação à v9.3.
7. Alterne os temas e confirme que os ícones mudam de cor sem comprimir os cartões.
