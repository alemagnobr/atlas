# Validação ATLAS v14.42

## Escopo

- corrigir o falso alerta de falha após um envio efetivamente aceito;
- preservar confirmação, endereço mascarado, bloqueio de repetição e ausência de dados sensíveis nos logs;
- distinguir confirmação textual, aceitação sem texto e falha explícita.

## Critérios

- HTTP entre 200 e 399, sem erro explícito: `sent=true`;
- mensagem de envio ou sucesso encontrada: `confirmed=true`;
- resposta aceita sem a mensagem esperada: `confirmed=false`;
- usuário não localizado, dados inválidos, recusa, bloqueio ou limite excedido: falha controlada;
- nenhuma resposta ambígua provoca uma segunda tentativa automática;
- o popup final reutiliza somente o endereço mascarado obtido na prévia.

## E-mail pessoal

O formulário público de recuperação permite conhecer o destino mascarado sem autenticação na área privada do PWM. O endereço completo só pode ser obtido fora do PWM se estiver publicado pelo Senado em um atributo autorizado do Active Directory, como `otherMailbox` ou outro atributo institucionalmente definido. A v14.42 não tenta adivinhar o endereço completo nem varrer atributos genéricos.

## Resultado automatizado

- 264 testes aprovados;
- 24 verificações estruturais aprovadas;
- sintaxe Python compilada;
- metadados 14.42 consistentes no aplicativo, runtime e instalador.
