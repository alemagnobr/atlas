# Validação ATLAS v14.44

## Escopo

- alternar a ação de consulta para **Nova consulta** após um retorno válido;
- permitir a abertura direta das informações complementares do AD pelo login consultado;
- incluir cópia rápida do login de rede;
- compactar os cards de usuário e estação;
- equilibrar **Micro** e **Usuário** no resumo da estação e remover dali o login redundante.

## Comportamentos protegidos

- **Nova consulta** usa o estilo vermelho, limpa o resultado e restaura o estado verde de consulta;
- uma edição manual de login também prepara imediatamente uma nova consulta;
- o atalho do AD aceita tanto o usuário da estação quanto o login consultado diretamente;
- a consulta direta usa o login normalizado e possui limite de 45 segundos;
- o botão de cópia envia o valor no padrão `SENADO\login`;
- o login deixa de aparecer na estação e permanece no controle de usuários;
- ícone de recuperação, margens, espaçamentos e controles administrativos usam dimensões reduzidas.

## Resultado automatizado

- 278 testes aprovados;
- 24 verificações estruturais aprovadas;
- sintaxe Python compilada;
- metadados 14.44 consistentes no aplicativo, runtime e instalador.
