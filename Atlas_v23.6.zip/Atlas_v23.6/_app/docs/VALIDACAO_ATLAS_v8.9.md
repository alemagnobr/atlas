# Validação — Atlas 8.9

## Chamados do Capri

1. Entre no perfil INS e abra **Chamados**.
2. Clique em **Mapear meus chamados**.
3. Confira se o total salvo coincide com o total apresentado pelo Capri (por exemplo, 1.646 de 1.646).
4. Pesquise o nome completo do operador e confirme que chamados criados por terceiros não aparecem apenas por causa do filtro local.
5. Abra alguns cartões e confira separadamente proprietário, responsável e usuário cliente.

Se o Capri informar um total maior do que o recebido, o Atlas deve exibir erro de coleta incompleta e preservar o catálogo anterior.
