# Publicar no GitHub usando o Visual Studio Code

> Recomendação: crie o repositório como **Private**, pois o projeto contém rotinas administrativas e referências de infraestrutura corporativa.

## Publicação automática

Para este projeto, o caminho mais simples é executar `PUBLICAR_NO_GITHUB.bat`. O arquivo prepara o Git local, usa o e-mail privado da conta `joaocerq-me`, conecta o repositório e publica a branch `main`. O Git Credential Manager poderá abrir o navegador para confirmar o login; nenhuma senha ou token é gravado no projeto.

As etapas manuais abaixo permanecem documentadas para consulta e manutenção.

## 1. Instalar e configurar o Git

Instale o Git for Windows. Depois, no terminal do VS Code:

```powershell
git --version
git config --global user.name "Seu Nome"
git config --global user.email "seu-email@exemplo.com"
```

## 2. Abrir o projeto no VS Code

1. Extraia a pasta do projeto.
2. No VS Code, selecione **File > Open Folder**.
3. Escolha `Atlas_Suporte_Avancado`.
4. Abra **Terminal > New Terminal**.

Confirme que o terminal está na pasta que contém `README.md`:

```powershell
Get-Location
Get-ChildItem README.md
```

## 3. Inicializar o repositório local

```powershell
git init
git branch -M main
git status
```

Revise o que será enviado:

```powershell
git add .
git status
git diff --cached
```

Se aparecer log, ZIP, executável, credencial ou dado sensível, execute `git restore --staged CAMINHO` e ajuste `.gitignore`.

## 4. Criar o primeiro commit

```powershell
git commit -m "feat: publica versão inicial do gerenciador de suporte"
```

## 5. Criar o repositório no GitHub

1. Acesse [github.com/new](https://github.com/new).
2. Informe um nome, por exemplo `gerenciador-suporte-senado`.
3. Selecione **Private**.
4. Não marque README, `.gitignore` ou licença, pois já existem arquivos locais.
5. Clique em **Create repository**.

## 6. Conectar e publicar

Copie a URL HTTPS apresentada pelo GitHub e execute:

```powershell
git remote add origin https://github.com/SEU-USUARIO/gerenciador-suporte-senado.git
git push -u origin main
```

O navegador pode abrir para autenticação. Não coloque senha ou token diretamente no código.

## 7. Publicações futuras

```powershell
git status
git add .
git commit -m "fix: descreva resumidamente a correção"
git push
```

## 8. Criar uma versão no GitHub

Depois de validar a aplicação:

```powershell
git tag -a v7.6 -m "Atlas — Suporte Avançado v7.6"
git push origin v7.6
```

No GitHub, abra **Releases > Draft a new release**, selecione `v7.6`, descreva as alterações e anexe o ZIP validado somente se a política interna permitir.

## Alternativa pela interface do VS Code

1. Abra **Source Control** com `Ctrl+Shift+G`.
2. Clique em **Initialize Repository**.
3. Revise os arquivos e clique em `+` para prepará-los.
4. Digite a mensagem e clique em **Commit**.
5. Clique em **Publish Branch**.
6. Entre no GitHub e escolha um repositório privado.

Mesmo usando a interface, confira `git status` antes da publicação.

## Comandos de conferência

```powershell
git remote -v
git log --oneline --decorate -5
git status
```

Resultado esperado: branch `main`, remoto `origin` e árvore de trabalho limpa.
