# Validação — Atlas 9.3

1. Entre no Atlas com a conta INS e abra **Chamados**.
2. Confirme que a credencial cadastrada no cadeado do Capri pertence à mesma conta padrão do operador.
3. Clique em **Mapear meus chamados**.
4. A pesquisa não deve mais exigir que “Criado por” exista como uma lista HTML visível.
5. Confira no resultado que o filtro registrado é **Criado por** e que o assunto é o nome completo obtido no AD.
