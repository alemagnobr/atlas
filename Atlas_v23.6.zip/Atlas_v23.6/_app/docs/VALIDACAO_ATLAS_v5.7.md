# Validação — Atlas v5.7

## Objetivo

Corrigir esta falha observada em estação real:

> A tarefa foi iniciada, mas o Atlas não conseguiu confirmar a exibição do popup na sessão do usuário.

## Alterações

- O popup WPF continua sendo a apresentação principal.
- O código deixou de ser transportado por `EncodedCommand`.
- A estação recebe um `.ps1` temporário legível em UTF-8 com BOM.
- A execução utiliza `RemoteSigned` e não altera a política permanente do Windows.
- O arquivo temporário é removido após confirmação ou fallback.
- `msg.exe`, componente nativo do Windows, é usado quando a política impede a janela WPF.
- Há duas rotas nativas: mensagem remota por RPC e execução local na sessão interativa.

## Segurança

- Nenhuma regra do Trellix é desativada ou contornada.
- Nenhum serviço de segurança é interrompido.
- O conteúdo enviado permanece limitado à orientação selecionada.
- Falhas das rotas são informadas ao operador com diagnóstico separado.

## Testes

- Estrutura Python compilada.
- Contratos da versão e do catálogo preservados.
- Ausência de `EncodedCommand` na rotina de orientações.
- Presença do script auditável, `RemoteSigned` e dos fallbacks nativos.
