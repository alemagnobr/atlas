# Auditoria técnica — Atlas v14.12

## Escopo

A revisão partiu da v14.11 estável e preservou a linha sem Chat. Foram auditados a interface PySide6, o bridge PowerShell, serviços, persistência, instalador, scripts de inicialização, estilos, recursos e testes.

## Problemas de desempenho encontrados e corrigidos

- A troca de tema reaplicava estilos e pesquisava todos os widgets, mesmo quando não havia mudança efetiva.
- Ícones SVG eram renderizados novamente para combinações já utilizadas.
- O indicador da estação repintava aproximadamente onze vezes por segundo, apesar de possuir apenas dois estados visuais úteis.
- A grade de chamados construía todos os cartões no mesmo ciclo da interface.
- A pesquisa de chamados normalizava repetidamente os mesmos textos.
- A navegação repolia a barra inteira ao trocar uma seção.
- Algumas rotinas de tema permaneciam duplicadas ou sem uso após evoluções anteriores.

## Soluções aplicadas

- Cache limitado de ícones por nome, cor e tamanho.
- Registro fraco dos botões tematizados, sem varredura global da interface.
- Folha de estilos reaplicada somente quando o tema muda.
- Transição de tema reutilizável, assíncrona e com restauração de segurança.
- Indicador da estação com frequência reduzida, cache de imagem e descarte de quadros repetidos.
- Renderização incremental de chamados em lotes de 16 cartões.
- Índice de pesquisa por chamado, invalidado junto com o catálogo.
- Atualização visual restrita aos itens anterior e atual da navegação.
- Remoção de métodos de tema obsoletos e atualização dos contratos de teste.

## Regras preservadas

- A v14.11 não foi sobrescrita.
- Chat e notificações de Chat permanecem ausentes.
- Capri, FAQs, chamados, impressoras, Active Directory, modo lateral, perfis e bridge mantêm seus contratos existentes.
- Operações remotas continuam assíncronas e ações sensíveis mantêm confirmação.

## Validação

- Compilação estrutural dos módulos Python críticos.
- Suíte automatizada completa do projeto.
- Verificação de versão, instalador, runtime isolado e ausência do Chat.
- Testes específicos para cache de ícones, troca de tema, renderização incremental e indicador da estação.

O teste visual final deve ser feito em Windows com PySide6, pois o ambiente de auditoria não fornece o runtime gráfico do Qt nem os serviços corporativos Windows/AD/Capri.
