# Validação — Atlas 9.9

1. Inicie o Atlas no modo claro e abra **FAQs**.
2. Clique no seletor de tema e confirme que um arco giratório aparece imediatamente.
3. Durante a transição, confirme o texto **Alterando tema…** e tente clicar novamente; o segundo clique deve ser ignorado.
4. Ao concluir, confirme que o seletor volta a mostrar o símbolo normal e o rótulo correto.
5. No painel **PESQUISAR FAQs**, confira o contraste do título, badge, descrição, rótulo do modo, botões, ícone, texto e placeholder.
6. Digite uma pesquisa e confirme que o texto permanece claro e legível.
7. Volte ao modo claro e confirme novamente a animação e as cores originais.
8. Repita a troca de tema na tela inicial.
9. Confirme que o aviso compacto da v9.8 e a renderização de **Todos** da v9.7 permanecem funcionando.
