# Validação — Atlas v8.2

## Chamados

1. Entre no INS e abra **Chamados**. A tela não deve consultar o Capri automaticamente.
2. Clique em **Acesso Capri**, autentique e depois em **Mapear meus chamados**.
3. Confirme que o nome completo do operador aparece como proprietário da consulta.
4. Teste pesquisa local por número, título, usuário e fila; digitar não deve gerar nova linha de consulta ao Capri.
5. Valide pendentes, finalizados com êxito, anteontem, ontem, hoje, esta semana, semana passada e intervalo de calendário.
6. Teste **Usuário informado** e **Usuário da estação conectada**. A consulta remota só deve ocorrer ao clicar em **Consultar com estes filtros**.
7. Feche e reabra o Atlas: o último catálogo deve continuar disponível no cache.

## FAQs e certificados

1. Remapeie algumas FAQs com números de tamanhos diferentes e confirme que o número exibido coincide exatamente com o cabeçalho do Capri.
2. Em **Certificados**, conecte primeiro à própria estação e depois a uma estação remota.
3. Confirme a leitura de `CurrentUser\My` e `LocalMachine\My` localmente e dos perfis correspondentes remotamente.

## Aparência

1. Alterne o botão de lua/sol e reinicie o Atlas; o tema selecionado deve persistir.
2. Conecte uma estação e confirme que o indicador verde desvanece suavemente, sem piscar.
3. Valide cartões, popups, navegação e modo lateral em 100%, 125% e 150% de escala do Windows.

## Observação de integração

O HTML e os nomes de campos do Capri podem variar conforme a versão do OTRS e a configuração institucional. A v8.2 usa os formulários e links oficiais `AgentTicketSearch` e `AgentTicketZoom`; se o ambiente publicar nomes diferentes, registre o HTML sanitizado da página de resultado para ajuste do adaptador, sem incluir credenciais ou conteúdo sigiloso.
