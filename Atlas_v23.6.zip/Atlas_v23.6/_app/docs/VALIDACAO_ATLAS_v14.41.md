# Validação ATLAS v14.41

## Escopo

- consulta de conta, senha expirada e vencimento diretamente no Active Directory;
- retirada dos campos E-mail pessoal e Conta habilitada do painel operacional;
- recuperação acionada por ícone próprio, sem consulta automática ao PWM;
- abas Controle da estação e Controle de usuários ocupando toda a largura em 50/50;
- limpeza segura de resíduos regeneráveis e pacote sem diretório intermediário `worktree`.

## Contratos validados

- `msDS-User-Account-Control-Computed` determina o estado calculado da senha;
- `msDS-UserPasswordExpiryTimeComputed` fornece o vencimento efetivo, inclusive sob política específica;
- a pesquisa comum termina após o marcador `@@USERCONTROL@@` e não inicia navegador;
- o ícone de e-mail chama `password_recovery_preview`, apresenta o destino mascarado e exige confirmação antes de `password_recovery_send`;
- o intervalo de segurança impede solicitações repetidas por 60 segundos;
- `BalancedTabWidget` reajusta a barra no `showEvent` e em todo `resizeEvent`;
- o ZIP contém diretamente a pasta `Atlas_Suporte_Avancado_v14.41`.

## Resultado automatizado

- 260 testes aprovados;
- 24 verificações estruturais aprovadas;
- sintaxe Python compilada;
- catálogos JSON validados;
- metadados 14.41 consistentes no aplicativo, runtime e instalador.

## Validação institucional recomendada

1. consultar uma conta com senha vigente;
2. consultar uma conta com senha expirada;
3. conferir vencimento e contagem regressiva;
4. clicar no ícone de e-mail, conferir o endereço mascarado e cancelar;
5. repetir com uma solicitação autorizada e confirmar um único envio;
6. abrir o Atlas após o login e alternar as duas abas nos modos normal e lateral.
