# Validação ATLAS v14.47

## Cobertura desta versão

- Consulta temporária de até 25 chamados no Capri para o usuário encontrado no Active Directory.
- Abertura do popup com busca explícita e filtros locais reaproveitando os cards da Central de Chamados.
- Integração automática após consulta manual do usuário ou consulta da estação.
- Serialização com outras consultas Capri e descarte de respostas obsoletas após troca de usuário.
- Progresso da estação mantido abaixo de 100% até a finalização do fluxo de usuário e chamados.
- Atualização de metadados e instalador para 14.47.

## Execução local

```text
python -m unittest discover -s tests -v
python -m compileall -q main.py services tests
```

A consulta real depende do ambiente institucional Windows, da conectividade com AD e Capri e de uma sessão Capri válida. A confirmação visual e funcional dessas integrações precisa ser feita nesse ambiente.
