# Validação — Atlas v7.4

- Em **Orientações ao usuário**, a pesquisa deve aparecer dentro de um cartão azul identificado como **PESQUISAR ORIENTAÇÕES** e **PESQUISA LOCAL**.
- O cartão deve informar que pesquisar não atualiza nem remapeia a base.
- O campo de pesquisa deve continuar filtrando imediatamente as orientações salvas.
- Nenhum comando de atualização deve aparecer dentro da barra de pesquisa.
- Abaixo da pesquisa, deve existir uma área amarela identificada como **ATUALIZAR A BASE**.
- O remapeamento integral deve aparecer como **Remapear catálogo completo**.
- A atualização individual deve solicitar o número completo e usar o botão **Atualizar FAQ específica**.
- As funções de pesquisa, remapeamento integral e atualização individual devem preservar o comportamento da v7.3.
