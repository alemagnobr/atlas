# Manual de uso

## Autenticação

Ao abrir o programa, clique em **Autenticar como INS**. Na primeira utilização, o Windows pode solicitar a senha. Ela é armazenada pelo Gerenciador de Credenciais do Windows, não nos arquivos do projeto.

Use **Redefinir acessos salvos** após troca de senha ou para remover a credencial armazenada.

## Conectar uma estação

1. Digite o nome ou IP no campo **Estação remota**.
2. Clique em **Conectar**.
3. Aguarde a consulta do painel.
4. Confirme estação, usuário remoto, Windows, administração local, RDP, BIOS, SCCM e impressoras.

Quando conectado, o botão muda para **Desconectar**. Os ícones ao lado do cabeçalho atualizam o painel e copiam o endereço da estação.

## Controle de usuários

1. Em **Informações**, selecione **Controle de usuários**.
2. Informe o login de rede, com ou sem `SENADO\`.
3. Clique em **Consultar usuário**.
4. O quadro **Informações do usuário** apresentará os dados pessoais, organizacionais e da conta.
5. Confira os telefones disponíveis, as observações do cadastro, o estado **Senha expirada** e a contagem regressiva de **Vencimento da senha**.

A consulta comum não abre o PWM nem depende de sessão do navegador. Os campos de senha são calculados pelo Active Directory, inclusive quando existe uma política específica aplicada ao usuário.

O card **Telefones** reúne somente os valores preenchidos no AD: telefone comercial, residência, pager, celular, fax e telefone IP. O card **Observações** apresenta o conteúdo do atributo `info`, correspondente ao campo de observações da aba **Telefones** do Active Directory. Valores ausentes são indicados como **Não informado**.

Depois que o usuário é localizado, o botão verde **Consultar** muda para **Nova consulta** em vermelho. Esse comando limpa o resultado anterior e posiciona o cursor no campo de login. O botão de cópia ao lado de **Login de rede** envia `SENADO\login` para a área de transferência.

O atalho lateral **Informações do usuário no AD** também fica disponível após uma consulta direta. Nesse caso, ele abre as informações complementares do usuário selecionado mesmo sem uma estação conectada.

O pequeno ícone de e-mail ao lado de **Senha expirada** abre o fluxo de recuperação. O Atlas consulta o destino protegido no Gestor, mostra o endereço mascarado e exige confirmação antes do envio. Consultar o usuário não envia mensagem automaticamente.

O botão **PWM**, ao lado do ícone de e-mail, abre `gestorsenhas.senado.leg.br` no navegador escolhido nas configurações do Atlas. Se o navegador escolhido não estiver disponível, o software usa o navegador padrão do Windows e registra o fallback no console.

Depois do envio, o Atlas diferencia a confirmação textual do portal da aceitação técnica da solicitação. Se o servidor aceitar o formulário sem mostrar uma mensagem final, o popup informa que o e-mail foi encaminhado e registra que não houve confirmação textual. Erros explícitos continuam sendo apresentados e o Atlas nunca repete o envio automaticamente.

## Atalhos laterais

- Controle Remoto SCCM;
- Prompt de Comando local;
- informações do usuário no Active Directory;
- Internet e certificados;
- discos e perfis;
- usuários e grupos locais.

Atalhos que apenas abrem outra ferramenta não exibem popup de sucesso.

## Central de chamados

Digite a palavra ou expressão e clique em **Pesquisar** ou pressione Enter para buscar em todos os chamados já mapeados no cache local. A busca considera número, título, usuário, fila, categoria, responsáveis, conteúdo e datas, sem consultar o Capri. Enquanto houver texto pesquisado, o Atlas usa **Todos**; ao limpar o campo e pesquisar novamente, restaura o filtro de situação anterior.

O botão **Atualizar** consulta somente ontem e hoje. Os registros desse intervalo são revalidados e substituídos no cache, enquanto os demais dias já mapeados permanecem preservados. Para mapear outro período, use **Escolher período e mapear**.

## Discos e perfis

Na aba **Discos e rede**, o software mostra:

- letra e tipo da unidade;
- caminho UNC dos drives mapeados;
- capacidade total, livre e percentual utilizado.

Na aba **Perfis**, mostra para cada pasta registrada:

- usuário e caminho;
- consumo em KB, MB ou GB;
- percentual do disco correspondente;
- carregado/não carregado;
- último uso e SID.

O cálculo pode demorar em estações com muitas pastas ou perfis grandes. A medição ocorre em paralelo com limite de três perfis para equilibrar velocidade e uso de disco. Apenas resultados com drives de rede confirmados permanecem em cache, por 30 segundos; use **Shift+clique** no atalho para forçar uma nova consulta.

## Ações destrutivas

Fechar Outlook, logoff, reinicialização e limpeza de TEMP pedem confirmação. Confira sempre a estação antes de confirmar.

## Modo lateral

Clique em **Modo lateral** para encaixar o aplicativo no canto direito. O conteúdo se reorganiza em uma coluna sem remover funcionalidades.

## Sair do INS

Clique em **Sair do INS** para encerrar o contexto administrativo e voltar à tela inicial do perfil padrão.
