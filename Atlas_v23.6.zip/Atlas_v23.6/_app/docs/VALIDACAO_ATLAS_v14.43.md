# Validação ATLAS v14.43

## Escopo

- reorganizar e compactar o quadro de informações do usuário;
- remover o selo visual redundante da fonte Active Directory;
- coletar os telefones e as observações exibidos na aba **Telefones** do AD;
- animar suavemente o ícone verde do usuário sem bloquear a interface.

## Mapeamento dos atributos

| Informação no Atlas | Atributo do Active Directory |
| --- | --- |
| Telefone comercial | `telephoneNumber` |
| Residência | `homePhone` |
| Pager | `pager` |
| Celular | `mobile` |
| Fax | `facsimileTelephoneNumber` |
| Telefone IP | `ipPhone` |
| Observações | `info` |

Somente telefones preenchidos são apresentados no card consolidado. O valor de observações preserva texto livre e quebras de linha recebidas do AD.

## Resultado automatizado

- 271 testes aprovados;
- 24 verificações estruturais aprovadas;
- sintaxe Python compilada;
- metadados 14.43 consistentes no aplicativo, runtime e instalador.
