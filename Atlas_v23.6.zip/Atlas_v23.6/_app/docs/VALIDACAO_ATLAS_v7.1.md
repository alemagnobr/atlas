# Validação — Atlas v7.1

- Com caminho da Intranet: mostra o aviso de abertura pelo chefe do setor.
- Somente contato: não mostra o aviso.
- Somente orientação direta: não mostra o aviso.
- Regra aplicada às rotas WPF e CMD.
