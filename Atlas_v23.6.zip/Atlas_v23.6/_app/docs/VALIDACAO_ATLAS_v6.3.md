# Validação — Atlas v6.3

## Rota de orientação remota

A alternativa visual utiliza uma tarefa agendada interativa no contexto do usuário conectado e abre um arquivo CMD previamente gravado no diretório temporário do Windows remoto. A janela é somente para leitura, não contém `pause`, `Read-Host` nem entrada de teclado e fecha automaticamente após dez minutos.

## Confirmação

O CMD remoto grava um marcador somente depois de montar o conteúdo na tela. O Atlas aguarda esse marcador antes de informar que a orientação foi exibida.

## Verificações

- Compilação estrutural do código Python.
- Suíte de contratos do Atlas.
- Ausência de solicitação de resposta no mensageiro.
- Persistência controlada da tarefa interativa.
- Integridade do pacote ZIP.
