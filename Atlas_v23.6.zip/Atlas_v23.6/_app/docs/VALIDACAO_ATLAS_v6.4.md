# Validação — Atlas v6.4

## Correção

O caminho do arquivo CMD remoto passa a ser entregue à tarefa como `/d /q /c call "arquivo.cmd"`. Essa forma evita o par adicional de aspas que era interpretado como parâmetro inválido em algumas versões do Windows.

O fallback por `msg.exe` foi removido do fluxo de orientações, pois podia abrir e fechar imediatamente e substituir o diagnóstico do mensageiro principal.

## Verificações

- Compilação estrutural do código Python.
- Suíte de contratos do Atlas.
- Contrato da chamada CMD com `call`.
- Ausência de `msg.exe`, `pause` e `Read-Host` na orientação.
- Integridade do pacote ZIP.
