# Validação — Atlas 5.2

- Compilação estrutural dos módulos Python: aprovada.
- Suíte automatizada: 21 testes aprovados.
- Grade principal: duas colunas a partir de 440 px de largura útil, independentemente do modo lateral.
- Botão de exportação das FAQs removido da interface e referências visuais eliminadas.
- Cópia individual: transfere somente o identificador numérico da FAQ para a área de transferência.
- Catálogo reorganizado em categoria, ferramenta/assunto, procedimento e artigos.
- Agrupamento das FAQs realizado em uma única passagem para reduzir processamento repetido.
- Título, descrição e conteúdo recebem transições coordenadas de opacidade.

## Conferência visual recomendada

Validar após o login INS, sem acionar a seta lateral, que os atalhos apareçam em duas colunas. Na seção FAQs, expandir uma categoria e uma ferramenta, conferir os procedimentos separados e testar o botão de cópia em artigos com números diferentes.
