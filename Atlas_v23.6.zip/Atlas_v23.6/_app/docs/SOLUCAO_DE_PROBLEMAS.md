# Solução de problemas

## Nada acontece ao executar

1. Extraia todo o ZIP.
2. Mova a pasta para `C:\Atlas_Suporte_Avancado`.
3. Execute `diagnostico.bat`.
4. Verifique `erro_inicializacao.txt` e o log de cópia em `%TEMP%`.

## Python não encontrado

Instale Python 3.11 ou superior com **Add Python to PATH**. Confirme:

```powershell
py -3 --version
python --version
```

## PySide6 não instala

```powershell
py -3 -m pip install --upgrade pip
py -3 -m pip install -r requirements.txt
```

Sem PySide6, o programa tenta abrir `fallback.py`.

## Permission denied no OneDrive ou Downloads

Execute pelo `run.bat`. Ele prepara a cópia em `%LOCALAPPDATA%`. Se necessário, extraia para `C:\Atlas_Suporte_Avancado`.

## Estação não conecta

Verifique DNS, ping, firewall, WMI/DCOM, permissões INS e nome da estação. Consulte o Console de atividades.

## Drives de rede não aparecem

Verifique se o usuário está conectado e se os mapeamentos estão visíveis no Explorador dele. A consulta principal permanece ativa por até 30 segundos no token interativo e combina `WNetGetConnection`, `WScript.Network`, `net use`, `Get-PSDrive` e `Shell.Application`. Se nenhuma unidade de rede for devolvida, o popup mostra o diagnóstico da tarefa; registre essa mensagem porque ela diferencia bloqueio de política, falha ao iniciar a tarefa e retorno vazio. As consultas WMI e `HKU\SID\Network` continuam como contingência.

## Tamanho do perfil não aparece

O software tenta `C$`/`D$` e depois cálculo local via WMI. Verifique:

- acesso ao compartilhamento administrativo;
- permissão para criar processo WMI;
- espaço e acesso à chave temporária em `HKLM\SOFTWARE`;
- tempo de espera para perfis grandes.

## SCCM não abre

Instale o Console do MECM ou coloque `CmRcViewer.exe` na pasta da aplicação. O programa também procura nos diretórios padrão do console.

## Erro de caracteres no PowerShell

Mantenha `bridge.ps1` e `bridge_launcher.ps1` em UTF-8. Não abra e salve os scripts com codificação ANSI.
