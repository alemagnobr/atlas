# Validação — Atlas v7.8

## Escopo

- Várias orientações podem coexistir em uma única FAQ.
- Uma orientação nova ou editada é persistida ao salvar ou enviar.
- O operador seleciona, revisa, edita, exclui ou cria orientações antes do envio.
- O índice por FAQ continua sendo construído uma única vez em memória.

## Compatibilidade

As preferências da versão 7.7 continuam válidas. O novo campo `additional` apenas acrescenta as orientações extras, sem duplicar o catálogo principal.
