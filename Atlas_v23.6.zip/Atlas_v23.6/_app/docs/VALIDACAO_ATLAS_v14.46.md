# Validação ATLAS v14.46

## Escopo

- equilibrar a largura dos cards de resumo da estação em duas colunas iguais;
- executar a busca de chamados somente após clique em **Pesquisar** ou Enter.

## Comportamentos protegidos

- as colunas do resumo de estação usam o mesmo fator de expansão, mantendo 50% da largura disponível para cada uma;
- Windows, Admin local, Acesso RDP, Tempo ligado, Serial/BIOS e Agente SCCM preservam a grade 2 × 3;
- digitar ou apagar texto não refaz a lista de chamados;
- clique em **Pesquisar** e Enter seguem executando a busca local;
- a pesquisa continua abrangendo todos os chamados do cache e mostra andamento durante a renderização.

## Resultado automatizado

- testes unitários e contratuais aprovados;
- verificações estruturais aprovadas;
- sintaxe Python compilada;
- metadados 14.46 consistentes no aplicativo, runtime e instalador.

## Homologação visual

- conferir a grade em largura normal, meia tela e modo lateral no Windows 10/11.
