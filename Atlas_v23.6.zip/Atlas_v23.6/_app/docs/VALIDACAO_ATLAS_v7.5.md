# Validação — Atlas v7.5

- Em **FAQs**, a pesquisa deve aparecer dentro de um cartão azul identificado como **PESQUISAR FAQs** e **PESQUISA LOCAL**.
- O cartão deve informar que pesquisar não consulta o Capri nem altera a base.
- O campo deve continuar filtrando imediatamente as FAQs já salvas.
- Os comandos de autenticação e mapeamento não devem aparecer dentro da barra de pesquisa.
- Abaixo da busca, deve existir uma área amarela identificada como **ATUALIZAR A BASE**.
- A manutenção deve apresentar **Acesso ao Capri**, **Remapear todas as FAQs** e **Atualizar FAQ específica**.
- Atualização individual deve aceitar somente o número completo de oito dígitos.
- Pesquisa, autenticação, remapeamento e atualização individual devem preservar o comportamento da v7.4.
