# Validação — Atlas v8.1

## Escopo

- Seletor **Relacionada** / **No título** na pesquisa local de FAQs.
- Expressão contínua pesquisada somente no título visível no segundo modo.
- Número completo da FAQ aceito como correspondência direta.
- Conteúdo interno, procedimento, categoria e orientação excluídos do modo **No título**.

## Segurança funcional

A alteração permanece limitada ao índice local. Não consulta o Capri, não remapeia o catálogo e não modifica nenhuma FAQ.

## Compatibilidade

A pesquisa **Relacionada** mantém o comportamento amplo da v8.0. Os caches permanecem separados por modo.
