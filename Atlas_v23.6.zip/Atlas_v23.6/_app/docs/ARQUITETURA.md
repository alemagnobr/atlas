# Arquitetura técnica

## Componentes

| Componente | Responsabilidade |
| --- | --- |
| `run.bat` | prepara cópia local, encontra Python e inicia a interface |
| `main.py` | UI PySide6, estado, animações, popups e execução assíncrona |
| `ui/transitions.py` | transições visuais não bloqueantes e restauração segura da interface |
| `ui/widgets.py` | componentes visuais reutilizáveis |
| `services/capri.py` | montagem e validação dos contratos enviados ao Capri |
| `storage/json_store.py` | persistência JSON atômica e tolerante a falhas |
| `fallback.py` | modo compatível quando PySide6 não está disponível |
| `bridge_launcher.ps1` | lê o bridge em UTF-8 e cria o script PowerShell |
| `bridge.ps1` | consultas e ações Windows/AD/impressoras |
| `legacy_tool.bat` | implementação original preservada |

## Fluxo de uma ação

```mermaid
flowchart TD
    A[Operador seleciona ação] --> B[Dashboard valida perfil e estação]
    B --> C[QProcess inicia bridge_launcher]
    C --> D[Launcher carrega bridge.ps1 em UTF-8]
    D --> E[Comando consulta ou altera a estação]
    E --> F[Saída textual ou JSON estruturado]
    F --> G[Console e popup da interface]
```

## Comunicação estruturada

O bridge inclui marcadores em linhas JSON:

- `@@STATUS@@` — resumo da estação;
- `@@USERCONTROL@@` — painel de usuário, conta e senha consultados no Active Directory;
- `@@ADUSER@@` — informações organizadas do usuário;
- `@@DISKPROFILE@@` — discos, drives e perfis.

A interface remove os marcadores do texto visível, interpreta o JSON e monta cartões e abas.

## Controle de usuários e recuperação

O painel consulta `userAccountControl`, `msDS-User-Account-Control-Computed` e `msDS-UserPasswordExpiryTimeComputed` diretamente no Active Directory. Assim, estado e vencimento da senha não dependem do PWM nem de navegador. O e-mail pessoal não é exibido.

A recuperação permanece isolada do carregamento do painel. Somente o clique no ícone de e-mail chama o formulário público do Gestor de Senhas, apresenta o destino mascarado e, após confirmação explícita, envia uma única solicitação. O bloqueio temporário impede repetição acidental.

## Consulta de discos

São combinadas cinco fontes:

1. `Win32_LogicalDisk`: discos locais e unidades expostas ao WMI;
2. `Win32_MappedLogicalDisk`: drives mapeados com letra, UNC e capacidade;
3. `HKU\SID\Network`: mapeamentos persistidos, enumerados também por `StdRegProv` para não depender do serviço de Registro Remoto;
4. `WNetGetConnection`, `WScript.Network`, `net use`, `Get-PSDrive` e `Shell.Application`: coleta executada no token da sessão interativa, correspondente ao que o usuário vê no Explorador;
5. `Win32_NetworkConnection`: conferência adicional de letras e caminhos UNC mantidos pela conexão de rede.

Os resultados são consolidados pela letra da unidade e ordenados por `DeviceID`. A sessão interativa tem prioridade para drives de rede, eliminando duplicatas sem ocultar discos locais ou removíveis.

O caminho principal não cria um novo logon do usuário. Um lançador temporário `SYSTEM` usa `WTSEnumerateSessions` e `WTSQueryUserToken`, assume o token da sessão já existente e chama `WNetGetConnection`. O script codificado é enviado por `StdRegProv` a uma chave temporária de `HKLM`; serviço temporário e Agendador funcionam como lançadores alternativos, sem arquivo XML. A coleta também reconcilia WMI, `HKU\Network`, `Explorer\MountPoints2`, WinRM, `Get-PSDrive`, `WScript.Network` e `net use`. Letras reais têm prioridade; padrões corporativos R/U/V/W/X completam somente compartilhamentos reconhecidos. Os dados e lançadores temporários são removidos no bloco de limpeza.

A coleta multi-método do Explorer fica isolada em `scripts/network_drives.ps1` e só é carregada pela ação `disk_profiles`. Dessa forma, eventual incompatibilidade em uma estação não interfere em conexão, pesquisa, impressoras ou outras funções do bridge principal.

A sessão candidata não depende apenas de `Win32_ComputerSystem.UserName`: o bridge também consulta os proprietários de `explorer.exe` e tenta cada conta interativa até receber pelo menos um caminho UNC. Resultados sem drives de rede não entram no cache; resultados confirmados permanecem por apenas 30 segundos.

A coleção `Shell.Application.Namespace(17).Items()` é percorrida pelo índice COM. Para cada item, a letra é obtida pelo caminho ou pelo sufixo visual `(X:)`; o UNC vem das propriedades estendidas do Shell e, como último recurso, do padrão `compartilhamento (\\servidor) (X:)` exibido pelo próprio Explorador.

## Cálculo de perfis

Primeiro, o bridge converte o caminho local em UNC administrativo. A medição tenta:

1. `Scripting.FileSystemObject`;
2. `robocopy /L /BYTES /XJ`;
3. `Get-ChildItem` e `Measure-Object`.

O caminho principal cria um único processo PowerShell remoto por WMI e mede no máximo três perfis simultaneamente com jobs. O limite reduz a duração sem saturar o disco. Os resultados temporários são gravados por SID no registro, lidos pelo bridge com `StdRegProv` e removidos ao final. Somente os perfis sem resposta passam pelas rotas UNC `C$`/`D$`.

A interface mantém o último resultado de cada estação em memória por dois minutos. Isso torna reaberturas instantâneas sem persistir dados em arquivo; **Shift+clique** força uma nova medição.

## Concorrência e interface

Os comandos são executados por `QProcess`, mantendo a janela responsiva. Uma nova ação é bloqueada enquanto outra está em andamento, evitando concorrência acidental sobre o mesmo runner.

Listas extensas são renderizadas de forma incremental pelo ciclo de eventos. Ícones SVG e textos normalizados de pesquisa usam caches limitados e invalidados quando a fonte muda. A troca de tema reaplica a folha de estilos somente quando o tema realmente mudou e atualiza apenas os botões registrados, evitando percorrer toda a árvore de widgets.

As animações decorativas têm frequência limitada e ignoram quadros visualmente idênticos. Transições de tema ficam isoladas em `ui/transitions.py` e possuem um temporizador de segurança que sempre devolve opacidade e controles ao estado normal, mesmo se uma etapa intermediária falhar.
