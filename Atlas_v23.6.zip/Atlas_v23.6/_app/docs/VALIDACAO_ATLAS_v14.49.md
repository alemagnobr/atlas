# Validação ATLAS v14.49

## Cobertura desta versão

- Consulta temporária do Capri com o nome completo apresentado pelo Active Directory.
- Preservação do filtro por login no catálogo regular da Central de Chamados.
- Botão de atualização da prévia reduzido e alinhado aos demais controles.
- Progressão e atualização visual mantidas durante novas consultas.
- Metadados e instalador atualizados para 14.49.

## Execução local

```text
python -m unittest discover -s tests -v
python -m compileall -q main.py services tests
```

A confirmação visual e a consulta real precisam ser verificadas em Windows com uma sessão institucional do Capri.
