# Novidades da v3.34

- Corrigido o conflito entre `$HKU` e `$hku` que fazia o PowerShell tentar converter um objeto WMI `__PARAMETERS` em `UInt32`.
- Integrada a solução funcional de certificados remotos da v1.06.
- A coleta agora prioriza a sessão interativa do usuário remoto e mantém fallbacks por WMI, Registro Remoto e WinRM.
- A exclusão usa a rotina validada `Remove-RemoteUserCertificate`, com tratamento separado para `CurrentUser\My` e `LocalMachine\My`.
- A opção continua bloqueada para o computador local do analista.
