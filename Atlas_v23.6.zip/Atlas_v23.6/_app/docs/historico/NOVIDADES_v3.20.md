# Suporte remoto simplificado — v3.20

- “Suporte remoto” agora exibe somente as seis rotinas de suporte ao computador.
- Fechar Outlook, limpar DNS, atualizar políticas, logoff, reiniciar e limpar TEMP permanecem na página.
- As seis rotinas de impressoras continuam disponíveis exclusivamente em “Impressoras”.
- O cartão de navegação foi retirado porque o Menu principal está sempre acessível na lateral.
- Nenhuma ação de impressora ou comando PowerShell foi removido.
- Login salvo, prompt silencioso, painel compacto, popups e impressora padrão foram preservados.
