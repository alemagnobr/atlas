# Cartões limpos e atualização contextual — v3.21

- Os números foram removidos visualmente dos títulos de todos os cartões.
- Ícone, nome do procedimento e descrição permanecem para facilitar a leitura.
- “Atualizar painel” saiu da barra lateral e da categoria Diagnóstico.
- Um ícone circular de atualização foi adicionado ao canto superior direito da estação.
- O ícone permanece desabilitado até a estação estar conectada.
- Durante a atualização, o ícone pulsa e bloqueia cliques duplicados.
- Os indicadores “SESSÃO INS” e “SESSÃO PADRÃO” agora pulsam suavemente.
- As rotinas operacionais, impressora padrão, login salvo e popups foram preservados.
