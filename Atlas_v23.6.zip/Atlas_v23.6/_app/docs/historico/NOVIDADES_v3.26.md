# Painel administrativo e atalhos — v3.26

- **Admin local** ganhou cadeado clicável para adicionar ou remover o usuário conectado.
- Cadeado fechado com ponto verde pulsante indica usuário administrador.
- Cadeado aberto com ponto vermelho pulsante indica usuário sem privilégio administrativo.
- Estado administrativo é consultado novamente após cada alteração.
- Categorias **Diagnóstico** e **Usuários e AD** removidas da navegação lateral.
- Título textual dos atalhos substituído por uma linha separadora moderna.
- Novos atalhos animados para Internet e certificados, Discos e perfis e Usuários e grupos locais.
- Diagnóstico de armazenamento reorganizado em popup com abas, barras de ocupação e lista detalhada de perfis.
- Ferramenta **Legada** preservada sem alterações.
