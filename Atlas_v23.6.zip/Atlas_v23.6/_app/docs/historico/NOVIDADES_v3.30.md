# Unidades mapeadas e confirmações compactas — v3.30

## Revisão — lógica da ferramenta Legada

- A coleta de discos foi substituída pela mesma combinação usada com sucesso na Legada.
- Consulta `Win32_LogicalDisk` para discos locais e unidades já visíveis ao WMI.
- Consulta `Win32_MappedLogicalDisk` para recuperar letra, caminho UNC, total e espaço livre dos drives de rede.
- Percorre `HKU\SID\Network` como alternativa para mapeamentos adicionais dos usuários.
- A apresentação mostra `Drive`, tipo, caminho de rede, capacidade total e espaço livre.
- Cada pasta de perfil é medida individualmente por múltiplos métodos: FSO, Robocopy e varredura de arquivos.
- Quando `C$` ou `D$` estiver bloqueado, o cálculo é executado localmente na estação por WMI.
- A aba Perfis exibe o consumo em KB, MB ou GB, percentual do disco, caminho, SID e último uso.

- A aba de discos mostra unidades locais, removíveis e unidades de rede mapeadas no usuário conectado.
- Caminho UNC, letra da unidade, tipo, capacidade e utilização são organizados em cartões.
- A aba de perfis mantém o cálculo individual do espaço ocupado por cada usuário acessível.
- Controle Remoto SCCM, Prompt de Comando e Internet/Certificados não exibem popup de sucesso.
- Erros dessas ações continuam visíveis no console ou em avisos, quando necessário.
- Confirmações de ações destrutivas e do cadeado administrativo usam popup próprio mais compacto.
- Ferramenta Legada e demais comandos foram preservados.
