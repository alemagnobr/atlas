# Menu principal inteligente — v3.10

- O Menu principal agora apresenta os comandos mais usados conforme o perfil padrão ou INS.
- O resumo completo da estação conectada fica concentrado no Menu principal.
- As páginas laterais continuam exibindo normalmente todos os comandos de cada categoria.
- A troca de categoria recebeu uma animação curta de desvanecimento com curva suave.
- Ao desconectar uma estação, o resumo anterior é removido imediatamente.
- Nenhum comando PowerShell, integração ou funcionalidade operacional foi removido.
