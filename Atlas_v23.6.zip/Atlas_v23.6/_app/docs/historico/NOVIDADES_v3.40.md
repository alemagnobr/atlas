# Novidades v3.40

- A abertura remota da limpeza do Chrome e Edge passa a forçar uma nova janela do navegador.
- O destino continua sendo `chrome://settings/clearBrowserData` ou `edge://settings/clearBrowserData`.
- Nenhuma limpeza é executada automaticamente; o usuário/técnico ainda confirma a ação no navegador.
