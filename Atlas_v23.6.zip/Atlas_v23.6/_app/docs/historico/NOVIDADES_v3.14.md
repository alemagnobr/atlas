# Inicialização protegida — v3.14

- Corrigido o erro `[Errno 13] Permission denied` ao abrir `main.py` pelo OneDrive.
- O `run.bat` agora prepara automaticamente o aplicativo em `%LOCALAPPDATA%`.
- Toda a estrutura, incluindo assets e scripts PowerShell, é copiada antes da execução.
- O inicializador valida se o ZIP foi realmente extraído.
- Em caso de bloqueio, apresenta orientação direta para desbloquear o arquivo.
- O diagnóstico agora testa explicitamente a permissão de leitura do código.
- Interface, popups e todas as 26 ações foram preservados.
