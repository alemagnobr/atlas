# Novidades visuais — v3.9

- Paleta digital baseada nas cores institucionais oficiais do Senado Federal.
- Login redesenhado com hierarquia mais clara e composição compacta automática.
- Barra lateral em azul profundo, navegação com seleção amarela e melhor contraste.
- Cartões operacionais com estados de foco, ícones, superfícies e espaçamento refinados.
- Painel de estação conectada com linguagem visual verde e leitura mais imediata.
- Console, campos, botões, barras de rolagem e diálogos harmonizados.
- Logo e ícone atualizados para a nova identidade visual.
- Nenhum comando, ação ou integração PowerShell foi removido ou alterado.
