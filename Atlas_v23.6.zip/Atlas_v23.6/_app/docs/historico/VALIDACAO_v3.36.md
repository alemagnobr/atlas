# Validação da v3.36

Executado no ambiente de desenvolvimento Linux:

- Compilação sintática de `main.py` e dos testes Python: aprovada.
- Dez testes automatizados: aprovados. Cobrem a ordem das três categorias, realocação de certificados, Chrome/Edge nos dois modos, ausência de confirmação extra, cancelamento da seleção, bloqueio sem estação/perfil INS, timeout, falha de inicialização e operação já em andamento.
- Esses testes carregam os métodos Python por AST e usam substitutos de Qt; não representam teste visual da interface PySide6.
- Módulo de certificados e demais scripts preexistentes preservados, exceto os novos casos de despacho no bridge.

Não executado neste ambiente: PowerShell, Agendador/WMI/SMB Windows e limpeza em estação real. O pacote inclui `tests/test_browser_cleanup.ps1` para validação sintática dos três scripts envolvidos, listas de limpeza, preservação de arquivos vizinhos e recusa de caminhos externos/junções. Esse teste usa somente uma pasta temporária de teste: não conecta a computadores e não fecha navegadores reais.

## Validação recomendada em Windows

1. Execute `python -m unittest discover -s tests -v` e `powershell.exe -NoProfile -ExecutionPolicy Bypass -File tests/test_browser_cleanup.ps1` na pasta extraída.
2. Em uma estação de teste autorizada, selecione Chrome + Limpeza segura. Confira fechamento, limpeza de cache, retorno do resultado e preservação de cookies, histórico, senhas e favoritos.
3. Repita com Edge. Verifique que o navegador não selecionado permanece aberto e com seus dados intactos.
4. Teste Limpeza completa com dados descartáveis: confira remoção de histórico/cookies e necessidade de novo login, preservando senhas/favoritos/arquivos baixados.
5. Confira recusas: destino local, ausência de usuário, acesso negado e uso do mesmo navegador pelo mesmo usuário em outra sessão.
6. Em interrupção de rede ou timeout, não considere a limpeza concluída. Verifique a estação e eventual tarefa temporária `GSS_Browser_<identificador>` antes de repetir. A tarefa tem limite remoto de dois minutos, mas perda de comunicação pode impedir a remoção dos arquivos/registro temporários.

As operações de exclusão não possuem desfazer. Conteúdo não salvo nas abas pode ser perdido pelo fechamento automático, inclusive na limpeza segura.
