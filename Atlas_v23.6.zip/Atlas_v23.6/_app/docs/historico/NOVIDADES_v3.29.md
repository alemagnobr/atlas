# Popups e ícones modernos — v3.29

- Resultados organizados em cartões claros, selecionáveis e copiáveis.
- Popups do Active Directory divididos em campos visuais modernos e abas adaptáveis.
- Cabeçalhos de sucesso e erro com identidade visual mais forte.
- Nova família de ícones vetoriais consistente em ações, atalhos, impressoras e controles.
- Símbolos antigos removidos para evitar diferenças entre versões do Windows.
- Caixas de confirmação e aviso refinadas para acompanhar o restante da interface.
- Todas as funções, comandos PowerShell e a ferramenta Legada foram preservados.
