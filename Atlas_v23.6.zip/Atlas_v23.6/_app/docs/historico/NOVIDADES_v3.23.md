# Novidades — v3.23

- Ferramenta **Legada** atualizada integralmente conforme o código fornecido.
- Nome **Ferramenta legada** simplificado para **Legada**.
- Ícones contextuais adicionados aos itens da barra lateral.
- Backend e comandos da interface oficial preservados sem alterações.
