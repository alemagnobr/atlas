# Fluxo INS e atalhos técnicos — v3.25

- Tela inicial simplificada com somente **Autenticação INS**.
- **Sair do INS** retorna à tela inicial em um novo processo executado pela conta padrão.
- Menu principal renomeado visualmente para **Informações**.
- Item **Computadores** removido; **Ping contínuo** transferido para **Suporte remoto**.
- Ícones removidos dos nomes das categorias laterais.
- Atalhos laterais animados para SCCM, Prompt de Comando e informações do usuário no AD.
- Consulta LDAP organizada em abas: **Organização**, **Conta**, **Perfil** e **Membro de**.
- Botões compactos no quadro de impressoras para ping e abertura da interface web.
- Setas dos cartões e botão de atualização redimensionados para melhor equilíbrio visual.
- Ferramenta **Legada** preservada sem alterações.
