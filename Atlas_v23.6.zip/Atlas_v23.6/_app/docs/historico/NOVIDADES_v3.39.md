# v3.39 — Abertura direta da limpeza do navegador

As opções de limpeza automática das versões 3.36 a 3.38 foram substituídas por dois botões simples em **Navegadores e certificados**:

- Abrir limpeza do Chrome: `chrome://settings/clearBrowserData`.
- Abrir limpeza do Edge: `edge://settings/clearBrowserData`.

A página é iniciada por uma tarefa no token interativo do usuário remoto. A rotina procura o executável registrado em App Paths e nos locais conhecidos de instalação da máquina e do usuário. Não copia módulos para o remoto, não usa `D$`, `ADMIN$`, perfil compartilhado ou pasta TEMP e não altera permissões de arquivos.

A ação abre a interface nativa do navegador. Ela não fecha o navegador, não marca opções, não escolhe intervalo e não clica em Limpar agora. Essas escolhas permanecem visíveis e precisam ser confirmadas pelo operador ou usuário. A mensagem de retorno confirma somente que a solicitação foi enviada.

Certificados digitais e o restante do layout não foram alterados. Os módulos de exclusão automática do navegador foram retirados do pacote. A v3.38 permanece preservada separadamente.

Validação local: compilação sintática Python e 14 testes Python aprovados, incluindo botões independentes, páginas exatas, ausência das rotinas antigas e ausência de dependência de arquivos/compartilhamentos. O teste de sintaxe PowerShell incluído não foi executado porque este ambiente não possui Windows PowerShell. A abertura real precisa ser verificada numa estação Windows com usuário conectado e acesso ao Agendador remoto.
