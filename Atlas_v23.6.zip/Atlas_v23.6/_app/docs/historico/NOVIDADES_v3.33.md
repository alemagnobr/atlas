# Novidades da v3.33

- Nova opção **Certificados digitais** em **Suporte remoto > Suporte ao computador**.
- Lista certificados pessoais do usuário conectado e do repositório da máquina remota.
- Exibe titular, emissor, validade, status, origem e impressão digital.
- Permite excluir apenas o certificado selecionado, com confirmação explícita.
- A consulta e a exclusão não acessam o repositório de certificados do computador do analista.
