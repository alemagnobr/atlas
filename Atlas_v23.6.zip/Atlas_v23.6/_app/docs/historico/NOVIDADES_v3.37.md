# v3.37 — Correção da preparação da limpeza remota

Corrige o erro de pasta `AppData\Local\Temp` não encontrada, relatado na v3.36. A execução utiliza uma pasta nova `GSS_Browser_<identificador>` na raiz do perfil remoto validado, sem depender da localização de TEMP/TMP e sem criar um perfil ausente.

A pasta recebe permissão de modificação para o SID do usuário remoto. Nenhuma ACL preexistente fora da pasta criada é alterada. Antes de fechar o navegador, o módulo confirma computador/SID, valida o diretório e testa a escrita na sessão do usuário. Perfis, nomes de arquivo e junções continuam validados. Ao terminar, são removidos apenas os arquivos conhecidos e a pasta da operação, se vazia.

O destino local continua bloqueado, mas agora recebe mensagem específica. Nome inválido, acesso negado, compartilhamento indisponível e demais etapas possuem diagnóstico mais claro. A inexistência da pasta TEMP deixou de ser um pré-requisito; outras restrições de acesso ou do Agendador remoto continuam podendo impedir a execução.

Layout, categorias, Chrome/Edge, modos seguro/completo e certificados não foram alterados. A v3.36 está preservada e a v3.37 usa diretório de execução próprio.

## Validação

- Compilação sintática Python e testes de roteamento/runner executados em Linux.
- Acrescentados cinco testes estáticos de contrato da preparação (não executam PowerShell).
- Ampliado `tests/test_browser_cleanup.ps1` com criação de pasta sem TEMP, colisão de nomes, perfil ausente, caminhos de resultado e destino local/inválido. Esse teste é para Windows e não foi executado neste ambiente, que não possui PowerShell.
- A execução real via WMI, SMB e Agendador precisa ser validada em uma estação Windows autorizada, começando pela limpeza segura no remoto que apresentou o erro.
