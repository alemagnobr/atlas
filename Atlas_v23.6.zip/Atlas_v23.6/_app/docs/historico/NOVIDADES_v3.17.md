# Impressora padrão no resumo — v3.17

- O painel consulta a impressora padrão do usuário conectado à estação remota.
- A busca principal lê o valor `Device` do perfil carregado no registro remoto.
- A resolução do SID usa a conta de domínio e possui alternativa pelo perfil WMI carregado.
- Se o registro não responder, `Win32_Printer.Default` é usado como alternativa.
- O campo “Impressoras de rede” mostra, por exemplo, `IS0434 (Padrão)`.
- Se a padrão não estiver na lista coletada, ela é adicionada automaticamente ao resumo.
- Uma lista interna sem o sufixo `(Padrão)` preserva teste e definição de impressoras.
- Login salvo, inicializador reforçado, popups e as 26 ações continuam preservados.
