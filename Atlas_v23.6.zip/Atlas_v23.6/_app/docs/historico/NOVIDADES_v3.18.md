# Painel principal compacto — v3.18

- O prompt do `run.bat` inicia minimizado.
- O resumo remove os campos redundantes Estação, Conexão e Usuário remoto.
- Estação e usuário remoto passam a aparecer juntos no título conectado.
- O ponto verde pulsa suavemente enquanto a estação estiver conectada.
- O botão Conectar muda para Desconectar e limpa o painel ao ser acionado.
- Os cartões 01 Conectar/desconectar e 04 Central de suporte remoto foram removidos.
- O Menu principal não possui mais os blocos Acesso e conexão ou Sessão.
- A visão geral mantém somente os comandos mais usados pelo perfil.
- A impressora padrão, o login salvo, os popups e o inicializador reforçado foram preservados.
