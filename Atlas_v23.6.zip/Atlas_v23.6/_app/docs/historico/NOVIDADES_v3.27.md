# Popups adaptativos e tamanho dos perfis — v3.27

- Cadeado de **Admin local** agora abre três ações: atualizar informações, adicionar como administrador e remover de administrador.
- Operações administrativas são explícitas e não dependem mais de alternância automática.
- Popups de resultado, AD e discos/perfis ajustam largura e altura ao conteúdo e à área útil do monitor.
- Nenhum popup é maximizado; o tamanho permanece limitado à tela disponível.
- Perfis de usuário exibidos em cartões, seguindo a linguagem visual dos discos.
- Cálculo do espaço consumido por perfil pela pasta administrativa remota.
- Cada perfil informa tamanho, percentual do disco, estado, último uso e SID.
- Ferramenta **Legada** preservada sem alterações.
