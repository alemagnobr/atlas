# Auditoria funcional — v3.8

Comparação realizada com o código funcional anexado (`Texto colado(4).txt`).

## Menu principal

| Função | Implementação gráfica |
|---|---|
| Conectar/desconectar | Consulta WMI, ping e painel persistente |
| Controle remoto SCCM | Busca dos caminhos MECM/SCCM e abertura do CmRcViewer |
| Ping contínuo | Janela dedicada com `ping -t` |
| Administrador local | ADSI com inclusão/remoção conforme estado atual |
| Usuários e grupos locais | `lusrmgr.msc` apontado para a estação |
| Active Directory | `dsa.msc` |
| Grupos do usuário | DirectorySearcher/ADSI |
| Disco e perfis | WMI para unidades e perfis registrados |
| Internet e certificados | Tarefa interativa remota; fallback `certlm.msc` |
| Atualizar painel | Nova consulta completa de status |
| Voltar ao padrão | Nova sessão Windows com a conta padrão |

## Suporte ao computador

| Função | Implementação gráfica |
|---|---|
| Fechar Outlook | `taskkill` remoto para `outlook.exe` e `olk.exe` |
| Limpar DNS | Tarefa interativa; fallback WMI |
| GPUpdate | Tarefa interativa; fallback WMI |
| Logoff | `Win32Shutdown(4)` conforme o código original |
| Reiniciar | `shutdown /r /f /t 0 /m` conforme o original |
| Limpar TEMP | Tarefa na sessão do usuário, sem depender de WinRM |

## Suporte a impressoras

| Função | Implementação gráfica |
|---|---|
| Detectar impressoras | Registro Remoto, HKLM, HKU, CSR, StdRegProv e WMI |
| Grupos autorizados | `*-ImprimirDoc` em `OU=Impressoras_OU` |
| Instalar impressora | Tarefa interativa PrintUI; fallback global WMI |
| Remover driver HP | Executável Prodasen na sessão; fallback WMI |
| Instalar driver HP | Executável Prodasen na sessão; fallback WMI |
| Página de teste | WMI `PrintTestPage`; fallback PrintUI interativo |
| Definir padrão | PrintUI na sessão interativa |
| Limpar spooler | WMI, compartilhamento administrativo e reinício do serviço |

Todos os comandos técnicos exibidos pela interface possuem um caso correspondente no `bridge.ps1`. O funcionamento externo ainda depende das permissões INS, políticas de WMI, compartilhamentos administrativos, Active Directory, `printserver`, unidade `X:` e arquivos corporativos existentes na rede.
