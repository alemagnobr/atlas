# Popups mais compactos — v3.22

- O tamanho padrão dos popups foi reduzido de 620 × 500 para 570 × 440 pixels.
- O tamanho mínimo passou para 420 × 330 pixels.
- A área de conteúdo continua rolável para resultados extensos.
- Os botões “Copiar resultado” e “Fechar” permanecem disponíveis.
- Animação, cores de sucesso/erro e conteúdo retornado foram preservados.
