# v3.38 — Limpeza sem depender de D$

## Evidência e alteração

Na estação testada pelo operador, `Win32_Share` apresentou somente `ADMIN$`, `C$` e `IPC$`. A v3.37 ainda tentava preparar arquivos usando o compartilhamento da unidade do perfil. A ausência de `D$` impedia essa etapa, mesmo com `ADMIN$` acessível.

A v3.38 consulta o caminho de `ADMIN$` na própria estação, cria ali uma pasta exclusiva `GSS_Browser_<identificador>` e usa esse local para o módulo e seu resultado. Não cria compartilhamentos, não muda políticas e não altera ACLs de pastas preexistentes. Apenas a nova pasta recebe acesso de modificação para o usuário remoto.

O navegador e seus dados continuam sendo manipulados dentro da sessão interativa do usuário remoto, com verificação de computador/SID. O caminho do navegador agora é montado a partir de `LocalApplicationData` consultado nessa sessão. Dados em D: não são transferidos para C: nem acessados por D$. Perfis personalizados continuam fora do escopo.

O arquivo de resultado deve pertencer à pasta da operação, diretamente no diretório Windows remoto; identificador, nome, caminho, links/junções e capacidade de escrita são verificados. Falhas de preparação ocorrem antes do fechamento do navegador. Na finalização, apenas arquivos conhecidos da operação e sua pasta vazia são removidos. Uma queda de comunicação pode impedir essa remoção; não se deve considerar timeout como sucesso.

Layout, certificados, seleção Chrome/Edge, fechamento automático e listas segura/completa foram preservados. A v3.37 permanece disponível separadamente.

## Validação e limite do teste

- Compilação sintática Python aprovada.
- 18 testes Python aprovados: 10 testes de métodos da interface/runner com substitutos de Qt e 8 verificações estáticas do contrato entre scripts. Esses testes não executam PowerShell.
- Atualizado `tests/test_browser_cleanup.ps1`: construção de caminhos por ADMIN$, Windows remoto em unidade diferente, dados do navegador em D:, seleção Chrome/Edge, recusa de caminho vazio, validação da operação, colisões, limites de diretório e preservação das listas de limpeza. Esse teste não foi executado aqui, pois PowerShell/Windows não estão disponíveis.
- Ainda necessária validação real de escrita via ADMIN$, ACL da pasta nova, tarefa interativa, fechamento e limpeza na estação autorizada. A confirmação de leitura de ADMIN$ não comprova essas etapas.

## Como testar

Extraia completamente o ZIP, execute `run.bat`, confirme a versão 3.38, autentique como INS e conecte a estação remota. Salve o trabalho aberto e execute Limpeza segura com um dos navegadores. O log deve mostrar transporte via ADMIN$; se o módulo iniciar, também mostrará o caminho de dados descoberto no remoto. Se ocorrer erro, copie o resultado completo com a etapa indicada. Não execute limpeza completa com dados importantes sem considerar a perda de histórico, cookies e sessões descrita no README.
