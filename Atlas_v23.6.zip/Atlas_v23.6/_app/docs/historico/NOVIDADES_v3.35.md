# Novidades da v3.35

- A atualização do Trellix não mantém mais o aplicativo processando por até 195 segundos.
- O app confirma que a tarefa remota foi criada e iniciada, aguarda apenas dois segundos e libera a interface.
- Os comandos `/p`, `/c` e `/e` continuam sendo executados na estação remota em segundo plano.
- Cada etapa remota possui limite próprio de 45 segundos para impedir processo preso indefinidamente.
- A tarefa temporária é removida depois do disparo sem encerrar a instância já iniciada.
