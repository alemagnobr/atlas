# Saída rápida e troca de perfil silenciosa — v3.19

- A tela inicial ganhou o botão vermelho “Sair do software”.
- O botão encerra imediatamente a aplicação antes de entrar em qualquer perfil.
- A troca para usuário padrão ou INS utiliza a flag segura `CREATE_NO_WINDOW`.
- A interface gráfica do perfil escolhido continua abrindo normalmente.
- O prompt auxiliar não aparece junto com a nova sessão.
- O prompt do `run.bat` inicial continua minimizado e disponível para diagnóstico.
- Login salvo, painel compacto, pulso conectado, impressora padrão e popups foram preservados.
