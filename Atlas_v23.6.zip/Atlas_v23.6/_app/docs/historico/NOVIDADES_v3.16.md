# Inicializador corporativo reforçado — v3.16

- Corrigida a interpretação incorreta de retornos do `robocopy`.
- O caminho de origem agora é normalizado sem barra final problemática.
- O sucesso é determinado pela presença real dos arquivos essenciais.
- Se `robocopy` não preparar o aplicativo, `xcopy` é tentado automaticamente.
- Um log detalhado é criado em `%TEMP%\GerenciadorSuporteSenado_copia.log`.
- A mensagem de contingência orienta mover a pasta para `C:\Gerenciador_Suporte_Senado`.
- Login salvo, modo lateral, popups e todas as 26 ações foram preservados.
