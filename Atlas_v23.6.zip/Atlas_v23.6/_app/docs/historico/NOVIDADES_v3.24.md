# Melhorias de execução — v3.24

- Confirmação adicionada a **Fechar Outlook**, **Logoff remoto** e **Reiniciar computador**.
- Indicador circular animado no cartão de DNS, políticas, instalação de impressora, página de teste, impressora padrão e limpeza da fila.
- O indicador é encerrado automaticamente antes da apresentação do resultado, tanto em sucesso quanto em erro.
- Popup de resultado reduzido para 530 × 390 px, preservando rolagem, cópia e animação.
- Ferramenta **Legada** e backend de comandos preservados.
