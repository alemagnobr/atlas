# Novidades v3.41

- Chrome e Edge agora têm fallback de navegação interativa para abrir diretamente a tela de limpeza de dados.
- Caso a URL interna seja ignorada na abertura, o script ativa a janela do navegador, usa `Ctrl+L`, digita a página `clearBrowserData` e pressiona Enter.
- Nenhuma limpeza é executada automaticamente: o usuário ainda confirma as opções no navegador.
