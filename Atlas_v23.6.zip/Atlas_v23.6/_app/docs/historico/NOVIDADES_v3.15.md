# Acesso rápido protegido — v3.15

- A tela de login passa a mostrar somente os cartões de usuário padrão e INS.
- A senha é solicitada apenas no primeiro uso de cada transição entre perfis.
- As credenciais são armazenadas pelo Gerenciador de Credenciais do Windows.
- Nenhuma senha é gravada em TXT, JSON, registro próprio ou código-fonte.
- Credenciais vencidas são descartadas e solicitadas novamente automaticamente.
- O botão “Redefinir acessos salvos” remove os dois acessos do cofre do usuário atual.
- A correção do OneDrive, os popups, o modo lateral e as 26 ações foram preservados.
