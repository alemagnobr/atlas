# v3.36 — Navegadores e certificados

Suporte remoto passa a exibir Conexão e controle, Suporte ao computador e Navegadores e certificados, nessa ordem.

Na nova categoria, Limpeza segura e Limpeza completa permitem selecionar Chrome ou Edge. Ao clicar em OK na seleção, o navegador escolhido é fechado automaticamente na sessão remota, sem outra confirmação. A opção segura remove caches; a completa também remove cookies, histórico e dados locais dos sites contemplados pela lista de limpeza.

Senhas, favoritos, extensões, preenchimento automático e arquivos baixados são preservados. A opção completa desconecta contas dos sites, não equivale a apagar o perfil inteiro e não limpa dados na nuvem. Conteúdo não salvo nas abas pode ser perdido em ambas as opções.

Certificados digitais foi movido para a nova categoria sem mudar sua lógica ou a confirmação de exclusão. Demais rotinas mantidas.

Execução exige Windows e acesso WMI/compartilhamento administrativo/Agendador remoto. Somente perfis padrão Default e Profile N são atendidos. Ausência de usuário, links/junções, uso em outra sessão e falhas de acesso interrompem a operação. Consulte o README para escopo e limites de tempo.

A v3.35 permanece preservada. A validação em uma estação real deve conferir separadamente Chrome e Edge, modos seguro/completo, preservação de dados e retorno de erros de acesso.
