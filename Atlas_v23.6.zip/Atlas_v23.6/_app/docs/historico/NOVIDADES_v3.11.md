# Resultado em popup e atualização lateral — v3.11

- “Grupos do usuário no AD” abre o resultado em uma janela com desvanecimento suave.
- O popup oferece leitura ampliada, rolagem e botão para copiar o resultado.
- A consulta continua registrada no Console de atividades.
- “Atualizar painel” agora fica permanentemente na lateral, acima de “Modo lateral”.
- O atalho duplicado de atualização foi retirado somente da visão geral; permanece em Diagnóstico.
- Todas as 26 ações e integrações PowerShell continuam preservadas.
