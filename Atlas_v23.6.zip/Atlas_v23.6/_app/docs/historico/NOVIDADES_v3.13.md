# Modo lateral responsivo — v3.13

- A largura lateral passou a 740 px para preservar textos e cartões em telas Full HD.
- A barra de navegação compacta agora reserva 190 px para os rótulos completos.
- As margens da barra e do conteúdo diminuem automaticamente no modo estreito.
- O subtítulo decorativo da marca é recolhido apenas quando não há espaço suficiente.
- O título de boas-vindas reduz o tamanho sem desaparecer ou ser cortado.
- “Atualizar painel”, “Ferramenta legada” e “Sair do INS” permanecem totalmente visíveis.
- Todas as ações, popups e integrações da versão anterior foram preservados.
