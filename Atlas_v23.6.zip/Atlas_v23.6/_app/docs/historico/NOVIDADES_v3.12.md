# Retorno visual das operações — v3.12

- As operações executadas pelo backend agora apresentam um popup elegante ao terminar.
- Sucesso e erro possuem identificação visual própria em verde ou vermelho.
- Ping contínuo informa que o monitoramento foi iniciado em uma janela separada.
- Limpeza de DNS, GPUpdate, Outlook, TEMP, reinicialização e logoff exibem o retorno real do comando.
- Instalação, teste, definição e manutenção de impressoras também exibem o resultado.
- Consultas de grupos do AD, discos e perfis mantêm a visualização ampliada e copiável.
- A atualização lateral confirma quando o resumo do Menu principal foi renovado.
- Ações puramente locais de navegação, troca de perfil e fechamento não geram popup desnecessário.
