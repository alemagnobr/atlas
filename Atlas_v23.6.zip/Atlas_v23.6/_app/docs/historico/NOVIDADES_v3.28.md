# Cadeado direto e cópia da estação — v3.28

- Menu do cadeado removido.
- Clique no cadeado fechado remove o usuário de Admin local.
- Clique no cadeado aberto adiciona o usuário como Admin local.
- Quando o estado não estiver identificado, o mesmo clique atualiza as informações.
- Após adicionar ou remover, o estado administrativo é consultado automaticamente.
- Botão de atualização reduzido para 26 × 26 px.
- Novo botão logo abaixo para copiar o nome ou IP da estação conectada.
- Confirmação visual temporária exibida no próprio botão após a cópia.
- Ferramenta **Legada** preservada sem alterações.
