# Validação do Atlas v14.21

## Tema na sessão autenticada

1. Entre com o perfil padrão e alterne entre os temas claro e escuro.
2. Repita o teste na sessão INS, com Informações, Impressoras e Chamados já carregados.
3. Confirme que o seletor começa a se mover imediatamente.
4. Confirme que o quadro anterior desvanece sobre o novo tema sem clarão, congelamento ou salto visual.
5. Alterne várias vezes, aguardando o término de cada transição, e verifique se o rótulo permanece coerente.

## Retorno visual dos botões de atualização

1. Conecte uma estação e clique no ícone de atualizar do Controle da estação.
2. Abra Impressoras e atualize somente o contêiner de impressoras.
3. Teste também Atualizar em Chamados e os controles de atualização de FAQs e Orientações.
4. Em todos os casos, confirme que apenas o glifo de atualização gira durante a ação.
5. Confirme que o ícone volta à posição normal ao concluir ou falhar, sem pulsação do botão inteiro.

## Impressão de página de teste

1. Em Impressoras, localize o contêiner Impressoras de rede.
2. Clique no novo ícone de impressora e selecione uma impressora instalada.
3. Confirme que o popup exibe barra e percentual por aproximadamente dois segundos, ou até o backend terminar caso leve mais tempo.
4. Verifique no Console de atividades a confirmação do envio.
5. Repita cancelando a seleção e confirme que nenhuma ação ou popup é iniciado.
