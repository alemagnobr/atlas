# Validação — Atlas 8.8

## Chamados

O Atlas tenta primeiro a saída de impressão da pesquisa, que normalmente contém o conjunto completo. Se o Capri ainda devolver apenas a página atual visual, a ferramenta percorre `StartHit` por número de página e, como compatibilidade adicional, por deslocamentos de 25 registros. Os resultados são deduplicados pelo `TicketID`.

## Interface

- badges de ação e lançamento com máscara circular real;
- filtros avançados distribuídos em linhas completas;
- campo de usuário visível apenas nas modalidades que precisam dele;
- datas, situação e origem da consulta com larguras equilibradas;
- funcionamento preservado nos temas claro e escuro.
