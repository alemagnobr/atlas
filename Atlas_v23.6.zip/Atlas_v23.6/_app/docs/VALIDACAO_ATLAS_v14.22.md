# Validação do Atlas v14.22

## Título da janela

1. Abra o Atlas no Windows e observe a barra superior.
2. Confirme que aparece somente **Atlas — Suporte Avançado**.
3. Confirme que **Senado Federal** não aparece no título.
4. Confirme que o nome do Atlas não é repetido depois de um hífen.

## Marca lateral

1. Entre na sessão padrão e na sessão INS.
2. Confirme que, ao lado da logo, aparece somente **ATLAS** em uma linha.
3. Verifique o alinhamento vertical da palavra com o centro da logo.
4. Teste em janela normal e no modo lateral compacto.
5. Confirme que menus, atalhos e demais textos institucionais permanecem inalterados.
