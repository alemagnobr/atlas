# Validação ATLAS v14.52

## Cobertura desta versão

- Prévia temporária ordenada de forma explícita do chamado mais recente ao mais antigo.
- Uso da data de criação fornecida pelo Capri e do carimbo de data/hora do número do chamado como alternativa quando a grade não retorna a data.
- Limite mantido em 25 chamados, sem gravar a prévia no cache da Central.
- Metadados e instalador atualizados para 14.52.

## Execução local

```text
python -m unittest discover -s tests -v
python -m compileall -q main.py services tests
```

A confirmação visual e a consulta real precisam ser verificadas em Windows com uma sessão institucional do Capri.
