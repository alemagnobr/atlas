# Validação ATLAS v14.32

## Escopo

- abas primárias equilibradas em 50/50 e sem preenchimento residual;
- remoção dos títulos internos redundantes;
- ações de atualizar e copiar posicionadas junto ao campo da estação;
- fluxo PWM consolidado em um único botão, preservando conexão e encerramento confirmado;
- resultado de usuário apresentado como cartão institucional equivalente ao da estação;
- preservação integral da consulta ao Active Directory, Gestor de Senhas e recuperação de senha.

## Verificações automatizadas

- compilação de todos os módulos Python;
- suíte completa de testes unitários;
- validação estrutural integrada do projeto;
- conferência do pacote ZIP e dos metadados de versão.

## Resultado

- **205 testes automatizados:** aprovados;
- **24 verificações estruturais:** aprovadas, sem ocorrências;
- **compilação estática:** aprovada para todos os módulos Python;
- **metadados:** versão 14.32 consistente no aplicativo, runtime e instalador.

O ambiente de validação não possui o runtime gráfico PySide6; por isso, a renderização Qt deve receber uma conferência visual final no Windows institucional. Os contratos de composição, responsividade e tema foram cobertos por testes estáticos dedicados.
