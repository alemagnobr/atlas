# Validação — Atlas 10.0

1. Selecione qualquer outro filtro em **Chamados**, digite algo na busca e saia da seção.
2. Entre novamente em **Chamados** e confirme que o filtro volta para **Todos** e a pesquisa fica limpa.
3. Confirme que a faixa **Organizando todos os chamados…** aparece antes dos cartões.
4. Confirme que a barra permanece visível durante a montagem e desaparece quando os cartões terminam de renderizar.
5. Verifique os cartões de **Todos** nos temas claro e escuro, sem campos vazios, alturas colapsadas ou sobreposição.
6. Selecione **Fechados com êxito** e aguarde o redesenho automático.
7. Confirme que os centenas de cartões fechados aparecem completos e corretamente espaçados.
8. Alterne rapidamente para outra seção durante a entrada em **Chamados** e confirme que a barra não reaparece fora da seção.
9. Confirme que a pesquisa de FAQs e o indicador de troca de tema da v9.9 continuam funcionando.
