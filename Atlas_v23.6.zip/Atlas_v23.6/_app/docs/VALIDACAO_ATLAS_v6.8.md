# Validação — Atlas v6.8

## Escopo

- Busca local por título, categoria, caminho e conteúdo integral dos procedimentos.
- Tolerância a pequenos erros de digitação com ordenação por relevância.
- Navegação e transições sem acúmulo de páginas ou reconstruções desnecessárias.
- Entrega rápida das orientações pela rota CMD compatível com a política institucional.
- Identidade e ícone próprios do Atlas no Windows.

## Critérios automatizados

- Sintaxe Python validada por `compileall` e AST.
- Contratos de versão, catálogo, bridge, pesquisa, ícone e orientações executados por `unittest`.
- Catálogo de orientações regenerado a partir das 697 FAQs.
- Arquivo ZIP verificado após o empacotamento.

## Verificação recomendada em estação

1. Pesquisar uma FAQ por palavras do corpo do procedimento.
2. Repetir a pesquisa com um pequeno erro ortográfico e conferir a relevância.
3. Alternar rapidamente entre três áreas do menu e entre os modos lateral e completo.
4. Enviar uma orientação e confirmar que a janela aparece sem a espera anterior.
5. Conferir o ícone do Atlas na janela, na barra de tarefas e na visualização de alternância do Windows.
