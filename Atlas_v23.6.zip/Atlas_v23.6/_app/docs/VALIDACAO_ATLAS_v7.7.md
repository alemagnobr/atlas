# Validação — Atlas v7.7

## Escopo

- Orientações incorporadas aos cartões das FAQs por consulta O(1) em memória.
- Pré-visualização obrigatória, editável e fiel ao conteúdo enviado ao usuário.
- Exclusão individual persistente sem apagar a FAQ correspondente.
- Atalhos laterais para Active Directory, Gerenciamento do Computador e Windows + L.

## Verificações

- Compilação sintática do Python e análise sintática do PowerShell.
- Execução integral da suíte automatizada.
- Conferência da estrutura e integridade do pacote ZIP final.
