# Validação — Atlas 10.1

1. Entre em **Chamados** com um catálogo já salvo.
2. Confirme que pesquisa, filtro e botões mantêm a altura e o espaçamento normais.
3. Confirme que a faixa **Organizando todos os chamados…** aparece abaixo do painel de filtros e acima dos resultados.
4. Confirme que a faixa permanece visível durante a montagem e desaparece quando os cartões terminam de renderizar.
5. Verifique que nenhum texto, campo ou botão fica cortado enquanto a faixa está visível.
6. Teste nos modos claro, escuro, janela completa e modo lateral.
7. Confirme a renderização completa de **Todos** e **Fechados com êxito**.
8. Confirme que as correções anteriores continuam funcionando.
