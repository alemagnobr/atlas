# Validação — Atlas v6.9

## Escopo

- Orientação remota limitada a caminho da Intranet e/ou contato responsável.
- Mapeamento sob demanda de FAQ específica a partir das 697 FAQs locais.
- Pesquisa local sem janelas auxiliares de sugestões.
- Ícone nativo preservado na instância autenticada pelo perfil INS.

## Verificação recomendada

1. Digitar palavras e erros simples nos campos de FAQs e orientações e confirmar que nenhuma janela auxiliar aparece.
2. Informar uma FAQ não presente nas orientações gerais e confirmar o cartão temporário em **FAQ específica**.
3. Enviar uma orientação e conferir que a estação recebe somente caminho/contato, aviso da chefia, agradecimento e assinatura.
4. Entrar no INS e conferir o ícone do Atlas na barra de tarefas e no `Alt+Tab`.
