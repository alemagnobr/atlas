# Validação ATLAS v14.40

## Escopo

- ausência de qualquer autenticação automática do PWM na abertura do Atlas;
- uso do Chrome normal já autenticado, sem perfil Chromium separado;
- extensão local limitada ao domínio `gestorsenhas.senado.leg.br`;
- ponte local temporária para entrega dos cookies da sessão ativa;
- preservação do login do Chrome quando o operador desconecta o PWM no ATLAS;
- confirmação explícita em cada consulta, depois da conclusão do Active Directory;
- opções de consultar, abrir o PWM ou manter somente os dados do AD;
- retomada automática da consulta depois do login sem repetir a pergunta;
- revalidação limitada para impedir ciclos de autenticação;
- abas primárias visíveis e equilibradas mesmo durante a montagem inicial do painel;
- confirmação da sessão pelo Chrome normal já autenticado;
- ponte local autenticada entre a sessão padrão do Windows e a interface INS;
- captura autorizada dos cookies somente do domínio do PWM pela extensão local;
- gravação protegida obrigatória antes de declarar a sessão conectada;
- nenhum logout do Chrome pessoal ao desconectar o PWM no ATLAS;
- seleção do resultado PWM por login, nome completo ou e-mail institucional;
- leitura otimizada somente de Perfil e Status;
- painel de usuário no mesmo padrão estrutural do resumo da estação;
- campos essenciais do Active Directory e dados complementares do PWM;
- estado pulsante e acionável de senha expirada;
- contagem regressiva do vencimento da senha;
- sincronização automática entre a estação consultada e seu usuário conectado;
- alinhamento da identidade do usuário na estação;
- cartões de ação em duas colunas no modo lateral, com quebra segura abaixo de 420 px;
- remoção dos dois botões redundantes do painel de usuário.

## Verificações previstas

- compilação estática dos módulos Python;
- suíte completa de testes unitários;
- contratos dedicados de largura mínima e composição lateral;
- validação estrutural integrada;
- integridade e metadados do pacote ZIP.

## Resultado

- **254 testes automatizados:** aprovados;
- **24 verificações estruturais:** aprovadas, sem ocorrências;
- **compilação estática:** aprovada para todos os módulos Python;
- **contratos de usuário e lateral:** painel, integração PWM, sincronização, largura mínima e composição aprovados;
- **metadados:** versão 14.40 consistente no aplicativo, runtime e instalador;
- **empacotamento:** raiz do ZIP corrigida, sem a pasta `worktree`.

O ambiente de validação não possui o runtime gráfico PySide6. A conferência visual final e a instalação única da extensão devem ser realizadas no Windows institucional, mantendo os contratos automatizados como proteção contra regressão.
