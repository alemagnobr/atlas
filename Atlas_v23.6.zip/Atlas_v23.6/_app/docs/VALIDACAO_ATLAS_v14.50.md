# Validação ATLAS v14.50

## Cobertura desta versão

- A prévia temporária pesquisa com o nome completo do Active Directory.
- Um chamado só é incluído se “Nome do usuário cliente” corresponder ao nome completo, ou se o título integral contiver esse nome.
- Títulos completos são lidos do atributo do link do Capri quando disponível; os resultados permanecem deduplicados e limitados aos 25 mais recentes.
- O catálogo persistente da Central de Chamados permanece inalterado pela consulta temporária.
- Metadados e instalador atualizados para 14.50.

## Execução local

```text
python -m unittest discover -s tests -v
python -m compileall -q main.py services tests
```

A confirmação visual e a consulta real precisam ser verificadas em Windows com uma sessão institucional do Capri.
