# Validação do ATLAS v14.20

## Escopo

- progresso com percentual na atualização de chamados;
- progresso não bloqueante de instalação e definição da impressora padrão;
- atualização seletiva dos contêineres de impressoras;
- consulta seletiva do estado de Admin local;
- controles compactos de impressoras com atualização, ping, web, Admin e logoff;
- preservação da confirmação de logoff e das funcionalidades da v14.19.

## Garantias estruturais

- o progresso visual para em 94% enquanto a operação remota não confirma o término;
- instalar impressora respeita o mínimo visual de 5 segundos;
- definir impressora padrão respeita o mínimo visual de 2 segundos;
- as duas ações atualizam as impressoras em Informações e Impressoras;
- o botão de atualização do painel Impressoras altera somente seu resumo local;
- a mudança de Admin atualiza somente o campo de Admin e o cadeado correspondente;
- chamados e FAQs continuam usando o processo PowerShell em segundo plano;
- consultas seletivas possuem prazos próprios para não prender a interface.

## Validação automatizada

- compilação de todos os módulos Python;
- suíte completa de testes unitários;
- testes específicos da v14.20 para progresso, marcadores do bridge e atualização granular;
- verificação de integridade do pacote ZIP.

## Teste prático recomendado no Windows institucional

1. Conectar uma estação e abrir **Impressoras**.
2. Confirmar a ordem dos ícones: atualizar, ping, web, Admin e logoff.
3. Instalar uma impressora e verificar o progresso por no mínimo 5 segundos.
4. Definir a padrão e verificar o progresso por no mínimo 2 segundos.
5. Confirmar que somente os contêineres de impressoras são sincronizados.
6. Alternar o Admin local e conferir o cadeado verde/vermelho sem recarga completa.
7. Atualizar chamados e acompanhar o percentual até a resposta do Capri.
