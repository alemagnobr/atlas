# Validação — Atlas 8.8

## Itens validados

- nome completo do AD enviado ao filtro `CreatedUserIDs` do Capri;
- paginação automática por `StartHit`/`Page`, com deduplicação por `TicketID`;
- mapeamento completo sem período quando acionado por “Mapear meus chamados”;
- classificação local em abertos, pendentes, finalizados com êxito e outros finalizados;
- filtro local por estado;
- layout de uma coluna para chamados no modo lateral;
- identificação visível e persistência do modo escuro.

## Segurança do resultado

Se o nome completo do operador não existir no campo **Criado por** do Capri, a consulta é interrompida. O Atlas não substitui esse filtro por proprietário ou por uma pesquisa ampla.
