# Validação — Atlas v7.3

- Ao clicar em **Conectar**, o botão deve exibir **Consultando…** com o ícone de sincronização girando.
- Durante a consulta, o campo da estação, o botão principal, atualizar e copiar devem permanecer indisponíveis.
- O cartão de controle deve ganhar borda verde e a mensagem de andamento deve aparecer em uma faixa destacada.
- Pressionar Enter ou clicar novamente não deve iniciar uma segunda consulta.
- Ao concluir com sucesso, o botão deve mudar para **Desconectar** e a mensagem deve informar que o painel está sincronizado.
- Em falha, o botão deve voltar para **Conectar**, o campo deve ser liberado e a mensagem deve informar que a conexão não foi estabelecida.
- Ao atualizar uma estação conectada, o botão deve exibir **Sincronizando…** até o fim da operação.
