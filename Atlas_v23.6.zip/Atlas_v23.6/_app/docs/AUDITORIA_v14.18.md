# Auditoria de manutenção e desempenho — ATLAS v14.18

## Resultado

A validação estrutural passou a executar uma manutenção conservadora, sem atuar em rede, Active Directory, Capri ou estações remotas. Ela continua fora da thread da interface e é adiada quando uma operação PowerShell está ativa.

## O que pode ser removido

- somente arquivos `*.tmp` abandonados há pelo menos 24 horas;
- somente dentro do armazenamento local pertencente ao ATLAS;
- caches transitórios em memória que expiraram ou ultrapassaram limites explícitos.

## O que é sempre preservado

- catálogos e conteúdo de FAQs;
- chamados e seus índices persistentes;
- preferências, aparência e configurações;
- credenciais e sessão protegida do Capri;
- scripts, recursos, executáveis e catálogos distribuídos;
- versões anteriores e dados de reversão;
- diagnósticos úteis do aplicativo.

## Otimizações estruturais

- o cache de ícones usa descarte incremental, evitando uma reconstrução completa durante mudanças de tema;
- caches de busca permanecem limitados e são reconstruídos somente quando necessário;
- consultas de discos/perfis expiradas deixam a memória após cinco minutos;
- o inicializador copia para a área local somente componentes de execução, excluindo testes, documentação e ferramentas de build;
- nenhuma limpeza participa do caminho de conexão com uma estação.

## Limites

Essa manutenção impede acúmulo local e reduz trabalho repetido da interface. Ela não acelera respostas de WMI, rede, AD ou Capri quando esses serviços externos estão lentos ou bloqueados.
