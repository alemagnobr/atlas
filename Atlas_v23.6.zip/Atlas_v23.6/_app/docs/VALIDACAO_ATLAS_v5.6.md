# Validação — Atlas v5.6

## Catálogo de orientações

- Fonte processada: `data/faqs.txt`.
- FAQs reconhecidas: 697.
- Orientações com caminho `Intranet > Central de Serviços`: 103.
- Números normalizados no padrão oficial de oito dígitos.
- Catálogo gerado: `data/orientations_catalog.json`.
- Geração reproduzível por `tools/build_orientation_catalog.py`.

## Interface

- Nova rota lateral **Orientações ao usuário**.
- Busca com sugestões por FAQ, assunto, categoria, título e caminho.
- Categorias recolhíveis e cartões responsivos.
- Cada cartão apresenta resumo, caminho oficial e botão de envio.

## Exibição remota

- A estação e a sessão interativa são validadas antes do envio.
- Primeiro e último nome são consultados no Active Directory.
- O popup usa WPF, permanece em primeiro plano e não exige instalação adicional.
- O Atlas somente confirma sucesso depois do evento de renderização do popup.
- Falhas de sessão, perfil, execução ou confirmação retornam mensagem explícita.

## Verificações automatizadas

- Compilação estrutural de todo o código Python.
- Testes contratuais do Atlas.
- Integridade e conteúdo do catálogo JSON.
- Presença e ordem do despachador PowerShell para a ação remota.
