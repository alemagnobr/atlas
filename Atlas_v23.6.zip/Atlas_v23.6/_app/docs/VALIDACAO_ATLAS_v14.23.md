# Validação do Atlas v14.23

## Cards de ação

1. Abra Informações, Suporte remoto e Impressoras.
2. Confirme que todos os cards de ação estão mais baixos e próximos entre si.
3. Verifique que ícone, título, descrição e botão permanecem alinhados verticalmente.
4. Confirme que descrições longas quebram linha sem serem cortadas.
5. Repita em janela normal, meia tela e modo lateral.
6. Execute uma ação e confirme que o spinner continua centralizado no lugar do botão.
