# Validação do ATLAS v14.31

## Escopo

A versão 14.31 acrescenta o Controle de Usuários sem substituir o Controle da Estação. A implementação separa consultas ao Active Directory, sessão do Gestor de Senhas e recuperação de senha das rotinas remotas já existentes.

## Contratos verificados automaticamente

- a consulta direta aceita somente login de rede normalizado e usa filtro LDAP exato;
- nenhuma estação precisa estar conectada para consultar um usuário;
- a consulta utiliza um processo assíncrono próprio, independente dos processos da estação e do Capri;
- as sessões do Capri e do Gestor utilizam arquivos de cookies e escopos de credenciais diferentes;
- credenciais são transportadas em Base64 pelo ambiente do processo, nunca por argumentos de linha de comando;
- marcadores JSON do usuário e do Gestor não são apresentados no Console de atividades;
- o Active Directory continua visível quando o Gestor está indisponível;
- a recuperação exige pré-visualização, confirmação explícita e intervalo mínimo contra repetição;
- o e-mail de recuperação é mascarado na interface;
- o encerramento do ATLAS tenta finalizar separadamente as duas sessões web.

## Validação necessária na rede institucional

O Gestor de Senhas é um serviço interno. Os itens abaixo devem ser conferidos em uma estação autorizada do Senado antes de habilitar a versão para uso geral:

1. abrir **Informações > Controle de usuários**;
2. consultar um login conhecido e confirmar os dados do Active Directory;
3. clicar em **Conectar Gestor** e validar autenticação, reutilização e encerramento da sessão;
4. consultar o mesmo usuário e conferir Perfil, Status, Histórico e Política;
5. selecionar uma conta de teste autorizada e conferir apenas a prévia mascarada da recuperação;
6. somente com autorização, confirmar um envio e validar a mensagem de sucesso do servidor;
7. repetir a consulta após expirar a sessão para conferir a reconexão;
8. manter uma estação conectada durante todo o teste e confirmar que ela não é desconectada nem bloqueada.

O ATLAS não contorna restrições do portal. Se a instalação institucional utilizar nomes de campos ou rotas diferentes, o Console mostrará uma falha controlada e os dados do Active Directory permanecerão disponíveis.

## Resultado esperado

- interface responsiva durante todas as consultas;
- nenhum carregamento infinito;
- falha parcial do Gestor sem perda do resultado do AD;
- ausência de senha, cookie, token, código ou e-mail pessoal completo nos logs;
- nenhuma solicitação de recuperação enviada durante uma consulta comum.
