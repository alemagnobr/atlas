# Validação do Atlas v14.30

## Escopo

- nome completo alinhado ao título **USUÁRIO**;
- destaque adaptativo do nome confirmado pelo AD;
- login de rede exibido abaixo no formato `SENADO\\login`;
- estados neutros durante consulta e sem usuário conectado;
- ícones íntegros nos cartões de **Softwares (X:)**;
- preservação do tamanho compacto e dos temas claro e escuro.

## Verificações automatizadas

- contrato de versão do aplicativo e do instalador;
- separação dos componentes de nome e login;
- normalização de contas de domínio, locais e UPN;
- regras visuais específicas para os dois temas;
- área segura do ícone sem máscara de recorte;
- suíte completa de regressão e validação estrutural.

## Resultado esperado

O nome do usuário aparece destacado ao lado de **USUÁRIO**, a conta de rede permanece logo abaixo e os ícones dos executáveis são apresentados sem cortes em diferentes escalas do Windows.
