# Validação — Atlas 9.7

1. Inicie o Atlas diretamente no modo claro e abra **Chamados**.
2. Selecione **Pendentes** e depois **Todos**, sem alternar o tema.
3. Confirme que o catálogo completo aparece após a montagem, com conteúdo e altura corretos em todos os cartões.
4. Repita iniciando diretamente no modo escuro.
5. Confirme que cada cabeçalho fica acima do seu cartão, sem textos ou bordas sobrepostos.
6. Confirme que número, situação, usuário, título, detalhes, etapa e botão permanecem dentro do cartão.
7. Alterne entre **Todos**, **Abertos**, **Pendentes** e **Fechados com êxito** e retorne a **Todos**.
8. Confirme que o tema não pisca nem muda de seleção durante o redesenho automático.
9. Compare a geometria e o espaçamento dos cartões com a v9.3.
10. Confirme que hover, ícones claros e autenticação escura do Capri continuam funcionando.
