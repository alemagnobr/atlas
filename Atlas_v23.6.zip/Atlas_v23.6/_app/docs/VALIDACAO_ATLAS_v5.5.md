# Validação — Atlas 5.5

- ItemID curto convertido para o número público completo da FAQ.
- Conversão aplicada também aos itens carregados do cache existente.
- Pesquisa aceita tanto o ItemID antigo quanto o número completo.
- Número e título são exibidos em elementos separados.
- Botões de copiar e abrir ficam agrupados no mesmo bloco visual.
- Catálogos usam uma coluna em larguras laterais e duas somente quando há espaço adequado.
- Cartões de software e FAQ possuem estilos próprios e alinhamento consistente.

## Conferência visual

No modo lateral, abra Softwares autorizados e FAQs. Os cartões devem ocupar a largura disponível, sem comprimir títulos. Uma FAQ armazenada como `1523` deve aparecer e ser copiada como `10001523`.
