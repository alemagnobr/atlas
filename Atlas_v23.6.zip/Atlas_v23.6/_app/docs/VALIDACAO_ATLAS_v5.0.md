# Validação estrutural — Atlas 5.0

## Resultado

- Compilação estática de todos os módulos Python: aprovada.
- Suíte automatizada: 18 testes aprovados.
- Contratos das rotinas de navegador e execução: preservados.
- Identidade, versão, diretório de execução e cache de FAQs: alinhados em `v5.0`.
- Popups de resposta: dimensões mínimas, margens e espaçamento reduzidos.
- Ícones vetoriais: traço reforçado para melhor nitidez.
- Transições: duração reduzida para resposta mais rápida.

## Validação necessária no Senado

As ações PowerShell dependem do Windows, domínio, WMI, sessões interativas e permissões institucionais. Antes da distribuição geral, valide em uma estação de homologação:

1. autenticação INS e retorno ao login;
2. conexão e desconexão de uma estação;
3. discos, perfis e unidades de rede;
4. SCCM, certificados, impressoras e Trellix;
5. catálogo, autenticação e exportação de FAQs;
6. alternância entre monitores e modo lateral.

Essa validação preserva as rotinas operacionais existentes e confirma o comportamento no ambiente real, que não pode ser reproduzido fora do domínio.
