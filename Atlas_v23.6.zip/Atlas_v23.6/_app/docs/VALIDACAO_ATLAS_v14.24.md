# Validação do Atlas v14.24

## Raio da marca lateral

1. Entre no painel do Atlas e aguarde dois segundos.
2. Confirme que o raio surge ao lado de **ATLAS** e é revelado de cima para baixo.
3. Observe que o brilho ganha força, apresenta um clarão curto e desaparece suavemente.
4. Confirme as pausas sucessivas aproximadas: 2, 5, 3, 2, 4 e 5 segundos.
5. Alterne entre os temas: azul-ciano no escuro e verde-dourado no claro.
6. Teste em janela normal e no modo lateral, confirmando que logo, nome e raio não são cortados.
7. Minimize o aplicativo e confirme que o restante do funcionamento permanece responsivo.
