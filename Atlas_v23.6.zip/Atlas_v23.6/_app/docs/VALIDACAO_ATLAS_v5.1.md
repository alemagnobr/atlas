# Validação — Atlas 5.1

- Compilação estrutural dos módulos Python: aprovada.
- Suíte automatizada: 20 testes aprovados.
- Ações de fechamento do Chrome e Edge classificadas como destrutivas e protegidas por confirmação.
- Encerramento remoto validado por contrato: `taskkill` remoto, fallback WMI e conferência de processos restantes.
- Cache persistente de FAQs com migração automática da versão 5.0.

## Homologação no domínio

Conecte uma estação de teste, mantenha múltiplas janelas do navegador abertas e execute cada ação separadamente. O popup deve informar a quantidade encerrada, e o Gerenciador de Tarefas remoto não deve conservar processos `chrome.exe` ou `msedge.exe` do navegador selecionado.
