# Validação — Atlas 10.2

1. Entre em **Chamados** e aguarde a montagem inicial de **Todos**.
2. Digite lentamente no campo e confirme que os caracteres aparecem sem travamento e os resultados ainda não mudam.
3. Escolha outra situação e confirme que a lista ainda permanece inalterada.
4. Clique em **Pesquisar** e confira a barra abaixo do painel antes da montagem dos novos resultados.
5. Durante a barra, confirme que campo, seletor e botão ficam temporariamente bloqueados.
6. Pesquise novamente usando a tecla Enter e confirme o mesmo comportamento.
7. Selecione **Fechados com êxito**, clique em **Pesquisar** e confira barra, cartões completos e espaçamento correto.
8. Limpe o texto, selecione **Todos**, clique em **Pesquisar** e confirme o retorno do catálogo completo.
9. Teste nos modos claro, escuro, janela completa e modo lateral.
10. Confirme que nenhuma pesquisa local consulta o Capri e que as correções anteriores continuam funcionando.
