# Segurança e privacidade

## Credenciais

- senhas não são gravadas no código nem em arquivos de configuração;
- credenciais reutilizáveis ficam no Gerenciador de Credenciais do Windows;
- use **Redefinir acessos salvos** após mudança de senha;
- nunca inclua credenciais em commits, issues ou screenshots.

## Princípio de menor privilégio

Use o perfil INS somente durante rotinas que realmente necessitem de privilégio administrativo. Ao terminar, clique em **Sair do INS**.

## Dados temporários

Algumas consultas criam tarefas, scripts ou chaves temporárias na estação. O código utiliza blocos de limpeza para removê-los ao final. Interrupções inesperadas devem ser verificadas em homologação.

## Publicação no GitHub

O repositório deve ser privado. Antes do primeiro push:

```powershell
git status
git diff --cached
git grep -n -i -E "password|senha|token|secret|credential"
```

Revise especialmente:

- logs e diagnósticos;
- nomes e IPs reais de estações;
- dados pessoais em imagens;
- caminhos internos e nomes de servidores;
- certificados e arquivos de credenciais.

O `.gitignore` reduz o risco, mas não substitui revisão humana.

## Relato de vulnerabilidade

Não abra uma issue pública com detalhes exploráveis. Comunique os mantenedores e a área de segurança pelos canais internos autorizados.
