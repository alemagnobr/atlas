# Validação — Atlas v6.6

## Apresentação da orientação

- Fundo branco e texto preto (`color F0`).
- Título “Orientação do Suporte”, sem identificação do Atlas no conteúdo.
- Quebra prévia dos parágrafos por palavra.
- Largura entre 64 e 92 colunas e altura entre 18 e 46 linhas, calculadas pelo conteúdo.
- Margem esquerda uniforme e encerramento automático após dez minutos.

## Ampliação do catálogo

- FAQs analisadas: 697.
- Orientações estruturadas: 126.
- Orientações com telefone, ramal ou setor responsável: 32.
- Novas orientações exclusivamente de contato: 23.
- Entrada falsa da tabela de patrimônio de leitores biométricos descartada pelo filtro de contexto.

## Verificações

- Compilação estrutural do código Python.
- Regeneração determinística do catálogo.
- Contratos de caminho ou contato obrigatório.
- Ausência de gravação remota na rota CMD.
- Integridade do pacote ZIP.
