# Validação — Atlas 5.4

- O stderr do `taskkill` não encerra mais antecipadamente a ação.
- Cada tentativa executa `Terminate()` por WMI e um `taskkill` isolado via `Start-Process`.
- São realizadas até três tentativas, sempre seguidas de nova consulta remota.
- O popup de sucesso depende da ausência real de `chrome.exe` ou `msedge.exe`.
- Falhas persistentes apresentam os PIDs restantes para diagnóstico.

## Teste no domínio

Abra várias janelas do Edge e do Chrome, execute cada fechamento e confira o Gerenciador de Tarefas. Caso um processo protegido permaneça, o Atlas deve aguardar as três tentativas e apresentar apenas os PIDs ainda ativos, sem expor mensagens intermediárias do `taskkill`.
