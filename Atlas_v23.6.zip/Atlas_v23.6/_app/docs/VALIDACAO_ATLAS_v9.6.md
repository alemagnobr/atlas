# Validação — Atlas 9.6

1. Inicie o Atlas diretamente no modo escuro.
2. Abra **Chamados** e selecione **Todos** com o catálogo completo.
3. Confirme que cada cabeçalho fica acima do seu cartão, sem textos ou bordas sobrepostos.
4. Confirme que número, situação, usuário, título, detalhes, etapa e botão permanecem dentro do cartão.
5. Alterne entre **Todos**, **Abertos**, **Pendentes** e **Fechados com êxito**.
6. Compare a altura natural e o espaçamento com a v9.3.
7. Confirme que hover, ícones claros e autenticação escura do Capri continuam funcionando.
