# Validação — Atlas v8.0

## Escopo

- Seletor exclusivo **Relacionada** / **Frase exata** no cartão de pesquisa local de FAQs.
- Pesquisa relacionada preservada como comportamento padrão.
- Correspondência exata da expressão completa, na mesma ordem e com limites de palavra.
- Normalização de maiúsculas, minúsculas, acentos e espaços em ambos os modos.
- Contagem visual específica para correspondências exatas.

## Segurança funcional

A alteração atua somente sobre o índice local já carregado. Não consulta o Capri, não remapeia o catálogo e não modifica nenhuma FAQ.

## Compatibilidade

O modo relacionado continua usando a busca ranqueada anterior. Os caches são separados por modo para impedir que resultados relacionados sejam reutilizados na pesquisa exata.
