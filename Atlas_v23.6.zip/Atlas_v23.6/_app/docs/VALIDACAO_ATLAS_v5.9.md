# Validação — Atlas v5.9

## Sintoma corrigido

O popup aparecia por poucos segundos e desaparecia antes que a orientação pudesse ser lida.

## Causa

A função genérica de tarefas interativas excluía a tarefa três segundos após iniciá-la. Essa limpeza é apropriada para comandos rápidos, porém poderia encerrar o processo WPF que mantinha o popup aberto.

## Correção

- `Invoke-InteractiveTask` recebeu o controle `DeleteAfterStart`, mantendo o comportamento anterior como padrão.
- Somente a tarefa visual de orientação usa `DeleteAfterStart = false`.
- O popup utiliza `ShowDialog()` e permanece aberto até o clique em **Entendi**.
- Uma nova orientação encerra e substitui uma janela anterior.
- O limite de execução de uma hora continua protegendo contra processos abandonados.
- Quando a renderização falha, a tarefa visual é encerrada antes do fallback nativo.
