# Validação — Atlas v5.8

## Falhas corrigidas

- `WriteAllText`: **O nome da rede não foi encontrado**.
- `msg.exe`: **Parâmetro(s) inválido(s)** para contas cujo login é um CPF.

## Estratégia

- Consulta `Win32_OperatingSystem.WindowsDirectory` na estação.
- Converte a unidade do Windows em compartilhamento administrativo, sem usar a unidade do perfil.
- Armazena `.ps1` e marcador somente em `Windows\Temp`.
- Direciona `msg.exe` para `*`, representando a sessão ativa.
- Executa primeiro o aviso dentro da sessão; RPC remoto fica como último fallback.
- Não exibe a saída OEM/ANSI do executável nativo no console UTF-8.

## Segurança

- Trellix permanece ativo e inalterado.
- Não há alteração de regras, exclusões, serviços ou políticas permanentes.
- Arquivos temporários são removidos ao final da operação.
