# Validação — Atlas 9.4

1. Inicie o Atlas diretamente em modo escuro e abra **Chamados**.
2. Passe o mouse sobre cartões abertos, pendentes e finalizados; o fundo deve permanecer escuro e todo texto deve continuar legível.
3. Confira os ícones de abrir, copiar, pesquisar, atualizar e bloquear: tons originalmente azuis devem aparecer em ciano claro.
4. Alterne para o modo claro e novamente para o escuro; os ícones devem mudar imediatamente junto com a interface.
5. Clique em **Acessar Capri** e confira corpo, rótulo, campo, botões e barra de título em tons escuros.
6. Confirme que a grade de chamados em **Todos** mantém a renderização e as dimensões originais da v9.3.
