# Validação ATLAS v14.45

## Escopo

- incluir acesso rápido ao PWM no card **Senha expirada**;
- padronizar a hierarquia de título e valor do resumo da estação;
- pesquisar automaticamente todo o catálogo local de chamados;
- restringir a atualização rápida aos chamados de ontem e hoje.

## Comportamentos protegidos

- o botão **PWM** usa a mesma preferência de navegador dos demais links e não altera a sessão da recuperação;
- títulos e valores da estação permanecem separados nos cards comuns, de Admin local e de impressoras;
- a busca possui debounce, troca temporariamente para **Todos** e restaura o filtro anterior quando é limpa;
- a busca continua exclusivamente local e usa o índice normalizado já existente;
- **Atualizar** envia exatamente ontem e hoje ao Capri;
- somente o intervalo retornado é substituído, preservando chamados de outros dias e meses mapeados.

## Resultado automatizado

- testes unitários e contratuais aprovados;
- verificações estruturais aprovadas;
- sintaxe Python compilada;
- metadados 14.45 consistentes no aplicativo, runtime e instalador.

## Homologação necessária

- confirmar visualmente os cards nos temas claro e escuro em Windows 10/11;
- validar a abertura do PWM com as preferências Padrão, Chrome e Edge;
- validar a atualização de ontem e hoje em uma sessão autenticada do Capri.
