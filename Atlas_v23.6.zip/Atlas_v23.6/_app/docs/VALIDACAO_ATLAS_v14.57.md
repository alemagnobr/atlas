# Validação ATLAS v15.20

- A frase sob “Bem-vindo ao Atlas” corresponde a “Assistência Técnica e Lógica de Apoio ao Senado”.
- Título da janela de login, rodapé e fluxo de fechamento do Outlook permanecem os da versão anterior.
- Metadados e caminhos de instalação foram atualizados para 15.20.

Verificação local: `python -m unittest discover -s tests -q` e `python -m compileall -q main.py services tests`.
