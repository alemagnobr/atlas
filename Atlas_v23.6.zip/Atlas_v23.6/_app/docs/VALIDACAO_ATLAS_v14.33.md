# Validação ATLAS v14.33

## Escopo

- responsividade do painel de informações em modo lateral;
- consulta de usuário distribuída em duas linhas abaixo de 620 px;
- cards de ações em uma coluna na largura lateral;
- remoção de larguras mínimas que provocavam rolagem ou corte horizontal;
- preservação do layout normal em duas colunas;
- preservação das sessões Capri/PWM e da recuperação de senha.

## Verificações previstas

- compilação estática de todos os módulos Python;
- suíte completa de testes unitários;
- contratos dedicados da responsividade lateral;
- validação estrutural integrada;
- integridade e metadados do pacote ZIP.

## Resultado

- **210 testes automatizados:** aprovados;
- **24 verificações estruturais:** aprovadas, sem ocorrências;
- **compilação estática:** aprovada para todos os módulos Python;
- **contratos responsivos:** largura lateral, grade em uma coluna e consulta de usuário em duas linhas aprovadas;
- **metadados:** versão 14.33 consistente no aplicativo, runtime e instalador.

O ambiente de validação não possui o runtime gráfico PySide6. A composição foi verificada por contratos estáticos e deve receber a conferência visual final no Windows institucional.
