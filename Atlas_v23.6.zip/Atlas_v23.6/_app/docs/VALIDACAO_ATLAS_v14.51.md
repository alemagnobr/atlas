# Validação ATLAS v14.51

## Cobertura desta versão

- Busca temporária do Capri pelo nome completo do Active Directory.
- Inclusão de chamados por correspondência do nome no cliente, no título ou no texto integral da linha retornada pelo Capri.
- Localização do link do chamado em qualquer posição da linha.
- Deduplicação e limite de 25 chamados mais recentes correspondentes; resultados sem persistência no cache da Central.
- Metadados e instalador atualizados para 14.51.

## Execução local

```text
python -m unittest discover -s tests -v
python -m compileall -q main.py services tests
```

A confirmação visual e a consulta real precisam ser verificadas em Windows com uma sessão institucional do Capri.
