# Validação — Atlas 8.8

## Escopo

- alinhamento e largura do modo lateral;
- painel compacto de chamados;
- filtro de chamados por **Criado por** e nome completo do AD;
- interruptor persistente de modo escuro;
- contraste de ícones e textos no tema escuro.

## Verificações automatizadas

- compilação estrutural de `main.py`;
- 45 testes de contrato e comportamento;
- ausência do antigo filtro `OwnerIDs` na consulta de chamados;
- presença do filtro `CreatedUserIDs` e da validação de identidade;
- reposicionamento horizontal após troca de página e reorganização responsiva.

## Resultado

Todas as verificações automatizadas foram concluídas com êxito.
