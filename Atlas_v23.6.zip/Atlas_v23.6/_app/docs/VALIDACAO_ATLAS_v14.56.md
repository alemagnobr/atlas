# Validação ATLAS v14.56

## Alterações

- Título da janela de login: `ATLAS — Assistência Técnica e Lógica de Apoio ao Senado`.
- Frase de apresentação: `Assistência Técnica, Lógica e Apoio ao Senado`.
- Assinatura inferior: `Atlas • v14.56`.
- O fechamento remoto do Outlook verifica `OUTLOOK.EXE` e `olk.exe` via WMI, tenta encerrar apenas os processos encontrados e confirma a ausência de ambos antes de relatar sucesso. Se não houver nenhum, informa que já estavam fechados.
- O título anterior do aplicativo continua nas demais telas; o título longo aparece durante o login.

## Verificação local

```text
python -m unittest discover -s tests -v
python -m compileall -q main.py services tests
```

A execução do PowerShell e a confirmação visual dependem de um computador Windows com acesso à estação remota.
