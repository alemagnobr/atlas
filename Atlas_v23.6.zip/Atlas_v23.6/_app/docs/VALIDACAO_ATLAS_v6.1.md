# Validação — Atlas v6.1

## Correção aplicada

O laço de espera da orientação remota foi reescrito para sintaxe compatível com o Windows PowerShell 5.1. A condição `while` permanece em uma única expressão; os testes de existência dos arquivos de sucesso e erro são executados dentro do bloco.

## Verificações

- Compilação estrutural do código Python.
- Suíte de contratos do Atlas.
- Busca estática pelo padrão multilinha incompatível no bridge.
- Integridade do pacote ZIP.

> A validação final do parser do Windows PowerShell 5.1 deve ser realizada em uma estação Windows, pois o ambiente de empacotamento não contém `powershell.exe`.
