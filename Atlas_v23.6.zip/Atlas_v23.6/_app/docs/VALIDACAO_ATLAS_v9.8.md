# Validação — Atlas 9.8

1. Inicie uma operação que permaneça processando por alguns segundos.
2. Antes de ela terminar, tente executar outra ação.
3. Confirme a mensagem **Aguarde a operação atual terminar.**
4. Confirme que o aviso tem largura compacta, ícone informativo e botão **OK** alinhado à direita.
5. Repita nos modos claro e escuro e verifique cores, bordas e contraste.
6. Feche o aviso e confirme que a operação original continua normalmente.
7. Depois que ela terminar, confirme que uma nova ação pode ser iniciada.
8. Abra **Chamados**, selecione **Todos** e confirme que a correção de renderização da v9.7 permanece funcionando.
