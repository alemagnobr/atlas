# Validação — Atlas v7.2

- Pesquisa de orientações sem modelo de sugestões, `QCompleter` ou popup auxiliar.
- Resultados apresentados exclusivamente na árvore da página.
- Sessão remota consultada uma única vez durante o envio.
- Espera posterior reduzida de 3.000 ms para 150 ms somente nas orientações.
- Demais tarefas interativas preservam o atraso padrão e o comportamento anterior.
