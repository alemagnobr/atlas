# Validação — Atlas 9.0

1. Abra **Chamados**: um cache antigo sem confirmação integral não deve aparecer.
2. Clique em **Mapear meus chamados**.
3. Confirme que o nome enviado é o `displayName` completo da conta padrão correspondente ao login INS.
4. O resultado deve indicar a quantidade completa, por exemplo `1.646 de 1.646`.
5. Pesquise termos do título com e sem acento e com um pequeno erro de digitação.
6. Confirme que cada número aparece uma vez no cartão e que não existem cartões duplicados.

O Atlas deve preservar o catálogo anterior e apresentar erro quando não puder confirmar o total completo informado pelo Capri.
