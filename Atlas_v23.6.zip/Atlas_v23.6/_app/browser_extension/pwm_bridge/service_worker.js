const RELAY = "http://127.0.0.1:47831";

async function readJob() {
  const response = await fetch(`${RELAY}/atlas-pwm/job`, { cache: "no-store" });
  if (!response.ok) return null;
  return await response.json();
}

async function sendResult(token, payload) {
  await fetch(`${RELAY}/atlas-pwm/result?token=${encodeURIComponent(token)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Atlas-Pwm-Token": token },
    body: JSON.stringify(payload)
  });
}

async function pollFromPwmPage() {
  try {
    const job = await readJob();
    if (!job || job.action !== "sync_cookies" || !job.job_id || !job.token) {
      return { ok: true, pending: false };
    }
    const cookies = await chrome.cookies.getAll({
      domain: job.domain || "gestorsenhas.senado.leg.br"
    });
    await sendResult(job.token, {
      job_id: job.job_id,
      ok: cookies.length > 0,
      cookies: cookies.map(cookie => ({
        name: cookie.name,
        value: cookie.value,
        domain: cookie.domain,
        path: cookie.path,
        secure: cookie.secure,
        httpOnly: cookie.httpOnly,
        expirationDate: cookie.expirationDate || 0
      }))
    });
    return { ok: cookies.length > 0, pending: true, count: cookies.length };
  } catch (error) {
    return { ok: false, pending: false, error: String(error) };
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== "atlas_pwm_poll") return false;
  pollFromPwmPage().then(sendResponse);
  return true;
});
