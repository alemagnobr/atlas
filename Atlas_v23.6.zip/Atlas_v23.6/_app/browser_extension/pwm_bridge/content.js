let polling = false;

async function poll() {
  if (polling) return;
  polling = true;
  try {
    await chrome.runtime.sendMessage({ type: "atlas_pwm_poll" });
  } catch (_) {
    // O ATLAS pode estar fechado; nenhuma mensagem é exibida ao usuário.
  } finally {
    polling = false;
  }
}

poll();
setInterval(poll, 700);
