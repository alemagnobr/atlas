# Ponte PWM do ATLAS

Esta extensão permite que o ATLAS use a sessão já autenticada do PWM no Chrome
normal. Ela não abre janela de login e não acessa cookies de outros domínios.

## Instalação única

1. Abra `chrome://extensions`.
2. Ative **Modo do desenvolvedor**.
3. Clique em **Carregar sem compactação**.
4. Selecione esta pasta `pwm_bridge`.
5. Mantenha aberta uma aba do PWM em `gestorsenhas.senado.leg.br`.

O ATLAS abre a URL do PWM no Chrome padrão quando uma consulta solicitar os
dados. Se a sessão estiver ativa, os cookies são enviados pela ponte local e
reutilizados apenas para a consulta autorizada.
