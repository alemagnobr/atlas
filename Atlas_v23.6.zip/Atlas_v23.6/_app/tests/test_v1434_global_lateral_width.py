import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class GlobalLateralWidthV1434Tests(unittest.TestCase):
    def test_version_is_current(self):
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_balanced_tabs_do_not_reuse_wide_window_as_minimum(self):
        start = MAIN.index("class BalancedTabBar(QTabBar):")
        end = MAIN.index("class QuickActionButton", start)
        tab_bar = MAIN[start:end]
        minimum_start = tab_bar.index("def minimumTabSizeHint")
        minimum_end = tab_bar.index("def resizeEvent", minimum_start)
        minimum_methods = tab_bar[minimum_start:minimum_end]
        self.assertNotIn("return self.tabSizeHint(index)", minimum_methods)
        self.assertIn("size.setWidth(0)", minimum_methods)
        self.assertIn("def minimumSizeHint(self) -> QSize:", minimum_methods)
        self.assertIn("size.setWidth(0)", minimum_methods)
        self.assertIn("class BalancedTabWidget(QTabWidget):", tab_bar)
        self.assertIn("bar.setFixedWidth(available)", tab_bar)

    def test_station_controls_stack_in_lateral_mode(self):
        start = MAIN.index("    def apply_station_control_compact_layout")
        end = MAIN.index("    def apply_user_result_compact_layout", start)
        method = MAIN[start:end]
        self.assertIn("layout.addWidget(self.target_input, 0, 0, 1, 2)", method)
        self.assertIn("layout.addWidget(self.connect_button, 1, 0)", method)
        self.assertIn("layout.addWidget(self.connection_tools, 1, 1", method)

    def test_header_is_rearranged_without_hiding_theme_or_session(self):
        self.assertIn('self.top_actions_host = QWidget(objectName="topActionsHost")', MAIN)
        self.assertIn("self.top_layout.addWidget(self.hello_host, 0, 0, 1, 2)", MAIN)
        self.assertIn("profile_row.addWidget(self.profile_badge)", MAIN)
        self.assertIn("self.top_layout.addWidget(self.profile_host, 1, 0", MAIN)
        self.assertIn("self.top_layout.addWidget(self.top_actions_host, 1, 1", MAIN)

    def test_user_identity_and_printer_actions_remain_compact(self):
        user_start = MAIN.index("    def apply_user_result_compact_layout")
        printer_start = MAIN.index("    def apply_printer_summary_compact_layout", user_start)
        reflow_start = MAIN.index("    def reflow(", printer_start)
        user_method = MAIN[user_start:printer_start]
        printer_method = MAIN[printer_start:reflow_start]
        self.assertIn("identity.addWidget(self.user_identity_login_host, 1, 0)", user_method)
        self.assertNotIn("password_recovery_button", user_method)
        for token in (
            "self.printer_summary_refresh", "self.printer_summary_ping", "self.printer_summary_web",
            "self.printer_summary_test_page", "self.printer_summary_admin", "self.printer_summary_logoff",
        ):
            self.assertIn(token, printer_method)
        self.assertIn("controls.addWidget(button, index // 2, index % 2)", printer_method)


if __name__ == "__main__":
    unittest.main()
