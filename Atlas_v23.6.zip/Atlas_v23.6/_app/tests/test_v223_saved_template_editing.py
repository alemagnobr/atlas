"""Edição persistente e recuperação dos modelos de fechamento anteriores."""

from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from services.ticket_template_store import load_saved_templates, save_template, update_template
from services.ticket_templates import extract_closure_fields, render_closure


class SavedTemplateEditingTests(unittest.TestCase):
    def test_old_closure_fields_can_be_reopened_without_html_formatting(self):
        values = ["Análise <rede> & teste", "Passo 1\nPasso 2", "Resolvido"]
        html = render_closure(*values, name="João", role="Analista")
        self.assertEqual(extract_closure_fields(html), values)
        self.assertIsNone(extract_closure_fields("<div>Outro template</div>"))

    def test_edit_preserves_identity_and_rejects_duplicate_name_without_changes(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "templates.json"
            first = save_template(path, "Impressora", "<p>Antes</p>", "closure")
            save_template(path, "Rede", "<p>Rede</p>", "closure")
            updated = update_template(path, first["id"], "Impressora nova", "<p>Depois</p>",
                                      "closure", draft=["a", "b", "c"])
            self.assertEqual(updated["id"], first["id"])
            self.assertEqual(len(load_saved_templates(path)), 2)
            self.assertEqual(load_saved_templates(path)[0]["draft"], ["a", "b", "c"])
            with self.assertRaises(ValueError):
                update_template(path, first["id"], "REDE", "<p>Não gravar</p>", "closure")
            self.assertEqual(load_saved_templates(path)[0]["html"], "<p>Depois</p>")


if __name__ == "__main__":
    unittest.main()
