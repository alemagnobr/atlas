from pathlib import Path
from tempfile import TemporaryDirectory
import os
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
EDITOR = (ROOT / "ui" / "capture_editor.py").read_text(encoding="utf-8")
CAPTURE = (ROOT / "ui" / "screen_capture.py").read_text(encoding="utf-8")


class EditorContractTests(unittest.TestCase):
    def test_selection_and_dpi_implementation_are_preserved(self):
        self.assertIn("self.snapshot.pixmap.copy(area).toImage()", CAPTURE)
        self.assertIn("logical_to_physical(self.selection", CAPTURE)
        self.assertIn("event.key() == Qt.Key_Escape", CAPTURE)
        self.assertIn("for screen in QGuiApplication.screens()", CAPTURE)

    def test_tools_and_cancel_confirmation_exist(self):
        for tool in ("select", "pen", "arrow", "rectangle", "ellipse", "text", "highlight"):
            self.assertIn(f'("{tool}",', EDITOR)
        self.assertIn('prompt.setText("Deseja descartar as alterações?")', EDITOR)
        self.assertIn('prompt.addButton("Descartar"', EDITOR)
        self.assertIn('prompt.addButton("Continuar editando"', EDITOR)
        self.assertIn('threading.Thread(target=write_file', EDITOR)


class EditorRenderingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
            sys.path.insert(0, str(ROOT))
            from PySide6.QtCore import QPoint, QPointF, QEventLoop, QTimer, Qt
            from PySide6.QtGui import QColor, QImage
            from PySide6.QtTest import QTest
            from PySide6.QtWidgets import QApplication, QDialog, QMessageBox
            from ui.capture_editor import Annotation, CaptureCanvas, CaptureEditorDialog
        except ImportError as exc:
            raise unittest.SkipTest(str(exc))
        cls.app = QApplication.instance() or QApplication([])
        cls.accepted_result = QDialog.Accepted
        cls.MessageBox = QMessageBox
        cls.P, cls.Loop, cls.Timer = QPointF, QEventLoop, QTimer
        cls.PixelPoint, cls.Qt, cls.Mouse = QPoint, Qt, QTest
        cls.Color, cls.Image = QColor, QImage
        cls.Annotation, cls.Canvas, cls.Dialog = Annotation, CaptureCanvas, CaptureEditorDialog

    def white_image(self):
        image = self.Image(200, 100, self.Image.Format_ARGB32)
        image.fill(self.Color("#FFFFFF"))
        image.setDevicePixelRatio(2)
        return image

    def test_preview_maps_to_physical_pixels_without_mutating_original(self):
        image = self.white_image()
        canvas = self.Canvas(image)
        canvas.resize(600, 500)
        point = canvas.image_point(self.P(300, 250))
        self.assertEqual((point.x(), point.y()), (100, 50))
        canvas.commit(self.Annotation("rectangle", [self.P(20, 10), self.P(80, 40)],
                                      self.Color("#F00000"), 3))
        result = canvas.rendered_image()
        self.assertEqual((result.width(), result.height()), (200, 100))
        self.assertEqual(result.pixelColor(20, 25).name(), "#f00000")
        self.assertEqual(result.pixelColor(100, 25).name(), "#ffffff")
        self.assertEqual(image.pixelColor(20, 25).name(), "#ffffff")
        canvas.undo()
        self.assertEqual(canvas.rendered_image().pixelColor(20, 25).name(), "#ffffff")
        canvas.redo()
        self.assertEqual(canvas.rendered_image().pixelColor(20, 25).name(), "#f00000")
        canvas.clear_annotations()
        self.assertEqual(canvas.rendered_image().pixelColor(20, 25).name(), "#ffffff")
        canvas.undo()
        self.assertEqual(canvas.rendered_image().pixelColor(20, 25).name(), "#f00000")

    def test_pen_arrow_ellipse_highlight_and_text_export_to_normal_png(self):
        canvas = self.Canvas(self.white_image())
        for kind, points in (
            ("pen", [self.P(5, 5), self.P(50, 5)]),
            ("arrow", [self.P(60, 10), self.P(100, 20)]),
            ("ellipse", [self.P(20, 30), self.P(70, 70)]),
            ("highlight", [self.P(110, 20), self.P(150, 50)]),
            ("text", [self.P(30, 90)]),
        ):
            canvas.commit(self.Annotation(kind, points, self.Color("#FF0000"), 4,
                                          "Teste" if kind == "text" else "", 18, True))
        with TemporaryDirectory() as directory:
            path = Path(directory) / "edited.png"
            self.assertTrue(canvas.rendered_image().save(str(path), "PNG"))
            exported = self.Image(str(path))
            self.assertFalse(exported.isNull())
            self.assertEqual(exported.pixelColor(25, 5).name(), "#ff0000")
            self.assertNotEqual(exported.pixelColor(125, 35).name(), "#ffffff")

    def test_mouse_drag_previews_and_commits_annotation(self):
        canvas = self.Canvas(self.white_image())
        canvas.resize(400, 250)
        canvas.show()
        self.app.processEvents()
        canvas.set_tool("pen")
        self.Mouse.mousePress(canvas, self.Qt.LeftButton, pos=self.PixelPoint(50, 100))
        self.Mouse.mouseMove(canvas, self.PixelPoint(140, 100))
        self.assertIsNotNone(canvas.draft)
        self.Mouse.mouseRelease(canvas, self.Qt.LeftButton, pos=self.PixelPoint(140, 100))
        self.assertIsNone(canvas.draft)
        self.assertEqual(len(canvas.annotations()), 1)
        self.assertEqual(canvas.rendered_image().pixelColor(70, 37).name(), "#f04452")
        canvas.close()

    def test_save_uses_selected_path_and_closes_only_after_write(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "chosen.jpg"
            dialog = self.Dialog(self.white_image(), str(path), dark=True)
            dialog.canvas.commit(self.Annotation("pen", [self.P(5, 5), self.P(60, 5)],
                                                 self.Color("#FF0000"), 5))
            reported = []
            dialog.saved.connect(lambda ok, file: reported.append((ok, file)))
            dialog.show()
            dialog.save_image()
            loop = self.Loop()
            dialog.finished.connect(loop.quit)
            self.Timer.singleShot(4000, loop.quit)
            loop.exec()
            self.assertEqual(reported, [(True, str(path))])
            self.assertEqual(dialog.result(), self.accepted_result)
            self.assertTrue(path.is_file())
            self.assertEqual(path.read_bytes()[:3], b"\xff\xd8\xff")

    def test_filename_is_editable_in_preview_and_saved_in_same_folder(self):
        with TemporaryDirectory() as directory:
            dialog = self.Dialog(self.white_image(), str(Path(directory) / "original.png"))
            dialog.name_edit.setText("evidencia.png")
            dialog.name_edit.textEdited.emit("evidencia.png")
            self.assertEqual(dialog.path_edit.text(), str(Path(directory) / "evidencia.png"))
            dialog.show()
            dialog.save_image()
            loop = self.Loop()
            dialog.finished.connect(loop.quit)
            self.Timer.singleShot(4000, loop.quit)
            loop.exec()
            self.assertTrue((Path(directory) / "evidencia.png").is_file())

    def test_selected_text_can_be_dragged_and_undo_restores_its_position(self):
        canvas = self.Canvas(self.white_image())
        canvas.resize(400, 200)
        canvas.show()
        self.app.processEvents()
        original = self.Annotation("text", [self.P(30, 50)], self.Color("#ff0000"), 3, "Teste", 18)
        canvas.commit(original)
        canvas.set_tool("select")
        self.Mouse.mousePress(canvas, self.Qt.LeftButton, pos=self.PixelPoint(90, 88))
        self.assertIs(canvas.selected_text, original)
        self.Mouse.mouseMove(canvas, self.PixelPoint(170, 108))
        self.Mouse.mouseRelease(canvas, self.Qt.LeftButton, pos=self.PixelPoint(170, 108))
        moved = canvas.annotations()[0]
        self.assertEqual((moved.points[0].x(), moved.points[0].y()), (70, 60))
        self.assertIsNot(moved, original)
        canvas.undo()
        self.assertIs(canvas.annotations()[0], original)
        canvas.redo()
        self.assertIs(canvas.annotations()[0], moved)
        canvas.close()

    def test_cancel_with_edits_offers_continue_or_discard_without_writing(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "unsaved.png"
            dialog = self.Dialog(self.white_image(), str(path))
            dialog.canvas.commit(self.Annotation("pen", [self.P(5, 5), self.P(60, 5)],
                                                 self.Color("#FF0000"), 4))
            dialog.show()

            def choose(caption):
                prompt = self.app.activeModalWidget()
                self.assertIsInstance(prompt, self.MessageBox)
                next(button for button in prompt.buttons() if button.text() == caption).click()

            self.Timer.singleShot(0, lambda: choose("Continuar editando"))
            dialog.reject()
            self.assertTrue(dialog.isVisible())
            self.Timer.singleShot(0, lambda: choose("Descartar"))
            dialog.reject()
            self.assertFalse(dialog.isVisible())
            self.assertFalse(path.exists())


if __name__ == "__main__":
    unittest.main()
