import sys
import unittest
from html.parser import HTMLParser
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from services.ticket_templates import render_closure, render_escalation


class ParsedHTML(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag == "img":
            self.images.append(dict(attrs).get("src", ""))


class TicketTemplateTests(unittest.TestCase):
    def test_closure_preserves_requested_sections_signature_and_images(self):
        source = render_closure(
            "Identificado problema\nno Outlook", "Cache limpo & perfil", "Resolvido <OK>",
            "João Victor de Jesus Cerqueira", "Analista de Suporte Junior",
        )
        for label in ("Análise técnica:", "Ações realizadas:", "Resultado:",
                      "Sua opinião é importante!", "pesquisa de satisfação"):
            self.assertIn(label, source)
        self.assertIn("problema<br />no Outlook", source)
        self.assertIn("Cache limpo &amp; perfil", source)
        self.assertIn("Resolvido &lt;OK&gt;", source)
        self.assertIn("<strong><em>João Victor de Jesus Cerqueira</em></strong>", source)
        self.assertIn("Analista de Suporte Junior", source)
        parsed = ParsedHTML()
        parsed.feed(source)
        self.assertEqual([url.rsplit("=", 1)[-1] for url in parsed.images], ["2", "3", "4"])

    def test_escalation_location_and_single_choices(self):
        source = render_escalation(
            "Ativar <acesso>", "Encaminhado\npara análise", sector="COATEN",
            building="Anexo II", contact="3303-2000", sector_status="Aberto",
            place="Senado", name="João Cerqueira", role="Suporte",
        )
        self.assertIn("Ativar &lt;acesso&gt;", source)
        self.assertIn("Encaminhado<br />para análise", source)
        self.assertIn("Edifício:&nbsp;Anexo II", source)
        self.assertIn("Complemento:&nbsp;Não informado", source)
        self.assertIn("(X) Aberto", source)
        self.assertIn("( ) Fechado", source)
        self.assertIn("(X) Senado", source)
        self.assertIn("( ) Externo", source)

    def test_required_fields_and_html_injection(self):
        with self.assertRaises(ValueError):
            render_closure("", "feito", "ok", "Nome", "Cargo")
        with self.assertRaises(ValueError):
            render_escalation("Solicitado", " ", name="Nome")
        with self.assertRaises(ValueError):
            render_escalation("Solicitado", "Tratado", place="Fora")
        source = render_escalation(
            "<script>alert(1)</script>", "Tratado", contact='" onclick="bad"',
            name="<img src=x>", role="Cargo & outro",
        )
        self.assertNotIn("<script>", source)
        self.assertNotIn('onclick="bad"', source)
        self.assertIn("&lt;img src=x&gt;", source)
        self.assertIn("Cargo &amp; outro", source)


if __name__ == "__main__":
    unittest.main()
