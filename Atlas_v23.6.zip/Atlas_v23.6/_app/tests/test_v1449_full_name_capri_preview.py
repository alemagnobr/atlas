import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class FullNameCapriPreviewV1449Tests(unittest.TestCase):
    def test_temporary_capri_preview_searches_the_complete_ad_display_name(self):
        ast.parse(MAIN)
        ticket_catalog = BRIDGE[BRIDGE.index('    "ticket_catalog" {'):]
        body_start = ticket_catalog.index("$body = [ordered]@{")
        date_filter_start = ticket_catalog.index("if ([string]$request.date_from", body_start)
        preview_filter = ticket_catalog[body_start:date_filter_start]
        preview_start = preview_filter.index("} elseif ($previewOnly) {")
        preview_end = preview_filter.index("} else {", preview_start)
        preview_filter = preview_filter[preview_start:preview_end]
        self.assertIn("} elseif ($previewOnly) {", preview_filter)
        self.assertIn("$body['Fulltext'] = $displayName", preview_filter)
        self.assertIn("Usando o nome completo recebido do Active Directory", preview_filter)
        self.assertNotIn("$body['CustomerUserLogin']", preview_filter)
        self.assertIn("-and !$previewOnly", ticket_catalog)

    def test_regular_ticket_catalog_keeps_its_existing_account_login_filter(self):
        ticket_catalog = BRIDGE[BRIDGE.index('    "ticket_catalog" {'):]
        self.assertIn("$body['CustomerUserLogin'] = $resolvedLogin", ticket_catalog)
        self.assertIn("$body['CustomerUser'] = $resolvedLogin", ticket_catalog)

    def test_popup_refresh_button_is_compact_and_still_rotates_during_search(self):
        dialog = MAIN[MAIN.index("class UserTicketsDialog"):MAIN.index("class Dashboard")]
        self.assertIn("self.refresh_button.setFixedSize(28, 28)", dialog)
        self.assertIn('set_button_icon(self.refresh_button, "refresh", BLUE_2, 12)', dialog)
        self.assertIn("set_refresh_icon_busy(self.refresh_button, True)", dialog)


if __name__ == "__main__":
    unittest.main()
