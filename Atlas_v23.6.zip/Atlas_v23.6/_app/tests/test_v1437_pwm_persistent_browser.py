import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class PwmPersistentBrowserV1437Tests(unittest.TestCase):
    def test_sources_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_pwm_uses_an_exclusive_persistent_chromium_profile(self):
        self.assertIn('"browser_profiles" / "pwm"', MAIN)
        self.assertIn('f"--user-data-dir={profile}"', MAIN)
        self.assertIn('"--remote-debugging-address=127.0.0.1"', MAIN)
        self.assertIn('"--app=https://gestorsenhas.senado.leg.br/private/login"', MAIN)
        self.assertIn('"--headless=new"', MAIN)

    def test_ins_uses_the_authenticated_loopback_helper(self):
        self.assertIn('operation == "pwm_browser"', MAIN)
        self.assertIn('"operation": "pwm_browser"', MAIN)
        self.assertIn('secrets.compare_digest(supplied_token, token)', MAIN)
        self.assertIn('request_password_manager_browser(interactive)', MAIN)

    def test_browser_cookies_must_be_saved_before_connected_marker(self):
        action = BRIDGE[BRIDGE.index('"password_manager_browser_session"'):]
        marker = action.index('@@PASSWORD_MANAGER_SESSION@@')
        self.assertLess(action.index('Save-PasswordManagerWebSession $webSession'), marker)
        self.assertIn('if (!$records.Count) { return $false }', BRIDGE)
        self.assertIn('@@PASSWORD_MANAGER_BROWSER_REQUIRED@@', action)

    def test_browser_is_closed_after_validation_but_profile_is_preserved(self):
        self.assertIn('Close-AtlasPwmBrowser $debugPort', BRIDGE)
        close_start = MAIN.index("    def closeEvent(self, event):")
        close_end = MAIN.index("    def update_login_arrow_direction", close_start)
        close_method = MAIN[close_start:close_end]
        self.assertNotIn("reset_password_manager_browser_profile", close_method)
        self.assertNotIn("terminate_password_manager_session", close_method)
        self.assertIn("self._reset_password_manager_profile_async()", MAIN)

    def test_tabs_are_rebalanced_after_the_final_window_size_exists(self):
        self.assertIn("class BalancedTabWidget(QTabWidget):", MAIN)
        self.assertIn("QTimer.singleShot(0, self._fit_tab_bar)", MAIN)
        self.assertIn("bar.setFixedWidth(available)", MAIN)
        self.assertIn("size.setWidth(max(1, available // count))", MAIN)
        self.assertIn("size.setWidth(0)", MAIN)


if __name__ == "__main__":
    unittest.main()
