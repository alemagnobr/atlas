import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class PwmLookupReliabilityV1436Tests(unittest.TestCase):
    def test_version_is_current(self):
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_ad_identity_is_sent_to_pwm_for_reliable_result_selection(self):
        method_start = MAIN.index("    def _start_password_manager_user_lookup")
        method_end = MAIN.index("    @staticmethod\n    def _information_value", method_start)
        method = MAIN[method_start:method_end]
        self.assertIn('"login": login', method)
        self.assertIn('"full_name":', method)
        self.assertIn('"institutional_email":', method)
        self.assertIn("json.dumps(payload", method)

    def test_pwm_result_matches_login_name_or_email(self):
        action_start = BRIDGE.index('    "password_manager_user_lookup" {')
        action_end = BRIDGE.index('    "password_recovery_preview" {', action_start)
        action = BRIDGE[action_start:action_end]
        self.assertIn("$fullNameKey", action)
        self.assertIn("$emailKey", action)
        self.assertIn("$plainKey.Contains($fullNameKey)", action)
        self.assertIn("$plainKey.Contains($emailKey)", action)
        self.assertIn("$hrefKey -match", action)

    def test_search_submits_the_explicit_search_button_and_honors_form_method(self):
        self.assertIn("$searchButton", BRIDGE)
        self.assertIn("$searchOverrides[[string]$searchButton.Name]", BRIDGE)
        self.assertIn("if ([string]$Form.Method -eq 'GET')", BRIDGE)
        self.assertIn("-TimeoutSeconds 20", BRIDGE)

    def test_lookup_fetches_only_profile_and_status(self):
        action_start = BRIDGE.index('    "password_manager_user_lookup" {')
        action_end = BRIDGE.index('    "password_recovery_preview" {', action_start)
        action = BRIDGE[action_start:action_end]
        self.assertIn("if ($label -notmatch '(?i)^Status$')", action)
        self.assertNotIn("$historyLines", action)
        self.assertNotIn("$policyLines", action)
        self.assertIn("password_history = @()", action)
        self.assertIn("password_policy = [ordered]@{}", action)

    def test_missing_status_is_reported_instead_of_returning_empty_pwm_data(self):
        self.assertIn("if (!$statusLoaded)", BRIDGE)
        self.assertIn("a aba Status não pôde ser carregada", BRIDGE)
        self.assertIn("if (!$essentialStatus.Count)", BRIDGE)

    def test_operational_panel_uses_active_directory_as_its_only_source(self):
        start = MAIN.index("    def render_user_control_data(self):")
        end = MAIN.index("    def preview_password_recovery", start)
        method = MAIN[start:end]
        self.assertIn('self.user_result_heading.setText("INFORMAÇÕES DO USUÁRIO")', method)
        self.assertNotIn("user_result_source", method)
        self.assertIn('password = dict(data.get("password") or {})', method)
        self.assertNotIn('data.get("password_manager")', method)

    def test_stale_pwm_data_is_removed_before_refresh(self):
        self.assertIn('self.user_control_data.pop("password_manager", None)', MAIN)


if __name__ == "__main__":
    unittest.main()
