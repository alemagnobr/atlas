import ast
import pathlib
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class CapriLogoutV1318Tests(unittest.TestCase):
    def test_python_source_is_valid(self):
        ast.parse(MAIN)

    def test_leaving_ins_terminates_capri_before_switching_profile(self):
        start = MAIN.index("    def return_to_standard(self):")
        end = MAIN.index("    def reset_saved_credentials(self):", start)
        method = MAIN[start:end]
        self.assertIn("dashboard.run_capri_logout()", method)
        self.assertIn("if not ok:", method)
        self.assertLess(
            method.index("dashboard.run_capri_logout()"),
            method.index('self.select_profile("standard", standard_user, "")'),
        )

    def test_server_logout_is_verified_before_local_session_removal(self):
        start = BRIDGE.index('    "capri_logout" {')
        end = BRIDGE.index('    "ticket_catalog" {', start)
        action = BRIDGE[start:end]
        self.assertIn("Action=Logout", action)
        self.assertIn("Action=AgentTicketSearch", action)
        self.assertIn("$stillAuthenticated", action)
        self.assertIn("$hasUserField -and $hasPasswordField", action)
        self.assertIn('"verified":true', action)
        self.assertLess(
            action.index("$verification = Invoke-WebRequest"),
            action.rindex("Remove-Item -LiteralPath $sessionPath -Force -ErrorAction Stop"),
        )

    def test_all_application_close_paths_keep_existing_logout_guard(self):
        self.assertIn("def closeEvent(self, event):", MAIN)
        self.assertIn("login.exit_requested.connect(self.close)", MAIN)
        self.assertIn("self.window().close()", MAIN)


if __name__ == "__main__":
    unittest.main()
