import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class AdPasswordRecoveryV1441Tests(unittest.TestCase):
    def test_sources_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_password_state_and_expiration_are_computed_by_ad(self):
        self.assertIn("'msDS-User-Account-Control-Computed'", BRIDGE)
        self.assertIn("'msDS-UserPasswordExpiryTimeComputed'", BRIDGE)
        self.assertIn("$computedUac -band 0x800000", BRIDGE)
        self.assertIn("$passwordExpirationDate -le (Get-Date)", BRIDGE)
        self.assertIn("'Senha expirada no AD' = $passwordExpired", BRIDGE)
        self.assertIn("'Vencimento calculado' = $passwordExpiration", BRIDGE)

    def test_user_lookup_finishes_without_pwm(self):
        lookup_start = MAIN.index("    def lookup_user_control(self, force_refresh: bool = False):")
        lookup = MAIN[lookup_start:MAIN.index("    def _start_password_manager_user_lookup", lookup_start)]
        self.assertNotIn("_start_password_manager_user_lookup(login)", lookup)
        done = MAIN[MAIN.index("    def _user_execution_done"):MAIN.index("    def connect_target", MAIN.index("    def _user_execution_done"))]
        ad_branch = done[done.index('if action == "user_control_lookup" and ok'):done.index('elif action == "password_manager_import_cookies"')]
        self.assertNotIn("_start_password_manager_user_lookup", ad_branch)

    def test_private_pwm_fields_are_removed_from_the_panel(self):
        fields = MAIN[MAIN.index("user_fields = ("):MAIN.index("for key, caption, row, column in user_fields")]
        self.assertNotIn('"E-mail pessoal"', fields)
        self.assertNotIn('"Conta habilitada"', fields)
        render = MAIN[MAIN.index("    def render_user_control_data(self):"):MAIN.index("    def preview_password_recovery")]
        self.assertNotIn('data.get("password_manager")', render)

    def test_recovery_icon_reuses_the_protected_confirmation_flow(self):
        self.assertIn('self.recovery_button.setObjectName("passwordRecoveryButton")', MAIN)
        self.assertIn('self.recovery_button.clicked.connect(self._activate)', MAIN)
        self.assertIn('self.password_expiry_status.recovery_requested.connect(self.preview_password_recovery)', MAIN)
        self.assertIn('"password_recovery_preview"', BRIDGE)
        self.assertIn('"password_recovery_send"', BRIDGE)
        self.assertIn("confirm_action(\n                    self, \"Confirmar recuperação de senha\"", MAIN)

    def test_tabs_fill_the_card_after_every_resize(self):
        self.assertIn("class BalancedTabWidget(QTabWidget):", MAIN)
        self.assertIn("bar.setFixedWidth(available)", MAIN)
        self.assertIn("size.setWidth(max(1, available // count))", MAIN)
        self.assertIn("self.control_tabs = BalancedTabWidget()", MAIN)


if __name__ == "__main__":
    unittest.main()
