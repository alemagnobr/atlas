import unittest

from services.printer_access import color_printing_allowed


class ColorPrinterAccessTests(unittest.TestCase):
    def test_gabsen_department_allows_color_without_group(self):
        self.assertTrue(color_printing_allowed("SF-GBS-GABSEN-SETOR", []))
        self.assertTrue(color_printing_allowed("GABSEN", []))

    def test_ad_group_allows_color_outside_gabsen(self):
        self.assertTrue(color_printing_allowed("SEARP", ["OutroGrupo", "impressaocolorida"]))

    def test_no_department_or_group_match_denies_color(self):
        self.assertFalse(color_printing_allowed("SF-OSE-SEARP", ["OutroGrupo"]))
        self.assertFalse(color_printing_allowed("GABSENADO", ["ImpressaoColoridaAntiga"]))


if __name__ == "__main__":
    unittest.main()
