import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class RecentUserTicketsRefinementV1448Tests(unittest.TestCase):
    def test_dialog_keeps_completed_progress_hidden_and_refreshes_on_demand(self):
        ast.parse(MAIN)
        dialog = MAIN[MAIN.index("class UserTicketsDialog"):MAIN.index("class Dashboard")]
        self.assertIn("refresh_requested = Signal()", dialog)
        self.assertIn('self.refresh_button.setObjectName("userTicketRefreshButton")', dialog)
        self.assertIn("self.refresh_button.clicked.connect(lambda _checked=False: self.refresh_requested.emit())", dialog)
        done = dialog[dialog.index("def set_tickets"):dialog.index("def apply_search")]
        self.assertIn("self.progress_bar.hide()", done)
        self.assertNotIn("self.progress_bar.setValue(100)", done)
        self.assertIn("self.progress_percent.hide()", done)

    def test_progress_and_refresh_icon_only_show_while_refresh_is_active(self):
        dialog = MAIN[MAIN.index("class UserTicketsDialog"):MAIN.index("class Dashboard")]
        progress = dialog[dialog.index("def set_progress"):dialog.index("def set_error")]
        self.assertIn("self.progress_percent.setText(f\"{percent}%\")", progress)
        self.assertIn("self.progress_bar.show()", progress)
        self.assertIn("set_refresh_icon_busy(self.refresh_button, True)", progress)
        done = dialog[dialog.index("def set_tickets"):dialog.index("def apply_search")]
        self.assertIn("set_refresh_icon_busy(self.refresh_button, False)", done)

    def test_dark_popup_styles_combo_cards_and_scroll_viewport(self):
        self.assertIn("#userTicketStatusFilter QAbstractItemView {{ background: #10293B; color: #E9F4FA;", MAIN)
        self.assertIn("#userTicketResultsScroll QWidget#qt_scrollarea_viewport {{ background: transparent;", MAIN)
        self.assertIn("#userTicketsDialog #ticketCard {{ background: #10293B;", MAIN)

    def test_card_and_popup_can_restart_the_ephemeral_capri_query(self):
        card = MAIN[MAIN.index("class UserTicketsPreviewCard"):MAIN.index("class UserTicketsDialog")]
        self.assertIn("refresh_requested = Signal()", card)
        self.assertIn("self.user_tickets_card.refresh_requested.connect(self.refresh_user_ticket_preview)", MAIN)
        self.assertIn("dialog.refresh_requested.connect(self.refresh_user_ticket_preview)", MAIN)
        refresh = MAIN[MAIN.index("def refresh_user_ticket_preview"):MAIN.index("def _user_ticket_dialog_closed")]
        self.assertIn("self.start_user_ticket_preview(login, full_name)", refresh)

    def test_copy_button_copies_only_the_login_value(self):
        copy = MAIN[MAIN.index("def copy_user_login"):MAIN.index("def restore_user_login_copy_button")]
        self.assertIn("QApplication.clipboard().setText(login)", copy)
        self.assertNotIn("SENADO\\\\", copy)


if __name__ == "__main__":
    unittest.main()
