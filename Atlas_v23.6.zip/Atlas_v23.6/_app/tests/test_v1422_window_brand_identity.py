from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
VERSION_INFO = (ROOT / "installer" / "version_info.txt").read_text(encoding="utf-8")


class WindowBrandIdentityTests(unittest.TestCase):
    def test_version_is_1422(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("filevers=(23, 6, 0, 0)", VERSION_INFO)
        self.assertIn("prodvers=(23, 6, 0, 0)", VERSION_INFO)

    def test_main_window_uses_only_application_display_name(self):
        self.assertIn('self.setWindowTitle("")', MAIN)
        self.assertIn("app.setApplicationDisplayName(APP_NAME)", MAIN)
        self.assertNotIn('self.setWindowTitle(f"{APP_NAME} — Senado Federal")', MAIN)

    def test_sidebar_brand_is_single_balanced_atlas_label(self):
        self.assertIn('brand_text = QLabel("ATLA")', MAIN)
        self.assertIn("brand.addWidget(mark, 0, Qt.AlignHCenter)", MAIN)
        self.assertIn("brand_word.addWidget(self.brand_lightning, 0, Qt.AlignVCenter)", MAIN)
        self.assertIn("brand_text.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)", MAIN)
        self.assertNotIn('brand_text = QLabel("SUPORTE\\nSENADO")', MAIN)


if __name__ == "__main__":
    unittest.main()
