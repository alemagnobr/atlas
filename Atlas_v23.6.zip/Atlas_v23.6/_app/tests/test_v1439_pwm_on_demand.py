import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class PwmOnDemandV1439Tests(unittest.TestCase):
    def test_source_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_pwm_is_not_authenticated_when_dashboard_opens(self):
        self.assertNotIn("QTimer.singleShot(900, self.connect_password_manager)", MAIN)
        initialization = MAIN[MAIN.index("class Dashboard(QWidget):"):MAIN.index("def build_ui", MAIN.index("class Dashboard(QWidget):"))]
        self.assertNotIn("self.pwm_chrome_relay.start()", initialization)

    def test_each_user_request_has_three_explicit_choices(self):
        self.assertIn("class PasswordManagerSessionDialog(QDialog):", MAIN)
        self.assertIn('QLabel("O PWM está logado?")', MAIN)
        self.assertIn('QPushButton("Somente AD")', MAIN)
        self.assertIn('QPushButton(f"Não, abrir PWM no {browser_label}")', MAIN)
        self.assertIn('QPushButton("Sim, consultar")', MAIN)

    def test_ad_completes_without_starting_a_pwm_lookup(self):
        done_start = MAIN.index("    def _user_execution_done")
        done_end = MAIN.index("    def connect_target", done_start)
        done = MAIN[done_start:done_end]
        self.assertIn('action == "user_control_lookup" and ok', done)
        self.assertIn("self.render_user_control_data()", done)
        ad_branch = done[done.index('if action == "user_control_lookup" and ok'):done.index('elif action == "password_manager_import_cookies"')]
        self.assertNotIn("_start_password_manager_user_lookup", ad_branch)
        self.assertIn("self.finish_station_enrichment(True", ad_branch)
        self.assertIn("self.start_user_ticket_preview", ad_branch)

    def test_confirmed_session_does_not_repeat_the_question(self):
        success = MAIN[MAIN.index('action == "password_manager_browser_session"'):]
        self.assertIn("self._run_password_manager_user_lookup(current)", success)
        before_next_method = success[:success.index("    def connect_target")]
        self.assertNotIn("lambda current=login: self._start_password_manager_user_lookup(current)", before_next_method)

    def test_ad_only_state_and_bounded_reauthentication_are_preserved(self):
        self.assertIn('return "Não consultado nesta solicitação"', MAIN)
        self.assertIn("self.password_manager_lookup_skipped = True", MAIN)
        self.assertIn("self.pwm_lookup_reauth_attempted", MAIN)
        self.assertIn("Sessão do PWM expirada — atualizando pelo Chrome", MAIN)


if __name__ == "__main__":
    unittest.main()
