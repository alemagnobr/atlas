from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8")


class SelectivePrinterProgressTests(unittest.TestCase):
    def test_version_is_1420(self):
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_printer_operations_have_real_completion_aware_progress(self):
        self.assertIn("class OperationProgressDialog(QDialog):", MAIN)
        self.assertIn('minimum_ms = 600 if command == "install_printer" else 400', MAIN)
        self.assertIn("if not self.backend_done:", MAIN)
        self.assertIn("if not self.backend_ok or not self.completion_confirmed:", MAIN)
        self.assertIn("self.printer_operation_progress.finish_operation(True, result, completion_confirmed=refreshed)", MAIN)

    def test_printer_refresh_is_selective(self):
        self.assertIn('self.run_bridge("printer_status", self.target)', MAIN)
        self.assertIn('"printer_status" {', BRIDGE)
        self.assertIn("@@PRINTER_STATUS@@", BRIDGE)
        self.assertIn("def apply_printer_status", MAIN)
        self.assertNotIn('self.run_bridge("status", self.target)\n            return started', MAIN)

    def test_admin_refresh_is_selective(self):
        self.assertIn('self.run_bridge("admin_status", self.target)', MAIN)
        self.assertIn('"admin_status" {', BRIDGE)
        self.assertIn("@@ADMIN_STATUS@@", BRIDGE)
        self.assertIn("def sync_printer_admin_button", MAIN)

    def test_printer_toolbar_contains_requested_actions(self):
        for name in (
            "printer_summary_refresh",
            "printer_summary_ping",
            "printer_summary_web",
            "printer_summary_test_page",
            "printer_summary_admin",
            "printer_summary_logoff",
        ):
            self.assertIn(f"self.{name}", MAIN)
        self.assertIn("self.printer_summary_logoff.clicked.connect(self.request_printer_logoff)", MAIN)
        self.assertIn("self.printer_admin_pulse.setLoopCount(-1)", MAIN)

    def test_ticket_refresh_reports_percentage(self):
        self.assertIn("ticketSyncProgressBar", MAIN)
        self.assertIn("ticket_sync_progress_timer", MAIN)
        self.assertIn("@@TICKET_PROGRESS@@", BRIDGE)
        self.assertIn("self.ticket_sync_progress_value = 100", MAIN)


if __name__ == "__main__":
    unittest.main()
