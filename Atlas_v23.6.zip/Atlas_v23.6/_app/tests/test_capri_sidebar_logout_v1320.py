import ast
import pathlib
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class CapriSidebarLogoutV1320Tests(unittest.TestCase):
    def test_python_source_is_valid(self):
        ast.parse(MAIN)

    def test_capri_has_one_global_logout_action_in_sidebar(self):
        self.assertEqual(MAIN.count('HoverFadeButton("Capri")'), 1)
        self.assertNotIn('QPushButton("Encerrar Capri")', MAIN)
        self.assertIn("self.capri_logout_button.clicked.connect(self.end_capri_session)", MAIN)
        self.assertIn("O perfil INS permanecerá aberto", MAIN)
        button = MAIN.index('HoverFadeButton("Capri")')
        exit_ins = MAIN.index('HoverFadeButton("INS"', button)
        self.assertLess(button, exit_ins)

    def test_logout_uses_authenticated_link_and_keeps_its_token(self):
        start = BRIDGE.index('    "capri_logout" {')
        end = BRIDGE.index('    "ticket_catalog" {', start)
        action = BRIDGE[start:end]
        self.assertIn("$logoutMatch", action)
        self.assertIn("[Net.WebUtility]::HtmlDecode", action)
        self.assertIn("$logoutUri.AbsoluteUri", action)
        self.assertIn("ChallengeToken", action)
        self.assertIn("$logoutUri.Host -ne 'capri.senado.leg.br'", action)

    def test_capri_logout_updates_only_capri_connection_state(self):
        start = MAIN.index("    def run_capri_logout(self)")
        end = MAIN.index("    def end_capri_session(self):", start)
        method = MAIN[start:end]
        self.assertIn("terminate_capri_session()", method)
        self.assertIn('self._capri_session_password = ""', method)
        self.assertIn("self.set_capri_connection_state(False)", method)
        self.assertNotIn("self.select_profile", method)

    def test_leaving_ins_warns_but_does_not_block_profile_switch(self):
        start = MAIN.index("    def return_to_standard(self):")
        end = MAIN.index("    def reset_saved_credentials(self):", start)
        method = MAIN[start:end]
        warning = method.index("if not ok:")
        profile_switch = method.index('self.select_profile("standard", standard_user, "")')
        self.assertLess(warning, profile_switch)
        self.assertNotIn("            return\n", method[warning:profile_switch])


if __name__ == "__main__":
    unittest.main()
