"""Ordem de escalonamento, horários e identidade remota."""

from datetime import datetime, timedelta
import json
from pathlib import Path
import unittest

from services.escalation import brasilia_now, may_escalate, on_duty


TARGETS = json.loads((Path(__file__).parents[1] / "data/escalation_targets.json").read_text(encoding="utf-8"))


class EscalationRulesTests(unittest.TestCase):
    def test_brasilia_timezone_is_independent_of_the_workstation(self):
        self.assertEqual(brasilia_now().utcoffset(), timedelta(hours=-3))

    def test_lunch_and_shift_boundaries(self):
        leader, marcia, alessandro = TARGETS
        self.assertTrue(on_duty(leader, datetime(2026, 10, 5, 8, 0)))
        self.assertFalse(on_duty(leader, datetime(2026, 10, 5, 11, 0)))
        self.assertTrue(on_duty(leader, datetime(2026, 10, 5, 12, 0)))
        self.assertFalse(on_duty(leader, datetime(2026, 10, 5, 17, 0)))
        self.assertFalse(on_duty(marcia, datetime(2026, 10, 5, 12, 30)))
        self.assertTrue(on_duty(alessandro, datetime(2026, 10, 5, 21, 59)))
        self.assertFalse(on_duty(alessandro, datetime(2026, 10, 5, 22, 0)))

    def test_supervision_requires_contact_and_reason_when_leader_available(self):
        leader, marcia, _ = TARGETS
        at_ten = datetime(2026, 10, 5, 10)
        self.assertTrue(may_escalate(leader, TARGETS,
                                     leader_contacted=False, reason="", now=at_ten))
        self.assertFalse(may_escalate(marcia, TARGETS,
                                      leader_contacted=False, reason="", now=at_ten))
        self.assertFalse(may_escalate(marcia, TARGETS,
                                      leader_contacted=True, reason=" ", now=at_ten))
        self.assertTrue(may_escalate(marcia, TARGETS,
                                     leader_contacted=True, reason="Escalonamento específico", now=at_ten))

    def test_leader_off_duty_allows_only_supervisors_on_duty(self):
        _, marcia, alessandro = TARGETS
        at_eleven_thirty = datetime(2026, 10, 5, 11, 30)
        self.assertTrue(may_escalate(marcia, TARGETS,
                                     leader_contacted=False, reason="", now=at_eleven_thirty))
        self.assertFalse(may_escalate(alessandro, TARGETS,
                                      leader_contacted=False, reason="", now=at_eleven_thirty))


if __name__ == "__main__":
    unittest.main()
