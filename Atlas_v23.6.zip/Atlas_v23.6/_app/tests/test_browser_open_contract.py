from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'main.py').read_text(encoding='utf-8-sig')
BRIDGE = (ROOT / 'scripts/bridge.ps1').read_text(encoding='utf-8-sig')


class BrowserOpenContractTests(unittest.TestCase):
    def test_exact_internal_pages(self):
        self.assertIn('chrome://settings/clearBrowserData', BRIDGE)
        self.assertIn('edge://settings/clearBrowserData', BRIDGE)

    def test_runs_in_interactive_user_task(self):
        self.assertIn("Invoke-InteractiveTask -TaskName $taskName -Command 'powershell.exe'", BRIDGE)
        self.assertIn("Start-Process -FilePath `$exe | Out-Null", BRIDGE)
        self.assertIn("MainWindowHandle -ne 0", BRIDGE)
        self.assertIn("SendKeys('^+{DELETE}')", BRIDGE)

    def test_no_remote_file_or_profile_share_dependency(self):
        browser_block = BRIDGE[BRIDGE.index('function Open-RemoteBrowserClearPage'):BRIDGE.index('function Get-RemoteSessionExecutables')]
        for forbidden in ('ADMIN$', 'Win32_UserProfile', 'Copy-Item', 'Remove-Item', 'clear cache', 'Cookies'):
            self.assertNotIn(forbidden, browser_block)

    def test_old_automatic_cleaning_is_not_exposed(self):
        combined = MAIN + BRIDGE
        for command in ('browser_clean_safe', 'browser_clean_full', 'Invoke-BrowserCleanup'):
            self.assertNotIn(command, combined)
        self.assertFalse((ROOT / 'scripts/browser_cleanup.ps1').exists())
        self.assertFalse((ROOT / 'scripts/browser_cleanup_worker.ps1').exists())

    def test_result_wording_does_not_claim_cleanup(self):
        self.assertIn('A limpeza ainda precisa ser confirmada no navegador.', BRIDGE)


if __name__ == '__main__':
    unittest.main()
