"""Campos preenchidos, opções e persistência dos templates pessoais."""

from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from services.ticket_template_store import delete_template, load_saved_templates, save_template
from services.ticket_templates import render_no_network, render_standard_installation, render_wifi_checklist


class TicketTemplateTests(unittest.TestCase):
    def test_wifi_checklist_keeps_sections_choices_and_escapes_input(self):
        html = render_wifi_checklist(
            user_type="Usuário da Câmara", event_time="25/11/2025 às 14h30",
            error_message="Rede <sem acesso>", equipment="Notebook", operating_system="Windows",
            clearpass="SIM", auth_error="NÃO", navigates="SIM",
            corrective_actions=("Esquecer a Rede", "Troca de senha"), signal="Baixa",
            access_point="AP1234", sector="SEARP", sector_status="Aberto", place="Senado",
            name="João & Silva", role="Analista",
        )
        for number in range(1, 13):
            self.assertIn(f"{number}. ", html)
        for expected in ("(X) Usuário da Câmara", "(X) Notebook", "(X) Windows",
                         "(X) Esquecer a Rede", "(X) Troca de senha", "(X) Baixa",
                         "(X) Aberto", "(X) Senado", "AP1234", "João &amp; Silva",
                         "Rede &lt;sem acesso&gt;"):
            self.assertIn(expected, html)
        self.assertNotIn("Rede <sem acesso>", html)

    def test_installation_checkboxes_and_input(self):
        html = render_standard_installation(
            "Instalar <pacote>", "Verificado", reason="Outros", reason_other="Novo software",
            authorized="Sim", shared_micro="Não", backup="Sim", place="Teletrabalho",
            name="Operador", role="Técnico",
        )
        for expected in ("Instalar &lt;pacote&gt;", "(X) Outros", "Novo software",
                         "(X) Sim", "(X) Não", "(X) Teletrabalho", "Operador"):
            self.assertIn(expected, html)
        with self.assertRaises(ValueError):
            render_standard_installation("", "Tratativa")

    def test_station_without_network_preserves_checklist_location_and_signature(self):
        html = render_no_network(
            other_devices="Não", recently_installed="Sim", cable_connected="Sim",
            via_ip_phone="Sim", phone_connected="Não",
            access_sites=("Intranet", "Internet"), sector="SEARP <teste>",
            building="Anexo", sector_status="Aberto", place="Senado",
            name="João & Silva", role="Analista",
        )
        for expected in (
            "Estação sem Rede/Internet", "Checklist de diagnóstico",
            "Afeta outros equipamentos do mesmo local/setor?", "telefone IP",
            "(X) Intranet", "(X) Internet", "( ) Nenhum",
            "Setor:&nbsp;SEARP &lt;teste&gt;", "(X) Aberto", "(X) Senado",
            "João &amp; Silva", "FileID=4",
        ):
            self.assertIn(expected, html)
        self.assertEqual(html.count("<div"), html.count("</div>"))
        with self.assertRaises(ValueError):
            render_no_network(access_sites=("Nenhum", "Internet"))
        with TemporaryDirectory() as directory:
            path = Path(directory) / "saved_templates.json"
            save_template(path, "Rede", html, "no_network")
            self.assertEqual(load_saved_templates(path)[0]["kind"], "no_network")

    def test_save_copy_source_and_delete(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "templates" / "saved_templates.json"
            html = render_standard_installation("Pedido", "Feito", name="Técnico", role="Suporte")
            entry = save_template(path, "Meu modelo", html, "installation")
            self.assertEqual(load_saved_templates(path)[0]["html"], html)
            with self.assertRaises(ValueError):
                save_template(path, "MEU MODELO", html, "installation")
            self.assertTrue(delete_template(path, entry["id"]))
            self.assertEqual(load_saved_templates(path), [])

    def test_structured_escalation_survives_save_and_legacy_entries_remain_readable(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "saved_templates.json"
            html = render_standard_installation("Pedido", "Feito", name="Técnico", role="Suporte")
            save_template(path, "Modelo antigo", html, "installation")
            save_template(path, "Modelo novo", html, "installation", draft=["Pedido", "Feito", 1, False])
            entries = load_saved_templates(path)
            self.assertIsNone(entries[0]["draft"])
            self.assertEqual(entries[1]["draft"], ["Pedido", "Feito", 1, False])
            self.assertEqual(entries[1]["html"], html)


if __name__ == "__main__":
    unittest.main()
