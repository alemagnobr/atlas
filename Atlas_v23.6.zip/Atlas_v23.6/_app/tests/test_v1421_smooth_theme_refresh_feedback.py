from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
TRANSITIONS = (ROOT / "ui" / "transitions.py").read_text(encoding="utf-8")


class SmoothThemeAndRefreshFeedbackTests(unittest.TestCase):
    def test_version_is_1421(self):
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_logged_theme_gives_the_toggle_a_frame_before_restyling(self):
        self.assertIn("apply_delay_ms: int = 0", TRANSITIONS)
        self.assertIn("QTimer.singleShot(apply_delay_ms, prepare_new_theme)", TRANSITIONS)
        self.assertIn("apply_delay_ms=16", MAIN)

    def test_logged_theme_recolors_icons_in_small_batches(self):
        self.assertIn("def refresh_themed_button_icons_chunked", MAIN)
        self.assertIn("refresh_themed_button_icons_chunked(self, 28)", MAIN)
        self.assertIn("QTimer.singleShot(0, refresh_batch)", MAIN)

    def test_refresh_feedback_rotates_the_icon_instead_of_pulsing_the_button(self):
        self.assertIn("def set_refresh_icon_busy", MAIN)
        self.assertIn("timer.setInterval(34)", MAIN)
        self.assertIn("painter.rotate", MAIN)
        self.assertNotIn("self.refresh_animation", MAIN)
        for button in (
            "refresh_button",
            "printer_summary_refresh",
            "ticket_refresh_cache_button",
            "orientation_refresh_button",
        ):
            self.assertIn(f"set_refresh_icon_busy(self.{button}, True)", MAIN)
        self.assertIn("set_refresh_icon_busy(feedback_button, True)", MAIN)

    def test_printer_summary_has_test_page_with_two_second_progress(self):
        self.assertIn("self.printer_summary_test_page = QPushButton()", MAIN)
        self.assertIn("self.printer_summary_test_page.clicked.connect(self.print_test_page)", MAIN)
        self.assertIn('self.run_bridge("test_print", self.target, printer)', MAIN)
        self.assertIn('"test_print": f"Enviando uma página de teste', MAIN)
        self.assertIn('minimum_ms = 600 if command == "install_printer" else 400', MAIN)

    def test_test_page_does_not_force_an_unrelated_printer_refresh(self):
        self.assertIn('self.printer_refresh_scope = "both"', MAIN)


if __name__ == "__main__":
    unittest.main()
