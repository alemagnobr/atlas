from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
TRANSITIONS = (ROOT / "ui" / "transitions.py").read_text(encoding="utf-8-sig")


class V1419ThemeCrossfadeTests(unittest.TestCase):
    def test_sources_and_version_are_valid(self):
        ast.parse(MAIN)
        ast.parse(TRANSITIONS)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_old_frame_is_dissolved_over_the_ready_theme(self):
        self.assertIn("class _ThemeSnapshotOverlay(QWidget):", TRANSITIONS)
        self.assertIn("snapshot = target.grab()", TRANSITIONS)
        self.assertIn("overlay = _ThemeSnapshotOverlay(snapshot, target)", TRANSITIONS)
        self.assertLess(TRANSITIONS.index("apply_theme()"), TRANSITIONS.index("QTimer.singleShot(24, reveal_new_theme)"))
        self.assertIn('fade.setStartValue(1.0)', TRANSITIONS)
        self.assertIn('fade.setEndValue(0.0)', TRANSITIONS)

    def test_transition_never_fades_the_live_interface_or_exposes_background(self):
        self.assertNotIn("target.setGraphicsEffect(effect)", TRANSITIONS)
        self.assertNotIn("setEndValue(0.82)", TRANSITIONS)
        self.assertIn("overlay.setGraphicsEffect(effect)", TRANSITIONS)
        self.assertIn("WA_TransparentForMouseEvents", TRANSITIONS)

    def test_switch_and_crossfade_share_the_same_delicate_timing(self):
        self.assertIn("duration_ms: int = 420", TRANSITIONS)
        self.assertIn("self._animation.setDuration(420)", MAIN)
        self.assertIn("QEasingCurve.InOutCubic", MAIN)
        self.assertIn("QEasingCurve.Type.InOutCubic", TRANSITIONS)

    def test_both_login_and_dashboard_keep_using_the_shared_transition(self):
        self.assertEqual(2, MAIN.count("fade_theme_change("))
        self.assertIn("self.apply_pending_login_theme", MAIN)
        self.assertIn("self.apply_pending_theme", MAIN)


if __name__ == "__main__":
    unittest.main()
