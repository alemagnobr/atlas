import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class CapriTicketRowMatchingV1451Tests(unittest.TestCase):
    def test_ticket_zoom_link_is_found_among_all_links_in_the_row(self):
        ast.parse(MAIN)
        catalog = BRIDGE[BRIDGE.index('    "ticket_catalog" {'):]
        self.assertIn("foreach ($anchorCandidate in [regex]::Matches($row", catalog)
        self.assertIn("$candidateLink = [regex]::Match($anchorCandidate.Groups['attrs'].Value", catalog)
        self.assertIn("if (!$zoom -or !$ticketLink) { continue }", catalog)

    def test_name_match_falls_back_to_all_visible_row_text(self):
        catalog = BRIDGE[BRIDGE.index('    "ticket_catalog" {'):]
        self.assertIn("$rowNameMatches = $targetName -and (Get-NormalizedPersonName $rowText).Contains($targetName)", catalog)
        self.assertIn("(!$customerMatches -and !$titleMatches -and !$rowNameMatches)", catalog)

    def test_preview_still_stops_after_25_matching_tickets(self):
        catalog = BRIDGE[BRIDGE.index('    "ticket_catalog" {'):]
        self.assertIn("$previewLimit = if ($previewOnly) { 25 }", catalog)
        self.assertIn("(!$previewOnly -or $items.Count -lt $previewLimit)", catalog)
        self.assertIn("if ($previewOnly -and $items.Count -ge $previewLimit)", catalog)


if __name__ == "__main__":
    unittest.main()
