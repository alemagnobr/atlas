"""UI routing/runner tests without PySide6 or access to a remote computer.

Run: python -m unittest discover -s tests -v
Only selected AST definitions are loaded; the application is never started.
"""
import ast
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
import unittest

ROOT = Path(__file__).resolve().parents[1]
TREE = ast.parse((ROOT / 'main.py').read_text(encoding='utf-8-sig'))


def load(nodes, namespace):
    exec(compile(ast.Module(body=nodes, type_ignores=[]), 'main.py', 'exec'), namespace)


class Signal:
    def __init__(self, *args):
        self.callbacks = []

    def __set_name__(self, owner, name):
        self.name = name

    def __get__(self, instance, owner):
        if instance is None:
            return self
        return instance.__dict__.setdefault('_signal_' + self.name, Signal())

    def connect(self, callback):
        self.callbacks.append(callback)

    def emit(self, *args):
        for callback in self.callbacks:
            callback(*args)


class FakeProcess:
    NotRunning, Running, FailedToStart, MergedChannels = 0, 1, 2, 3

    def __init__(self, parent=None):
        self.finished, self.errorOccurred, self.readyReadStandardOutput = Signal(), Signal(), Signal()
        self.current_state = self.NotRunning

    def setProcessChannelMode(self, *args):
        pass

    def setProcessEnvironment(self, environment):
        pass

    def state(self):
        return self.current_state

    def start(self, *args):
        self.current_state = self.Running

    def kill(self):
        self.current_state = self.NotRunning
        self.finished.emit(-1, None)

    def readAllStandardOutput(self):
        return b''


class FakeTimer:
    def __init__(self, parent=None):
        self.timeout = Signal()
        self.interval = 0

    def setSingleShot(self, *args):
        pass

    def start(self, ms):
        self.interval = ms

    def stop(self):
        self.interval = 0


NS = {'dataclass': dataclass}
load([n for n in TREE.body if (isinstance(n, ast.ClassDef) and n.name == 'Action') or
      (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in {'ACTIONS', 'LOADING_ACTIONS'} for t in n.targets))], NS)
ACTIONS = {a.command: a for a in NS['ACTIONS']}
dashboard = next(n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == 'Dashboard')


class BrowserUiTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        self.ns = dict(NS, QInputDialog=SimpleNamespace(getItem=lambda *args: self.fail('Unexpected browser selection')),
                       confirm_action=lambda *args: self.fail('Unexpected confirmation prompt'),
                       QMessageBox=SimpleNamespace(warning=lambda *args: self.calls.append('warning')),
                       show_notice=lambda *args: self.calls.append('notice'), APP_NAME='Test')
        load([n for n in dashboard.body if isinstance(n, ast.FunctionDef) and n.name in
              {'section_actions', 'action_group', 'execute_action'}], self.ns)
        self.ui = SimpleNamespace(profile='ins', target='REMOTE-TEST', current_section='Suporte remoto',
                                  append_log=lambda *args: None,
                                  run_bridge=lambda *args, **kwargs: self.calls.append((args, kwargs)) or True,
                                  set_action_loading=lambda *args: self.calls.append(('loading', args)))

    def test_three_groups_in_requested_order(self):
        self.ui.cards = [(a, None) for a in NS['ACTIONS']]
        # section_actions uses action_cards in the production dashboard.
        self.ui.action_cards = self.ui.cards
        items = self.ns['section_actions'](self.ui)
        groups = list(dict.fromkeys(self.ns['action_group'](self.ui, a) for a, _ in items))
        self.assertEqual(groups, ['SUPORTE AO COMPUTADOR', 'CONEXÃO E CONTROLE', 'NAVEGADORES E CERTIFICADOS'])

    def test_certificates_moved(self):
        self.assertEqual(self.ns['action_group'](self.ui, ACTIONS['cert_list']), 'NAVEGADORES E CERTIFICADOS')

    def test_browser_close_actions_are_in_browser_group(self):
        for command in ('browser_close_chrome', 'browser_close_edge'):
            with self.subTest(command=command):
                self.assertEqual(self.ns['action_group'](self.ui, ACTIONS[command]), 'NAVEGADORES E CERTIFICADOS')
                self.assertTrue(ACTIONS[command].destructive)

    def test_each_button_opens_its_browser_without_selection_or_confirmation(self):
        for command in ('browser_open_chrome_cleanup', 'browser_open_edge_cleanup'):
            with self.subTest(command=command):
                self.calls.clear()
                self.ns['execute_action'](self.ui, ACTIONS[command])
                self.assertEqual(self.calls[0][0], (command, 'REMOTE-TEST', ''))
                self.assertEqual(self.calls[1], ('loading', (command, True)))

    def test_missing_remote_does_not_execute(self):
        self.ui.target = ''
        self.ns['execute_action'](self.ui, ACTIONS['browser_open_chrome_cleanup'])
        self.assertEqual(self.calls, ['notice'])

    def test_standard_profile_cannot_execute(self):
        self.ui.profile = 'standard'
        self.ns['execute_action'](self.ui, ACTIONS['browser_open_edge_cleanup'])
        self.assertEqual(self.calls, ['warning'])


class RunnerTests(unittest.TestCase):
    def setUp(self):
        env = SimpleNamespace(systemEnvironment=lambda: SimpleNamespace(insert=lambda *args: None))
        ns = dict(QProcess=FakeProcess, Signal=Signal, QTimer=FakeTimer, QProcessEnvironment=env)
        load([n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == 'PowerShellRunner'], ns)
        self.runner = ns['PowerShellRunner']()
        self.results = []
        self.runner.completed.connect(self.results.append)

    def test_timeout_finishes_once_and_is_failure(self):
        self.runner.run_script('unused.ps1', [], timeout_ms=150000)
        self.assertEqual(self.runner.deadline.interval, 150000)
        self.runner.deadline.timeout.emit()
        self.runner.finished.emit(0, None)
        self.assertEqual(self.results, [False])
        self.assertEqual(self.runner.deadline.interval, 0)

    def test_failed_start_finishes_once(self):
        self.runner.run_script('unused.ps1', [], timeout_ms=150000)
        self.runner.errorOccurred.emit(FakeProcess.FailedToStart)
        self.runner.finished.emit(-1, None)
        self.assertEqual(self.results, [False])

    def test_success_and_no_timeout_for_other_actions(self):
        self.runner.run_script('unused.ps1', [])
        self.assertEqual(self.runner.deadline.interval, 0)
        self.runner.finished.emit(0, None)
        self.assertEqual(self.results, [True])

    def test_busy_runner_rejects_second_action(self):
        self.assertTrue(self.runner.run_script('unused.ps1', []))
        self.assertFalse(self.runner.run_script('unused.ps1', []))


if __name__ == '__main__':
    unittest.main()
