import unittest
from pathlib import Path


MAIN = (Path(__file__).resolve().parents[1] / "main.py").read_text(encoding="utf-8")


class QuickActionLayoutTests(unittest.TestCase):
    def test_v129_login_keeps_only_gear_at_top_and_exit_at_bottom(self):
        login_start = MAIN.index("class LoginPage(QWidget):")
        login_end = MAIN.index("class ActionCard", login_start)
        login = MAIN[login_start:login_end]
        self.assertIn('self.login_settings_button = QPushButton(self.panel)', login)
        self.assertIn('self.login_settings_button.setFixedSize(28, 28)', login)
        self.assertIn('self.login_settings_button.clicked.connect(lambda: open_browser_settings_dialog(self))', login)
        self.assertIn('self.login_settings_button, "gear"', login)
        self.assertNotIn('self.login_exit_ins_button', login)
        self.assertNotIn('exit_ins_requested = Signal()', login)
        self.assertIn('self.login_exit_software_button = QPushButton(self.panel)', login)
        self.assertIn('self.login_exit_software_button.setFixedSize(44, 44)', login)
        self.assertIn('exit_requested = Signal()', login)
        self.assertIn('self.login_exit_software_button.clicked.connect(self.exit_requested.emit)', login)
        self.assertIn('self.panel.width() - self.login_exit_software_button.width() - 16', login)
        self.assertIn('self.panel.height() - self.login_exit_software_button.height() - 16', login)
        self.assertNotIn('exit_app = QPushButton("Sair do software")', login)
        self.assertIn('def position_login_top_controls(self):', login)

    def test_v127_developer_credits_link_to_linkedin(self):
        self.assertIn('href="https://www.linkedin.com/in/alemagnobr/"', MAIN)
        self.assertIn('href="https://www.linkedin.com/in/joaocerq/"', MAIN)
        self.assertIn('footer.linkActivated.connect(self.open_credit_link)', MAIN)
        self.assertIn('opened, _used_browser, _used_fallback = launch_external_url(url)', MAIN)

    def test_v126_ticket_refresh_returns_only_number_and_title(self):
        self.assertIn('self.request_tickets(True, "recent")', MAIN)
        self.assertIn('received_tickets.append((number, title))', MAIN)
        self.assertIn('f"{number}\\n{title}" for number, title in unique_received.items()', MAIN)
        self.assertIn('self.show_information_result("Atualização de chamados", subtitle, content, True)', MAIN)
        self.assertIn('or "@@TICKETS@@" in line', MAIN)

    def test_v126_background_results_do_not_reuse_foreground_popup_titles(self):
        start = MAIN.index('def _background_execution_done(self, ok: bool):')
        end = MAIN.index('def execution_done(', start)
        implementation = MAIN[start:end]
        self.assertIn('previous_popup = self.pending_popup_title, self.pending_popup_subtitle', implementation)
        self.assertIn('self.pending_popup_title = ""', implementation)
        self.assertIn('self.pending_popup_title, self.pending_popup_subtitle = previous_popup', implementation)
        self.assertIn('if self.pending_popup_title and not is_background:', MAIN)

    def test_v125_printer_quick_actions_always_require_a_list_choice(self):
        self.assertIn('class PrinterSelectionDialog(QDialog):', MAIN)
        start = MAIN.index('def select_printer_for_quick_action(self, title: str)')
        end = MAIN.index('def ping_printer(self):', start)
        implementation = MAIN[start:end]
        self.assertIn('dialog = PrinterSelectionDialog(title, choices, default_name, self)', implementation)
        self.assertNotIn('return default_name', implementation)
        self.assertNotIn('if len(installed) == 1:', implementation)
        ping_start = MAIN.index('def ping_printer(self):')
        web_start = MAIN.index('def open_printer_web(self):', ping_start)
        self.assertIn('self.select_printer_for_quick_action("Pingar impressora")', MAIN[ping_start:web_start])
        web_end = MAIN.index('def refresh_panel(self):', web_start)
        self.assertIn('self.select_printer_for_quick_action("Interface web da impressora")', MAIN[web_start:web_end])

    def test_v124_browser_links_reuse_the_standard_windows_session(self):
        self.assertIn('def run_browser_session_helper()', MAIN)
        self.assertIn('def start_browser_session_helper()', MAIN)
        self.assertIn('def request_browser_session(url: str, preference: str)', MAIN)
        self.assertIn('if getpass.getuser().lower().endswith("_ins"):', MAIN)
        self.assertIn('if "--browser-session-helper" in sys.argv:', MAIN)
        self.assertIn('secrets.compare_digest(supplied_token, token)', MAIN)
        self.assertIn('url.lower().startswith(("http://", "https://"))', MAIN)
        self.assertNotIn('[str(executable), url],\n                creationflags', MAIN[MAIN.index('def launch_external_url'):MAIN.index('def load_faq_cache')])

    def test_v123_browser_settings_are_persistent_and_control_external_links(self):
        self.assertIn('browser_preferences.json', MAIN)
        self.assertIn('(\"system\", \"Padrão do Windows\")', MAIN)
        self.assertIn('(\"chrome\", \"Google Chrome\")', MAIN)
        self.assertIn('(\"edge\", \"Microsoft Edge\")', MAIN)
        settings_position = MAIN.index('settings = HoverFadeButton(\"\")')
        exit_position = MAIN.index('exit_btn = HoverFadeButton', settings_position)
        self.assertLess(settings_position, exit_position)
        self.assertIn('def launch_external_url(url: str)', MAIN)
        self.assertIn('if self.open_external_link(url):', MAIN)
        self.assertIn('if not self.open_external_link(url):', MAIN)

    def test_v122_software_menu_uses_compact_drive_label(self):
        self.assertIn('(\"Softwares autorizados\", \"Softwares (X:)\")', MAIN)

    def test_v121_quick_actions_follow_the_requested_grid(self):
        expected_positions = {
            "self.quick_disk_button": (0, 0),
            "self.quick_internet_button": (0, 1),
            "self.quick_local_users_button": (0, 2),
            "self.quick_dsa_button": (1, 0),
            "self.quick_cmd_button": (1, 1),
            "self.quick_compmgmt_button": (1, 2),
        }
        for button, (row, column) in expected_positions.items():
            with self.subTest(button=button):
                self.assertIn(f"quick_grid.addWidget({button}, {row}, {column})", MAIN)
        self.assertIn('machine_buttons_row.addWidget(self.station_remote_button)', MAIN)
        self.assertIn('user_name_layout.addWidget(self.quick_ad_button', MAIN)
        self.assertIn('footer_tools.addWidget(self.screen_capture_button)', MAIN)


if __name__ == "__main__":
    unittest.main()
