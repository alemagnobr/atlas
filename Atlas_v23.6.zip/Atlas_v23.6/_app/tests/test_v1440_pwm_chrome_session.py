import ast
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")
MANIFEST = json.loads((ROOT / "browser_extension" / "pwm_bridge" / "manifest.json").read_text())


class PwmChromeSessionV1440Tests(unittest.TestCase):
    def test_source_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_pwm_uses_the_selected_normal_browser_session(self):
        self.assertIn("open_password_manager_in_selected_browser", MAIN)
        self.assertIn('subprocess.Popen(\n                [str(executable), url]', MAIN)
        self.assertIn('PWM_URL = "https://gestorsenhas.senado.leg.br/private/login"', MAIN)
        start = MAIN.index("    def connect_password_manager")
        end = MAIN.index("    def _begin_password_manager_browser", start)
        active_flow = MAIN[start:end]
        self.assertNotIn("_begin_password_manager_browser", active_flow)
        self.assertNotIn("launch_password_manager_browser", active_flow)

    def test_local_extension_reads_only_pwm_cookies(self):
        self.assertEqual(MANIFEST["manifest_version"], 3)
        self.assertIn("cookies", MANIFEST["permissions"])
        self.assertEqual(MANIFEST["host_permissions"], [
            "https://gestorsenhas.senado.leg.br/*",
            "http://127.0.0.1/*",
        ])
        self.assertIn('chrome.cookies.getAll', (ROOT / "browser_extension/pwm_bridge/service_worker.js").read_text())
        self.assertIn('domain: job.domain', (ROOT / "browser_extension/pwm_bridge/service_worker.js").read_text())

    def test_cookie_relay_is_not_automatic_at_startup(self):
        self.assertIn("class PwmChromeRelay(QObject):", MAIN)
        initialization = MAIN[MAIN.index("class Dashboard(QWidget):"):MAIN.index("def build_ui", MAIN.index("class Dashboard(QWidget):"))]
        self.assertNotIn("self.pwm_chrome_relay.start()", initialization)
        self.assertIn("request_cookie_sync", MAIN)
        self.assertIn("open_password_manager_in_selected_browser()", MAIN)
        self.assertNotIn("QTimer.singleShot(900, self.connect_password_manager)", MAIN)

    def test_powershell_protects_cookies_received_from_chrome(self):
        self.assertIn('"password_manager_import_cookies"', BRIDGE)
        self.assertIn("Save-PasswordManagerWebSession $webSession", BRIDGE)
        self.assertIn("@@PASSWORD_MANAGER_CHROME_SESSION@@", BRIDGE)
        self.assertIn("$normalizedDomain.EndsWith('.senado.leg.br')", BRIDGE)

    def test_local_disconnect_does_not_logout_personal_chrome(self):
        start = MAIN.index("    def end_password_manager_session")
        end = MAIN.index("    def _reset_password_manager_profile_async", start)
        method = MAIN[start:end]
        self.assertIn("O Chrome continuará logado no PWM", method)
        self.assertNotIn('run_user_bridge("password_manager_logout"', method)
        self.assertNotIn("reset_password_manager_browser_profile", method)


if __name__ == "__main__":
    unittest.main()
