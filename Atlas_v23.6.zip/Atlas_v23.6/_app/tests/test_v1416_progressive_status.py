from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class V1416ProgressiveStatusTests(unittest.TestCase):
    def test_source_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_core_status_is_consumed_before_process_completion(self):
        self.assertIn('self.pending_action == "status"', MAIN)
        self.assertIn('and "@@STATUS@@" in self.command_output', MAIN)
        self.assertIn('self.update_status_panel(self.command_output)', MAIN)
        core_handler = MAIN[MAIN.index("def append_log"):MAIN.index("def _append_user_log")]
        self.assertNotIn('self.set_connection_query_state(False)', core_handler)
        self.assertIn('35, "Dados principais do micro carregados', core_handler)

    def test_final_status_marker_wins_over_preliminary_marker(self):
        self.assertIn('for line in reversed(output.splitlines()):', MAIN)
        self.assertIn('self._status_core_received = False', MAIN)

    def test_remote_core_operations_are_individually_bounded(self):
        self.assertIn('function Get-BoundedWmiObject', BRIDGE)
        self.assertIn('Wait-Job -Job $job -Timeout $TimeoutSeconds', BRIDGE)
        self.assertIn('Get-WmiObject @parameters', BRIDGE)
        self.assertIn('$pingClient.Send($Computer, 1800)', BRIDGE)

    def test_bridge_publishes_core_before_slow_complementary_queries(self):
        core = BRIDGE.index('Write-Output ("@@STATUS@@" + ($coreStatusData')
        permissions = BRIDGE.index('Write-Output "[STATUS] Consultando permissões locais..."')
        printers = BRIDGE.index('Write-Output "[STATUS] Consultando impressoras e Registro remoto..."')
        self.assertLess(core, permissions)
        self.assertLess(core, printers)


if __name__ == "__main__":
    unittest.main()
