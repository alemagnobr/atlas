from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class UserHeaderRefreshV1515Tests(unittest.TestCase):
    def test_source_parses_and_version_is_current(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_refresh_button_is_next_to_user_heading(self):
        header = MAIN[MAIN.index('self.user_result_heading = QLabel("INFORMAÇÕES DO USUÁRIO")'):]
        header = header[:header.index("user_result_layout.addLayout(user_result_header)")]
        self.assertIn('self.user_information_refresh_button.setObjectName("userHeaderRefreshButton")', header)
        self.assertIn('set_button_icon(self.user_information_refresh_button, "refresh"', header)
        self.assertIn("self.user_information_refresh_button.clicked.connect(self.refresh_user_information)", header)
        self.assertIn("user_result_header.addWidget(self.user_information_refresh_button", header)

    def test_manual_refresh_uses_current_login_and_bypasses_cache(self):
        method = MAIN[MAIN.index("def refresh_user_information"):MAIN.index("def user_login_edited")]
        self.assertIn('self.user_control_data.get("login")', method)
        self.assertIn("self.lookup_user_control(force_refresh=True)", method)
        self.assertIn("self.reset_user_ticket_preview", method)

    def test_regular_lookup_keeps_cache_but_supports_explicit_refresh(self):
        method = MAIN[MAIN.index("def lookup_user_control"):MAIN.index("def _start_password_manager_user_lookup")]
        self.assertIn("def lookup_user_control(self, force_refresh: bool = False)", method)
        self.assertIn("force_refresh or QApplication.keyboardModifiers()", method)
        self.assertIn("if cache and not force_refresh", method)

    def test_refresh_button_follows_query_busy_state(self):
        state = MAIN[MAIN.index("def set_user_query_state"):MAIN.index("def set_password_manager_connection_state")]
        self.assertIn("self.user_information_refresh_button.setEnabled(not active and bool(self.user_control_data))", state)
        self.assertIn("set_refresh_icon_busy(self.user_information_refresh_button, active)", state)


if __name__ == "__main__":
    unittest.main()
