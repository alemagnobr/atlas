import ast
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")
function = next(node for node in ast.parse(SOURCE).body if isinstance(node, ast.FunctionDef) and node.name == "station_ping_display")
namespace = {}
exec(compile(ast.Module(body=[function], type_ignores=[]), "main.py", "exec"), namespace)


class StationPingTests(unittest.TestCase):
    def test_color_groups_and_unclassified_ttl(self):
        display = namespace["station_ping_display"]
        for ttl, expected in ((123, "green"), (126, "green"), (250, "yellow"), (253, "yellow"), (64, "neutral")):
            with self.subTest(ttl=ttl):
                self.assertEqual(display({"ping_result": "Resposta recebida", "ping_ttl": ttl}), (expected, f"TTL={ttl}"))

    def test_failure_never_looks_green(self):
        display = namespace["station_ping_display"]
        self.assertEqual(display({"ping_result": "Tempo de limite perdido", "ping_ttl": None}), ("timeout", "Tempo de limite perdido"))
        self.assertEqual(display({"ping_result": "Sem resposta ao ping"}), ("timeout", "Tempo de limite perdido"))
        self.assertEqual(display({"ping_result": "Testando"}), ("pending", "Testando…"))
        self.assertEqual(display({"ping_result": "Resposta recebida"}), ("neutral", "TTL indisponível"))

    def test_bridge_provides_ping_on_initial_and_final_status(self):
        status = BRIDGE.split('    "status" {', 1)[1].split('    "ping" {', 1)[0]
        self.assertIn('ping.exe -n 1 -w 1800 $Computer', status)
        self.assertIn(r'(?i)\bTTL\s*=\s*(\d{1,3})\b', status)
        self.assertIn('$pingObject.ResponseTimeToLive', status)
        self.assertEqual(status.count('ping_ttl = $pingTtl'), 2)
        self.assertEqual(status.count('ping_result = $pingResult'), 2)

    def test_windows_ping_reply_exposes_the_received_ttl(self):
        pattern = re.search(r"\[regex\]::Match\(\[string\]\$pingOutput, '([^']+)'\)", BRIDGE).group(1)
        reply = "Resposta de 10.10.10.1: bytes=32 tempo=2ms TTL=253"
        self.assertEqual(int(re.search(pattern, reply).group(1)), 253)
        self.assertIsNone(re.search(pattern, "Esgotado o tempo limite do pedido."))


if __name__ == "__main__":
    unittest.main()
