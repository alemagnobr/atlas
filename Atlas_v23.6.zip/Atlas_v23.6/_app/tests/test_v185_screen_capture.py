from datetime import datetime
from pathlib import Path
import os
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
CAPTURE = (ROOT / "ui" / "screen_capture.py").read_text(encoding="utf-8")


class ScreenCaptureSourceTests(unittest.TestCase):
    def test_footer_replaces_windows_lock_with_capture_button(self):
        footer = MAIN.split("self.side_mode_button = AnimatedSideModeButton(framed=True)", 1)[1].split(
            "self.screen_capture_saved.connect", 1)[0]
        self.assertIn('settings.setToolTip("Configurações do Atlas")', footer)
        self.assertIn('setAccessibleName("Capturar Tela")', footer)
        self.assertIn('set_button_icon(self.screen_capture_button, "camera", "#FFFFFF", 17)', footer)
        self.assertIn("clicked.connect(self.start_screen_capture)", footer)
        self.assertNotIn("quick_lock_windows", MAIN)
        self.assertNotIn("sccm_capture", MAIN)

    def test_flow_opens_editor_after_existing_selection(self):
        block = MAIN[MAIN.index("def start_screen_capture"):MAIN.index("def finish_screen_capture_save")]
        self.assertIn("window.setWindowOpacity(0.0)", block)
        self.assertIn("editor = CaptureEditorDialog(", block)
        self.assertIn("editor.exec()", block)
        self.assertNotIn("getSaveFileName(", block)
        self.assertIn("session.cancelled.connect(self._end_screen_capture)", block)

    def test_overlay_freezes_each_monitor_and_crops_physical_pixels(self):
        self.assertIn("for screen in QGuiApplication.screens():", CAPTURE)
        self.assertIn("screen.grabWindow(0)", CAPTURE)
        self.assertIn("self.snapshot.pixmap.copy(area).toImage()", CAPTURE)
        self.assertIn("event.key() == Qt.Key_Escape", CAPTURE)
        self.assertIn("QColor(0, 0, 0, 115)", CAPTURE)
        self.assertIn('f"{size.width()} × {size.height()} px"', CAPTURE)


class ScreenCaptureFolderTests(unittest.TestCase):
    def test_default_folder_is_standard_user_downloads(self):
        block = MAIN[MAIN.index("def default_screen_capture_folder"):MAIN.index("def open_browser_settings_dialog")]
        self.assertIn("profile = interactive_user_profile()", block)
        self.assertIn('dict(standard_user_folders(profile)).get("Downloads")', block)
        self.assertIn('faq_cache_path().with_name("screen_capture_preferences.json")', MAIN)
        self.assertIn("if configured and Path(configured).is_dir():", block)

    def test_settings_dialog_selects_and_saves_capture_folder(self):
        settings = MAIN[MAIN.index("def open_browser_settings_dialog"):MAIN.index("class AuthorizedPrinterDialog")]
        self.assertIn('QLabel("Pasta das capturas de tela")', settings)
        self.assertIn("QFileDialog.getExistingDirectory(", settings)
        self.assertIn('default_capture.setAccessibleName("Usar padrão")', settings)
        self.assertIn("default_capture.clicked.connect(reset_capture_folder)", settings)
        self.assertIn('save_json_cache(screen_capture_settings_path(), {"folder": capture_choice["folder"]})', settings)

    def test_editor_starts_in_configured_folder(self):
        block = MAIN[MAIN.index("def _screen_capture_selected"):MAIN.index("def finish_screen_capture_save")]
        self.assertIn("str(screen_capture_folder() / default_capture_filename())", block)
        self.assertIn("editor.saved.connect(self.screen_capture_saved.emit)", block)


class ScreenCaptureHelperTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
            sys.path.insert(0, str(ROOT))
            from PySide6.QtCore import QPoint, QRect, QSize
            from ui import screen_capture
        except ImportError as exc:  # testes de contrato não exigem PySide6
            raise unittest.SkipTest(str(exc))
        cls.QPoint, cls.QRect, cls.QSize, cls.capture = QPoint, QRect, QSize, screen_capture

    def test_default_name_and_formats(self):
        capture = self.capture
        self.assertEqual(capture.default_capture_filename(datetime(2026, 10, 1, 13, 30, 25)),
                         "Captura_2026-10-01_13-30-25.png")
        self.assertEqual(capture.capture_save_filter().split(";;")[0], capture.DEFAULT_CAPTURE_FILTER)
        self.assertIn("*.jpg *.jpeg", capture.capture_save_filter())
        self.assertIn("*.bmp", capture.capture_save_filter())

    def test_extension_follows_selected_format(self):
        resolve = self.capture.resolve_capture_path
        self.assertEqual(resolve("C:/x/a.png", ""), ("C:/x/a.png", "PNG"))
        self.assertEqual(resolve("C:/x/a.JPEG", ""), ("C:/x/a.JPEG", "JPG"))
        self.assertEqual(resolve("C:/x/a", "Imagem BMP (*.bmp)"), ("C:/x/a.bmp", "BMP"))
        self.assertEqual(resolve("C:/x/a", "Imagem JPEG (*.jpg *.jpeg)"), ("C:/x/a.jpg", "JPG"))
        self.assertEqual(resolve("C:/x/a", ""), ("C:/x/a.png", "PNG"))

    def test_selection_is_normalized_and_scaled_for_dpi(self):
        P, R, S = self.QPoint, self.QRect, self.QSize
        bounds = R(0, 0, 1536, 864)
        selection = self.capture.normalized_selection(P(300, 200), P(100, 50), bounds)
        self.assertEqual((selection.x(), selection.y(), selection.width(), selection.height()), (100, 50, 201, 151))
        clipped = self.capture.normalized_selection(P(-20, -20), P(5000, 5000), bounds)
        self.assertEqual(clipped, bounds)
        physical = self.capture.logical_to_physical(R(100, 40, 200, 100), S(1536, 864), S(1920, 1080))
        self.assertEqual((physical.x(), physical.y(), physical.width(), physical.height()), (125, 50, 250, 125))
        same = self.capture.logical_to_physical(R(10, 10, 50, 20), S(1920, 1080), S(1920, 1080))
        self.assertEqual((same.width(), same.height()), (50, 20))


if __name__ == "__main__":
    unittest.main()
