import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")
VERSION_INFO = (ROOT / "installer" / "version_info.txt").read_text(encoding="utf-8")


class UserControlPasswordManagerV1431Tests(unittest.TestCase):
    def test_version_is_consistent(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("filevers=(23, 6, 0, 0)", VERSION_INFO)
        self.assertIn("prodvers=(23, 6, 0, 0)", VERSION_INFO)

    def test_user_control_is_a_real_second_tab(self):
        self.assertIn('self.control_tabs.addTab(station_control_page, "Controle da estação")', MAIN)
        self.assertIn('self.control_tabs.addTab(self.user_control_page, "Controle de usuários")', MAIN)
        self.assertIn('self.user_login_input.setPlaceholderText("Login de rede do usuário")', MAIN)
        self.assertIn('self.user_result_card = QFrame(objectName="userResultCard")', MAIN)

    def test_direct_ad_lookup_does_not_require_a_station(self):
        start = BRIDGE.index('    "user_control_lookup" {')
        end = BRIDGE.index('    "ad_groups" {', start)
        action = BRIDGE[start:end]
        self.assertNotIn("Require-Computer", action)
        self.assertIn("Normalize-AtlasNetworkLogin $Value", action)
        self.assertIn("Get-AtlasAdUserData $userOnly", action)
        self.assertIn("@@USERCONTROL@@", action)

    def test_ad_query_uses_exact_validated_login_and_escaped_filter(self):
        self.assertIn("function Normalize-AtlasNetworkLogin", BRIDGE)
        self.assertIn("^[A-Za-z0-9._-]{1,128}$", BRIDGE)
        self.assertIn("$escapedLogin", BRIDGE)
        self.assertIn("sAMAccountName=$escapedLogin", BRIDGE)
        for field in ("identity", "organization", "contact", "account", "password", "profile", "groups"):
            self.assertRegex(BRIDGE, rf"(?m)^\s*{re.escape(field)}\s*=")

    def test_user_work_uses_an_independent_nonblocking_runner(self):
        self.assertIn("self.user_runner = PowerShellRunner(self)", MAIN)
        self.assertIn("self.user_runner.output.connect(self._append_user_output)", MAIN)
        self.assertIn("self.user_runner.completed.connect(self._user_execution_done)", MAIN)
        self.assertIn("timeout_ms=45000", MAIN)
        self.assertIn("timeout_ms=85000", MAIN)

    def test_password_manager_session_is_independent_from_capri(self):
        self.assertIn("password_manager_session.protected", BRIDGE)
        self.assertIn("capri_session.protected", BRIDGE)
        self.assertIn('credential_write(self.password_manager_username, password, "gestor_senhas")', MAIN)
        self.assertIn('credential_write(username, password, "capri")', MAIN)
        self.assertIn("Save-PasswordManagerWebSession", BRIDGE)
        self.assertIn("Restore-PasswordManagerWebSession", BRIDGE)

    def test_manager_login_reuses_a_session_and_does_not_put_password_in_arguments(self):
        start = BRIDGE.index('    "password_manager_login" {')
        end = BRIDGE.index('    "password_manager_logout" {', start)
        action = BRIDGE[start:end]
        self.assertIn("Restore-PasswordManagerWebSession", action)
        self.assertIn("Save-PasswordManagerWebSession", action)
        self.assertIn("ATLAS_PASSWORD_MANAGER_PASSWORD_B64", action)
        run_start = MAIN.index("    def run_user_bridge(")
        run_end = MAIN.index("    def _append_user_output", run_start)
        self.assertNotIn("password", MAIN[run_start:run_end].lower())

    def test_recovery_requires_preview_confirmation_and_cooldown(self):
        self.assertIn('"password_recovery_preview"', MAIN)
        self.assertIn('"password_recovery_send"', MAIN)
        self.assertIn('confirm_action(\n                    self, "Confirmar recuperação de senha"', MAIN)
        self.assertIn("password_recovery_cooldown_until", MAIN)
        self.assertIn("Nenhuma repetição automática foi realizada", BRIDGE)
        self.assertIn("@@PASSWORD_RECOVERY_PREVIEW@@", BRIDGE)
        self.assertIn("@@PASSWORD_RECOVERY_SENT@@", BRIDGE)

    def test_sensitive_markers_are_removed_from_visual_log(self):
        start = MAIN.index("    def _append_user_log")
        end = MAIN.index("    @staticmethod\n    def normalize_user_lookup_login", start)
        method = MAIN[start:end]
        for marker in (
            "USERCONTROL", "PASSWORD_MANAGER_USER", "PASSWORD_MANAGER_SESSION",
            "PASSWORD_RECOVERY_PREVIEW", "PASSWORD_RECOVERY_SENT",
        ):
            self.assertIn(marker, method)

    def test_ad_result_survives_manager_failure(self):
        self.assertIn("o PWM está conectado, mas a consulta do usuário não foi concluída", MAIN)
        self.assertIn("Active Directory carregado; a sessão do PWM expirou", MAIN)
        self.assertIn("Não consultado nesta solicitação", MAIN)

    def test_exit_preserves_pwm_but_keeps_capri_logout_guard(self):
        close_start = MAIN.index("    def closeEvent(self, event):")
        close_end = MAIN.index("    def update_login_arrow_direction", close_start)
        close_method = MAIN[close_start:close_end]
        self.assertNotIn("terminate_password_manager_session()", close_method)
        self.assertIn("Preserva o perfil PWM", close_method)
        self.assertIn("terminate_capri_session()", close_method)


if __name__ == "__main__":
    unittest.main()
