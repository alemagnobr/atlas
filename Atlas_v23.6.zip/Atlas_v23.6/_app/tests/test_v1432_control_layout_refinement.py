import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class ControlLayoutRefinementV1432Tests(unittest.TestCase):
    def test_version_is_current(self):
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_primary_tabs_fill_the_available_width(self):
        self.assertIn("class BalancedTabBar(QTabBar):", MAIN)
        self.assertIn("self.setExpanding(True)", MAIN)
        self.assertIn("self.control_tabs.setTabBar(BalancedTabBar(self.control_tabs))", MAIN)
        self.assertIn("#controlTabs QTabBar {{ background: transparent; border: none; }}", MAIN)

    def test_station_title_is_not_duplicated_in_the_visible_layout(self):
        construction = MAIN[MAIN.index('station_control_page = QWidget()'):MAIN.index('self.control_tabs.addTab(station_control_page')]
        self.assertNotIn('cbox.addWidget(self.connection_status', construction)
        self.assertIn('cbox.addWidget(self.target_input, 0, 0)', construction)
        self.assertIn('cbox.addWidget(self.connection_tools, 0, 2', construction)

    def test_user_query_has_no_redundant_pwm_toggle(self):
        construction = MAIN[MAIN.index('self.user_control_page = QWidget()'):MAIN.index('self.control_tabs.addTab(self.user_control_page')]
        self.assertNotIn('self.password_manager_button =', construction)
        self.assertNotIn('self.password_manager_status =', construction)
        self.assertIn('self.user_lookup_button = QPushButton("Consultar usuário")', construction)

    def test_user_result_uses_station_style_card_language(self):
        for token in (
            'self.user_result_card.setProperty("connected", True)',
            'self.user_result_pulse.setObjectName("connectedUserPulse")',
            'self.user_result_identity = QFrame(objectName="userIdentityBar")',
            'self.user_identity_name_host = CopyableInfoFrame(objectName="userIdentityItem")',
            'self.user_identity_login_host = CopyableInfoFrame(objectName="userIdentityItem")',
        ):
            self.assertIn(token, MAIN)


if __name__ == "__main__":
    unittest.main()
