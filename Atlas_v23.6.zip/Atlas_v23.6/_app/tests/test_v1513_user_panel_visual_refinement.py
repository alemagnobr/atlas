from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class UserPanelVisualRefinementV1513Tests(unittest.TestCase):
    def test_source_parses_and_version_is_current(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_user_cards_have_more_internal_space_without_changing_station_cards(self):
        user = MAIN[MAIN.index("class UserDataFieldCard"):MAIN.index("class StationDataFieldCard")]
        station = MAIN[MAIN.index("class StationDataFieldCard"):MAIN.index("class PasswordExpiryStatusCard")]
        password = MAIN[MAIN.index("class PasswordExpiryStatusCard"):MAIN.index("class AdminStatusWidget")]
        self.assertIn("layout.setContentsMargins(10, 7, 10, 8)", user)
        self.assertIn("layout.setSpacing(3)", user)
        self.assertIn("layout.setContentsMargins(10, 7, 10, 8)", password)
        self.assertIn("layout.setContentsMargins(7, 4, 7, 5)", station)

    def test_identity_and_ticket_controls_are_more_legible(self):
        self.assertIn('self.user_result_heading.setObjectName("userResultTitle")', MAIN)
        self.assertIn("self.quick_ad_button.setFixedSize(27, 27)", MAIN)
        self.assertIn("self.user_login_copy_button.setFixedSize(27, 27)", MAIN)
        self.assertIn("self.refresh_button.setFixedSize(30, 30)", MAIN)
        self.assertIn("self.open_button.setFixedSize(30, 30)", MAIN)

    def test_recent_ticket_caption_uses_natural_wording(self):
        self.assertIn('self.caption_label.setText(f"Chamados recentes de {first_name}")', MAIN)
        self.assertNotIn('self.caption_label.setText(f"Chamados do Sr(a). {first_name}")', MAIN)

    def test_dark_theme_uses_refined_panel_palette(self):
        self.assertIn('background: #081F28; border-color: #24515D; border-left-color: #27B986;', MAIN)
        self.assertIn('#userFieldCaption {{ color: #8FCBEA; }}', MAIN)
        self.assertIn('#userResultTitle {{ color: #F2F8FC; }}', MAIN)


if __name__ == "__main__":
    unittest.main()
