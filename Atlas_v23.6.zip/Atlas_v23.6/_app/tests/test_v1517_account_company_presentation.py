from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class AccountCompanyPresentationV1517Tests(unittest.TestCase):
    def test_source_parses_and_version_is_current(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_uppercase_company_is_formatted_only_for_display(self):
        method = MAIN[MAIN.index("def format_company_name"):MAIN.index("def parse_password_expiration")]
        self.assertIn("if not visible.isupper()", method)
        self.assertIn("visible.casefold().title()", method)
        self.assertIn('(" Da ", " Das ", " De ", " Do ", " Dos ", " E ")', method)
        render = MAIN[MAIN.index("def render_user_control_data"):MAIN.index("def reset_user_ticket_preview")]
        self.assertIn('"company": self.format_company_name(self._information_value(organization, "Empresa"))', render)

    def test_active_account_sets_a_semantic_card_state(self):
        render = MAIN[MAIN.index("def render_user_control_data"):MAIN.index("def reset_user_ticket_preview")]
        self.assertIn('status_card = self.user_field_cards["status"]', render)
        self.assertIn('"fieldState", "active"', render)
        for value in ("ativa", "ativo", "active", "habilitada", "habilitado", "enabled"):
            self.assertIn(f'"{value}"', render)
        self.assertIn("status_card.style().unpolish(status_card)", render)
        self.assertIn("status_card.style().polish(status_card)", render)

    def test_active_account_is_green_in_both_themes(self):
        self.assertIn('#userFieldCard[fieldState="active"] #userFieldValue {{ color: {GREEN}; font-weight: 850; }}', MAIN)
        self.assertIn('#userFieldCard[fieldState="active"] #userFieldValue {{ color: #66E2B1; }}', MAIN)


if __name__ == "__main__":
    unittest.main()
