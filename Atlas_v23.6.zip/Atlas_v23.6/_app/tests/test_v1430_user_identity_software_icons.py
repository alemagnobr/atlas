from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
VERSION_INFO = (ROOT / "installer" / "version_info.txt").read_text(encoding="utf-8")


class UserIdentityAndSoftwareIconTests(unittest.TestCase):
    def test_version_is_1430(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("filevers=(23, 6, 0, 0)", VERSION_INFO)
        self.assertIn("prodvers=(23, 6, 0, 0)", VERSION_INFO)

    def test_station_identity_keeps_micro_and_user_side_by_side(self):
        self.assertIn('self.station_identity_user_name = QLabel("USUÁRIO\\n—")', MAIN)
        self.assertIn('self.station_identity_user_name.setObjectName("stationIdentityText")', MAIN)
        self.assertIn("user_identity_layout = QHBoxLayout(self.station_identity_user_host)", MAIN)
        self.assertIn("identity_layout.setColumnStretch(0, 1)", MAIN)
        self.assertIn("identity_layout.setColumnStretch(1, 1)", MAIN)
        self.assertNotIn("station_identity_user_login", MAIN)

    def test_network_login_is_copied_from_the_user_panel(self):
        self.assertIn("QApplication.clipboard().setText(login)", MAIN)
        self.assertNotIn('network_login = f"SENADO\\\\{login}"', MAIN)

    def test_station_user_uses_the_same_identity_language_in_both_themes(self):
        self.assertIn("self.station_identity_user_name.setProperty(\"nameResolved\", name_resolved)", MAIN)
        self.assertIn("#stationIdentityText {{ background: transparent; color: {BLUE}", MAIN)
        self.assertIn("#stationIdentityText, #statusValueText {{ color: #E9F4FA; }}", MAIN)

    def test_software_icon_has_safe_area_without_pixel_mask(self):
        card = MAIN.split("class AuthorizedSoftwareCard", 1)[1].split("class SoftwareCategoryButton", 1)[0]
        self.assertIn("icon.setFixedSize(40, 40)", card)
        self.assertIn("icon.setAttribute(Qt.WA_StyledBackground, True)", card)
        self.assertIn('modern_icon("software", GREEN, 18).pixmap(18, 18)', card)
        self.assertNotIn("icon.setMask", card)
        self.assertIn("#softwareGlyph {{", MAIN)
        self.assertIn("border-radius: 20px; padding: 0;", MAIN)


if __name__ == "__main__":
    unittest.main()
