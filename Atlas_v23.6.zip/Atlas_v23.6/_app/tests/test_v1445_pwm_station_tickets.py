import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
VERSION_INFO = (ROOT / "installer" / "version_info.txt").read_text(encoding="utf-8-sig")


class PwmStationTicketsV1445Tests(unittest.TestCase):
    def test_sources_and_version_metadata_are_current(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("filevers=(23, 6, 0, 0)", VERSION_INFO)
        self.assertIn("prodvers=(23, 6, 0, 0)", VERSION_INFO)

    def test_password_card_has_pwm_action_using_configured_browser(self):
        password_card = MAIN[MAIN.index("class PasswordExpiryStatusCard"):MAIN.index("class AdminStatusWidget")]
        self.assertIn("pwm_requested = Signal()", password_card)
        self.assertIn('self.pwm_button = QPushButton("PWM")', password_card)
        self.assertIn("self.pwm_button.clicked.connect(self.pwm_requested.emit)", password_card)
        self.assertIn("self.password_expiry_status.pwm_requested.connect(self.open_password_manager_page)", MAIN)
        pwm_method = MAIN[MAIN.index("def open_password_manager_page"):MAIN.index("def _user_execution_done")]
        self.assertIn("self.open_external_link(PWM_URL)", pwm_method)

    def test_station_fields_separate_caption_from_value(self):
        station_card = MAIN[MAIN.index("class StationDataFieldCard"):MAIN.index("class PasswordExpiryStatusCard")]
        self.assertIn('self.caption_label.setObjectName("statusFieldCaption")', station_card)
        self.assertIn('self.value_label.setObjectName("statusFieldValue")', station_card)
        admin = MAIN[MAIN.index("class AdminStatusWidget"):MAIN.index("class ActionCard")]
        self.assertIn('self.caption_label.setObjectName("statusFieldCaption")', admin)
        self.assertIn('self.value_label.setObjectName("statusFieldValue")', admin)
        self.assertIn("display_widget = StationDataFieldCard(", MAIN)
        self.assertIn("self.disk_d_button.clicked.connect(self.quick_disk_profiles)", MAIN)

    def test_ticket_search_runs_only_when_requested_and_uses_all_cached_statuses(self):
        self.assertNotIn("self.ticket_search.textEdited.connect", MAIN)
        self.assertNotIn("self.ticket_search.textChanged.connect", MAIN)
        self.assertIn("self.ticket_search.returnPressed.connect(self.search_tickets)", MAIN)
        self.assertIn("self.ticket_search_button.clicked.connect(self.search_tickets)", MAIN)
        search = MAIN[MAIN.index("def search_tickets"):MAIN.index("def filter_tickets")]
        self.assertIn("self.ticket_status_combo.setCurrentIndex(1)", search)
        self.assertIn('self.ticket_period = "all"', search)

    def test_station_status_columns_take_equal_half_widths(self):
        self.assertIn("self.status_grid.setColumnStretch(0, 1)", MAIN)
        self.assertIn("self.status_grid.setColumnStretch(1, 1)", MAIN)

    def test_ticket_search_restores_previous_filter_when_cleared(self):
        search = MAIN[MAIN.index("def search_tickets"):MAIN.index("def filter_tickets")]
        self.assertIn("self.ticket_status_before_search = current_index if current_index > 0 else 3", search)
        self.assertIn("self.ticket_status_combo.setCurrentIndex(restore_index)", search)
        self.assertIn("self.ticket_status_index = restore_index", search)

    def test_refresh_maps_only_yesterday_and_today(self):
        refresh = MAIN[MAIN.index("def refresh_recent_tickets"):MAIN.index("def open_ticket_period_dialog")]
        self.assertIn("yesterday = today.addDays(-1)", refresh)
        self.assertIn("self.ticket_from.setDate(yesterday)", refresh)
        self.assertIn("self.ticket_to.setDate(today)", refresh)
        self.assertIn('self.request_tickets(True, "recent")', refresh)
        self.assertNotIn("mapped_months", refresh)

    def test_recent_refresh_replaces_only_returned_interval(self):
        self.assertIn('refresh_existing=feedback_mode in {"recent", "reconcile_mapped"}', MAIN)
        self.assertIn('replace_interval = self.ticket_feedback_mode in {"recent", "reconcile_mapped"}', MAIN)
        self.assertIn("if replace_interval else None", MAIN)
        self.assertIn("replace_interval and created_date and reconcile_from and reconcile_to", MAIN)


if __name__ == "__main__":
    unittest.main()
