from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class V1415ConnectionWatchdogTests(unittest.TestCase):
    def test_source_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_status_query_has_a_real_deadline(self):
        self.assertIn('timeout_ms = 60_000 if action == "status" else 0', MAIN)
        self.assertIn('timeout_ms=timeout_ms', MAIN)
        self.assertIn('self.deadline.timeout.connect(self._timeout)', MAIN)
        self.assertIn('self.kill()', MAIN)

    def test_timeout_returns_dashboard_to_idle_state(self):
        self.assertIn('self.completed.emit(code == 0 and not self._timed_out)', MAIN)
        self.assertIn('self.set_connection_query_state(False)', MAIN)
        self.assertIn('Tempo limite excedido.', MAIN)

    def test_status_reports_each_remote_phase(self):
        for phase in (
            "Testando conectividade", "Consultando Windows e usuário",
            "Consultando permissões locais", "Consultando impressoras e Registro remoto",
            "Consultando espaço livre na unidade D:",
            "Consultando usuário e grupos no Active Directory",
            "Verificando o acesso ao catálogo de softwares",
        ):
            self.assertIn(phase, BRIDGE)


if __name__ == "__main__":
    unittest.main()
