from pathlib import Path
import unittest

from tools.build_icon_launcher import _resource_leaves, _ico_images


APP_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = APP_ROOT.parent
MAIN = (APP_ROOT / "main.py").read_text(encoding="utf-8-sig")
INTERNAL_RUN = (APP_ROOT / "run.bat").read_text(encoding="utf-8-sig")
LAUNCHER = PACKAGE_ROOT / "Atlas.exe"
ICON = APP_ROOT / "assets" / "app_icon.ico"


class EmbeddedIconLauncherTests(unittest.TestCase):
    def test_version_contract(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn(r"AtlasSuporteAvancado\v23.6", INTERNAL_RUN)

    def test_package_root_contains_only_launcher_and_internal_folder(self):
        self.assertEqual(
            sorted(path.name for path in PACKAGE_ROOT.iterdir()),
            ["Atlas.exe", "_app"],
        )

    def test_launcher_is_a_windows_gui_executable(self):
        data = LAUNCHER.read_bytes()
        self.assertEqual(data[:2], b"MZ")
        pe_offset = int.from_bytes(data[0x3C:0x40], "little")
        self.assertEqual(data[pe_offset:pe_offset + 4], b"PE\0\0")
        optional = pe_offset + 24
        self.assertEqual(int.from_bytes(data[optional + 68:optional + 70], "little"), 2)

    def test_launcher_contains_the_atlas_logo_resources(self):
        executable = LAUNCHER.read_bytes()
        leaves = _resource_leaves(executable)
        images = _ico_images(ICON.read_bytes())
        group_offset, _size = leaves[(14, 101, 0)]
        matched = 0
        count = int.from_bytes(executable[group_offset + 4:group_offset + 6], "little")
        for index in range(count):
            entry = group_offset + 6 + index * 14
            width = executable[entry] or 256
            height = executable[entry + 1] or 256
            bits = int.from_bytes(executable[entry + 6:entry + 8], "little")
            resource_id = int.from_bytes(executable[entry + 12:entry + 14], "little")
            source = images.get((width, height, bits))
            resource = leaves.get((3, resource_id, 0))
            if width in (16, 32, 48) and bits == 32 and source and resource:
                offset, size = resource
                self.assertEqual(executable[offset:offset + size], source)
                matched += 1
        self.assertEqual(matched, 3)

    def test_launcher_opens_the_internal_batch(self):
        self.assertIn(b"#!pyw.exe -3\r\n", LAUNCHER.read_bytes())
        source = (APP_ROOT / "tools" / "build_icon_launcher.py").read_text(encoding="utf-8")
        self.assertIn('root / "_app" / "run.bat"', source)
        self.assertIn("os.startfile(str(launcher))", source)


if __name__ == "__main__":
    unittest.main()
