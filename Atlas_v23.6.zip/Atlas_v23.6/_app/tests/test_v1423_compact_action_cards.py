from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
VERSION_INFO = (ROOT / "installer" / "version_info.txt").read_text(encoding="utf-8")


class CompactActionCardTests(unittest.TestCase):
    def test_version_is_1423(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("filevers=(23, 6, 0, 0)", VERSION_INFO)

    def test_cards_use_content_aware_vertical_sizing(self):
        self.assertIn("self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)", MAIN)
        self.assertIn("self.setMinimumHeight(96)", MAIN)
        self.assertIn("self.setMinimumHeight(100)", MAIN)
        self.assertNotIn("self.setMinimumHeight(136)", MAIN)
        self.assertNotIn("self.setMinimumHeight(118)", MAIN)

    def test_compact_card_aligns_icon_title_description_and_action(self):
        self.assertIn(
            "self.card_layout.addWidget(self.glyph, 0, 0, 2, 1, Qt.AlignVCenter)",
            MAIN,
        )
        self.assertIn("self.card_layout.addWidget(self.subtitle_label, 1, 1)", MAIN)
        self.assertIn(
            "self.card_layout.addWidget(self.action_slot, 0, 2, 2, 1, Qt.AlignVCenter)",
            MAIN,
        )

    def test_grid_spacing_is_reduced_in_both_layout_modes(self):
        self.assertIn("self.action_grid.setHorizontalSpacing(10 if compact_actions else 12)", MAIN)
        self.assertIn("self.action_grid.setVerticalSpacing(10 if compact_actions else 12)", MAIN)


if __name__ == "__main__":
    unittest.main()
