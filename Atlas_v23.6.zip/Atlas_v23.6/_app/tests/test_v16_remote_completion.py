"""Garante que tarefas enviadas não apareçam como execução remota concluída."""

import ast
from pathlib import Path
import re
import unittest


MAIN = (Path(__file__).resolve().parents[1] / "main.py").read_text(encoding="utf-8")


def method(class_name, method_name, namespace):
    tree = ast.parse(MAIN)
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == class_name)
    function = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == method_name)
    code = compile(ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[])), "main.py", "exec")
    exec(code, namespace)
    return namespace[method_name]


class DummyTimer:
    def __init__(self):
        self.active = True

    def isActive(self):
        return self.active

    def stop(self):
        self.active = False


class DummyBar:
    def __init__(self):
        self.number = 70

    def value(self):
        return self.number

    def setValue(self, value):
        self.number = value


class DummyLabel:
    def setText(self, value):
        self.text = value


class RemoteCompletionTests(unittest.TestCase):
    def test_only_verified_remote_completion_reaches_one_hundred(self):
        class DeferredTimer:
            @staticmethod
            def singleShot(_delay, _callback):
                pass

        finish = method("ActionCard", "finish_remote_progress", {"QTimer": DeferredTimer})
        for ok, confirmed, expected in ((True, True, 100), (True, False, 70), (False, False, 70)):
            with self.subTest(ok=ok, confirmed=confirmed):
                card = type("Card", (), {})()
                card.remote_progress_bar = DummyBar()
                card.remote_progress_label = DummyLabel()
                card.remote_progress_timer = DummyTimer()
                card.remote_progress_generation = 1
                finish(card, ok, confirmed)
                self.assertEqual(card.remote_progress_bar.value(), expected)
                self.assertFalse(card.remote_progress_timer.isActive())

    def test_dispatch_only_actions_cannot_claim_remote_completion(self):
        completion = method("Dashboard", "remote_process_confirmed", {"re": re})
        fake = type("Result", (), {"extract_json_marker": lambda _self, _output, _marker: {}})()
        for command in ("dns", "gpupdate", "temp", "trellix_config", "atlas_repair", "restart"):
            with self.subTest(command=command):
                self.assertFalse(completion(fake, command, True, "Comando iniciado na estação."))
        self.assertTrue(completion(fake, "outlook", True, "Outlook fechado em micro remoto."))
        self.assertFalse(completion(fake, "outlook", False, "Outlook fechado em micro remoto."))


if __name__ == "__main__":
    unittest.main()
