from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class BrowserPreferenceEverywhereV1516Tests(unittest.TestCase):
    def test_source_parses_and_version_is_current(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_common_links_always_reach_the_selected_browser_launcher(self):
        method = MAIN[MAIN.index("def launch_external_url"):MAIN.index("def open_password_manager_in_selected_browser")]
        self.assertIn("preference = preferred_browser()", method)
        self.assertIn("request_browser_session(url, preference)", method)
        self.assertIn("return launch_url_for_current_windows_user(url, preference)", method)
        self.assertNotIn("QDesktopServices.openUrl", method)

    def test_explicit_choice_never_falls_back_to_windows_default(self):
        method = MAIN[MAIN.index("def launch_url_for_current_windows_user"):MAIN.index("def available_loopback_port")]
        explicit = method[method.index('if preference in {"chrome", "edge"}'):method.index('if os.name == "nt"')]
        self.assertIn("if executable is None:", explicit)
        self.assertIn("return False, preference, False", explicit)
        self.assertNotIn("os.startfile", explicit)

    def test_pwm_normal_and_exclusive_flows_receive_the_same_preference(self):
        normal = MAIN[MAIN.index("def open_password_manager_in_selected_browser"):MAIN.index("def load_faq_cache")]
        exclusive = MAIN[MAIN.index("def request_password_manager_browser"):MAIN.index("def reset_password_manager_browser_profile")]
        self.assertIn("preference = preferred_browser()", normal)
        self.assertIn("launch_url_for_current_windows_user(PWM_URL, preference)", normal)
        self.assertIn('"browser": preference', exclusive)
        self.assertIn("launch_password_manager_browser(interactive, preference)", exclusive)

    def test_browser_detection_uses_path_and_windows_app_paths(self):
        method = MAIN[MAIN.index("def browser_executable"):MAIN.index("def default_windows_browser_preference")]
        self.assertIn("shutil.which(executable_name)", method)
        self.assertIn("CurrentVersion\\App Paths", method)
        self.assertIn("winreg.HKEY_CURRENT_USER", method)
        self.assertIn("winreg.HKEY_LOCAL_MACHINE", method)

    def test_preference_is_transferred_and_synced_with_ins(self):
        self.assertIn('browser_arg = f" --preferred-browser={preferred_browser()}"', MAIN)
        self.assertIn('command_argument("--preferred-browser=")', MAIN)
        self.assertIn('"operation": "save_browser_preference"', MAIN)
        settings_start = MAIN.index("def open_browser_settings_dialog")
        settings = MAIN[settings_start:MAIN.index("class AuthorizedPrinterDialog", settings_start)]
        self.assertIn("_BROWSER_PREFERENCE_OVERRIDE = preference", settings)
        self.assertIn("sync_browser_preference_with_standard_session(preference)", settings)

    def test_pwm_messages_no_longer_claim_chrome_when_edge_or_system_is_selected(self):
        method = MAIN[MAIN.index("def _request_pwm_browser_session"):MAIN.index("def _pwm_chrome_sync_timeout")]
        self.assertIn("browser_label = dict(BROWSER_OPTIONS).get(preferred_browser()", method)
        self.assertIn("open_password_manager_in_selected_browser()", method)
        self.assertNotIn("Chrome normal", method)


if __name__ == "__main__":
    unittest.main()
