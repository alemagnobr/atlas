from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
TRANSITIONS = (ROOT / "ui" / "transitions.py").read_text(encoding="utf-8-sig")


class V1412PerformanceArchitectureTests(unittest.TestCase):
    def test_sources_are_valid_and_transition_is_modular(self):
        ast.parse(MAIN)
        ast.parse(TRANSITIONS)
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("from ui.transitions import fade_theme_change", MAIN)
        self.assertNotIn("def animate_theme_transition", MAIN)

    def test_icons_are_cached_and_buttons_are_tracked_weakly(self):
        self.assertIn("_ICON_CACHE: dict", MAIN)
        self.assertIn("_THEMED_BUTTONS: weakref.WeakSet", MAIN)
        self.assertIn("cached = _ICON_CACHE.get(cache_key)", MAIN)
        self.assertIn("for button in tuple(_THEMED_BUTTONS):", MAIN)
        self.assertNotIn("for button in app.allWidgets():", MAIN)

    def test_theme_stylesheet_is_not_reapplied_unnecessarily(self):
        self.assertIn('already_applied = app.property("atlasThemeApplied")', MAIN)
        self.assertIn('app.setProperty("atlasThemeApplied", dark)', MAIN)

    def test_ticket_search_and_cards_are_incremental(self):
        self.assertIn("def indexed_ticket_text(self, item: dict)", MAIN)
        self.assertIn("def render_ticket_card_batch(self, generation: int)", MAIN)
        self.assertIn("self.ticket_card_render_queue[:16]", MAIN)
        self.assertIn("QTimer.singleShot(0, lambda current=generation", MAIN)

    def test_station_pulse_avoids_high_frequency_svg_rendering(self):
        self.assertIn("self.station_pulse_timer.setInterval(480)", MAIN)
        self.assertIn("if signature == self._station_icon_signature:", MAIN)


if __name__ == "__main__":
    unittest.main()
