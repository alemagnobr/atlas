from datetime import date, datetime
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from services.template_history import clear_today, display_timestamp, load_today, readable_preview, record_copy


class TemplateHistoryTests(unittest.TestCase):
    def test_records_copied_html_and_only_displays_current_day(self):
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / "template_history.json"
            first = datetime(2026, 10, 8, 14, 20, 5)
            self.assertTrue(record_copy(path, "Fechamento", "closure", "<p>Análise concluída</p>", now=first))
            entries = load_today(path, today=date(2026, 10, 8))
            self.assertEqual(len(entries), 1)
            self.assertEqual(entries[0]["time"], "14:20:05")
            self.assertEqual(display_timestamp(entries[0]), "08/10/2026 às 14:20:05")
            self.assertEqual(entries[0]["html"], "<p>Análise concluída</p>")
            self.assertEqual(load_today(path, today=date(2026, 10, 9)), [])
            self.assertTrue(record_copy(path, "Escalonamento", "escalation", "<p>Tratativa</p>",
                                        now=datetime(2026, 10, 9, 9, 0)))
            self.assertEqual([entry["label"] for entry in load_today(path, today=date(2026, 10, 9))],
                             ["Escalonamento"])

    def test_clear_removes_local_cache_without_touching_saved_templates(self):
        with TemporaryDirectory() as temporary:
            directory = Path(temporary)
            path = directory / "template_history.json"
            saved = directory / "saved_templates.json"
            saved.write_text('{"templates":[]}', encoding="utf-8")
            self.assertTrue(record_copy(path, "Fechamento", "closure", "<div>Resultado</div>"))
            self.assertTrue(clear_today(path))
            self.assertFalse(path.exists())
            self.assertTrue(saved.exists())
            self.assertEqual(load_today(path), [])

    def test_invalid_html_is_not_recorded(self):
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / "template_history.json"
            self.assertFalse(record_copy(path, "Teste", "closure", "texto simples"))
            self.assertFalse(path.exists())

    def test_readable_preview_keeps_content_and_excludes_remote_images(self):
        source = ('<div><div style="font-weight:bold">Análise técnica:</div>'
                  '<div>Texto &lt;validado&gt;</div><p>Atenciosamente,</p>'
                  '<img src="https://capri.senado.leg.br/logo.png" alt="Logo" /></div>')
        preview = readable_preview(source)
        self.assertIn("Análise técnica:\nTexto <validado>", preview)
        self.assertIn("Atenciosamente,", preview)
        self.assertNotIn("capri.senado", preview)
        self.assertNotIn("Logo", preview)


if __name__ == "__main__":
    unittest.main()
