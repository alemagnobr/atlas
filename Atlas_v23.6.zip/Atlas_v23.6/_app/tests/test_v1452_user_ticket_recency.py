import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class UserTicketRecencyV1452Tests(unittest.TestCase):
    def test_preview_is_sorted_newest_first_and_kept_to_25(self):
        ast.parse(MAIN)
        catalog = BRIDGE[BRIDGE.index('    "ticket_catalog" {'):]
        self.assertIn("function Get-CapriPreviewSortDate([object]$Ticket)", catalog)
        self.assertIn("Get-CapriPreviewSortDate $_ }; Descending = $true", catalog)
        self.assertIn("Expression = { [string]$_.number }; Descending = $true", catalog)
        self.assertIn("Select-Object -First $previewLimit", catalog)

    def test_ticket_number_timestamp_is_the_fallback_when_creation_date_is_missing(self):
        self.assertIn("'^(?<date>\\d{14})\\d{0,6}$'", BRIDGE)
        self.assertIn("'yyyyMMddHHmmss'", BRIDGE)
        self.assertIn("return [datetime]::MinValue", BRIDGE)


if __name__ == "__main__":
    unittest.main()
