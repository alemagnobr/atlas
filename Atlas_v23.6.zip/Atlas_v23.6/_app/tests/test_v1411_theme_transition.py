from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
TRANSITIONS = (ROOT / "ui" / "transitions.py").read_text(encoding="utf-8-sig")


class V1411ThemeTransitionTests(unittest.TestCase):
    def test_source_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_both_screens_use_the_fade_transition(self):
        self.assertIn("def fade_theme_change(", TRANSITIONS)
        self.assertIn("self, self.panel,\n            self.apply_pending_login_theme", MAIN)
        self.assertIn("self, self,\n            self.apply_pending_theme", MAIN)
        self.assertIn("snapshot = target.grab()", TRANSITIONS)
        self.assertIn('fade.setStartValue(1.0)', TRANSITIONS)
        self.assertIn('fade.setEndValue(0.0)', TRANSITIONS)
        self.assertIn("QTimer.singleShot(24, reveal_new_theme)", TRANSITIONS)
        self.assertNotIn("target.setGraphicsEffect(effect)", TRANSITIONS)

    def test_login_theme_does_not_call_dashboard_printer_method(self):
        start = MAIN.index("    def apply_pending_login_theme(self):")
        end = MAIN.index("    def finish_login_theme_change(self):", start)
        self.assertNotIn("update_printer_summary", MAIN[start:end])

    def test_dark_printer_buttons_have_all_states(self):
        self.assertIn("#printerQuickButton {{ background: #123047; color: #72DEB2;", MAIN)
        self.assertIn("#printerQuickButton:hover {{ background: #087A54;", MAIN)
        self.assertIn("#printerQuickButton:disabled {{ background: #0B2232;", MAIN)


if __name__ == "__main__":
    unittest.main()
