"""Comportamento das disponibilidades e contratos remotos da versão 18."""
import ast
from pathlib import Path
from types import SimpleNamespace
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'main.py').read_text(encoding='utf-8')
REMOTE = (ROOT / 'scripts' / 'remote_message.ps1').read_text(encoding='utf-8')
INVENTORY = (ROOT / 'scripts' / 'remote_inventory.ps1').read_text(encoding='utf-8')


class Card:
    def __init__(self):
        self.enabled = None

    def setEnabled(self, value):
        self.enabled = bool(value)


class RemoteInventoryTests(unittest.TestCase):
    def test_station_and_user_actions_are_gated(self):
        tree = ast.parse(MAIN)
        dashboard = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'Dashboard')
        method = next(node for node in dashboard.body if isinstance(node, ast.FunctionDef) and node.name == 'update_action_card_availability')
        scope = {}
        exec(compile(ast.Module(body=[method], type_ignores=[]), '<main>', 'exec'), scope)
        station, user, local = Card(), Card(), Card()
        fake = SimpleNamespace(
            cards=[(SimpleNamespace(command='dns', needs_target=True), station),
                   (SimpleNamespace(command='remote_process_list', needs_target=True), user),
                   (SimpleNamespace(command='ad', needs_target=False), local)],
            loading_command='', connection_active=False, last_status_data={},
            station_user_login=lambda value: 'joao' if value == 'SENADO\\joao' else '',
        )
        scope['update_action_card_availability'](fake)
        self.assertEqual((station.enabled, user.enabled, local.enabled), (False, False, True))
        fake.connection_active = True
        scope['update_action_card_availability'](fake)
        self.assertEqual((station.enabled, user.enabled), (True, False))
        fake.last_status_data['user'] = 'SENADO\\joao'
        scope['update_action_card_availability'](fake)
        self.assertTrue(user.enabled)

    def test_termination_revalidates_process_and_owner(self):
        end = INVENTORY.split('function Stop-AtlasUserProcess {', 1)[1].split('function Get-AtlasUserSoftware {', 1)[0]
        self.assertIn('ProcessId=$pidNumber', end)
        self.assertIn('$process.Name -ine [string]$request.name', end)
        self.assertIn('$logged -ine [string]$request.user', end)
        self.assertIn('$owner.User', end)
        self.assertIn('$process.Terminate()', end)
        self.assertIn('$result.ReturnValue -ne 0', end)

    def test_visual_task_uses_v17_direct_delivery_and_requested_message(self):
        self.assertIn("-PostStartDelayMilliseconds 2500", REMOTE)
        self.assertIn("-NoProfile -STA -WindowStyle Hidden -EncodedCommand $encoded", REMOTE)
        self.assertNotIn("wscript.exe", REMOTE)
        self.assertIn("[Atlas.WindowNative]::ShowWindow(`$console, 0)", REMOTE)
        self.assertIn('[void]`$window.ShowDialog()', REMOTE)
        self.assertIn('Sua opinião é importante!', REMOTE)
        self.assertIn('[string]`$data.operator_title', REMOTE)
        self.assertIn('operator_full_name()', MAIN)
        self.assertIn('"operator_title": operator_job_title()', MAIN)
        self.assertIn('`$duration = 10', REMOTE)
        self.assertIn('`$duration = 3', REMOTE)


if __name__ == '__main__':
    unittest.main()
