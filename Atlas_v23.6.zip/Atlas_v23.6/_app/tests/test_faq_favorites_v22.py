from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from services.faq_favorites import load_favorites, toggle_favorite


class FaqFavoritesTests(unittest.TestCase):
    def test_favorites_survive_catalog_deletion_and_toggle_by_number(self):
        with TemporaryDirectory() as directory:
            favorites = Path(directory) / "faq_favorites.json"
            catalog = Path(directory) / "faq_catalog.json"
            catalog.write_text("{}", encoding="utf-8")
            item = {"id": "FAQ#: 1007", "title": "Impressoras", "url": "https://capri.senado.leg.br/otrs/index.pl?ItemID=1007"}
            added, saved = toggle_favorite(favorites, item)
            self.assertTrue(added)
            self.assertEqual(saved[0]["id"], "1007")
            catalog.unlink()
            self.assertEqual(load_favorites(favorites), saved)
            removed, saved = toggle_favorite(favorites, {"id": "1007"})
            self.assertFalse(removed)
            self.assertEqual(saved, [])

    def test_requires_official_url_and_keeps_existing_favorites_on_error(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "faq_favorites.json"
            toggle_favorite(path, {"id": "42", "title": "Rede", "url": "https://capri.senado.leg.br/faq/42"})
            with self.assertRaises(ValueError):
                toggle_favorite(path, {"id": "43", "title": "Outro", "url": "https://example.org/"})
            self.assertEqual([item["id"] for item in load_favorites(path)], ["42"])


if __name__ == "__main__":
    unittest.main()
