from pathlib import Path
import ast
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
REMOTE = (ROOT / "scripts" / "remote_message.ps1").read_text(encoding="utf-8")


class OperatorAndSidebarTests(unittest.TestCase):
    def test_job_title_cleans_employment_marker_without_inventing_a_role(self):
        tree = ast.parse(MAIN)
        function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "operator_job_title")
        namespace = {"re": re, "_OPERATOR_JOB_TITLE_CACHE": "TERCEIRIZADO - Analista de Suporte Junior"}
        exec(compile(ast.Module(body=[function], type_ignores=[]), "<operator title>", "exec"), namespace)
        self.assertEqual(namespace["operator_job_title"](), "Analista de Suporte Junior")
        namespace["_OPERATOR_JOB_TITLE_CACHE"] = ""
        self.assertEqual(namespace["operator_job_title"](), "")

    def test_evaluation_uses_ad_title_and_short_outlook_actions(self):
        self.assertIn("PropertiesToLoad.Add('title')", MAIN)
        self.assertIn('"operator_title": operator_job_title()', MAIN)
        self.assertIn("Acessar Outlook Web", REMOTE)
        self.assertIn("Acessar Outlook Desktop", REMOTE)
        self.assertNotIn("Analista de Suporte Junior", REMOTE)
        self.assertIn("[string]`$data.operator_title", REMOTE)

    def test_sidebar_emphasis_only_when_actions_are_available(self):
        self.assertIn('self.quick_sccm_button.setProperty("emphasis", True)', MAIN)
        self.assertIn('self.quick_ad_user_button.setProperty("emphasis", True)', MAIN)
        self.assertIn('#quickActionButton[emphasis="true"]:disabled', MAIN)
        self.assertIn('self.quick_sccm_button.setEnabled(False)', MAIN)
        self.assertIn('self.quick_ad_user_button.setEnabled(False)', MAIN)


if __name__ == "__main__":
    unittest.main()
