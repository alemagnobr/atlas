import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class UserContactPanelV1443Tests(unittest.TestCase):
    def test_sources_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_ad_loads_telephone_tab_and_notes_properties(self):
        for property_name in (
            "homePhone", "pager", "mobile", "facsimileTelephoneNumber", "ipPhone", "info",
        ):
            self.assertIn(f"'{property_name}'", BRIDGE)
        self.assertIn("notes = (Read-AtlasAdProperty 'info')", BRIDGE)

    def test_ad_contact_payload_preserves_each_phone_type(self):
        expected = {
            "Telefone comercial": "telephonenumber",
            "Residência": "homephone",
            "Pager": "pager",
            "Celular": "mobile",
            "Fax": "facsimiletelephonenumber",
            "Telefone IP": "ipphone",
        }
        for label, property_name in expected.items():
            self.assertIn(
                f"'{label}' = (Read-AtlasAdProperty '{property_name}')",
                BRIDGE,
            )

    def test_heading_is_clean_and_the_source_badge_was_removed(self):
        self.assertIn('self.user_result_heading = QLabel("INFORMAÇÕES DO USUÁRIO")', MAIN)
        self.assertNotIn("self.user_result_source =", MAIN)
        self.assertNotIn('QLabel("Active Directory")', MAIN)

    def test_user_icon_has_a_continuous_fade_animation(self):
        self.assertIn("self.user_result_pulse_opacity = QGraphicsOpacityEffect", MAIN)
        self.assertIn("self.user_result_pulse_animation.setLoopCount(-1)", MAIN)
        self.assertIn("self.user_result_pulse_animation.setKeyValueAt(0.5, 0.32)", MAIN)
        self.assertIn("self.user_result_pulse_animation.start()", MAIN)

    def test_panel_has_compact_phone_and_notes_cards(self):
        self.assertIn('self.user_phones_card = UserDataFieldCard("Telefones")', MAIN)
        self.assertIn('self.user_notes_card = UserDataFieldCard("Observações")', MAIN)
        self.assertIn('self.user_phones_card.set_value("  •  ".join(phone_values)', MAIN)
        self.assertIn('self.user_notes_card.set_value(data.get("notes")', MAIN)
        self.assertIn("layout.setContentsMargins(7, 4, 7, 5)", MAIN)

    def test_identity_stacks_only_when_the_viewport_is_really_narrow(self):
        self.assertIn("stack_identity = compact and available < 430", MAIN)
        self.assertIn("identity.addWidget(self.user_identity_login_host, 0, 1)", MAIN)


if __name__ == "__main__":
    unittest.main()
