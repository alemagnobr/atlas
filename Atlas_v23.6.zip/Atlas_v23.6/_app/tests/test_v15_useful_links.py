import ast
import tempfile
import unittest
import urllib.parse
from pathlib import Path

from storage.json_store import load_json, save_json


MAIN = (Path(__file__).resolve().parents[1] / "main.py").read_text(encoding="utf-8-sig")
TREE = ast.parse(MAIN)
SELECTED = {"DEFAULT_USEFUL_LINKS", "valid_useful_link", "load_useful_links"}
nodes = [node for node in TREE.body if (
    isinstance(node, ast.FunctionDef) and node.name in SELECTED
    or isinstance(node, ast.Assign) and any(
        isinstance(target, ast.Name) and target.id in SELECTED for target in node.targets
    )
)]


class UsefulLinksTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        path = Path(self.temp.name) / "useful_links.json"
        self.path = path
        self.ns = {
            "urllib": urllib,
            "useful_links_path": lambda: path,
            "load_json_cache": load_json,
        }
        exec(compile(ast.Module(body=nodes, type_ignores=[]), "main.py", "exec"), self.ns)

    def test_defaults_only_on_first_use(self):
        self.assertEqual(len(self.ns["load_useful_links"]()), 5)
        self.assertTrue(save_json(self.path, {"links": []}))
        self.assertEqual(self.ns["load_useful_links"](), [])

    def test_added_link_survives_reload_and_deleted_default_stays_deleted(self):
        items = self.ns["load_useful_links"]()
        items = [item for item in items if item["name"] != "Capri"]
        items.append({"name": "Portal", "url": "https://portal.exemplo.br/"})
        self.assertTrue(save_json(self.path, {"links": items}))
        self.assertEqual(self.ns["load_useful_links"](), items)

    def test_rejects_non_web_and_credential_urls(self):
        check = self.ns["valid_useful_link"]
        for url in ("javascript:alert(1)", "file:///C:/x", "https://user:pass@host/", "https://host /path"):
            with self.subTest(url=url):
                self.assertFalse(check("Teste", url))
        self.assertTrue(check("Intranet", "https://intranet.senado.leg.br/"))


if __name__ == "__main__":
    unittest.main()
