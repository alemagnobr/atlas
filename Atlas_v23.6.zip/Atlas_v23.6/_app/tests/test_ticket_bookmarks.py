import tempfile
import unittest
from pathlib import Path

from services.ticket_bookmarks import load_bookmarks, mapped_bookmarks, save_bookmarks, toggle_bookmark
from services.ticket_status_refresh import apply_state_updates


def classify(state, fallback="other"):
    return {"Aberto": "open", "Fechado com êxito": "closed_success"}.get(state, fallback)


class TicketBookmarkTests(unittest.TestCase):
    def test_favorites_and_monitored_survive_reload_and_only_show_mapped_tickets(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "bookmarks.json"
            toggle_bookmark(path, "favorites", "2026100810000101")
            toggle_bookmark(path, "monitored", "2026100810000101")
            toggle_bookmark(path, "favorites", "2026100810000102")
            saved = load_bookmarks(path)
            self.assertEqual(saved["favorites"], {"2026100810000101", "2026100810000102"})
            catalog = {"items": [{"number": "2026100810000101", "state": "Aberto"}]}
            self.assertEqual(len(mapped_bookmarks(catalog, saved, "favorites")), 1)
            self.assertEqual(len(mapped_bookmarks(catalog, saved, "monitored")), 1)
            toggle_bookmark(path, "favorites", "2026100810000101")
            self.assertEqual(load_bookmarks(path)["favorites"], {"2026100810000102"})
            self.assertEqual(load_bookmarks(path)["monitored"], {"2026100810000101"})

    def test_only_confirmed_capri_state_updates_change_mapped_ticket(self):
        saved = {"2026100810000101": {"number": "2026100810000101", "state": "Aberto"}}
        confirmed, changes = apply_state_updates(saved, [
            {"number": "2026100810000101", "state": "Fechado com êxito"},
            {"number": "2026100810000102", "state": "Fechado com êxito"},
            {"number": "2026100810000101", "state": "Estado ilegível"},
        ], classify, "2026-10-08T12:00:00")
        self.assertEqual(confirmed, 1)
        self.assertEqual(changes[0][0], "2026100810000101")
        self.assertEqual(saved["2026100810000101"]["state"], "Fechado com êxito")

    def test_invalid_numbers_never_enter_lists(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "bookmarks.json"
            with self.assertRaises(ValueError):
                toggle_bookmark(path, "favorites", "not-a-ticket")
            self.assertFalse(path.exists())

    def test_user_preview_only_persists_explicitly_selected_ticket(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "bookmarks.json"
            selected = {
                "number": "2026100910000193", "title": "Configuração de impressora",
                "state": "Aberto", "state_kind": "open", "queue": "Nível 1",
                "url": "https://capri.senado.leg.br/otrs/index.pl?Action=AgentTicketZoom;TicketID=123",
                "content": "Cliente pediu orientação",
            }
            other = {"number": "2026100910000194", "title": "Outro chamado"}
            toggle_bookmark(path, "favorites", selected["number"], ticket=selected)
            saved = load_bookmarks(path)
            self.assertEqual([item["number"] for item in mapped_bookmarks({"items": []}, saved, "favorites")],
                             [selected["number"]])
            self.assertNotIn(other["number"], saved["snapshots"])
            toggle_bookmark(path, "monitored", selected["number"], ticket=selected)
            toggle_bookmark(path, "favorites", selected["number"])
            self.assertIn(selected["number"], load_bookmarks(path)["snapshots"])
            toggle_bookmark(path, "monitored", selected["number"])
            self.assertNotIn(selected["number"], load_bookmarks(path)["snapshots"])

    def test_saved_snapshot_state_refresh_and_mapped_catalog_precedence(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "bookmarks.json"
            number = "2026100910000193"
            toggle_bookmark(path, "monitored", number, ticket={
                "number": number, "title": "Suporte", "state": "Aberto",
            })
            saved = load_bookmarks(path)
            confirmed, changes = apply_state_updates(saved["snapshots"], [
                {"number": number, "state": "Fechado com êxito"},
            ], classify, "2026-10-09T12:00:00")
            self.assertEqual(confirmed, 1)
            self.assertEqual(len(changes), 1)
            self.assertTrue(save_bookmarks(path, saved))
            reloaded = load_bookmarks(path)
            self.assertEqual(mapped_bookmarks({"items": []}, reloaded, "monitored")[0]["state"],
                             "Fechado com êxito")
            catalog = {"items": [{"number": number, "title": "Versão do catálogo", "state": "Fechado com êxito"}]}
            self.assertEqual(len(mapped_bookmarks(catalog, reloaded, "monitored")), 1)
            self.assertEqual(mapped_bookmarks(catalog, reloaded, "monitored")[0]["title"],
                             "Versão do catálogo")

    def test_user_dialog_connects_both_card_actions_to_bookmark_callback(self):
        main = (Path(__file__).resolve().parents[1] / "main.py").read_text(encoding="utf-8")
        dialog = main[main.index("class UserTicketsDialog(QDialog):"):main.index("class Dashboard(QWidget):")]
        self.assertIn("card.favorite_requested.connect(", dialog)
        self.assertIn("card.monitored_requested.connect(", dialog)
        self.assertIn('self._toggle_bookmark("favorites", item, control)', dialog)
        self.assertIn('self._toggle_bookmark("monitored", item, control)', dialog)


if __name__ == "__main__":
    unittest.main()
