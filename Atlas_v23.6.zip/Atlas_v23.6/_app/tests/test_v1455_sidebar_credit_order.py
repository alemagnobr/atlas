from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class PageFooterAndSidebarV158Tests(unittest.TestCase):
    def test_source_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_sidebar_credit_was_removed_and_arrow_replaces_legacy_tool(self):
        start = MAIN.index("    def build_ui(self):", MAIN.index("class Dashboard"))
        end = MAIN.index("        root.addWidget(sidebar)", start)
        sidebar = MAIN[start:end]
        self.assertNotIn("sidebar_developer_footer", sidebar)
        self.assertNotIn("Abrir ferramenta legada", sidebar)
        self.assertIn("self.side_mode_button = AnimatedSideModeButton(framed=True)", sidebar)
        self.assertIn("footer_tools.addWidget(self.side_mode_button)", sidebar)

    def test_names_are_linked_in_page_footer(self):
        start = MAIN.index("        self.page_developer_footer = QLabel(")
        end = MAIN.index('        self.page_developer_footer.setObjectName', start)
        footer = MAIN[start:end]
        self.assertIn('Software desenvolvido por ', footer)
        self.assertIn('>Alexandre Linhares</a> e ', footer)
        self.assertIn('>João Cerqueira</a>', footer)
        self.assertIn("https://www.linkedin.com/in/alemagnobr/", footer)
        self.assertIn("https://www.linkedin.com/in/joaocerq/", footer)

    def test_links_keep_dashboard_browser_flow(self):
        self.assertIn(
            "self.page_developer_footer.linkActivated.connect(self.open_external_link)",
            MAIN,
        )
        self.assertIn("#pageDeveloperFooter", MAIN)

    def test_useful_links_open_in_scrollable_popup_without_reflowing_sidebar(self):
        self.assertIn("self.useful_links_popup = QDialog(self)", MAIN)
        self.assertIn("popup_layout.addWidget(self.useful_links_panel, 1)", MAIN)
        self.assertNotIn("side.addWidget(self.useful_links_panel)", MAIN)
        self.assertIn("self.useful_links_scroll.setMaximumHeight(16777215)", MAIN)

    def test_framed_side_mode_uses_login_speed_without_shadow_arrow(self):
        arrow = MAIN[MAIN.index("class AnimatedSideModeButton"):MAIN.index("class ThemeSwitch")]
        self.assertIn("self.timer.setInterval(34)", arrow)
        self.assertIn("self.progress + 0.032", arrow)
        self.assertIn("shift = self.direction * pulse * 2.0", arrow)
        self.assertNotIn("ghost_x", arrow)

    def test_login_credits_remain_unchanged(self):
        login = MAIN[MAIN.index("class LoginPage"):MAIN.index("class BusySpinner")]
        self.assertIn('footer.setObjectName("loginFooter")', login)
        self.assertIn("Alexandre Linhares", login)
        self.assertIn("João Cerqueira", login)


if __name__ == "__main__":
    unittest.main()
