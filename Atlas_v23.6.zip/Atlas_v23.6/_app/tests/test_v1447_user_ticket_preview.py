import ast
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class UserTicketPreviewV1447Tests(unittest.TestCase):
    def test_user_preview_payload_is_explicitly_temporary_and_limited(self):
        from services.capri import build_user_ticket_preview_payload

        payload = json.loads(build_user_ticket_preview_payload(
            login="jcerqueira", display_name="João Victor de Jesus Cerqueira",
        ))
        self.assertEqual(payload["scope"], "customer")
        self.assertEqual(payload["customer_login"], "jcerqueira")
        self.assertEqual(payload["display_name"], "João Victor de Jesus Cerqueira")
        self.assertTrue(payload["preview_only"])
        self.assertEqual(payload["limit"], 25)
        self.assertEqual(payload["cache_path"], "")

    def test_python_source_parses_and_preview_is_routed_away_from_catalog_merge(self):
        ast.parse(MAIN)
        done = MAIN[MAIN.index("def _background_execution_done(self, ok: bool):"):MAIN.index("def execution_done(")]
        self.assertIn('if action == "user_ticket_preview":', done)
        self.assertIn("self.finish_user_ticket_preview(ok, output, generation)", done)
        self.assertLess(done.index('if action == "user_ticket_preview":'), done.index("self.execution_done(ok, action, output)"))
        finish = MAIN[MAIN.index("def finish_user_ticket_preview"):MAIN.index("def finish_station_enrichment")]
        self.assertIn('data.get("preview_only")', finish)
        self.assertIn("self.user_ticket_preview_items = list(data[\"items\"][:25])", finish)
        self.assertIn("em memória; nenhum catálogo foi alterado", finish)

    def test_bridge_uses_recent_customer_query_without_reading_or_writing_catalog(self):
        bridge = BRIDGE[BRIDGE.index('    "ticket_catalog" {'):]
        self.assertIn("$previewOnly = [bool]$request.preview_only", bridge)
        self.assertIn("$previewLimit = if ($previewOnly) { 25 }", bridge)
        self.assertIn("if (!$previewOnly -and $cachePath", bridge)
        self.assertIn("$body['CustomerUserLogin'] = $resolvedLogin", bridge)
        self.assertIn("while ($pageQueue.Count -gt 0", bridge)
        self.assertIn("$items.Count -lt $previewLimit", bridge)
        self.assertIn("preview_only=$previewOnly", bridge)
        self.assertIn("result_limit=$(if ($previewOnly) { $previewLimit } else { 0 })", bridge)

    def test_station_progress_waits_for_temporary_ticket_lookup(self):
        sync = MAIN[MAIN.index("def sync_station_user_control"):MAIN.index("def flush_pending_station_user")]
        connection_state = MAIN[MAIN.index("def set_connection_query_state"):MAIN.index("def set_connection_state")]
        self.assertIn("self.station_enrichment_active = True", sync)
        self.assertIn("from_station=True", sync)
        self.assertIn("self.station_load_cycle_active or self.station_enrichment_active", connection_state)
        self.assertIn("self.connection_progress.show()", connection_state)
        self.assertIn("final_percent = 100 if success else min(99", MAIN[MAIN.index("def finish_station_enrichment"):MAIN.index("def hide_station_enrichment_progress")])


if __name__ == "__main__":
    unittest.main()
