from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8")
INVENTORY_FILE = ROOT / "scripts" / "remote_inventory.ps1"
INVENTORY = INVENTORY_FILE.read_text(encoding="utf-8-sig")


class InventoryGroupingTests(unittest.TestCase):
    def test_process_group_closes_only_selected_pids_after_revalidation(self):
        ast.parse(MAIN)
        self.assertIn('QTreeWidget()', MAIN)
        self.assertIn('"pids": [item.get("pid") for item in processes]', MAIN)
        self.assertIn('"remote_process_end_group" if group else "remote_process_end"', MAIN)
        self.assertIn('"remote_process_end_group" {', BRIDGE)
        block = INVENTORY.split("function Stop-AtlasUserProcessGroup {", 1)[1].split(
            "function Get-AtlasUserSoftware {", 1
        )[0]
        self.assertIn('$request.pids', block)
        self.assertIn('$process.Name -ine $name', block)
        self.assertIn('$process.SessionId -eq 0', block)
        self.assertIn('$owner.User', block)
        self.assertLess(block.index("$verified += $process"), block.index("$process.Terminate()"))
        self.assertNotIn("taskkill", block.lower())

    def test_programs_group_by_scope_and_refresh_is_available(self):
        self.assertIn('groups.setdefault(str(item.get("scope")', MAIN)
        self.assertIn('"Perfil do usuário", "Estação (64 bits)", "Estação (32 bits)"', MAIN)
        self.assertIn('Atualizar processos', MAIN)
        self.assertIn('Atualizar programas', MAIN)
        self.assertTrue(INVENTORY_FILE.read_bytes().startswith(b"\xef\xbb\xbf"))

    def test_connected_cards_use_bright_text_and_disabled_cards_remain_muted(self):
        self.assertIn('#actionCard[compact="true"][available="true"] #cardTitle', MAIN)
        self.assertIn('#actionCard[compact="true"][available="true"] #cardSubtitle', MAIN)
        self.assertIn('#actionCard[compact="true"][available="false"] #cardTitle', MAIN)
        self.assertNotIn(':enabled #cardTitle', MAIN)
        self.assertNotIn(':disabled #cardTitle', MAIN)
        self.assertIn('self.setProperty("available", self.isEnabled())', MAIN)
        self.assertIn('#inventoryTree QHeaderView::section', MAIN)


if __name__ == "__main__":
    unittest.main()
