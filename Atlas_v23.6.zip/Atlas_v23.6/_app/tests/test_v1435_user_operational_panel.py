import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class UserOperationalPanelV1435Tests(unittest.TestCase):
    def test_version_is_current(self):
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_panel_contains_the_requested_operational_fields(self):
        for caption in (
            "Status da conta", "Empresa", "Departamento", "Cargo", "Unidade-Sala", "Gestor",
            "E-mail institucional", "Script de logon", "Vencimento da senha",
        ):
            self.assertIn(f'"{caption}"', MAIN)
        construction = MAIN[MAIN.index("user_fields = ("):MAIN.index("for key, caption, row, column in user_fields")]
        self.assertNotIn('"E-mail pessoal"', construction)
        self.assertNotIn('"Conta habilitada"', construction)
        self.assertIn('self.user_identity_name.setText(f"NOME COMPLETO', MAIN)
        self.assertIn('self.user_identity_login.setText(f"LOGIN DE REDE', MAIN)

    def test_logon_script_and_password_status_are_paired_as_requested(self):
        self.assertIn('(\"logon_script\", \"Script de logon\", 3, 1)', MAIN)
        self.assertIn('self.user_fields_grid.addWidget(self.password_expiration_card, 4, 0)', MAIN)
        self.assertIn('self.user_fields_grid.addWidget(self.password_expiry_status, 4, 1)', MAIN)
        self.assertIn('profile = dict(data.get("profile") or {})', MAIN)
        self.assertIn('"logon_script": self._information_value(profile, "Script de logon")', MAIN)

    def test_ad_values_feed_the_password_cards(self):
        for key in ("Senha expirada no AD", "Vencimento calculado"):
            self.assertIn(f'"{key}"', MAIN)
            self.assertIn(f"'{key}'", BRIDGE)
        self.assertIn("msDS-User-Account-Control-Computed", BRIDGE)
        self.assertIn("msDS-UserPasswordExpiryTimeComputed", BRIDGE)

    def test_expiration_state_is_animated_and_has_a_separate_recovery_icon(self):
        expiry_start = MAIN.index("class PasswordExpiryStatusCard")
        expiry_end = MAIN.index("class AdminStatusWidget", expiry_start)
        expiry = MAIN[expiry_start:expiry_end]
        self.assertIn('text, state = "SIM", "expired"', expiry)
        self.assertIn('text, state = "NÃO", "valid"', expiry)
        self.assertIn("self.pulse.setLoopCount(-1)", expiry)
        self.assertIn('self.recovery_button.setObjectName("passwordRecoveryButton")', expiry)
        self.assertIn('set_button_icon(self.recovery_button, "mail"', expiry)
        self.assertIn('self.recovery_available = state in {"expired", "valid"}', expiry)
        self.assertIn("if self.recovery_available:", expiry)
        self.assertIn("self.recovery_requested.emit()", expiry)
        self.assertIn("self.password_expiry_status.recovery_requested.connect(self.preview_password_recovery)", MAIN)

    def test_expiration_countdown_accepts_pwm_and_ad_date_shapes(self):
        self.assertIn("def parse_password_expiration", MAIN)
        self.assertIn('"outubro": 10', MAIN)
        self.assertIn('"%d/%m/%Y %H:%M"', MAIN)
        self.assertIn('f"{days} dias restantes"', MAIN)
        self.assertIn("self.password_expiration_timer.start()", MAIN)

    def test_station_user_is_automatically_synchronized_after_final_status(self):
        self.assertIn("def sync_station_user_control", MAIN)
        self.assertIn('"concluindo consulta"', MAIN)
        self.assertIn("self.sync_station_user_control(data)", MAIN)
        self.assertIn("self.user_login_input.setText(login)", MAIN)
        self.assertIn("self.lookup_user_control()", MAIN)

    def test_redundant_user_buttons_are_not_created(self):
        self.assertNotIn("self.user_refresh_button =", MAIN)
        self.assertNotIn("self.password_recovery_button =", MAIN)

    def test_station_identity_uses_an_aligned_grid(self):
        self.assertIn("user_identity_layout = QHBoxLayout(self.station_identity_user_host)", MAIN)
        self.assertIn("user_identity_layout.addWidget(self.station_identity_user_name, 1)", MAIN)
        self.assertIn("user_identity_layout.addWidget(self.free_orientation_button, 0", MAIN)

    def test_action_cards_keep_two_columns_in_lateral_width(self):
        self.assertIn("columns = forced_columns or (1 if width < 420 or ticket_narrow else 2)", MAIN)


if __name__ == "__main__":
    unittest.main()
