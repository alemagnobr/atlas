from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class UserLogonLayoutV1512Tests(unittest.TestCase):
    def test_source_parses_and_version_is_current(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_email_and_logon_script_share_the_same_row(self):
        self.assertIn('(\"institutional_email\", \"E-mail institucional\", 3, 0)', MAIN)
        self.assertIn('(\"logon_script\", \"Script de logon\", 3, 1)', MAIN)

    def test_password_expiration_and_expired_state_share_the_next_row(self):
        self.assertIn('self.user_fields_grid.addWidget(self.password_expiration_card, 4, 0)', MAIN)
        self.assertIn('self.user_fields_grid.addWidget(self.password_expiry_status, 4, 1)', MAIN)

    def test_logon_script_comes_from_active_directory_profile(self):
        self.assertIn("'Script de logon' = (Read-AtlasAdProperty 'scriptpath')", BRIDGE)
        self.assertIn('profile = dict(data.get("profile") or {})', MAIN)
        self.assertIn('self._information_value(profile, "Script de logon")', MAIN)


if __name__ == "__main__":
    unittest.main()
