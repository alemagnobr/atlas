from pathlib import Path
import ast
import json
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
RUNNER = (ROOT / "run.bat").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")
REMOTE_MESSAGE = (ROOT / "scripts" / "remote_message.ps1").read_text(encoding="utf-8-sig")
CAPRI_SERVICE = (ROOT / "services" / "capri.py").read_text(encoding="utf-8-sig")
ORIENTATIONS = json.loads((ROOT / "data" / "orientations_catalog.json").read_text(encoding="utf-8"))


class AtlasV5ContractTests(unittest.TestCase):
    def test_python_source_is_structurally_valid(self):
        ast.parse(MAIN)

    def test_official_brand_and_version(self):
        self.assertIn('APP_NAME = "Atlas — Suporte Avançado"', MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_runtime_isolated_from_legacy_versions(self):
        expected = r"AtlasSuporteAvancado\v23.6"
        self.assertIn(expected, RUNNER)
        self.assertIn(r"AtlasSuporteAvancado\cache", BRIDGE)

    def test_software_exit_closes_capri_session_first(self):
        self.assertIn('def terminate_capri_session', MAIN)
        self.assertIn('"capri_logout"', BRIDGE)
        self.assertIn("Action=Logout", BRIDGE)
        self.assertIn("@@CAPRI_LOGOUT@@", BRIDGE)
        self.assertIn("def closeEvent(self, event):", MAIN)
        self.assertIn("login.exit_requested.connect(self.close)", MAIN)
        self.assertIn("self.window().close()", MAIN)
        logout_action = BRIDGE.index('"capri_logout"')
        remote_logout = BRIDGE.index("Action=Logout", logout_action)
        local_cleanup = BRIDGE.index("Remove-Item -LiteralPath $sessionPath -Force -ErrorAction Stop", remote_logout)
        self.assertLess(remote_logout, local_cleanup)

    def test_connection_query_has_visible_locked_sync_state(self):
        self.assertIn("self.connection_query_active = False", MAIN)
        self.assertIn("def set_connection_query_state", MAIN)
        self.assertIn('self.connect_button.setObjectName("syncButton")', MAIN)
        self.assertIn("self.connect_sync_timer.start()", MAIN)
        self.assertIn("self.connect_button.setEnabled(False)", MAIN)
        self.assertIn("self.target_input.setEnabled(False)", MAIN)
        self.assertIn('self.connection_card.setProperty("querying", querying)', MAIN)
        self.assertIn('if completed_action == "status":', MAIN)
        self.assertIn('self.set_connection_query_state(False)', MAIN)

    def test_action_cards_use_responsive_compact_internal_layout(self):
        self.assertIn("class ActionCard(QFrame):", MAIN)
        self.assertIn("def set_compact(self, compact: bool):", MAIN)
        self.assertIn("self.card_layout.addWidget(self.subtitle_label, 1, 1)", MAIN)
        self.assertIn("compact_actions = narrow", MAIN)
        self.assertIn("columns = forced_columns or (1 if width < 420 or ticket_narrow else 2)", MAIN)
        self.assertIn("card.set_compact(compact_actions)", MAIN)
        self.assertIn('ticket_narrow = self.current_section == "Chamados" and width < 680', MAIN)
        self.assertIn('#actionCard[compact="true"]', MAIN)

    def test_bridge_polling_loop_is_powershell_51_compatible(self):
        self.assertIn("[bool]$DeleteAfterStart = $true", BRIDGE)
        self.assertIn("[int]$PostStartDelayMilliseconds = 3000", BRIDGE)
        self.assertIn("[TimeSpan]::FromMinutes(`$duration)", REMOTE_MESSAGE)
        self.assertIn("[Text.Encoding]::Unicode.GetBytes($remoteCode)", REMOTE_MESSAGE)

    def test_browser_close_actions_are_remote_and_verified(self):
        self.assertIn('"browser_close_chrome"', MAIN)
        self.assertIn('"browser_close_edge"', MAIN)
        self.assertIn("function Close-RemoteBrowser", BRIDGE)
        self.assertIn("Start-Process -FilePath $taskkillPath", BRIDGE)
        self.assertIn("$attempt -le 3", BRIDGE)
        self.assertIn("PID(s) restante(s)", BRIDGE)
        self.assertNotIn("& taskkill.exe /S $Computer /IM $processName /F", BRIDGE)
        open_function = BRIDGE.index("function Open-RemoteBrowserClearPage")
        remote_script_end = BRIDGE.index('"@', open_function)
        close_function = BRIDGE.index("function Close-RemoteBrowser")
        dispatcher = BRIDGE.index("switch ($Action)")
        self.assertLess(remote_script_end, close_function)
        self.assertLess(close_function, dispatcher)

    def test_faq_copy_and_compact_grid_contract(self):
        self.assertIn("copy_faq_number", MAIN)
        self.assertIn("QApplication.clipboard().setText(faq_id)", MAIN)
        self.assertNotIn("faq_export_button", MAIN)
        self.assertIn("columns = forced_columns or (1 if width < 420 or ticket_narrow else 2)", MAIN)
        self.assertIn("hierarchy.setdefault(major, {})", MAIN)

    def test_catalog_cards_and_full_faq_number_contract(self):
        self.assertIn("def normalize_faq_number", MAIN)
        self.assertNotIn("number + 10_000_000", MAIN)
        self.assertIn('setObjectName("faqNumber")', MAIN)
        self.assertIn('QFrame(objectName="cardActions")', MAIN)
        self.assertIn("viewport_width < 820", MAIN)
        self.assertIn("$officialFaqId", BRIDGE)
        self.assertNotIn("[int64]$faqId + 10000000", BRIDGE)
        self.assertIn("Resolve-CapriPublishedFaqId", BRIDGE)

    def test_user_orientation_catalog_and_remote_popup_contract(self):
        self.assertEqual(697, ORIENTATIONS["source_faq_count"])
        self.assertGreaterEqual(ORIENTATIONS["count"], 126)
        self.assertTrue(all(item.get("path") or item.get("contact") or item.get("guidance") for item in ORIENTATIONS["items"]))
        self.assertTrue(all(item["path"].lower().startswith("intranet > central de serviços") for item in ORIENTATIONS["items"] if item.get("path")))
        self.assertGreaterEqual(sum(bool(item.get("contact")) for item in ORIENTATIONS["items"]), 32)
        self.assertTrue(all(len(item["faq_number"]) == 8 for item in ORIENTATIONS["items"]))
        self.assertNotIn('("Orientações ao usuário", "Orientações ao usuário")', MAIN)
        self.assertIn("class OrientationPreviewDialog", MAIN)
        self.assertIn("orientation_requested = Signal(dict)", MAIN)
        self.assertIn("def rebuild_orientation_lookup", MAIN)
        self.assertIn("faq_orientation_preferences.json", MAIN)
        self.assertIn("class UserOrientationCard", MAIN)
        self.assertIn("def render_orientation_catalog", MAIN)
        self.assertIn('"user_orientation_show"', MAIN)
        self.assertIn("function Show-RemoteUserOrientation", BRIDGE)
        self.assertIn("[void]`$window.ShowDialog()", REMOTE_MESSAGE)
        self.assertLess(BRIDGE.index("function Show-RemoteUserOrientation"), BRIDGE.index("switch ($Action)"))

    def test_v77_orientation_preview_deletion_and_shortcuts(self):
        self.assertIn("PRÉ-VISUALIZAÇÃO ANTES DO ENVIO", MAIN)
        self.assertIn('QPushButton("Excluir orientação")', MAIN)
        self.assertIn('QPushButton("Enviar orientação")', MAIN)
        self.assertIn("self.orientation_by_faq.get(faq_id, [])", MAIN)
        self.assertIn("class OrientationChooserDialog", MAIN)
        self.assertIn('QPushButton("Nova orientação")', MAIN)
        self.assertIn('QPushButton("Salvar")', MAIN)
        self.assertIn('preferences.get("additional", {})', MAIN)
        self.assertIn('["mmc.exe", "dsa.msc"]', MAIN)
        self.assertIn('["mmc.exe", "compmgmt.msc"]', MAIN)
        self.assertNotIn("LockWorkStation", MAIN)
        self.assertNotIn('setObjectName("quickWindowsLock")', MAIN)

    def test_v78_multiple_orientations_are_persistent_and_indexed(self):
        self.assertIn("class OrientationChooserDialog", MAIN)
        self.assertIn("NEW_ORIENTATION = 2", MAIN)
        self.assertIn("SAVE_ONLY = 3", MAIN)
        self.assertIn('preferences.get("additional", {})', MAIN)
        self.assertIn('additional.setdefault(faq_id, [])', MAIN)
        self.assertIn('self.orientation_by_faq.get(faq_id, [])', MAIN)
        self.assertIn("for item in self.orientation_by_faq.get(faq_id, [])", MAIN)
        self.assertIn("self.save_orientation_preferences()", MAIN)
        self.assertIn("self.rebuild_local_search_indexes()", MAIN)

    def test_v79_progress_free_orientation_and_direct_lock(self):
        self.assertIn('setObjectName("connectionProgress")', MAIN)
        self.assertIn("def advance_connection_progress", MAIN)
        self.assertIn("self.set_connection_progress_stage(10, detail_text)", MAIN)
        self.assertIn("self.connection_progress_timer.start()", MAIN)
        self.assertIn("class FreeOrientationDialog", MAIN)
        self.assertIn('setObjectName("freeOrientationButton")', MAIN)
        self.assertIn("def open_free_orientation", MAIN)
        self.assertIn('"title": "Orientação livre"', MAIN)
        self.assertNotIn("def quick_lock_windows", MAIN)

    def test_v81_faq_search_can_switch_between_related_and_title_only(self):
        self.assertIn("self.faq_title_search = False", MAIN)
        self.assertIn('QPushButton("Relacionada")', MAIN)
        self.assertIn('QPushButton("No título")', MAIN)
        self.assertIn("self.faq_search_mode_group.setExclusive(True)", MAIN)
        self.assertIn("def set_faq_search_mode(self, title_only: bool):", MAIN)
        self.assertIn("title_only: bool = False", MAIN)
        self.assertIn('cache_key = ("title" if title_only else "related", query)', MAIN)
        self.assertIn('pattern = rf"(?<![a-z0-9]){re.escape(query)}(?![a-z0-9])"', MAIN)
        self.assertIn('title_match = re.search(pattern, title)', MAIN)
        self.assertIn('number_match = query.isdigit() and query == item_number', MAIN)
        self.assertIn("title_only=self.faq_title_search", MAIN)
        self.assertIn('#faqSearchModeButton:checked', MAIN)

    def test_orientation_delivery_uses_auditable_visual_message(self):
        self.assertIn("function Show-RemoteUserOrientation", BRIDGE)
        self.assertIn("Invoke-AtlasRemoteMessage -Kind 'orientation'", BRIDGE)
        self.assertIn("function Invoke-AtlasRemoteMessage", REMOTE_MESSAGE)
        self.assertIn("-NoProfile -STA -WindowStyle Hidden -EncodedCommand $encoded", REMOTE_MESSAGE)
        self.assertIn("-InteractiveUser $sessionUser", REMOTE_MESSAGE)
        self.assertNotIn("wscript.exe", REMOTE_MESSAGE)
        self.assertIn("Atenciosamente,", REMOTE_MESSAGE)
        payload_start = MAIN.index('payload = json.dumps({', MAIN.index("def send_user_orientation"))
        payload_end = MAIN.index('}, ensure_ascii=False', payload_start)
        remote_payload = MAIN[payload_start:payload_end]
        self.assertIn('"expected_user": expected_user', remote_payload)
        self.assertIn('"operator_name": operator_friendly_name()', remote_payload)

    def test_fast_local_catalog_search_and_native_app_identity(self):
        self.assertIn("def load_bundled_faq_search_texts", MAIN)
        self.assertIn("def rebuild_local_search_indexes", MAIN)
        self.assertIn("def ranked_catalog_search", MAIN)
        self.assertIn("difflib.SequenceMatcher", MAIN)
        self.assertIn("limit: int = 48", MAIN)
        self.assertIn("self.faq_search_timer.setInterval(85)", MAIN)
        self.assertIn("self.orientation_search_timer.setInterval(85)", MAIN)
        self.assertIn("SetCurrentProcessExplicitAppUserModelID", MAIN)
        self.assertIn('resource_path("assets/app_icon.ico")', MAIN)
        self.assertIn("def replace_page", MAIN)

    def test_specific_orientation_and_popup_free_search_contract(self):
        self.assertIn("def map_specific_faq_orientation", MAIN)
        self.assertIn("def map_specific_orientation(self)", MAIN)
        self.assertIn('self.specific_faq_input.setMaxLength(12)', MAIN)
        self.assertIn('self.specific_faq_button = QPushButton("Atualizar FAQ específica")', MAIN)
        self.assertNotIn("self.faq_search.setCompleter", MAIN)
        self.assertIn("self.orientation_search.setCompleter(None)", MAIN)
        self.assertNotIn("self.orientation_search.setCompleter(self.", MAIN)

    def test_v82_tickets_theme_local_certificates_and_fade(self):
        self.assertIn('(\"Chamados\", \"Chamados\")', MAIN)
        self.assertIn('def request_tickets(self, filtered: bool, feedback_mode: str = "")', MAIN)
        self.assertIn('ticket_cache_path()', MAIN)
        self.assertIn('\"ticket_catalog\"', BRIDGE)
        self.assertIn('Action=AgentTicketSearch', BRIDGE)
        self.assertIn('DARK_STYLE', MAIN)
        self.assertIn('self.station_pulse_timer.setInterval(480)', MAIN)
        self.assertIn('Get-LocalProfileCertificates', BRIDGE)

    def test_v83_visual_system_and_balanced_ticket_filters(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('self.ticket_status_frame.hide()', MAIN)
        self.assertIn('def toggle_ticket_advanced', MAIN)
        self.assertIn('self.ticket_map_button.clicked.connect(self.open_ticket_period_dialog)', MAIN)
        self.assertIn('#ticketSearchFrame', MAIN)
        self.assertIn('#ticketAdvancedFrame', MAIN)
        self.assertIn("background: #07131F", MAIN)
        self.assertIn('navigation_icons = {', MAIN)
        self.assertIn('dialog = AuthorizedPrinterDialog(action.title, choices, self)', MAIN)

    def test_v84_global_dark_mode_and_responsive_tickets(self):
        self.assertIn('self.login_theme_button = ThemeSwitch(self.dark_mode, self.panel)', MAIN)
        self.assertIn('fade_theme_change(', MAIN)
        self.assertIn('save_json_cache(theme_settings_path(), {"dark": self.dark_mode})', MAIN)
        self.assertIn('scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)', MAIN)
        self.assertIn('ticket_actions = QGridLayout()', MAIN)
        self.assertIn('#actionCard[compact="true"], #actionCard[compact="false"]', MAIN)
        self.assertIn('#softwareNotice {{ background: #0E2A3E', MAIN)

    def test_v85_created_by_filter_switch_and_lateral_alignment(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('class ThemeSwitch(QWidget):', MAIN)
        self.assertIn('scroll.setAlignment(Qt.AlignLeft | Qt.AlignTop)', MAIN)
        self.assertIn('def reset_horizontal_scroll(self):', MAIN)
        self.assertIn("$body['Fulltext'] = $displayName", BRIDGE)
        self.assertNotIn("$body['OwnerIDs']", BRIDGE)
        self.assertIn('"Criado por" é informação do detalhe do chamado', BRIDGE)
        self.assertIn('#actionCard[compact="true"] #glyph', MAIN)

    def test_v86_ticket_pagination_states_and_compact_theme_label(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('$pageQueue = [System.Collections.Generic.Queue[string]]::new()', BRIDGE)
        self.assertIn('$pageCount -lt 500', BRIDGE)
        self.assertIn("state_kind=$stateKind", BRIDGE)
        self.assertIn('"", "Todos", "Abertos", "Pendentes", "Fechados com êxito",', MAIN)
        self.assertIn('self.theme_label = QLabel("Modo escuro")', MAIN)
        self.assertIn('self.sidebar.setFixedWidth(178 if narrow else 216)', MAIN)

    def test_v87_login_dark_mode_has_complete_contrast(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('#loginPanel {{ background: qlineargradient', MAIN)
        self.assertIn('#loginPanel #identityCard {{ background: #0D2A48; color: #F1F8FC;', MAIN)
        self.assertIn('#profileName {{ color: #8FCBEA; }}', MAIN)
        self.assertIn('#profileAccount {{ color: #F1F7FB; }}', MAIN)
        self.assertIn('#profileStatus {{ color: #55DDAA; }}', MAIN)
        self.assertIn('self.side_arrow.core_color = "#35BCEB" if self.dark_mode else BLUE', MAIN)

    def test_v88_complete_ticket_fallback_round_icons_and_advanced_layout(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("$pageBody['ResultForm'] = 'Print'", BRIDGE)
        self.assertIn("$pageBody['StartHit'] = [string]$nextStartHit", BRIDGE)
        self.assertIn("$paginationMode = 'offset'", BRIDGE)
        self.assertIn('QRegion(self.glyph.rect(), QRegion.Ellipse)', MAIN)
        self.assertIn('QRegion(self.action_button.rect(), QRegion.Ellipse)', MAIN)
        self.assertIn('self.ticket_status_frame = QFrame(objectName="ticketStatusPanel")', MAIN)
        self.assertIn('self.ticket_search_frame.hide()', MAIN)

    def test_v89_capri_collects_every_page_without_forging_creator(self):
        self.assertIn("VERSION = \"23.6\"", MAIN)
        self.assertIn("function Get-CapriTicketPageUrls", BRIDGE)
        self.assertIn("Get-TicketColumnIndex $headers 'PROPRIET'", BRIDGE)
        self.assertIn("Get-TicketColumnIndex $headers 'RESPONS'", BRIDGE)
        self.assertIn("$body['Fulltext'] = $displayName", BRIDGE)
        self.assertIn("$expectedTotal", BRIDGE)
        self.assertIn("a coleta incompleta não será salva", BRIDGE)
        self.assertIn("expected_count=$expectedTotal", BRIDGE)
        self.assertIn("creator=''; owner=$owner; responsible=$responsible", BRIDGE)

    def test_v90_complete_csv_creator_cache_and_ticket_search(self):
        self.assertIn("$csvBody['ResultForm'] = 'CSV'", BRIDGE)
        self.assertIn("schema_version=4", BRIDGE)
        self.assertIn("Criado por + período de criação", BRIDGE)
        self.assertIn("def load_ticket_cache()", MAIN)
        self.assertIn('if int(data.get("schema_version", 0) or 0) < 4 or not data.get("complete"):', MAIN)
        self.assertIn("data[\"items\"] = list(deduplicated.values())", MAIN)
        self.assertIn("cutoff=.72", MAIN)
        self.assertIn("redundant_titles", MAIN)

    def test_v91_theme_is_global_persistent_and_visually_complete(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('theme_arg = " --theme-dark" if dark_mode else " --theme-light"', MAIN)
        self.assertIn('"--theme-dark" in sys.argv', MAIN)
        self.assertIn('"--theme-light" in sys.argv', MAIN)
        self.assertIn('self.login_theme_label.setText("Modo claro" if self.dark_mode else "Modo escuro")', MAIN)
        self.assertIn('self.theme_label.setText("Modo claro" if self.dark_mode else "Modo escuro")', MAIN)
        self.assertIn('gradient = QLinearGradient', MAIN)
        self.assertIn('class ThemeSwitch(QWidget):', MAIN)
        self.assertIn('#statusCard[connected="true"] #statusValue', MAIN)

    def test_v92_creator_is_read_from_ticket_detail(self):
        self.assertIn("function Get-CapriTicketIdentity", BRIDGE)
        self.assertIn("Get-NormalizedPersonName $displayName", BRIDGE)
        self.assertIn("Get-CapriTicketIdentity ([string]$ticket.url)", BRIDGE)
        self.assertIn("$ticket.creator = $creator", BRIDGE)
        self.assertIn("scanned_count=$candidateCount", BRIDGE)
        self.assertNotIn("$body[$createdField] = $optionValue", BRIDGE)

    def test_v92_dynamic_created_by_identity_resolution(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('operator_login=re.sub(r"(?i)_ins$", "", getpass.getuser().strip())', MAIN)
        self.assertIn('"operator_login": operator_login', CAPRI_SERVICE)
        self.assertIn("$body['Fulltext'] = $displayName", BRIDGE)
        self.assertIn("Criado\\s+por", BRIDGE)
        self.assertIn("$ticket.creator = $creator", BRIDGE)
        self.assertNotIn('O filtro "Criado por" não foi localizado na tela de pesquisa do Capri', BRIDGE)

    def test_v93_clean_ticket_period_flow_and_dark_hover_contrast(self):
        self.assertIn('def open_ticket_period_dialog(self):', MAIN)
        self.assertIn('def authenticate_capri_startup(self)', MAIN)
        self.assertIn('QTimer.singleShot(0, self.open_ticket_period_dialog)', MAIN)
        self.assertNotIn('QLabel("PERÍODO RÁPIDO")', MAIN)
        self.assertIn('"", "Todos", "Abertos", "Pendentes", "Fechados com êxito",', MAIN)
        self.assertIn('Nesta etapa:', MAIN)
        self.assertIn('QToolTip {{ color: #F5FAFD;', MAIN)
        self.assertNotIn('#quickWindowsLock', MAIN)

    def test_v94_dark_hover_icons_and_capri_dialog_contract(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('#ticketCard:hover {{ background: #102B40;', MAIN)
        self.assertIn('#ticketCard:hover #ticketTitle {{ color: #FFFFFF;', MAIN)
        self.assertIn('#ticketNumber {{ color: #76C8EC;', MAIN)
        self.assertIn('button._atlas_icon_color = color', MAIN)
        self.assertIn('def refresh_themed_button_icons():', MAIN)
        self.assertIn('BLUE.casefold(): "#73CFF3"', MAIN)
        self.assertIn('QInputDialog, QMessageBox', MAIN)
        self.assertIn('QInputDialog QPushButton:default', MAIN)
        self.assertIn('class ThemeWindowFilter(QObject):', MAIN)
        self.assertIn('DwmSetWindowAttribute', MAIN)
        self.assertNotIn('app.setStyle("Fusion")', MAIN)

    def test_ticket_cards_keep_readable_height_in_large_catalogs(self):
        self.assertIn('getattr(button, "_atlas_icon_color", None)', MAIN)
        self.assertNotIn('button.setProperty("atlasIconColor", color)', MAIN)
        ticket_start = MAIN.index("class TicketCard(QFrame):")
        ticket_end = MAIN.index("class Dashboard(QWidget):", ticket_start)
        ticket_block = MAIN[ticket_start:ticket_end]
        self.assertIn("self.setMinimumHeight(116)", ticket_block)
        self.assertIn("self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)", ticket_block)
        self.assertIn("self.action_grid.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)", MAIN)
        self.assertIn('self.actions_opacity.setEnabled(section != "Chamados")', MAIN)
        start = MAIN.index("def render_ticket_catalog(self, columns: int):")
        end = MAIN.index("def open_ticket(self, url: str, number: str):", start)
        render_block = MAIN[start:end]
        self.assertIn("items = self.visible_tickets()", render_block)
        self.assertIn("TicketCard(ticket, self.actions_host,", render_block)

    def test_ticket_cards_keep_their_layout_after_last_batch(self):
        start = MAIN.index("def render_ticket_card_batch(self, generation: int):")
        end = MAIN.index("def open_external_link(self, url: str)", start)
        block = MAIN[start:end]
        self.assertIn("self.ticket_result_count.setText(f\"{self._ticket_cards_total} de {total_catalog}\")", block)
        self.assertIn("self.action_grid.activate()", block)
        self.assertNotIn("apply_application_theme", block)
        self.assertNotIn("schedule_ticket_theme_refresh", MAIN)

    def test_v98_busy_operation_uses_compact_notice(self):
        start = MAIN.index("def run_bridge(")
        end = MAIN.index("def execution_done", start)
        implementation = MAIN[start:end]
        self.assertIn('show_notice(self, "Aguarde a operação atual terminar.")', implementation)
        self.assertNotIn('QMessageBox.warning(self, APP_NAME, "Aguarde a operação atual terminar.")', implementation)

    def test_v99_faq_dark_contrast_and_theme_loading_indicator(self):
        self.assertIn('#faqSearchTitle {{ color: #8EDBFF;', MAIN)
        self.assertIn('#faqSearchHint {{ color: #B4CDDC;', MAIN)
        self.assertIn('#faqSearchModeButton {{ color: #C4D8E5;', MAIN)
        self.assertIn('placeholder-text-color: #8EACBF;', MAIN)
        self.assertIn('self.faq_search_icon = QLabel()', MAIN)
        self.assertIn('color = "#73CFF3" if self.dark_mode else BLUE', MAIN)
        self.assertIn('def set_loading(self, loading: bool):', MAIN)
        self.assertIn('self._animation.setDuration(420)', MAIN)
        self.assertIn('painter.drawRoundedRect(track, 16, 16)', MAIN)
        self.assertIn('and not self._loading', MAIN)
        self.assertNotIn('self.theme_label.setText("Alterando tema…")', MAIN)
        self.assertNotIn('self.login_theme_label.setText("Alterando tema…")', MAIN)
        self.assertIn('fade_theme_change(', MAIN)
        self.assertIn('duration_ms: int = 420', (ROOT / "ui" / "transitions.py").read_text(encoding="utf-8"))

    def test_v100_ticket_entry_progress(self):
        self.assertIn('QFrame(objectName="ticketRenderProgress")', MAIN)
        self.assertIn('QLabel("Organizando todos os chamados…")', MAIN)
        self.assertIn('self.ticket_render_progress_bar.setRange(0, 0)', MAIN)
        self.assertIn('self.ticket_render_progress_bar.setTextVisible(False)', MAIN)
        self.assertIn('entering_tickets = section == "Chamados" and previous_section != "Chamados"', MAIN)
        self.assertIn('self.ticket_status_combo.setCurrentIndex(3)', MAIN)
        self.assertIn('self.ticket_search.clear()', MAIN)
        self.assertIn('QTimer.singleShot(', MAIN)
        self.assertIn('lambda generation=render_generation: self.finish_ticket_entry_render(generation)', MAIN)
        self.assertIn('def finish_ticket_entry_render(self, generation: int):', MAIN)
        self.assertIn('def finish_ticket_render_progress(self, generation: int):', MAIN)
        self.assertIn('#ticketRenderProgress {{ background:', MAIN)
        self.assertIn('#ticketRenderProgressBar::chunk {{ background:', MAIN)

    def test_v101_ticket_progress_is_outside_filter_panel(self):
        progress_start = MAIN.index('self.ticket_render_progress = QFrame(objectName="ticketRenderProgress")')
        filter_added = MAIN.index('page.addWidget(self.ticket_filter_frame)', progress_start)
        progress_added = MAIN.index('page.addWidget(self.ticket_render_progress)', filter_added)
        actions_added = MAIN.index('page.addWidget(self.actions_host)', progress_added)
        self.assertLess(filter_added, progress_added)
        self.assertLess(progress_added, actions_added)
        progress_block = MAIN[progress_start:filter_added]
        self.assertNotIn('ticket_box.addWidget(self.ticket_render_progress)', progress_block)

    def test_v102_ticket_search_runs_only_after_explicit_action(self):
        self.assertNotIn('self.ticket_search.textChanged.connect(self.filter_tickets)', MAIN)
        self.assertNotIn('self.ticket_status_combo.currentIndexChanged.connect(self.filter_tickets)', MAIN)
        self.assertNotIn('self.ticket_search.textEdited.connect', MAIN)
        self.assertNotIn('self.ticket_search.textChanged.connect', MAIN)
        self.assertIn('self.ticket_search.returnPressed.connect(self.search_tickets)', MAIN)
        self.assertIn('self.ticket_search_button = QPushButton("Pesquisar")', MAIN)
        self.assertIn('self.ticket_search_button.clicked.connect(self.search_tickets)', MAIN)
        self.assertIn('self.ticket_status_index = self.ticket_status_combo.currentIndex()', MAIN)
        self.assertIn('status_index = self.ticket_status_index', MAIN)
        self.assertIn('def begin_ticket_render(self, message: str):', MAIN)
        self.assertIn('self.ticket_render_progress_label.setText(message)', MAIN)
        self.assertIn('self.set_ticket_filter_controls_enabled(False)', MAIN)
        self.assertIn('self.set_ticket_filter_controls_enabled(True)', MAIN)
        self.assertIn('message = f"Aplicando filtro: {self.ticket_status_combo.currentText()}…"', MAIN)
        self.assertIn('self.ticket_render_progress_label.setWordWrap(True)', MAIN)
        self.assertIn('if len(search_summary) > 56:', MAIN)
        self.assertIn('self.ticket_status_combo.setCurrentIndex(1)', MAIN)
        self.assertIn('message = f"Pesquisando em todos os chamados locais por “{search_summary}”…"', MAIN)
        self.assertIn('#ticketSearchButton {{ background:', MAIN)

    def test_v103_status_filter_has_its_own_button(self):
        self.assertIn('"filter": \'<path d="M4 5h16l-6 7v6l-4 2v-8z"/>\'', MAIN)
        self.assertIn('self.ticket_filter_button = QPushButton("Filtrar")', MAIN)
        self.assertIn('self.ticket_filter_button.setObjectName("ticketFilterButton")', MAIN)
        self.assertIn('self.ticket_filter_button.clicked.connect(self.filter_tickets)', MAIN)
        self.assertIn('def search_tickets(self, *_args):', MAIN)
        self.assertIn('def filter_tickets(self, *_args):', MAIN)
        search_start = MAIN.index('def search_tickets(self, *_args):')
        filter_start = MAIN.index('def filter_tickets(self, *_args):', search_start)
        normalize_start = MAIN.index('@staticmethod\n    def normalize_ticket_search', filter_start)
        self.assertNotIn('self.ticket_status_index = self.ticket_status_combo.currentIndex()', MAIN[search_start:filter_start])
        self.assertIn('self.ticket_status_index = self.ticket_status_combo.currentIndex()', MAIN[filter_start:normalize_start])
        self.assertIn('"ticket_filter_button"', MAIN)
        self.assertIn('#ticketFilterButton {{ background:', MAIN)

    def test_ticket_filter_defaults_to_pending_on_entry_and_after_mapping(self):
        entry_start = MAIN.index('elif section == "Chamados":', MAIN.index('def apply_filter(self, section: str):'))
        entry_end = MAIN.index('elif section == "Orientações ao usuário":', entry_start)
        entry = MAIN[entry_start:entry_end]
        self.assertIn('self.ticket_status_combo.setCurrentIndex(3)', entry)
        self.assertIn('self.ticket_status_index = 3', entry)
        self.assertIn('self.ticket_period = "all"', entry)
        mapping = MAIN[MAIN.index('self.ticket_catalog = data'):]
        self.assertIn('self.ticket_status_combo.setCurrentIndex(3)', mapping)
        self.assertIn('self.ticket_period = "all"', mapping)
        self.assertIn('"", "Todos", "Abertos", "Pendentes", "Fechados com êxito",', MAIN)
        self.assertIn('if status_index == 0 and not terms:', MAIN)
        self.assertIn('self.ticket_status_index = self.ticket_status_combo.currentIndex()', MAIN)

    def test_orientation_search_is_visually_distinct_from_catalog_maintenance(self):
        self.assertIn('QFrame(objectName="orientationSearchPanel")', MAIN)
        self.assertIn('QFrame(objectName="orientationMaintenanceFrame")', MAIN)
        search_start = MAIN.index('QFrame(objectName="orientationSearchPanel")')
        maintenance_start = MAIN.index('QFrame(objectName="orientationMaintenanceFrame")')
        self.assertNotIn("orientation_refresh_button", MAIN[search_start:maintenance_start])
        self.assertIn("'CAMINHO NA INTRANET'", REMOTE_MESSAGE)
        self.assertIn("'CONTATO / SETOR RESPONSÁVEL'", REMOTE_MESSAGE)
        self.assertIn("'MENSAGEM DO SUPORTE'", REMOTE_MESSAGE)

    def test_faq_search_is_visually_distinct_from_capri_maintenance(self):
        self.assertIn('QFrame(objectName="faqSearchPanel")', MAIN)
        self.assertIn('QLabel("PESQUISAR FAQs")', MAIN)
        self.assertIn('QLabel("PESQUISA LOCAL")', MAIN)
        self.assertIn("Esta pesquisa não consulta o Capri nem altera a base.", MAIN)
        self.assertIn('QFrame(objectName="faqMaintenanceFrame")', MAIN)
        self.assertIn('QLabel("ATUALIZAR A BASE")', MAIN)
        self.assertIn('QPushButton("Acesso ao Capri")', MAIN)
        self.assertIn('QPushButton("Remapear todas as FAQs")', MAIN)
        self.assertIn('self.faq_specific_button = QPushButton("Atualizar FAQ específica")', MAIN)
        search_start = MAIN.index('QFrame(objectName="faqSearchPanel")')
        maintenance_start = MAIN.index('QFrame(objectName="faqMaintenanceFrame")')
        search_block = MAIN[search_start:maintenance_start]
        self.assertNotIn("faq_refresh_button", search_block)
        self.assertNotIn("faq_login_button", search_block)

    def test_persistent_unified_faq_orientation_mapping(self):
        self.assertIn("def orientation_cache_path", MAIN)
        self.assertIn("def map_all_orientations", MAIN)
        self.assertIn("def request_single_faq_update", MAIN)
        self.assertIn("def apply_single_faq_update", MAIN)
        self.assertIn('"faq_single"', BRIDGE)
        self.assertIn("@@FAQ_SINGLE@@", BRIDGE)
        self.assertIn("faq_content_overrides.json", MAIN)
        self.assertIn("self.map_all_orientations()", MAIN)

    def test_chief_notice_is_limited_to_intranet_paths(self):
        notice = "IMPORTANTE: O chamado deve ser aberto pelo chefe do setor."
        self.assertEqual(1, REMOTE_MESSAGE.count(notice))
        path_branch = REMOTE_MESSAGE[REMOTE_MESSAGE.index("if (![string]::IsNullOrWhiteSpace([string]`$data.path))"):
                                     REMOTE_MESSAGE.index("if (![string]::IsNullOrWhiteSpace([string]`$data.contact))")]
        self.assertIn(notice, path_branch)
        self.assertIn('if (`$data.include_chief_notice -ne `$false)', path_branch)
        self.assertIn('self.chief_notice_check = QCheckBox(', MAIN)
        self.assertIn('"include_chief_notice": self.chief_notice_check.isChecked()', MAIN)
        self.assertIn('"include_chief_notice": orientation.get("include_chief_notice", True) is not False', MAIN)

    def test_orientation_search_has_no_popup_and_delivery_is_fast(self):
        self.assertIn("self.orientation_search.setCompleter(None)", MAIN)
        self.assertIn("self.orientation_search.setInputMethodHints(Qt.ImhNoPredictiveText)", MAIN)
        self.assertNotIn("orientation_suggestion_model", MAIN)
        self.assertNotIn("orientation_completer", MAIN)
        self.assertIn("[string]$InteractiveUser = ''", BRIDGE)
        self.assertIn("[int]$PostStartDelayMilliseconds = 3000", BRIDGE)
        self.assertIn("-PostStartDelayMilliseconds 2500", REMOTE_MESSAGE)

    def test_ins_window_reapplies_native_atlas_icon(self):
        self.assertIn("def apply_native_window_icon", MAIN)
        self.assertIn("LoadImageW", MAIN)
        self.assertIn("SendMessageW", MAIN)
        self.assertIn("QTimer.singleShot(250, self.refresh_taskbar_icon)", MAIN)

    def test_visual_orientation_task_remains_alive_until_user_closes_popup(self):
        self.assertIn("[bool]$DeleteAfterStart = $true", BRIDGE)
        self.assertIn("[void]`$window.ShowDialog()", REMOTE_MESSAGE)
        self.assertIn("§$timer.Add_Tick({ §$timer.Stop(); §$window.Close() })".replace("§", "`"), REMOTE_MESSAGE)
        self.assertIn("`$duration = 10", REMOTE_MESSAGE)
        self.assertIn("`$duration = 3", REMOTE_MESSAGE)

    def test_orientation_cleanup_is_silent_and_wpf_reports_its_own_error(self):
        self.assertIn("function Remove-RemoteScheduledTaskQuiet", BRIDGE)
        self.assertIn("-WindowStyle Hidden", REMOTE_MESSAGE)
        self.assertIn("[Atlas.WindowNative]::ShowWindow(`$console, 0)", REMOTE_MESSAGE)
        self.assertIn("[Atlas.WindowNative]::ShowWindow(`$handle, 5)", REMOTE_MESSAGE)
        self.assertIn("A abertura e a leitura da janela não podem ser confirmadas", REMOTE_MESSAGE)

    def test_popup_defaults_remain_compact(self):
        self.assertIn("self.resize(470, 330)", MAIN)
        self.assertIn("self.setMinimumSize(380, 270)", MAIN)

    def test_v105_session_only_capri_calendar_and_motion_contract(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('section in {"Chamados", "FAQs"} and not self._capri_session_password', MAIN)
        self.assertIn('self.open_capri_login(False, True, True)', MAIN)
        ticket_start = MAIN.index("    def request_tickets")
        period_start = MAIN.index("    def open_ticket_period_dialog", ticket_start)
        ticket_request = MAIN[ticket_start:period_start]
        self.assertIn("password = self._capri_session_password", ticket_request)
        self.assertNotIn("credential_read", ticket_request)
        self.assertIn('field.setObjectName("ticketPeriodDate")', MAIN)
        self.assertIn('calendar.setObjectName("ticketCalendar")', MAIN)
        self.assertIn("QCalendarWidget.NoVerticalHeader", MAIN)
        self.assertIn("#ticketCalendar QAbstractItemView", MAIN)
        self.assertIn("class HoverFadeButton", MAIN)
        self.assertIn("self.fade.setDuration(285)", MAIN)

    def test_v106_calendar_is_spacious_and_has_visible_date_icon(self):
        self.assertIn('calendar.setMinimumSize(372, 300)', MAIN)
        self.assertIn('calendar.setHorizontalHeaderFormat(QCalendarWidget.ShortDayNames)', MAIN)
        self.assertIn('QDateEdit::down-arrow {{ image: url(assets/calendar_field.svg)', MAIN)
        self.assertIn('#ticketCalendar QWidget#qt_calendar_navigationbar', MAIN)
        icon = (ROOT / "assets" / "calendar_field.svg").read_text(encoding="utf-8")
        self.assertIn('#53C9F3', icon)
        self.assertIn('#4CE0A8', icon)

    def test_v107_period_is_enforced_and_catalog_caches_can_be_cleared(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("TicketCreateTimeStartDay", BRIDGE)
        self.assertIn("TicketCreateTimeStopDay", BRIDGE)
        self.assertIn("$insidePeriod", BRIDGE)
        self.assertIn("Get-CapriTicketIdentity", BRIDGE)
        self.assertIn("def clear_faq_cache(self):", MAIN)
        self.assertIn("faq_cache_path().unlink(missing_ok=True)", MAIN)
        self.assertIn("def clear_ticket_cache(self):", MAIN)
        self.assertIn("ticket_cache_path().unlink(missing_ok=True)", MAIN)
        self.assertIn('self.ticket_clear_cache_button.setObjectName("cacheClearButton")', MAIN)
        self.assertIn("#faqCard, #faqCard:focus", MAIN)
        self.assertIn("#faqCard:hover", MAIN)

    def test_v108_login_credit_cards_and_theme_switch_are_modernized(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('>Alexandre Linhares</a> e ', MAIN)
        self.assertIn('>João Cerqueira</a>', MAIN)
        self.assertIn('heading = QLabel("Bem-vindo ao Atlas")', MAIN)
        self.assertIn('identity_icon.setObjectName("loginCardIcon")', MAIN)
        self.assertIn('ins_icon.setPixmap(modern_icon("shield"', MAIN)
        self.assertIn("self.setFixedSize(62, 32)", MAIN)
        self.assertIn("gradient = QLinearGradient", MAIN)
        self.assertIn("self._animation.setDuration(420)", MAIN)
        self.assertIn("#identityCard:hover, #loginProfileCard:hover", MAIN)

    def test_v109_capri_applies_detected_period_before_creator_checks(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("$body['TimeSearchType'] = 'TimeSlot'", BRIDGE)
        self.assertIn("TicketCreateTimeStartYear", BRIDGE)
        self.assertIn("TicketCreateTimeStopYear", BRIDGE)
        self.assertIn('00:00:00', BRIDGE)
        self.assertIn('23:59:59', BRIDGE)
        period_reduction = BRIDGE.index("$periodItems")
        creator_check = BRIDGE.index("Get-CapriTicketIdentity ([string]$ticket.url)")
        self.assertLess(period_reduction, creator_check)
        self.assertIn("[CHAMADOS] Período aplicado:", BRIDGE)
        self.assertIn("source_count=$receivedCount", BRIDGE)
        self.assertIn("gradient = QLinearGradient", MAIN)

    def test_v1010_uses_otrs_native_time_slot_instead_of_relative_time(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("$body['TimeSearchType'] = 'TimeSlot'", BRIDGE)
        self.assertIn("$body['TicketCreateTimeStartDay']", BRIDGE)
        self.assertIn("$body['TicketCreateTimeStartMonth']", BRIDGE)
        self.assertIn("$body['TicketCreateTimeStartYear']", BRIDGE)
        self.assertIn("$body['TicketCreateTimeStopDay']", BRIDGE)
        self.assertIn("$body['TicketCreateTimeStopMonth']", BRIDGE)
        self.assertIn("$body['TicketCreateTimeStopYear']", BRIDGE)
        ticket_start = BRIDGE.index('    "ticket_catalog" {')
        ticket_end = BRIDGE.index('    "faq_catalog" {', ticket_start)
        ticket_contract = BRIDGE[ticket_start:ticket_end]
        self.assertNotIn("TicketCreateTimePointFormat", ticket_contract)
        self.assertIn("Consultando no Capri somente o intervalo", ticket_contract)

    def test_v1011_month_year_and_yesterday_today_defaults(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('period_tabs.addTab(month_page, "Mês e ano")', MAIN)
        self.assertIn('period_tabs.addTab(range_page, "Intervalo personalizado")', MAIN)
        self.assertIn('start = QDateEdit(today.addDays(-1))', MAIN)
        self.assertIn('end = QDateEdit(today)', MAIN)
        self.assertIn('selected_start = QDate(selected_year, selected_month, 1)', MAIN)
        self.assertIn('selected_start.daysInMonth()', MAIN)
        self.assertIn('#qt_calendar_monthbutton', MAIN)

    def test_v1012_compact_tools_and_dark_station_pulse(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('self.ticket_clear_cache_button = QPushButton("Limpar cache")', MAIN)
        self.assertIn('self.ticket_clear_cache_button.setFixedHeight(28)', MAIN)
        self.assertIn('ticket_head.addWidget(self.ticket_clear_cache_button, 0, Qt.AlignVCenter)', MAIN)
        self.assertIn('ticket_head.addWidget(self.ticket_result_count, 0, Qt.AlignVCenter)', MAIN)
        self.assertIn('self.connection_tools = QFrame(objectName="connectionTools")', MAIN)
        self.assertIn('self.station_pulse_timer.setInterval(480)', MAIN)
        self.assertNotIn('self.station_icon_effect = QGraphicsOpacityEffect', MAIN)
        self.assertIn('if self.dark_mode:', MAIN)
        self.assertIn('#refreshIconButton:disabled, #copyTargetButton:disabled', MAIN)

    def test_v1014_authorized_software_cards_keep_dark_interaction_states(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('#softwareCard:hover, #authorizedSoftwareCard:hover', MAIN)
        self.assertIn('#softwareCard:focus, #authorizedSoftwareCard', MAIN)
        self.assertIn('#authorizedSoftwareCard #softwareTitle', MAIN)
        self.assertIn('#authorizedSoftwareCard #softwarePath', MAIN)
        dark_start = MAIN.index('DARK_STYLE = f"""')
        dark_style = MAIN[dark_start:]
        self.assertIn('background: #102B40', dark_style)
        self.assertIn('border-left: 4px solid #52E0AD', dark_style)

    def test_v1015_incremental_ticket_cache_and_recent_refresh(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('self.ticket_refresh_cache_button = QPushButton("Atualizar")', MAIN)
        self.assertIn('self.ticket_refresh_cache_button.clicked.connect(self.refresh_recent_tickets)', MAIN)
        self.assertIn('def refresh_recent_tickets(self):', MAIN)
        self.assertIn('today.addDays(-1)', MAIN)
        self.assertIn('cache_path=str(ticket_cache_path())', MAIN)
        self.assertIn('"cache_path": cache_path', CAPRI_SERVICE)
        self.assertIn('$cachedNumbers = [System.Collections.Generic.HashSet[string]]::new', BRIDGE)
        self.assertIn('Cache incremental:', BRIDGE)
        self.assertNotIn('savedTicket.number ??', BRIDGE)
        self.assertNotIn('ticket.number ??', BRIDGE)
        self.assertIn('previous = self.ticket_catalog', MAIN)

    def test_v1016_incremental_faqs_and_ticket_number_copy(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('def copy_ticket_number(number: str, button: QPushButton)', MAIN)
        self.assertIn('Copiar somente o número {number}', MAIN)
        self.assertIn('faq_payload = json.dumps({"cache_path": str(faq_cache_path())}', MAIN)
        self.assertIn('cachedFaqUrls = [System.Collections.Generic.HashSet[string]]::new', BRIDGE)
        self.assertIn('Cache anterior não pôde ser lido', BRIDGE)
        self.assertIn('new_count = $ordered.Count', BRIDGE)
        self.assertIn('self.faq_specific_frame.setVisible(False)', MAIN)
        self.assertIn('entering_faqs = section == "FAQs"', MAIN)
        self.assertIn('if entering_faqs:', MAIN)

    def test_v1017_faq_cache_first_loading(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('self.faq_incremental_button = QPushButton("Atualizar")', MAIN)
        self.assertIn('if self.faq_catalog.get("items") and not force:', MAIN)
        self.assertIn('Cache local carregado', MAIN)
        self.assertIn('self.request_faq_catalog(False)', MAIN)
        self.assertIn('self.faq_incremental_button.setEnabled(False)', MAIN)
        self.assertIn('self.faq_incremental_button.setEnabled(True)', MAIN)

    def test_v1018_catalog_queries_use_background_runner(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('self.background_runner = PowerShellRunner(self)', MAIN)
        self.assertIn('def run_background_bridge(self, action: str', MAIN)
        self.assertIn('self.background_runner.completed.connect(self._background_execution_done)', MAIN)
        self.assertIn('self.run_background_bridge("faq_catalog"', MAIN)
        self.assertIn('self.run_background_bridge(TICKET_CATALOG', MAIN)
        self.assertIn('def _background_execution_done(self, ok: bool)', MAIN)

    def test_v1019_faq_login_matches_ticket_session(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn('section in {"Chamados", "FAQs"}', MAIN)
        self.assertIn('enter_faqs_after: bool = False', MAIN)
        self.assertIn('self.faq_capri_status = QLabel("Capri conectado" if self._capri_session_password else "Capri não conectado")', MAIN)
        self.assertIn('def set_capri_connection_state(self, connected: bool):', MAIN)
        self.assertIn('self.set_capri_connection_state(True)', MAIN)
        self.assertIn('self.apply_filter("FAQs")', MAIN)

    def test_v130_filter_theme_and_modularization(self):
        self.assertIn('self.ticket_status_combo = NoWheelComboBox()', MAIN)
        self.assertIn('#sectionSeparator', MAIN)
        self.assertIn('#settingsBrowserCombo QAbstractItemView', MAIN)
        for package in ("ui", "services", "commands", "storage", "core"):
            self.assertTrue((ROOT / package / "__init__.py").is_file())
        self.assertIn('from services.capri import build_ticket_payload', MAIN)

    def test_v130_lateral_tickets(self):
        self.assertIn('def apply_ticket_compact_layout(self, compact: bool):', MAIN)
        self.assertIn('actions.addWidget(self.ticket_map_button, 0, 1, Qt.AlignCenter)', MAIN)
        self.assertIn('self.ticket_search_button.setText("" if compact else "Pesquisar")', MAIN)

    def test_v133_login_detection_does_not_match_customer_user_field(self):
        self.assertIn("$hasUserField -and $hasPasswordField -and $hasLoginAction", BRIDGE)
        self.assertIn("CustomerUserLogin", BRIDGE)
        self.assertNotIn("$body['CustomerID'] = $resolvedLogin", BRIDGE)
        self.assertIn("A sessão persistente do Capri não pôde ser renovada", BRIDGE)

    def test_v134_authenticated_page_wins_over_embedded_login_form(self):
        logout_check = BRIDGE.index("(?:Action=|Action%3D)Logout")
        login_fields = BRIDGE.index("$hasUserField", logout_check)
        self.assertLess(logout_check, login_fields)
        self.assertIn("Autenticação aceita; sessão web do Capri confirmada", BRIDGE)

    def test_v135_atlas_repair_runs_the_four_maintenance_steps(self):
        self.assertIn('Action("08  Atlas Repair"', MAIN)
        self.assertIn('"atlas_repair": "gear"', MAIN)
        self.assertIn('if action.command == "atlas_repair"', MAIN)
        repair_start = BRIDGE.index('    "atlas_repair" {')
        repair_end = BRIDGE.index('    "logoff" {', repair_start)
        repair = BRIDGE[repair_start:repair_end]
        for command in ("Action='temp'", "Action='dns'", "Action='gpupdate'", "Action='trellix_config'"):
            self.assertIn(command, repair)
        self.assertNotIn('& $PSCommandPath', repair)
        self.assertIn("$launcherPath = Join-Path $ModuleRoot 'bridge_launcher.ps1'", repair)
        self.assertIn('powershell.exe -NoLogo -NoProfile -NonInteractive', repair)
        self.assertIn('if ($stepExitCode -ne 0)', repair)
        self.assertIn('ATLAS REPAIR CONCLUÍDO', repair)

    def test_v136_windows_executable_and_installer_contract(self):
        build = (ROOT / "build_exe.bat").read_text(encoding="utf-8-sig")
        installer = (ROOT / "installer" / "Atlas_Setup.iss").read_text(encoding="utf-8-sig")
        release = (ROOT / "CRIAR_INSTALADOR.bat").read_text(encoding="utf-8-sig")
        self.assertIn('--add-data "data;data"', build)
        self.assertIn('--version-file "installer\\version_info.txt"', build)
        self.assertIn('PrivilegesRequired=lowest', installer)
        self.assertIn('OutputBaseFilename=Atlas_Setup_v23.6', installer)
        self.assertIn('UninstallDisplayIcon={app}\\{#MyAppExeName}', installer)
        self.assertIn('release\\Atlas_Setup_v23.6.exe', release)

    def test_v137_user_search_was_removed(self):
        self.assertNotIn('Usuário Search', MAIN)
        self.assertNotIn('ticket_user_search_button', MAIN)
        self.assertNotIn('open_ticket_user_search_dialog', MAIN)
        self.assertNotIn('self.ticket_auth_button = QPushButton("Acessar Capri")', MAIN)
        self.assertIn('ticket_head.addWidget(self.ticket_capri_status, 0, Qt.AlignVCenter)', MAIN)
        self.assertIn('actions.addWidget(self.ticket_map_button, 0, 1, Qt.AlignCenter)', MAIN)

    def test_v1312_faq_progress_and_balanced_ticket_header(self):
        self.assertIn('@@FAQ_PROGRESS@@', BRIDGE)
        self.assertIn('objectName="faqMappingProgress"', MAIN)
        self.assertIn('self.faq_mapping_progress_bar = QProgressBar()', MAIN)
        self.assertIn('#faqMappingProgressBar::chunk', MAIN)
        self.assertIn('self.ticket_map_button.setMaximumWidth(330)', MAIN)

    def test_v1313_lateral_mode_cycles_both_sides_of_every_monitor(self):
        self.assertIn('for side in ("left", "right")', MAIN)
        self.assertIn('def next_lateral_slot(window):', MAIN)
        self.assertIn('def apply_lateral_slot(window, screen, side: str):', MAIN)
        self.assertIn('available.left() + left_frame if side == "left"', MAIN)
        self.assertIn('target_screen, target_side = next_lateral_slot(window)', MAIN)
        self.assertIn('target_screen, target_side = next_lateral_slot(self)', MAIN)
        self.assertIn('lateral_slot_direction(window, target_screen, target_side)', MAIN)

    def test_v1311_capri_session_is_authenticated_once_and_reused(self):
        self.assertIn('"capri_login" {', BRIDGE)
        self.assertIn('function Save-CapriWebSession', BRIDGE)
        self.assertIn('function Restore-CapriWebSession', BRIDGE)
        self.assertIn('capri_session.protected', BRIDGE)
        self.assertIn('validate_capri_session(username, password)', MAIN)
        self.assertIn('credential_write(username, password, "capri")', MAIN)
        self.assertIn('self.ticket_capri_status = QLabel(', MAIN)

    def test_v138_ticket_page_markers_prevent_false_login(self):
        self.assertIn('name=["\'\']CustomerUserLogin', BRIDGE)
        self.assertIn('name=["\'\']TicketCreateTimeStartDay', BRIDGE)

    def test_v139_mapped_months_and_extended_ticket_filters(self):
        self.assertIn('self.ticket_mapping_month_key = ""', MAIN)
        self.assertIn('self.ticket_catalog.get("mapped_months")', MAIN)
        self.assertIn('item.setText(f"✓ {name} — mapeado" if mapped else name)', MAIN)
        self.assertIn('item.setEnabled(not mapped)', MAIN)
        self.assertIn('data["mapped_months"] = sorted(mapped_months)', MAIN)
        self.assertIn('"Rejeitada", "Cancelado pelo cliente", "Fechado sem êxito"', MAIN)
        self.assertIn('5: "rejected"', MAIN)
        self.assertIn('6: "customer_cancelled"', MAIN)
        self.assertIn('7: "closed_unsuccessful"', MAIN)
        self.assertIn('def classify_ticket_state(state: object, fallback: object = "other")', MAIN)
        self.assertIn('item["state_kind"] = classify_ticket_state(', MAIN)
        self.assertIn("return 'rejected'", BRIDGE)
        self.assertIn("return 'customer_cancelled'", BRIDGE)
        self.assertIn("return 'closed_unsuccessful'", BRIDGE)
        self.assertIn('AgentTicketZoom', BRIDGE)

    def test_v1314_persistent_capri_cookie_paths_and_cache_reconciliation(self):
        self.assertIn("[uri]'https://capri.senado.leg.br/otrs/index.pl'", BRIDGE)
        self.assertIn('$uniqueCookies[$key] = $cookie', BRIDGE)
        self.assertIn('Save-CapriWebSession $webSession', BRIDGE)
        self.assertIn('$cachedNumbers.Count -gt 0 -and ![bool]$request.refresh_existing', BRIDGE)
        self.assertIn('refresh_existing=feedback_mode in {"recent", "reconcile_mapped"}', MAIN)
        self.assertIn('def ticket_created_date(value: object):', MAIN)
        self.assertIn('data["mapped_months_verified_at"]', MAIN)
        self.assertIn('self.request_tickets(True, "recent")', MAIN)


if __name__ == "__main__":
    unittest.main()
