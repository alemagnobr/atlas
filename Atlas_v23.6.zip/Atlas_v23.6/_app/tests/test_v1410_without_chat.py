from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class V1410WithoutChatTests(unittest.TestCase):
    def test_source_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_dashboard_does_not_initialize_or_show_chat(self):
        dashboard = MAIN[MAIN.index("class Dashboard(QWidget):"):]
        for marker in (
            "self.chat_service",
            "self.chat_panel",
            "self.chat_header_button",
            'section == "Chat"',
            'request_section_access("Chat")',
        ):
            self.assertNotIn(marker, dashboard)

    def test_chat_transport_module_was_removed(self):
        self.assertFalse((ROOT / "services" / "chat.py").exists())
        self.assertNotIn("from services.chat import", MAIN)


if __name__ == "__main__":
    unittest.main()
