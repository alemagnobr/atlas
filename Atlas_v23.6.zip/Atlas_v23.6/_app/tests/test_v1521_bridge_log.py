import unittest

from core.bridge_log import filter_bridge_log_chunk


class BridgeLogTests(unittest.TestCase):
    def test_large_json_is_kept_out_of_visible_log_across_chunks(self):
        chunks = (
            "[CHAMADOS] Consultando…\r\n@@TIC",
            'KETS@@{"items":[' + '"x",' * 10000,
            '"fim"]}\r\n[CHAMADOS] 25 chamados entregues.\r\n',
        )
        pending, skipping = "", False
        visible = []
        for chunk in chunks:
            text, pending, skipping = filter_bridge_log_chunk(chunk, pending, skipping)
            visible.append(text)
        self.assertEqual(
            "".join(visible),
            "[CHAMADOS] Consultando…\r\n[CHAMADOS] 25 chamados entregues.\r\n",
        )
        self.assertEqual((pending, skipping), ("", False))

    def test_partial_plain_line_remains_available(self):
        text, pending, skipping = filter_bridge_log_chunk("Etapa", "", False)
        self.assertEqual((text, pending, skipping), ("", "Etapa", False))
        self.assertEqual(filter_bridge_log_chunk(" concluída\n", pending, skipping),
                         ("Etapa concluída\n", "", False))


if __name__ == "__main__":
    unittest.main()
