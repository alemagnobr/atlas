# Offline Windows PowerShell 5.1 syntax/contract test. Never connects remotely.
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$path = Join-Path (Join-Path $root 'scripts') 'bridge.ps1'
$tokens = $null
$errors = $null
$source = [IO.File]::ReadAllText($path, [Text.Encoding]::UTF8)
[void][Management.Automation.Language.Parser]::ParseInput($source, [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | Out-String) }
foreach ($required in @('chrome://settings/clearBrowserData','edge://settings/clearBrowserData','Open-RemoteBrowserClearPage','Invoke-InteractiveTask')) {
    if (!$source.Contains($required)) { throw "Contrato ausente: $required" }
}
foreach ($forbidden in @('browser_clean_safe','browser_clean_full','Invoke-BrowserCleanup')) {
    if ($source.Contains($forbidden)) { throw "Rotina automatica antiga ainda exposta: $forbidden" }
}
Write-Output 'PASS: sintaxe e contrato de abertura das paginas internas.'
