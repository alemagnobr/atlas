from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
RUN = (ROOT / "run.bat").read_text(encoding="utf-8-sig")


class ContinuousProgressWithoutPythonPromptV1511Tests(unittest.TestCase):
    def test_source_parses_and_version_is_current(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_progress_uses_confirmed_stage_targets(self):
        self.assertIn("def set_connection_progress_stage", MAIN)
        self.assertIn('35, "Dados principais do micro carregados', MAIN)
        self.assertIn('60, "Detalhes da estação carregados', MAIN)
        self.assertIn('self.finish_station_enrichment(True, "Estação e usuário carregados.")', MAIN)
        ticket = MAIN[MAIN.index("def update_user_ticket_preview_progress"):MAIN.index("def finish_user_ticket_preview")]
        self.assertNotIn("set_connection_progress_stage", ticket)
        self.assertNotIn("set_user_query_state", ticket)

    def test_preliminary_status_does_not_close_the_progress_cycle(self):
        handler = MAIN[MAIN.index("def append_log"):MAIN.index("def _append_user_log")]
        self.assertNotIn("set_connection_query_state(False)", handler)
        self.assertIn("set_connection_progress_stage", handler)

    def test_partial_completion_stays_below_one_hundred(self):
        finish = MAIN[MAIN.index("def finish_station_enrichment"):MAIN.index("def hide_station_enrichment_progress")]
        self.assertIn("final_percent = 100 if success else min(99", finish)
        self.assertIn("self.connection_progress.setValue(final_percent)", finish)
        self.assertIn("self.station_load_partial = not success", finish)

    def test_python_install_prompt_from_v159_was_not_reintroduced(self):
        self.assertNotIn("https://www.python.org/downloads/", RUN)
        self.assertNotIn(":PYTHON_REQUIRED", RUN)
        self.assertNotIn("PresentationFramework", RUN)
        self.assertIn("Python nao foi encontrado neste computador.", RUN)


if __name__ == "__main__":
    unittest.main()
