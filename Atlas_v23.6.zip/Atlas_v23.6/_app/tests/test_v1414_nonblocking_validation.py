from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class V1414NonBlockingValidationTests(unittest.TestCase):
    def test_source_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_validation_never_runs_during_connection_or_bridge_work(self):
        self.assertIn('runner.state() != QProcess.NotRunning', MAIN)
        self.assertIn('QTimer.singleShot(60_000, self.run_due_structural_validation)', MAIN)
        self.assertNotIn('QTimer.singleShot(1800, self.run_due_structural_validation)', MAIN)

    def test_validation_runs_outside_the_qt_interface_thread(self):
        self.assertIn('threading.Thread(', MAIN)
        self.assertIn('name="atlas-structural-validation"', MAIN)
        self.assertIn('structural_validation_completed = Signal(dict)', MAIN)
        self.assertIn('self.structural_validation_completed.emit(result)', MAIN)
        self.assertIn('def finish_structural_validation(self, result: dict):', MAIN)


if __name__ == "__main__":
    unittest.main()
