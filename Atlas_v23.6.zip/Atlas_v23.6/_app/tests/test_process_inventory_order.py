import unittest

from services.process_inventory import group_processes_by_memory


class ProcessInventoryOrderTests(unittest.TestCase):
    def test_software_uses_total_memory_and_instances_use_individual_memory(self):
        groups = group_processes_by_memory([
            {"name": "chrome.exe", "pid": 10, "memory_mb": 180},
            {"name": "Excel.exe", "pid": 30, "memory_mb": 300},
            {"name": "CHROME.EXE", "pid": 11, "memory_mb": 190},
            {"name": "Teams.exe", "pid": 20, "memory_mb": 24},
        ])
        self.assertEqual([name.casefold() for name, _items, _total in groups], [
            "chrome.exe", "excel.exe", "teams.exe",
        ])
        self.assertEqual(groups[0][2], 370)
        self.assertEqual([item["pid"] for item in groups[0][1]], [11, 10])

    def test_equal_memory_uses_name_then_pid_for_stable_display(self):
        groups = group_processes_by_memory([
            {"name": "Z.exe", "pid": 4, "memory_mb": 10},
            {"name": "a.exe", "pid": 3, "memory_mb": 10},
            {"name": "A.exe", "pid": 2, "memory_mb": 10},
        ])
        self.assertEqual([name.casefold() for name, _items, _total in groups], ["a.exe", "z.exe"])
        self.assertEqual([item["pid"] for item in groups[0][1]], [2, 3])


if __name__ == "__main__":
    unittest.main()
