import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class TabsAndPwmConfirmationV1438Tests(unittest.TestCase):
    def test_sources_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_tabs_never_use_the_transient_tab_bar_width(self):
        start = MAIN.index("class BalancedTabBar(QTabBar):")
        end = MAIN.index("class QuickActionButton", start)
        tab_bar = MAIN[start:end]
        self.assertNotIn("self.width(), host.contentsRect().width()", tab_bar)
        self.assertIn("available = host.contentsRect().width()", tab_bar)
        self.assertIn("self.setMinimumHeight(38)", tab_bar)
        self.assertIn("max(1, available // count)", tab_bar)
        self.assertIn("bar.setFixedWidth(available)", tab_bar)

    def test_browser_page_itself_confirms_completed_pwm_login(self):
        self.assertIn("function Get-AtlasPwmBrowserState", BRIDGE)
        self.assertIn("'Runtime.evaluate'", BRIDGE)
        self.assertIn("document.querySelector('input[type=\"password\"]')", BRIDGE)
        self.assertIn("Authenticated=(!$hasPassword", BRIDGE)

    def test_http_and_browser_confirmation_are_both_accepted(self):
        action = BRIDGE[BRIDGE.index('"password_manager_browser_session"'):]
        self.assertIn("$browserState = Get-AtlasPwmBrowserState $debugPort", action)
        self.assertIn("$httpAuthenticated -or $browserState.Authenticated", action)
        self.assertIn("$requestArguments['UserAgent'] = $browserState.UserAgent", action)
        self.assertLess(
            action.index("Save-PasswordManagerWebSession $webSession"),
            action.index("@@PASSWORD_MANAGER_SESSION@@"),
        )


if __name__ == "__main__":
    unittest.main()
