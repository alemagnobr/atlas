import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")
VERSION_INFO = (ROOT / "installer" / "version_info.txt").read_text(encoding="utf-8-sig")


class CompactUserStationFlowV1444Tests(unittest.TestCase):
    def test_sources_and_version_metadata_are_current(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("filevers=(23, 6, 0, 0)", VERSION_INFO)
        self.assertIn("prodvers=(23, 6, 0, 0)", VERSION_INFO)

    def test_completed_lookup_becomes_red_new_query_action(self):
        self.assertIn("self.user_lookup_complete = True", MAIN)
        self.assertIn('self.user_lookup_button.setText("Nova consulta")', MAIN)
        self.assertIn('self.user_lookup_button.setObjectName("disconnectButton")', MAIN)
        self.assertIn("self.start_new_user_query()", MAIN)
        self.assertIn("self.user_control_data = {}", MAIN)
        self.assertIn("self.user_result_card.hide()", MAIN)

    def test_user_shortcut_supports_a_direct_login_lookup(self):
        self.assertIn("available = has_user or (self.connection_active", MAIN)
        self.assertIn('self.run_bridge("ad_user_info_login", "", selected_login)', MAIN)
        self.assertIn('"ad_user_info_login" {', BRIDGE)
        action = BRIDGE[BRIDGE.index('    "ad_user_info_login" {'):BRIDGE.index('    "user_control_lookup" {')]
        self.assertIn("Normalize-AtlasNetworkLogin $Value", action)
        self.assertIn("Get-AtlasAdUserData $userOnly", action)
        self.assertNotIn("Require-Computer", action)
        self.assertIn('elif action == "ad_user_info_login":', MAIN)
        self.assertIn("timeout_ms = 45_000", MAIN)

    def test_network_login_has_a_dedicated_copy_button(self):
        self.assertIn('self.user_login_copy_button.setObjectName("userLoginCopyButton")', MAIN)
        self.assertIn("QApplication.clipboard().setText(login)", MAIN)
        self.assertNotIn('network_login = f"SENADO\\\\{login}"', MAIN)
        self.assertIn('set_button_icon(self.user_login_copy_button, "copy"', MAIN)

    def test_recovery_and_user_cards_are_more_compact(self):
        self.assertIn("layout.setContentsMargins(7, 4, 7, 5)", MAIN)
        self.assertIn("self.recovery_button.setFixedSize(26, 26)", MAIN)
        self.assertIn('set_button_icon(self.recovery_button, "mail", GREEN, 13)', MAIN)
        self.assertIn('min-height: 18px; font-size: 11px', MAIN)

    def test_station_identity_is_balanced_without_the_network_login(self):
        self.assertIn('machine_caption = QLabel("MICRO")', MAIN)
        self.assertIn('self.station_identity_machine = QLabel("—")', MAIN)
        self.assertIn('machine_actions_layout.addWidget(self.station_ping_result, 0, Qt.AlignHCenter)', MAIN)
        self.assertIn('self.station_identity_user_name = QLabel("USUÁRIO\\n—")', MAIN)
        self.assertIn("identity_layout.setColumnStretch(0, 1)", MAIN)
        self.assertIn("identity_layout.setColumnStretch(1, 1)", MAIN)
        self.assertNotIn("station_identity_user_login", MAIN)

    def test_station_cards_use_reduced_spacing_and_horizontal_admin_controls(self):
        admin = MAIN[MAIN.index("class AdminStatusWidget"):MAIN.index("class ActionCard")]
        self.assertIn("indicator = QHBoxLayout()", admin)
        self.assertIn("self.lock_button.setFixedSize(26, 26)", admin)
        self.assertIn("self.status_grid.setVerticalSpacing(5 if compact_status else 7)", MAIN)
        self.assertIn('#statusCard[compact="true"] #statusValue {{ border-radius: 8px; padding: 6px 7px', MAIN)


if __name__ == "__main__":
    unittest.main()
