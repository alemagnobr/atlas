import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class LateralResponsiveLayoutV1433Tests(unittest.TestCase):
    def test_version_is_current(self):
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_lateral_layout_keeps_two_action_columns_when_they_fit(self):
        self.assertIn('narrow = width < 620', MAIN)
        self.assertIn('columns = forced_columns or (1 if width < 420 or ticket_narrow else 2)', MAIN)
        self.assertIn('compact_actions = narrow', MAIN)

    def test_user_query_breaks_into_two_rows_in_lateral_mode(self):
        start = MAIN.index('    def apply_user_control_compact_layout(self, compact: bool):')
        end = MAIN.index('    def reflow(', start)
        method = MAIN[start:end]
        self.assertIn('layout.addWidget(self.user_login_input, 0, 0, 1, 2)', method)
        self.assertIn('layout.addWidget(self.user_lookup_button, 1, 0, 1, 2)', method)
        self.assertIn("self.refresh_user_lookup_button()", method)
        self.assertIn('label = "Consultar" if self.user_control_compact else "Consultar usuário"', MAIN)

    def test_wide_user_layout_is_preserved(self):
        start = MAIN.index('    def apply_user_control_compact_layout(self, compact: bool):')
        end = MAIN.index('    def reflow(', start)
        method = MAIN[start:end]
        self.assertIn("self.refresh_user_lookup_button()", method)
        self.assertIn('layout.addWidget(self.user_login_input, 0, 0)', method)
        self.assertIn('layout.addWidget(self.user_lookup_button, 0, 1)', method)
        self.assertNotIn('layout.addWidget(self.password_manager_button', method)

    def test_cards_can_shrink_without_horizontal_overflow(self):
        self.assertIn('self.title_label.setMinimumWidth(0)', MAIN)
        self.assertIn('self.subtitle_label.setMinimumWidth(0)', MAIN)
        self.assertIn('self.actions_host.setMinimumWidth(0)', MAIN)
        self.assertIn('content.setMinimumWidth(0)', MAIN)


if __name__ == "__main__":
    unittest.main()
