import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class LoginOutlookConfirmationTests(unittest.TestCase):
    def test_login_identity_is_scoped_to_the_login_page(self):
        ast.parse(MAIN)
        self.assertIn('LOGIN_WINDOW_TITLE = "ATLAS — Assistência Técnica e Lógica de Apoio ao Senado"', MAIN)
        self.assertIn('QLabel("Assistência Técnica e Lógica de Apoio ao Senado")', MAIN)
        self.assertIn('f"Atlas  •  v{VERSION}<br>"', MAIN)
        login = MAIN[MAIN.index("    def show_login(self):"):MAIN.index("    def closeEvent(self, event):", MAIN.index("    def show_login(self):"))]
        self.assertIn("setApplicationDisplayName(LOGIN_WINDOW_TITLE)", login)
        self.assertIn("setApplicationDisplayName(APP_NAME)", MAIN[MAIN.index("        dashboard = Dashboard("):])

    def test_outlook_is_confirmed_from_remote_processes(self):
        implementation = BRIDGE[BRIDGE.index("function Close-RemoteOutlook {"):BRIDGE.index("function Get-RemoteSessionExecutables {")]
        self.assertIn("Name='OUTLOOK.EXE' OR Name='olk.exe'", implementation)
        self.assertIn('Nenhum processo encontrado.', implementation)
        self.assertIn("if (!$remaining.Count) { break }", implementation)
        self.assertIn("if ($remaining.Count) {", implementation)
        self.assertIn("-ErrorAction Stop", implementation)
        self.assertIn("Outlook fechado e confirmado", implementation)
        dispatcher = BRIDGE[BRIDGE.index('    "outlook" {'):]
        self.assertIn("Close-RemoteOutlook", dispatcher.split("}", 1)[0])
        self.assertNotIn("taskkill.exe /S $Computer /IM olk.exe", dispatcher)


if __name__ == "__main__":
    unittest.main()
