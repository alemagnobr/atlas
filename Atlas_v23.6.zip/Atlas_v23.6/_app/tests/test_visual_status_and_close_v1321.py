import ast
import pathlib
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class VisualStatusAndCloseV1321Tests(unittest.TestCase):
    def test_python_source_is_valid(self):
        ast.parse(MAIN)

    def test_printer_status_uses_rich_text_and_semantic_colors(self):
        self.assertIn("label.setTextFormat(Qt.RichText)", MAIN)
        self.assertIn("def format_printer_status(self, caption: str, value: str)", MAIN)
        self.assertIn('r"\\bOnline\\b"', MAIN)
        self.assertIn('r"\\bOffline\\b"', MAIN)
        self.assertIn('online_color = "#55E0AD" if self.dark_mode else "#00824A"', MAIN)
        self.assertIn('offline_color = "#FF8A98" if self.dark_mode else "#C73D4D"', MAIN)
        self.assertIn("html.escape(str(value))", MAIN)
        self.assertIn('label.setText(self.format_printer_status("", value))', MAIN)

    def test_bridge_reports_online_or_offline(self):
        helper_start = BRIDGE.index("function Get-PrinterReachability")
        helper_end = BRIDGE.index("function Get-AllRemotePrinters", helper_start)
        helper = BRIDGE[helper_start:helper_end]
        self.assertIn("return 'Online'", helper)
        self.assertIn("return 'Offline'", helper)
        self.assertNotIn("Sem resposta", helper)

    def test_closing_application_automatically_attempts_capri_logout(self):
        start = MAIN.index("    def closeEvent(self, event):")
        end = MAIN.index("    def update_login_arrow_direction(self):", start)
        method = MAIN[start:end]
        self.assertIn("terminate_capri_session()", method)
        self.assertIn("event.accept()", method)
        self.assertIn("event.ignore()", method)
        self.assertLess(method.index("terminate_capri_session()"), method.index("event.accept()", method.index("terminate_capri_session()")))


if __name__ == "__main__":
    unittest.main()
