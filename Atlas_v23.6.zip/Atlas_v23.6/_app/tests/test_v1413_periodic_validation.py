from datetime import datetime, timedelta, timezone
from pathlib import Path
import ast
import tempfile
import unittest

from services.structural_validation import validation_is_due, validate_installation


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
VALIDATOR = (ROOT / "services" / "structural_validation.py").read_text(encoding="utf-8-sig")
TRANSITIONS = (ROOT / "ui" / "transitions.py").read_text(encoding="utf-8-sig")


class V1413PeriodicValidationTests(unittest.TestCase):
    def test_sources_and_version_are_valid(self):
        ast.parse(MAIN)
        ast.parse(VALIDATOR)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_periodic_validation_is_configurable_and_non_networked(self):
        self.assertIn('("weekly", "Semanalmente (recomendado)", 7)', VALIDATOR)
        self.assertIn('validation_combo.setObjectName("settingsValidationCombo")', MAIN)
        self.assertIn('validate_now = QPushButton("Validar agora")', MAIN)
        self.assertNotIn("socket", VALIDATOR)
        self.assertNotIn("subprocess", VALIDATOR)

    def test_due_logic_respects_interval(self):
        now = datetime.now(timezone.utc)
        recent = {"interval": "weekly", "last_checked": (now - timedelta(days=2)).isoformat()}
        old = {"interval": "weekly", "last_checked": (now - timedelta(days=8)).isoformat()}
        self.assertFalse(validation_is_due(recent, now))
        self.assertTrue(validation_is_due(old, now))
        self.assertFalse(validation_is_due({"interval": "disabled"}, now))

    def test_validator_reports_missing_files_without_crashing(self):
        with tempfile.TemporaryDirectory() as directory:
            result = validate_installation(Path(directory), "14.24")
        self.assertEqual("attention", result["last_status"])
        self.assertTrue(result["issues"])

    def test_theme_motion_is_continuous_and_subtle(self):
        self.assertIn("dark_progress = max(0.0", MAIN)
        self.assertIn("def mix(light: str, dark: str", MAIN)
        self.assertNotIn("_spinner_angle", MAIN)
        self.assertIn("fade.setEasingCurve(QEasingCurve.Type.InOutCubic)", TRANSITIONS)
        self.assertIn("duration_ms: int = 420", TRANSITIONS)
        self.assertNotIn('setText("Alterando tema…")', MAIN)


if __name__ == "__main__":
    unittest.main()
