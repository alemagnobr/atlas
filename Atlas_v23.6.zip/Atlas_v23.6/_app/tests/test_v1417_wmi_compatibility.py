from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class V1417WmiCompatibilityTests(unittest.TestCase):
    def test_source_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_wmi_uses_the_stable_provider_with_cancelable_jobs(self):
        self.assertIn('$job = Get-WmiObject @parameters', BRIDGE)
        self.assertIn('AsJob = $true', BRIDGE)
        self.assertIn('Wait-Job -Job $job -Timeout $TimeoutSeconds', BRIDGE)
        self.assertIn('Stop-Job -Job $job', BRIDGE)
        self.assertIn('Remove-Job -Job $job -Force', BRIDGE)
        self.assertNotIn('System.Management.ManagementScope', BRIDGE)

    def test_partial_status_never_leaves_loading_placeholders(self):
        self.assertIn('if not ok and self.connection_active and self.last_status_data:', MAIN)
        self.assertIn('settled[key] = "Não foi possível consultar no prazo"', MAIN)
        self.assertIn('json.dumps(settled, ensure_ascii=False)', MAIN)


if __name__ == "__main__":
    unittest.main()
