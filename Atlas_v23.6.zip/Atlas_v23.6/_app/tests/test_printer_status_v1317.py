import pathlib
import unittest


ROOT = pathlib.Path(__file__).resolve().parents[1]
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class PrinterStatusV1317Tests(unittest.TestCase):
    def test_reachability_uses_bounded_ping_and_expected_labels(self):
        self.assertIn("function Get-PrinterReachability", BRIDGE)
        self.assertIn("$ping.Send($hostName, 800)", BRIDGE)
        self.assertIn("return 'Online'", BRIDGE)
        self.assertIn("return 'Offline'", BRIDGE)

    def test_display_includes_status_and_preserves_default_marker(self):
        self.assertIn("Get-PrinterReachability -PrinterName $_", BRIDGE)
        self.assertIn('"$_ — $reachability$defaultSuffix"', BRIDGE)
        self.assertIn('" (Padrão)"', BRIDGE)

    def test_raw_printer_names_remain_available_to_quick_actions(self):
        self.assertIn(
            'printer_names = if ($printerNames.Count) { $printerNames -join ", " } else { "Nenhuma" }',
            BRIDGE,
        )
        self.assertIn(
            'printers = if ($displayPrinters.Count) { $displayPrinters -join ", " } else { "Nenhuma" }',
            BRIDGE,
        )


if __name__ == "__main__":
    unittest.main()
