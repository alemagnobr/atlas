import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class CustomerAndTitleMatchingV1450Tests(unittest.TestCase):
    def test_preview_requires_exact_customer_or_full_name_in_title(self):
        ast.parse(MAIN)
        ticket_catalog = BRIDGE[BRIDGE.index('    "ticket_catalog" {'):]
        self.assertIn("$targetName = Get-NormalizedPersonName $resolvedDisplayName", ticket_catalog)
        self.assertIn("(Get-NormalizedPersonName $customer) -eq $targetName", ticket_catalog)
        self.assertIn("(Get-NormalizedPersonName $title).Contains($targetName)", ticket_catalog)
        self.assertIn("if (!$targetName -or (!$customerMatches -and !$titleMatches -and !$rowNameMatches)) { continue }", ticket_catalog)

    def test_full_anchor_title_is_used_for_matching_when_available(self):
        ticket_catalog = BRIDGE[BRIDGE.index('    "ticket_catalog" {'):]
        self.assertIn("$anchorTitle = [regex]::Match($zoom.Groups['attrs'].Value", ticket_catalog)
        self.assertIn("if ($anchorTitle.Success) { $title = Get-TicketPlainText", ticket_catalog)
        self.assertIn("if (!$anchorTitle.Success -and $titleColumn", ticket_catalog)

    def test_preview_metadata_explains_both_inclusion_conditions(self):
        self.assertIn("Nome do usuário cliente igual ao AD ou título contendo o nome completo", BRIDGE)


if __name__ == "__main__":
    unittest.main()
