"""Reconciliar estados antigos sem alterar chamados sem confirmação do Capri."""

import json
import unittest

from services.capri import build_ticket_payload
from services.ticket_status_refresh import apply_state_updates, open_ticket_numbers


def classify(state, fallback="other"):
    text = str(state or "").lower()
    if "pendente" in text:
        return "pending"
    if "aberto" in text:
        return "open"
    if "fechado com êxito" in text:
        return "closed_success"
    return fallback


class TicketStateRefreshTests(unittest.TestCase):
    def test_only_open_or_pending_numbers_are_requested(self):
        items = [
            {"number": "2026010100000001", "state": "Pendente"},
            {"number": "2026010200000002", "state": "Aberto"},
            {"number": "2026010100000001", "state": "Pendente"},
            {"number": "2026010300000003", "state": "Fechado com êxito"},
        ]
        numbers = open_ticket_numbers(items, classify)
        self.assertEqual(numbers, ["2026010100000001", "2026010200000002"])
        payload = json.loads(build_ticket_payload(
            scope="operator", display_name="Analista", operator_login="analista",
            date_from="2026-10-04", date_to="2026-10-05", cache_path="cache.json",
            refresh_existing=True, recheck_numbers=numbers,
        ))
        self.assertEqual(payload["recheck_numbers"], numbers)

    def test_confirmed_transition_updates_only_the_matching_cached_ticket(self):
        tickets = {
            "2026010100000001": {"number": "2026010100000001", "state": "Pendente", "state_kind": "pending"},
            "2026010200000002": {"number": "2026010200000002", "state": "Aberto", "state_kind": "open"},
        }
        count, changes = apply_state_updates(tickets, [
            {"number": "2026010100000001", "state": "Fechado com êxito"},
            {"number": "2026010200000002", "state": "Estado desconhecido"},
            {"number": "2026010300000003", "state": "Fechado com êxito"},
        ], classify, "2026-10-05T11:55:00")
        self.assertEqual((count, changes), (1, [("2026010100000001", "Pendente", "Fechado com êxito")]))
        self.assertEqual(tickets["2026010100000001"]["state_kind"], "closed_success")
        self.assertTrue(tickets["2026010100000001"]["closed"])
        self.assertEqual(tickets["2026010200000002"]["state"], "Aberto")


if __name__ == "__main__":
    unittest.main()
