"""Regressões das quatro alterações da versão 17 sem exigir PySide6 no CI."""

import ast
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8")
REMOTE_MESSAGE = (ROOT / "scripts" / "remote_message.ps1").read_text(encoding="utf-8")


class Version17WorkflowTests(unittest.TestCase):
    def test_licenses_match_all_ad_codes_and_do_not_guess_unknown_groups(self):
        tree = ast.parse(MAIN)
        assignment = next(node for node in tree.body if isinstance(node, ast.Assign)
                          and any(isinstance(t, ast.Name) and t.id == "AD_LICENSE_DESCRIPTIONS" for t in node.targets))
        mapping = ast.literal_eval(assignment.value)
        self.assertEqual(len(mapping), 17)  # Inclui Lic-ADP1 (MFA) e WEB_Libera_Chat.
        for code in (
            "lic-o365-e1", "lic-o365-e1-adp1", "lic-m365-apps-contrato-ct12-2025",
            "lic-m365-f1", "lic-exchk", "lic-m365-f1-exchk", "lic-ems-e3-contrato-ct12-2025",
            "lic-visio-plan2-contrato-ct12-2025", "lic-project-plan3-contrato-ct12-2025",
            "lic-visualstudio-contrato-ct12-2025", "lic-copilot-contrato-ct12-2025",
            "lic-m365-lic-e5-security-e1", "lic-o365-e3-adp1",
            "lic-defender-office-plan1-contrato-ct12-2025", "lic-fabric-free", "lic-adp1",
            "web_libera_chat",
        ):
            self.assertTrue(mapping[code])
        fn = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "ad_license_description")
        namespace = {"AD_LICENSE_DESCRIPTIONS": mapping}
        exec(compile(ast.Module(body=[fn], type_ignores=[]), "<license test>", "exec"), namespace)
        self.assertIn("Power BI", namespace["ad_license_description"]("Lic-Fabric-free"))
        self.assertEqual("Acesso ao WhatsApp Web", namespace["ad_license_description"]("WEB_Libera_Chat"))
        self.assertEqual("", namespace["ad_license_description"]("Grupo comum"))
        self.assertIn("sem descrição", namespace["ad_license_description"]("Lic-Nova"))
        self.assertIn('LicenseInfoCard(str(item), description)', MAIN)

    def test_tickets_do_not_hold_ad_or_station_progress(self):
        start = MAIN.index("    def start_user_ticket_preview(")
        end = MAIN.index("    def finish_station_enrichment(", start)
        ticket_flow = MAIN[start:end]
        for method in ("set_user_query_state(", "finish_station_enrichment(", "set_connection_progress_stage("):
            self.assertNotIn(method, ticket_flow)
        ad = MAIN[MAIN.index('if action == "user_control_lookup" and ok:'):]
        self.assertLess(ad.index('self.finish_station_enrichment(True, "Estação e usuário carregados.")'),
                        ad.index('self.start_user_ticket_preview(u, n)'))
        self.assertIn("self.user_ticket_preview_percent", MAIN)

    def test_remote_evaluation_has_checked_session_clickable_actions_and_timer(self):
        remote = REMOTE_MESSAGE
        self.assertIn("$account -ine [string]$payload.expected_user", remote)
        self.assertIn("Start-Process 'https://outlook.office.com/mail/'", remote)
        self.assertIn("Start-Process 'outlook.exe'", remote)
        self.assertIn("`$duration = 3", remote)
        self.assertIn("`$duration = 10", remote)
        self.assertIn("-InteractiveUser $sessionUser", remote)
        self.assertIn('"user_evaluation_show" {', BRIDGE)
        self.assertIn("self.evaluation_button.clicked.connect(self.send_remote_evaluation)", MAIN)

    def test_all_remote_messages_use_the_same_gui_without_persistent_console(self):
        self.assertIn("Invoke-AtlasRemoteMessage -Kind 'evaluation'", BRIDGE)
        self.assertIn("Invoke-AtlasRemoteMessage -Kind 'orientation'", BRIDGE)
        self.assertIn("-NoProfile -STA -WindowStyle Hidden -EncodedCommand $encoded", REMOTE_MESSAGE)
        self.assertIn("GetConsoleWindow()", REMOTE_MESSAGE)
        self.assertNotIn('wscript.exe', REMOTE_MESSAGE)
        self.assertNotIn("$remoteCmd = 'cmd.exe'", BRIDGE)
        self.assertIn("if ([string]`$data.title -eq 'Orientação livre')", REMOTE_MESSAGE)
        self.assertIn('"display_name": str(self.last_status_data.get("user_ad_name")', MAIN)

    def test_printer_popup_owns_progress_and_refreshes_both_summaries(self):
        action = MAIN[MAIN.index("    def execute_action("):MAIN.index("    def run_bridge(", MAIN.index("    def execute_action("))]
        self.assertIn("started and not printer_progress", action)
        self.assertIn('self.printer_refresh_scope = "both"', action)
        self.assertNotIn("self.refresh_printer_status(\"both\")", action)
        completed = MAIN[MAIN.index("    def execution_done("):MAIN.index("    def set_action_loading(", MAIN.index("    def execution_done("))]
        self.assertIn("self.printer_operation_refresh_pending = True", completed)
        self.assertIn("completion_confirmed=refreshed", completed)


if __name__ == "__main__":
    unittest.main()
