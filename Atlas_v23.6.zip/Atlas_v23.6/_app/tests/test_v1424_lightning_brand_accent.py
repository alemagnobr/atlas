from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
VERSION_INFO = (ROOT / "installer" / "version_info.txt").read_text(encoding="utf-8")


class LightningBrandAccentTests(unittest.TestCase):
    def test_version_is_1424(self):
        self.assertIn('VERSION = "23.6"', MAIN)
        self.assertIn("filevers=(23, 6, 0, 0)", VERSION_INFO)

    def test_lightning_uses_the_requested_pause_cycle(self):
        self.assertIn("class LightningAccent(QWidget):", MAIN)
        self.assertIn("PAUSE_SEQUENCE = (2000, 5000, 3000, 2000, 4000, 5000)", MAIN)
        self.assertIn("self._pause_timer.setSingleShot(True)", MAIN)

    def test_lightning_descends_then_fades(self):
        self.assertIn("reveal = phase / 0.42", MAIN)
        self.assertIn("self.height() * reveal + 3", MAIN)
        self.assertIn("intensity = max(0.0, (1.0 - phase) / 0.36)", MAIN)
        self.assertIn("self._draw_glowing_path", MAIN)

    def test_lightning_forms_the_final_s_and_follows_theme(self):
        self.assertIn("class AtlasSAccent(LightningAccent):", MAIN)
        self.assertIn("self.brand_lightning = AtlasSAccent", MAIN)
        self.assertIn("brand_word.addWidget(self.brand_lightning, 0, Qt.AlignVCenter)", MAIN)
        self.assertIn("self.brand_lightning.set_dark_mode(self.dark_mode)", MAIN)
        self.assertIn('brand_text = QLabel("ATLA")', MAIN)
        self.assertIn("self.hero_lightning = AtlasSAccent(True, hero, large=True)", MAIN)
        self.assertIn('self._glyph.addText(0, 0, font, "S")', MAIN)
        self.assertIn('font = QFont("Georgia")', MAIN)

    def test_s_stays_animated_only_while_visible(self):
        self.assertIn("self._flash_animation.setLoopCount(-1)", MAIN)
        self.assertIn("def showEvent(self, event):", MAIN)
        self.assertIn("def hideEvent(self, event):", MAIN)
        self.assertIn("# Descargas curtas, assimétricas", MAIN)
        self.assertIn("(self.width() - 12) / bounds.width()", MAIN)
        self.assertIn("wave ** 5", MAIN)
        self.assertNotIn('font.setBold(True)\n        font.setPixelSize(92)', MAIN)
        self.assertNotIn("spark = glyph.pointAtPercent(phase)", MAIN)

    def test_lightning_does_not_animate_while_hidden(self):
        self.assertIn("if not self.isVisible() or not self.window().isVisible():", MAIN)


if __name__ == "__main__":
    unittest.main()
