from pathlib import Path
import ast
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")


class CopyableUserInformationV1514Tests(unittest.TestCase):
    def test_source_parses_and_version_is_current(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_information_surface_copies_and_gives_feedback(self):
        surface = MAIN[MAIN.index("class CopyableInfoFrame"):MAIN.index("class UserDataFieldCard")]
        self.assertIn("QApplication.clipboard().setText(self._copy_value)", surface)
        self.assertIn('QToolTip.showText(position, "Informação copiada"', surface)
        self.assertIn("QEvent.Type.MouseButtonRelease", surface)

    def test_selected_user_cards_copy_title_and_displayed_value(self):
        card = MAIN[MAIN.index("class UserDataFieldCard"):MAIN.index("class StationDataFieldCard")]
        self.assertIn("class UserDataFieldCard(CopyableInfoFrame)", card)
        self.assertIn('self.set_copy_value(f"{self.caption}: {visible}")', card)
        self.assertIn("self.register_copy_surface(self.value_label)", card)
        self.assertIn('card = UserDataFieldCard(caption)', MAIN)

    def test_name_copies_title_and_value_while_login_keeps_its_own_button(self):
        self.assertIn('self.user_identity_name_host = CopyableInfoFrame(objectName="userIdentityItem")', MAIN)
        self.assertIn('self.user_identity_login_host = CopyableInfoFrame(objectName="userIdentityItem")', MAIN)
        self.assertIn('self.user_identity_name_host.set_copy_value(f"Nome completo: {display_name}")', MAIN)
        self.assertIn("self.user_identity_login_host.set_copy_value(identity_login_value)", MAIN)
        self.assertNotIn("self.user_identity_name_host.set_copy_enabled(False)", MAIN)
        self.assertIn("self.user_identity_login_host.set_copy_enabled(False)", MAIN)

    def test_existing_action_buttons_keep_their_connections(self):
        self.assertIn("self.quick_ad_button.clicked.connect(self.quick_ad_user_info)", MAIN)
        self.assertIn("self.user_login_copy_button.clicked.connect(self.copy_user_login)", MAIN)
        self.assertIn("self.recovery_button.clicked.connect(self._activate)", MAIN)
        self.assertIn("self.pwm_button.clicked.connect(self.pwm_requested.emit)", MAIN)
        self.assertIn("self.user_tickets_card.activated.connect(self.open_user_ticket_preview)", MAIN)

    def test_password_state_is_copyable_without_replacing_action_buttons(self):
        card = MAIN[MAIN.index("class PasswordExpiryStatusCard"):MAIN.index("class AdminStatusWidget")]
        self.assertIn("class PasswordExpiryStatusCard(CopyableInfoFrame)", card)
        self.assertIn("self.action.clicked.connect(self.copy_information)", card)
        self.assertIn('self.set_copy_value(f"Senha expirada: {text}")', card)


if __name__ == "__main__":
    unittest.main()
