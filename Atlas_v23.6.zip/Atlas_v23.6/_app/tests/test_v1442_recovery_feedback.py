import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8-sig")


class RecoveryFeedbackV1442Tests(unittest.TestCase):
    def test_sources_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_server_acceptance_is_distinct_from_textual_confirmation(self):
        self.assertIn("$statusCode -ge 200 -and $statusCode -lt 400", BRIDGE)
        self.assertIn("confirmed = [bool]$successText.Count", BRIDGE)
        self.assertIn("$explicitFailure.Count", BRIDGE)
        self.assertIn("Solicitação aceita pelo servidor sem confirmação textual", BRIDGE)

    def test_explicit_rejection_still_fails_safely(self):
        for marker in (
            "não|nao", "localizado|encontrado", "recusada|bloqueada",
            "limite", "dados\\s+inv",
        ):
            self.assertIn(marker, BRIDGE)
        self.assertIn("Nenhuma repetição automática foi realizada", BRIDGE)

    def test_masked_destination_reaches_the_success_feedback(self):
        self.assertIn('send_payload["masked_email"] = destination', MAIN)
        self.assertIn('payload.get("masked_email")', MAIN)
        self.assertIn("E-mail de redefinição encaminhado com sucesso para", MAIN)
        self.assertIn("não exibiu uma confirmação textual", MAIN)


if __name__ == "__main__":
    unittest.main()
