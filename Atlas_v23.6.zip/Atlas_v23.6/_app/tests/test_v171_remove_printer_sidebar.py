"""Exclusão de impressora e atalhos laterais de SCCM, AD e Admin local."""

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8")
BRIDGE = (ROOT / "scripts" / "bridge.ps1").read_text(encoding="utf-8")


class RemovePrinterAndSidebarTests(unittest.TestCase):
    def test_remove_printer_card_sits_beside_install_printer(self):
        self.assertIn('"remove_printer", "Suporte remoto", destructive=True', MAIN)
        self.assertIn('"install_printer", "remove_printer",\n', MAIN)
        self.assertIn('action.command in {"install_printer", "remove_printer", "test_print", "set_default_printer"}', MAIN)
        self.assertIn('completed_action in {"install_printer", "remove_printer", "set_default_printer", "test_print"}', MAIN)

    def test_bridge_removes_printer_in_session_and_globally(self):
        remove = BRIDGE[BRIDGE.index('"remove_printer" {'):BRIDGE.index('"remove_hp_driver" {')]
        self.assertIn("PrintUIEntry /dn /n", remove)
        self.assertIn("PrintUIEntry /gd /n", remove)
        self.assertIn("Require-Computer", remove)

    def test_sidebar_has_sccm_ad_and_admin_shortcuts(self):
        for button, column in (("self.quick_sccm_button", 0), ("self.quick_ad_user_button", 1), ("self.quick_admin_button", 2)):
            with self.subTest(button=button):
                self.assertIn(f"quick_grid.addWidget({button}, 2, {column})", MAIN)
        self.assertIn("self.quick_sccm_button.clicked.connect(self.quick_sidebar_sccm)", MAIN)
        self.assertIn("self.quick_ad_user_button.clicked.connect(self.quick_sidebar_ad_user_info)", MAIN)
        self.assertIn("self.quick_admin_button.clicked.connect(self.quick_sidebar_admin)", MAIN)
        self.assertIn("self.quick_admin_button.set_icon_state(icon", MAIN)


if __name__ == "__main__":
    unittest.main()
