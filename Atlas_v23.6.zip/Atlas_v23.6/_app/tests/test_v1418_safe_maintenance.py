from datetime import datetime, timedelta, timezone
from pathlib import Path
import ast
import os
import tempfile
import unittest

from services.structural_validation import cleanup_regenerable_files, default_validation_settings


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "main.py").read_text(encoding="utf-8-sig")
RUN = (ROOT / "run.bat").read_text(encoding="utf-8-sig")


class V1418SafeMaintenanceTests(unittest.TestCase):
    def test_sources_and_version_are_valid(self):
        ast.parse(MAIN)
        self.assertIn('VERSION = "23.6"', MAIN)

    def test_cleanup_is_enabled_but_limited_to_abandoned_tmp_files(self):
        self.assertTrue(default_validation_settings()["safe_cleanup"])
        now = datetime.now(timezone.utc)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            stale = root / "appearance.tmp"
            recent = root / "ticket_catalog.tmp"
            protected = root / "ticket_catalog.json"
            stale.write_bytes(b"old temporary")
            recent.write_bytes(b"active temporary")
            protected.write_bytes(b'{"items": []}')
            old = (now - timedelta(days=2)).timestamp()
            os.utime(stale, (old, old))

            result = cleanup_regenerable_files(root, now=now)

            self.assertEqual(1, result["cleanup_files"])
            self.assertFalse(stale.exists())
            self.assertTrue(recent.exists())
            self.assertTrue(protected.exists())

    def test_settings_explain_protected_functional_data(self):
        self.assertIn('cleanup_checkbox = QCheckBox("Remover resíduos regeneráveis do Atlas")', MAIN)
        for protected in ("FAQs", "chamados", "preferências", "credenciais", "sessões", "scripts", "versões anteriores"):
            self.assertIn(protected, MAIN)

    def test_runtime_caches_are_bounded_without_deleting_catalogs(self):
        self.assertIn("ICON_CACHE_LIMIT = 768", MAIN)
        self.assertIn("def compact_transient_caches(self) -> int:", MAIN)
        self.assertIn("self.disk_profiles_cache", MAIN)
        self.assertNotIn("faq_cache_path().unlink", MAIN[MAIN.index("def compact_transient_caches"):MAIN.index("def build_ui", MAIN.index("def compact_transient_caches"))])

    def test_runtime_copy_excludes_development_only_directories(self):
        for name in ('"tests"', '"docs"', '"tools"', '"installer"'):
            self.assertIn(name, RUN)
        self.assertIn("for %%D in (assets commands core data scripts services storage ui)", RUN)

    def test_periodic_maintenance_remains_off_the_ui_thread_and_remote_flow(self):
        self.assertIn('name="atlas-structural-validation"', MAIN)
        self.assertIn("runner.state() != QProcess.NotRunning", MAIN)
        self.assertIn("cleanup_regenerable_files(faq_cache_path().parent)", MAIN)


if __name__ == "__main__":
    unittest.main()
