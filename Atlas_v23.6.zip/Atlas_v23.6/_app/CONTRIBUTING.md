# Como contribuir

## Fluxo recomendado

1. Abra uma issue descrevendo o problema ou melhoria.
2. Crie uma branch a partir de `main`:

   ```bash
   git switch main
   git pull
   git switch -c tipo/resumo-da-alteracao
   ```

3. Faça uma alteração por vez e preserve as rotinas existentes.
4. Execute as verificações locais.
5. Registre a mudança no `CHANGELOG.md`.
6. Abra um Pull Request para revisão.

Mantenedores do projeto: **[@joaocerq-me](https://github.com/joaocerq-me)** e **[@alemagnobr](https://github.com/alemagnobr)**.

Prefixos sugeridos: `feature/`, `fix/`, `docs/`, `refactor/` e `security/`.

## Verificações obrigatórias

```bash
python -m py_compile main.py fallback.py
python -m pip install -r requirements.txt
```

No Windows, valide também a abertura pelo `run.bat`, login INS, modo lateral, conexão com estação de homologação, rotina alterada, UTF-8 do bridge e integridade do botão **Legada**.

## Regras de segurança

- nunca versionar senha, token, certificado privado ou arquivo `.env`;
- não incluir dados reais de usuários ou estações em testes e screenshots;
- não remover confirmações de ações destrutivas;
- alterações em PowerShell devem preservar tratamento de erro e saída UTF-8;
- ações administrativas exigem revisão de outro mantenedor.

## Revisão e administração

- alterações em `main.py` devem preservar a interface e o modo lateral;
- alterações em `scripts/` devem ser testadas em homologação e revisadas por outro mantenedor;
- nenhuma Pull Request deve conter dados reais de usuário, estação, rede ou credenciais;
- correções urgentes também devem ser registradas no histórico de alterações.

## Padrão de commit

```text
feat: exibe consumo individual dos perfis
fix: recupera drives mapeados pelo Win32_MappedLogicalDisk
docs: adiciona guia de instalação no VS Code
```
